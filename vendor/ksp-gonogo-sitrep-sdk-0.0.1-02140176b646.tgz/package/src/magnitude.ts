/**
 * Taking a quantity's magnitude, at the places where a caller genuinely has to.
 *
 * ## When this is right
 *
 * Code that draws or computes. SVG attributes take numbers; a Kepler solver, a
 * median filter and a rolling window all take numbers; a model that predates
 * the unit system and is shared with code that does the above takes numbers.
 * Those boundaries are real, and one funnel through them is better than
 * `.magnitude` sprinkled at every use.
 *
 * ## When this is WRONG
 *
 * Showing the value. `<Unit value={x} />` is how a quantity is displayed, and
 * reaching for a magnitude to build a string is how a dashboard ends up with
 * six spellings of "m/s" and one readout quietly showing kilometres under a
 * metres label. If the number is going on screen, this is not the function you
 * want.
 *
 * The narrow `{ magnitude: number }` parameter rather than `Value<Unit>` is
 * deliberate: it accepts a plain number too, which is what the app's own
 * derived models still carry, so a caller does not have to know which side of
 * the migration a given field is on. It is REQUIRED rather than optional for a
 * reason worth keeping: with `magnitude?: number` any object at all satisfies
 * the parameter, and a diverged copy that made it optional is how a test came
 * to hand a widget a `Reading` where a payload belonged and typecheck.
 *
 * ## Why it lives HERE
 *
 * With `Value`, which is what it unwraps, so there is one unwrap and one rule
 * for absence.
 *
 * `@ksp-gonogo/ui-kit` re-exports all three names.
 *
 * @category Units and values
 */
export type Quantityish = { magnitude: number } | number | null | undefined;

/**
 * The magnitude, or `null` for anything absent or non-finite.
 *
 * @category Units and values
 */
export function magnitudeOf(v: Quantityish): number | null {
  const n = typeof v === "object" && v !== null ? v.magnitude : v;
  return n === null || n === undefined || !Number.isFinite(n) ? null : n;
}

/**
 * The magnitude, or `fallback` when there is nothing usable to take.
 *
 * @category Units and values
 */
export function magnitudeOr(v: Quantityish, fallback: number): number {
  return magnitudeOf(v) ?? fallback;
}

/**
 * A value read off an untyped wire bag AS a quantity, and `undefined` for
 * anything that is not one.
 *
 * A flattened payload can hold a string where a magnitude was expected, and
 * naming the field back as a `Quantityish` tells `magnitudeOf` a shape the
 * value never had. This checks instead, so a renamed or retyped field reads as
 * absent rather than as a number nobody sent.
 *
 * @category Units and values
 */
export function asQuantityish(value: unknown): Quantityish {
  if (value === null || value === undefined || typeof value === "number") {
    return value;
  }
  if (typeof value !== "object") return undefined;
  const magnitude: unknown = Reflect.get(value, "magnitude");
  return typeof magnitude === "number"
    ? (value as { magnitude: number })
    : undefined;
}
