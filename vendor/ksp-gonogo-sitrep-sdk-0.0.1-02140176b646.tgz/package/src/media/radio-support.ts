/**
 * Capability detection for the WebCodecs Opus path the push-to-talk radio
 * rides.
 *
 * The shape mirrors `isFrameDelaySupported()` next door: a synchronous feature
 * detect a caller runs before building anything, so an unsupported browser gets
 * a reported fact instead of a broken pipeline. **A presence check alone is
 * wrong in both directions.** `AudioEncoder`/`AudioDecoder` need a secure
 * context, and on a plain-http origin chromium and firefox leave both
 * constructors `undefined` while webkit exposes them and fails later, at
 * `getUserMedia`.
 *
 * `radioSupportStatus()` therefore asks about the context FIRST and names
 * an insecure origin as its own outcome, so a caller can say "this page is
 * not a secure origin" rather than the falsehood "your browser has no
 * codec". That distinction is operator-facing: the dev server binds the LAN
 * (`packages/app/vite.config.ts`, `server: { host: true }`), so a station
 * opened at `http://<lan-ip>:5173` lands in exactly this state every time.
 * Production over https, and `localhost` dev, are both secure and fine.
 *
 * `tests/playwright/radio-capability.spec.ts` is the cross-engine ratchet
 * over the same facts, including a live encode/decode round trip.
 */

/**
 * The WebCodecs constructors the radio pipeline needs, named once so the
 * runtime detect and the Playwright probe cannot drift apart.
 *
 * `AudioData` and `EncodedAudioChunk` are present even on an insecure
 * origin in all three engines, so they never discriminate; the encoder and
 * decoder are the two that do. All four are listed because all four are
 * used.
 *
 * @category Radio
 */
export const RADIO_REQUIRED_GLOBALS = [
  "AudioEncoder",
  "AudioDecoder",
  "AudioData",
  "EncodedAudioChunk",
] as const;

/**
 * The encoder configuration the radio transmits at, and the one the probe
 * measures. 20 ms of mono 48 kHz per chunk at a voice-radio bitrate;
 * `bitrate` is a hint that firefox overshoots, so size buffers and budgets
 * against the measured rate rather than this number.
 *
 * @category Radio
 */
export const RADIO_ENCODER_CONFIG = {
  codec: "opus",
  sampleRate: 48_000,
  numberOfChannels: 1,
  bitrate: 12_000,
} as const;

/** The decoder half of {@link RADIO_ENCODER_CONFIG}: no bitrate, since a
 *  decoder is told what the stream is rather than what to aim for.
 *
 * @category Radio
 */
export const RADIO_DECODER_CONFIG = {
  codec: "opus",
  sampleRate: 48_000,
  numberOfChannels: 1,
} as const;

/** Samples per encoded chunk at {@link RADIO_ENCODER_CONFIG}'s sample
 *  rate: 20 ms, the grid Opus and the design's wire frame both use.
 *
 * @category Radio
 */
export const RADIO_CHUNK_FRAMES = 960;

/** Why the radio cannot run here. `insecure-context` is recoverable by the
 *  operator (reach the page over https or via localhost); `no-codec` is
 *  not.
 *
 * @category Radio
 */
export type RadioUnsupportedReason = "insecure-context" | "no-codec";

/**
 * Whether this browser can carry radio audio, and why not when it cannot.
 *
 * @category Radio
 */
export type RadioSupport =
  | { supported: true }
  | {
      supported: false;
      reason: RadioUnsupportedReason;
      /** The names from {@link RADIO_REQUIRED_GLOBALS} that were absent.
       *  Empty for `insecure-context`, which is diagnosed before the
       *  globals are consulted at all. */
      missing: readonly string[];
    };

/**
 * The full verdict, with the reason attached. Prefer this over
 * {@link isRadioSupported} anywhere the result is shown to an operator: a
 * page served over plain http wants "not a secure origin", not "no codec".
 *
 * @category Radio
 */
export function radioSupportStatus(): RadioSupport {
  // `=== true` rather than a truthiness test: a host that is not a browser
  // (node, a test runner) does not define `isSecureContext` at all, and
  // anything other than the boolean a browser sets is a host we do not
  // recognise. Guessing in its favour is how a probe goes green somewhere
  // the microphone is refused.
  if (
    !("isSecureContext" in globalThis) ||
    globalThis.isSecureContext !== true
  ) {
    return { supported: false, reason: "insecure-context", missing: [] };
  }

  const missing = RADIO_REQUIRED_GLOBALS.filter(
    (name) => !(name in globalThis),
  );
  if (missing.length > 0) {
    return { supported: false, reason: "no-codec", missing };
  }
  return { supported: true };
}

/** True when this page can run the radio's encode/decode path at all: a
 *  secure context exposing every WebCodecs constructor it needs. The
 *  boolean twin of {@link radioSupportStatus}, for callers that only branch
 *  on it.
 *
 * @category Radio
 */
export function isRadioSupported(): boolean {
  return radioSupportStatus().supported;
}
