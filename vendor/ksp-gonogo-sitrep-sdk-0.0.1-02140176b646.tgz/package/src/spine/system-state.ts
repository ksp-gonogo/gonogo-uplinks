import type { DerivedChannelDefinition, DerivedGet } from "./timeline-store";
import type { SystemBodiesPayload } from "./wire-payloads";

/**
 * The `system.state` derived channel, for display maps that resolve a
 * `system.*` raw channel to a widget-facing shape but have nothing to do with
 * any one vessel.
 *
 * Today it carries a single field, `bodyCount`. `system.bodies` on the wire is
 * the raw ARRAY of bodies (`SystemViewProvider.BuildSystemBodies`), whereas
 * SystemView/useCelestialBodies.ts reads a plain `number` (how many bodies
 * exist, so it can fan out per-index subscribes). A body count does not depend
 * on anything flying, so it stays available whenever `system.bodies` is.
 */
export interface SystemState {
  /** Number of bodies in `system.bodies`. */
  bodyCount: number;
}

/**
 * `system.state` derivation. `undefined` while `system.bodies` hasn't arrived
 * ("still resyncing"); `null` when it's a confirmed tombstone; otherwise the
 * array length. Never throws.
 */
export function deriveSystemState(
  get: DerivedGet,
): SystemState | null | undefined {
  const bodiesPoint = get<SystemBodiesPayload>("system.bodies");
  if (!bodiesPoint) return undefined;
  if (bodiesPoint.payload === null) return null;
  return { bodyCount: bodiesPoint.payload.bodies.length };
}

/**
 * Ready-to-register definition: `store.registerDerivedChannel(systemStateChannel)`.
 * `fields: true` exposes `system.state.bodyCount`. Its status is its single
 * `system.bodies` input's.
 */
export const systemStateChannel: DerivedChannelDefinition<SystemState> = {
  topic: "system.state",
  inputs: ["system.bodies"],
  derive: deriveSystemState,
  fields: true,
};
