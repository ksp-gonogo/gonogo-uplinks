import type { DelayLane } from "../delay-roles";
import {
  type ClockFormulaInputs,
  type ClockFormulaSnapshot,
  computeConfirmedEdgeUt,
  computeUtNowEstimate,
} from "../view-clock-formula";

export type { DelayLane } from "../delay-roles";
export type {
  ClockFormulaInputs,
  ClockFormulaSnapshot,
} from "../view-clock-formula";

/**
 * The light-time below which SCET and the received clock are the same instant as
 * far as anything on screen can show: instants are printed to the whole second.
 */
export const VISIBLE_GAP_SECONDS = 1;

/**
 * Whether a read sits at-or-before the certainty horizon (`"confirmed"`: a
 * delivered sample or an honest interpolation between two of them) or past
 * it (`"predicted"`: a propagated/held-last estimate). Rides
 * alongside a value/status the same way `StreamStatusValue` does; see
 * `TimelineStore.sampleCertainty`.
 */
export type Certainty = "confirmed" | "predicted";

/**
 * Estimator health, used to widen hold margins; never to gate
 * confirmation itself. Only the `"locked"`/`"coasting"` split
 * (silence-based) is implemented today; `"degraded"` (a warp-rate change
 * detected during silence) is deferred.
 */
export type ViewClockConfidence = "locked" | "coasting" | "degraded";

export interface ViewClockOptions {
  /** One delay authority: the default is a fixed/zero delay; a real `DelayAuthority` can be swapped in. */
  delaySeconds?: () => number;
  /** UT-per-wall-second slope. Default 1 (real-time, no warp modelling yet, a later task feeds the real `time.warp` channel). */
  warpRate?: () => number;
  /** Injectable wall clock (seconds), defaulting to `performance.now() / 1000`. Tests inject a controllable one. */
  nowWall?: () => number;
  /** Small slack added to the sample-clamp side of `confirmedEdgeUt`'s min(). Default 0; keep the clamp tight/exact for testability; a later task may widen it for jitter tolerance. */
  slackSeconds?: number;
  /** Wall-seconds of silence (no `observeSample`) before `confidence()` reports `"coasting"`. Default 5. */
  coastingAfterSeconds?: number;
}

function defaultNowWall(): number {
  return performance.now() / 1000;
}

type FrameTickHandle =
  | { kind: "raf"; id: number }
  | { kind: "timer"; id: ReturnType<typeof setTimeout> };

/**
 * One per client: THE single view time. Fits a UT↔wall
 * relationship from delivered-sample observations, but the central
 * invariant holds: **the estimate only schedules; samples confirm**:
 *
 * `confirmedEdgeUt()` is clamped to the max `validAt` actually observed via
 * `observeSample`. A wrong or fast-running estimate can therefore only ever
 * make `confirmedEdgeUt()` LOWER than the raw estimate (display latency, or
 * a too-early `Held` later on): never higher than what's actually been
 * delivered. That is the one invariant every other feature (staleness,
 * media release, reckoning to SCET) is built to never violate.
 *
 * Epoch-aware exactly like `ClientTimeline`: `observeSample`'s `epoch` argument
 * resets the fit + sample clamp + monotonic view cursor on a rewind, and
 * discards stragglers from before the rewind: the same per-epoch hygiene,
 * applied to the one clock instead of per-topic buffers.
 *
 * @category Stream fixture
 */
export class ViewClock {
  private epoch = 0;
  private anchorWall: number | undefined;
  private anchorUt: number | undefined;
  private maxSampleUt = Number.NEGATIVE_INFINITY;
  private lastObservedWall: number | undefined;
  /**
   * Monotonic cursor behind {@link viewUt}, kept apart from {@link scetUt}'s so
   * a present that runs ahead can never pin the received edge ahead of what
   * has been delivered.
   *
   * One PER LANE, because the two cursors run a whole light-time apart: a
   * shared one would let the first true-now read of a frame pin the delayed
   * cursor at true now, and every delayed topic would then be read a light-time
   * into its own future, which is the failure the delay clock exists to
   * prevent.
   */
  private readonly lastConfirmedViewUt: Record<DelayLane, number> = {
    delayed: Number.NEGATIVE_INFINITY,
    "true-now": Number.NEGATIVE_INFINITY,
  };
  /** Monotonic cursor for {@link scetUt}, reset with the others on an epoch bump. */
  private lastScetUt = Number.NEGATIVE_INFINITY;
  /** Manual history-scrub target, `null` = live. Set via `scrubTo`. */
  private scrubTarget: number | null = null;

  /** Every live `onFrame` callback: one shared loop notifies the lot. */
  private readonly frameSubscribers = new Set<(viewUt: number) => void>();
  /** The one pending tick, tagged with the scheduler that minted it so cancelling matches. */
  private frameHandle: FrameTickHandle | undefined;
  /** Set by `suspendFrames`: the loop stays stopped and only `emitFrame` mints frames. */
  private framesSuspended = false;

  constructor(private readonly options: ViewClockOptions = {}) {}

  /**
   * Feed one delivered sample's timing into the UT↔wall fit and the sample
   * clamp. Call this for every delivered sample on every topic (not just
   * one): it's what lets `confirmedEdgeUt` know "the max buffered sample
   * UT" without itself owning any per-topic buffer.
   */
  observeSample(validAt: number, deliveredAt: number, epoch = 0): void {
    if (epoch < this.epoch) return; // stale-epoch straggler, discard
    if (epoch > this.epoch) {
      this.epoch = epoch;
      this.maxSampleUt = Number.NEGATIVE_INFINITY;
      this.lastConfirmedViewUt.delayed = Number.NEGATIVE_INFINITY;
      this.lastConfirmedViewUt["true-now"] = Number.NEGATIVE_INFINITY;
      this.lastScetUt = Number.NEGATIVE_INFINITY;
      this.anchorWall = undefined;
      this.anchorUt = undefined;
      // A scrub target from the dead pre-rewind timeline must not survive, same per-epoch hygiene as every other reset here.
      this.scrubTarget = null;
    }

    const wallNow = this.now();
    this.anchorWall = wallNow;
    this.anchorUt = deliveredAt;
    this.lastObservedWall = wallNow;
    if (validAt > this.maxSampleUt) this.maxSampleUt = validAt;
  }

  /** The client's epoch generation: bumped by `observeSample` on a rewind. Read-only mirror of `ClientTimeline.epoch`'s reset generation. */
  getEpoch(): number {
    return this.epoch;
  }

  /** One delay authority: feeds media release too. */
  delaySeconds(): number {
    return this.options.delaySeconds?.() ?? 0;
  }

  /** Estimated "vessel now": a piecewise-linear UT(wall) fit, coasting on
   *  the last observed slope between observations. Delegates to the shared
   *  pure formula (`view-clock-formula.ts`) so a second context (the
   *  kerbcast per-frame video-delay worker) can mirror this exactly; see
   *  that module's doc. */
  utNowEstimate(): number {
    return computeUtNowEstimate(this.formulaInputs(), this.now());
  }

  /**
   * The certainty horizon: `min(utNowEstimate() - delaySeconds(),
   * maxBufferedSampleUt + slack)`. Never ahead of the max sample UT actually
   * observed; see the class doc. Returns `-Infinity` before any sample has ever
   * been observed (nothing confirmed yet: the "resynchronizing" state after a
   * rewind). Delegates to the shared pure formula: see `utNowEstimate()`'s doc.
   */
  confirmedEdgeUt(lane: DelayLane = "delayed"): number {
    return computeConfirmedEdgeUt(this.formulaInputs(lane), this.now());
  }

  /** This clock's formula inputs, as of right now, the shared shape both
   *  `utNowEstimate`/`confirmedEdgeUt` (via `view-clock-formula.ts`) and
   *  `snapshot()` (below) read from, so the two can never drift apart.
   *
   *  The LANE is the whole of the difference between the two horizons: a
   *  true-now read is the same formula with no delay subtracted, so it stays
   *  clamped to the max sample UT actually observed exactly like the delayed
   *  one. That clamp is why this is safe before any true-now channel has
   *  arrived: with nothing newer delivered, the lane is held at the delayed
   *  edge rather than running ahead of the wire. */
  private formulaInputs(lane: DelayLane = "delayed"): ClockFormulaInputs {
    return {
      anchorWall: this.anchorWall,
      anchorUt: this.anchorUt,
      maxSampleUt: this.maxSampleUt,
      delaySeconds: lane === "true-now" ? 0 : this.delaySeconds(),
      warpRate: this.warpRate(),
      slackSeconds: this.options.slackSeconds ?? 0,
    };
  }

  /**
   * Serializable snapshot of this clock's formula inputs, for a SECOND
   * context to mirror `confirmedEdgeUt()`/`utNowEstimate()` locally against
   * its own wall clock, such as a video-delay worker. The
   * receiving side evaluates the exact same `view-clock-formula.ts`
   * functions this class uses, so there is one implementation, never a
   * fork. `epoch` lets a snapshot from an earlier epoch be discarded the same way
   * `observeSample` discards a straggler from before a rewind.
   */
  snapshot(): ClockFormulaSnapshot {
    return { epoch: this.epoch, ...this.formulaInputs() };
  }

  /**
   * The certainty horizon: a first-class alias for
   * `confirmedEdgeUt()`. A `viewUt` at-or-before this is CONFIRMED (a
   * delivered sample or an honest interpolation between two of them);
   * strictly after it is PREDICTED (propagated / held-last). It's the exact
   * same sample-clamped quantity as `confirmedEdgeUt()`: exposed under its
   * own name because callers (the SDK surface, `TimelineStore.beginFrame`'s
   * per-frame certainty classification) reason about it as a first-class
   * value, not as "confirmedEdgeUt renamed".
   */
  certaintyHorizonUt(lane: DelayLane = "delayed"): number {
    return this.confirmedEdgeUt(lane);
  }

  /** Classify `ut` against the certainty horizon: `<=` is CONFIRMED, matching `viewUt() === confirmedEdgeUt()` exactly (never falsely "predicted" while merely tracking live). Classified against the SAME lane the `ut` was drawn from, or a true-now read lands a light-time past the delayed horizon and every one of them reports `"predicted"`. */
  certaintyFor(ut: number, lane: DelayLane = "delayed"): Certainty {
    return ut <= this.certaintyHorizonUt(lane) ? "confirmed" : "predicted";
  }

  /**
   * Manual history scrub: pins `viewUt()` to `ut`, for exploring history (a
   * scrub bar). The live cursor keeps advancing underneath while scrubbed (the
   * confirmed edge and the estimate both keep updating from `observeSample`
   * and wall-clock flow): so `scrubTo(null)` resumes live tracking with a
   * monotonic catch-up, picking up wherever the live cursor has reached by
   * then, never a backward jump. Cleared automatically on an epoch bump
   * (see `observeSample`): a scrub target from a dead timeline must not
   * survive a rewind.
   */
  scrubTo(ut: number | null): void {
    this.scrubTarget = ut;
  }

  /**
   * THE view time: every read in a frame uses this (via the frozen
   * `FrameToken`, see `timeline-store.ts`).
   *
   * - **Live**: tracks `confirmedEdgeUt()`, monotonic non-decreasing within
   *   an epoch (mirrors `Archive.ReadAtVantage`'s cursor clamp server-side):
   *   the cursor resets to `-Infinity` on an epoch bump via `observeSample`,
   *   so "monotonic" is scoped per-epoch, not across a rewind.
   * - **Scrubbed**: `scrubTo`'s target wins outright, but the live cursor
   *   still advances underneath (see `scrubTo`'s doc).
   *
   * The LANE picks which of the two confirmed edges is tracked, and the store
   * asks for whichever one the topic being read declared. It changes nothing
   * while scrubbed, where a scrub target is a past instant both lanes agree on.
   */
  viewUt(lane: DelayLane = "delayed"): number {
    const live = Math.max(
      this.lastConfirmedViewUt[lane],
      this.confirmedEdgeUt(lane),
    );
    this.lastConfirmedViewUt[lane] = live;
    return this.scrubTarget !== null ? this.scrubTarget : live;
  }

  /**
   * The craft's present (SCET) for a frame whose delayed view time is `viewUt`:
   * the instant every reading is reckoned to.
   *
   * - Never behind `viewUt`, and monotonic within an epoch, because the estimate
   *   re-anchors on each delivery and can step back
   * - `viewUt` itself while scrubbed, since history is observed rather than
   *   modelled
   * - `viewUt` itself when the light-time is under {@link VISIBLE_GAP_SECONDS},
   *   where the two clocks read the same, and before anything has been received
   */
  scetUt(viewUt: number): number {
    if (!Number.isFinite(viewUt)) return viewUt;
    if (this.scrubTarget !== null) return viewUt;
    if (this.delaySeconds() < VISIBLE_GAP_SECONDS) return viewUt;
    const scet = Math.max(this.lastScetUt, this.utNowEstimate(), viewUt);
    this.lastScetUt = scet;
    return scet;
  }

  /**
   * When a command sent now reaches the craft: {@link scetUt} plus the one-way
   * light-time, for a surface that plans what a command will find on arrival.
   * The SCET itself while scrubbed, where nothing is being sent.
   */
  commandArrivalUt(scetUt: number): number {
    if (!Number.isFinite(scetUt)) return scetUt;
    if (this.scrubTarget !== null) return scetUt;
    return scetUt + this.delaySeconds();
  }

  /** Estimator health: `"locked"` recently observed, `"coasting"` during silence. `"degraded"` (warp-change-during-silence) is a later task. */
  confidence(): ViewClockConfidence {
    if (this.lastObservedWall === undefined) return "coasting";
    const silence = this.now() - this.lastObservedWall;
    return silence > (this.options.coastingAfterSeconds ?? 5)
      ? "coasting"
      : "locked";
  }

  /**
   * Best-effort per-frame notification, driven by `requestAnimationFrame`
   * when available (browser) and a ~60Hz timer fallback otherwise (SSR/test
   * environments without rAF). NOT what enforces the single-view-time
   * invariant: that's `TimelineStore`'s frozen `FrameToken` (structural);
   * this is just a convenience scheduling hook for callers that want to
   * drive `TimelineStore.beginFrame()` from wall-clock frames.
   *
   * One loop serves every subscriber, so the whole tree sees the same frame
   * rather than one animation-frame loop per `useViewUt`. The loop starts on
   * the first subscription and stops on the last unsubscribe, and
   * {@link suspendFrames} stops it without disturbing who is subscribed.
   */
  onFrame(cb: (viewUt: number) => void): () => void {
    this.frameSubscribers.add(cb);
    this.scheduleFrameTick();
    return () => {
      this.frameSubscribers.delete(cb);
      if (this.frameSubscribers.size === 0) this.cancelFrameTick();
    };
  }

  /**
   * Notify every {@link onFrame} subscriber once, synchronously, off whatever
   * the caller is doing rather than off an animation frame.
   *
   * Written for tests that have called {@link suspendFrames}: a mount driven
   * by explicit frames settles the same way on every machine, where one racing
   * a live loop settles only when the loop happens to lose. Safe alongside a
   * running loop too (a frame is idempotent), it just isn't useful there.
   */
  emitFrame(): void {
    if (this.frameSubscribers.size === 0) return;
    const ut = this.viewUt();
    /*
     * Snapshot, then re-check membership: a callback is free to subscribe or
     * unsubscribe from inside the frame (a React effect cleanup does exactly
     * that), and one unsubscribed earlier in this same frame must not be called.
     */
    for (const cb of Array.from(this.frameSubscribers)) {
      if (this.frameSubscribers.has(cb)) cb(ut);
    }
  }

  /**
   * Stop minting frames until {@link resumeFrames}. Subscriptions are
   * untouched: {@link emitFrame} still reaches all of them.
   *
   * The frame loop has no stopping condition by design, so a quiet link still
   * advances view time. That makes it unquiescable, and React's async `act()`
   * drains its queue and then requires the queue to be EMPTY: a frame landing
   * in that window means it never is, and the mount hangs until the test times
   * out. A test harness that needs `act()` to return has to stop the clock and
   * drive it, not race it.
   */
  suspendFrames(): void {
    this.framesSuspended = true;
    this.cancelFrameTick();
  }

  /** Resume the loop {@link suspendFrames} stopped, if anything is still subscribed. */
  resumeFrames(): void {
    if (!this.framesSuspended) return;
    this.framesSuspended = false;
    this.scheduleFrameTick();
  }

  /** Whether {@link suspendFrames} is in force. */
  get framesAreSuspended(): boolean {
    return this.framesSuspended;
  }

  private scheduleFrameTick(): void {
    if (this.framesSuspended) return;
    if (this.frameHandle !== undefined) return;
    if (this.frameSubscribers.size === 0) return;
    const tick = () => {
      this.frameHandle = undefined;
      this.emitFrame();
      this.scheduleFrameTick();
    };
    /*
     * The handle carries which scheduler minted it rather than a flag captured
     * at subscribe time, so cancelling still uses the right one when the two
     * globals are swapped underneath a live loop (which is exactly what a test
     * substituting the frame clock does).
     */
    this.frameHandle =
      typeof requestAnimationFrame === "function"
        ? { kind: "raf", id: requestAnimationFrame(tick) }
        : { kind: "timer", id: setTimeout(tick, 16) };
  }

  private cancelFrameTick(): void {
    const handle = this.frameHandle;
    if (handle === undefined) return;
    this.frameHandle = undefined;
    if (handle.kind === "raf") cancelAnimationFrame(handle.id);
    else clearTimeout(handle.id);
  }

  private now(): number {
    return (this.options.nowWall ?? defaultNowWall)();
  }

  private warpRate(): number {
    return this.options.warpRate?.() ?? 1;
  }
}
