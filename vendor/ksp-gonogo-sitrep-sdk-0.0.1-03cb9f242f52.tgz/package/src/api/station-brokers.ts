import type { StationBrokerAttach } from "./types";

/** Called by the screen watching the registry, once per registration it sees. */
type StationBrokerWatcher = (
  uplinkId: string,
  attach: StationBrokerAttach,
) => void;

interface Slot {
  attaches: Map<string, StationBrokerAttach>;
  watchers: Set<StationBrokerWatcher>;
}

/**
 * A `globalThis` slot keyed by a string, like the handle registry, so an Uplink
 * bundle and the app find the same registrations whichever copy of this
 * package each was built against.
 */
const STATION_BROKERS_KEY = "__GONOGO_STATION_BROKERS__" as const;

function slot(): Slot {
  const g = globalThis as typeof globalThis & {
    [STATION_BROKERS_KEY]?: Slot;
  };
  g[STATION_BROKERS_KEY] ??= { attaches: new Map(), watchers: new Set() };
  return g[STATION_BROKERS_KEY];
}

/**
 * Asks to be handed a {@link StationBroker} whenever this screen is a station,
 * so an Uplink's object can reach the main screen through the station's own
 * connection to it. Useful for letting a station show the operator something
 * the main screen holds, such as a media stream.
 *
 * Use it when your Uplink's client keeps a long-lived object outside React,
 * such as a media connection, which cannot call the `useUplinkRelay` hook.
 * `attach` is never called on the main screen, and is called on a station
 * whether the Uplink registered before the station screen came up or after. It
 * receives a {@link StationBroker}. The broker's `relay(method, args)` calls
 * the `relay` function of the object the Uplink stored on the main screen with
 * {@link registerUplinkHandle}, passing the `method` name and `args` through.
 * The broker can arrive before the
 * connection to the main screen does, and `relay` rejects until it is up, so a
 * caller retries rather than giving up.
 *
 * A media connection a station opens to a server on the main screen's network
 * is negotiated through `relay`: the station sends its offer, and the handle on
 * the main screen answers it, through {@link RelayCaller.bridgeMedia} when the
 * station joined through the relay's endpoint.
 *
 * ```ts
 * // myMediaConnection stands for your Uplink's own long-lived object.
 * registerStationBroker("my-uplink", ({ relay }) => {
 *   myMediaConnection.sendOffer = (offer) => relay("negotiate", [offer]);
 * });
 * ```
 *
 * Last write wins: registering the same id again replaces the previous attach,
 * and a station already up is handed the new one.
 *
 * @category Registering
 */
export function registerStationBroker(
  uplinkId: string,
  attach: StationBrokerAttach,
): void {
  const { attaches, watchers } = slot();
  attaches.set(uplinkId, attach);
  for (const watcher of watchers) watcher(uplinkId, attach);
}

/**
 * Removes a registration, so a station that comes up later does not attach it.
 * No-op if none was registered.
 * Useful for stopping an Uplink's station-side code from attaching on stations
 * that start later.
 *
 * @category Registering
 */
export function unregisterStationBroker(uplinkId: string): void {
  slot().attaches.delete(uplinkId);
}

/**
 * Removes every registration, and stops the screen's own watch for them. For
 * tests; a running app never calls it.
 *
 * @category Registering
 */
export function clearStationBrokers(): void {
  const { attaches, watchers } = slot();
  attaches.clear();
  watchers.clear();
}

/**
 * Hand every registration, present and future, to `watcher`, until the
 * returned function is called. Useful in a test for checking that an Uplink
 * registered a station broker with {@link registerStationBroker}. Used by the
 * station screen, which hands each registration a broker bound to the main
 * screen. An Uplink's client never calls it outside a test.
 *
 * @category Extensions
 */
export function watchStationBrokers(watcher: StationBrokerWatcher): () => void {
  const { attaches, watchers } = slot();
  watchers.add(watcher);
  for (const [uplinkId, attach] of attaches) watcher(uplinkId, attach);
  return () => {
    watchers.delete(watcher);
  };
}
