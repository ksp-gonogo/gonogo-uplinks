import type { StreamData } from "../__generated__/contract";
import type { ClientMessage, ServerMessage } from "../envelope";

/**
 * Connection status of a {@link Transport}'s underlying pipe. Useful for
 * telling the operator whether the stream from the game is up. Read from
 * `Transport.status`.
 *
 * @category Stream messages
 */
export type TransportStatus =
  | "connected"
  | "disconnected"
  | "reconnecting"
  | "error";

/**
 * A command a transport accepted and will now never send, with the
 * transport's own reason. It never reached the mod. Useful for telling the
 * operator that a command did not run. Reported by `Transport.onUndelivered`.
 *
 * @category Stream messages
 */
export interface UndeliveredCommand {
  /** The dispatch's own `requestId`, as it was handed to `send`. */
  requestId: string;
  /** Why it will never go, in a sentence a surface can show an operator. */
  reason: string;
}

/**
 * A command that the machine a transport relays for, such as the main screen
 * for a station, has stopped waiting for. Nobody knows whether it ran, unlike
 * an {@link UndeliveredCommand}, which certainly did not. Useful for warning
 * the operator that a command may or may not have run. Reported by
 * `Transport.onLost`.
 *
 * @category Stream messages
 */
export interface LostCommand {
  /** The dispatch's own `requestId`, as it was handed to `send`. */
  requestId: string;
  /** Why the far side stopped waiting, in its own words. */
  reason: string;
}

/**
 * A typed message pipe between the app and a telemetry source, such as a
 * WebSocket to the mod. It carries the SDK's messages and knows nothing about
 * Topics, subscriptions or commands beyond that. Useful for connecting the app
 * to a different source of the game's telemetry.
 *
 * @category Stream messages
 */
export interface Transport {
  /** Current connection status. */
  readonly status: TransportStatus;

  /** Send a client -> server message (subscribe/unsubscribe/command-request). */
  send(message: ClientMessage): void;

  /**
   * Register a listener for inbound server -> client messages. Returns an unsubscribe function.
   *
   * `delivery.replayed` is set on a message that re-delivers the past, such as
   * history a relay sends a late reader. It still enters the record, but it
   * does not say where the game is now, so it never pulls the view clock back.
   */
  onMessage(
    listener: (
      message: ServerMessage,
      delivery?: { replayed: boolean },
    ) => void,
  ): () => void;

  /** Register a listener for status changes. Returns an unsubscribe function. */
  onStatusChange(listener: (status: TransportStatus) => void): () => void;

  /**
   * Optional: reports each command this transport accepted and has stopped
   * trying to send, which the client then marks `undelivered`: it did not run.
   * Report only commands that certainly never went out. A transport that cannot
   * tell leaves this out, and its commands stay `lost`.
   */
  // A separate channel, not an `error` frame: an error correlated to a request id is read as proof the mod received it.
  onUndelivered?(listener: (command: UndeliveredCommand) => void): () => void;

  /**
   * Optional: reports each command the machine this transport relays for has
   * stopped waiting for, which the client then marks `lost`: it may or may not
   * have run. For a command that certainly never left, use `onUndelivered`.
   */
  onLost?(listener: (command: LostCommand) => void): () => void;

  /**
   * Optional: the UT by which a command sent now is expected to be confirmed,
   * for a transport that runs its own delay model. A transport carrying the
   * mod's delay must leave this out: the client then takes the delay from
   * `comms.delay`, and this would override it.
   */
  predictConfirmEta?(): number | undefined;

  /**
   * Optional: `false` when this transport cannot choose which command centre
   * it observes from, so the client refuses a change of vantage. Absent means
   * it can. A station's transport cannot, since it shares the main screen's
   * session with the mod.
   */
  readonly carriesVantage?: boolean;
  /**
   * Optional: `true` when this transport is the mod's own connection and so can
   * send a `claim`, the frame that asks the mod for the answers to commands
   * sent on an earlier connection. Absent means no: a station's transport
   * relays through the main screen, which holds the answers for it.
   */
  readonly claimsAnswers?: boolean;
  /**
   * Optional: asks the machine that holds the full run for the frames of
   * `topic` with `validAt` in `[fromUt, toUt]`, oldest first. A transport
   * offering it marks a client that keeps only the window its widgets draw, and
   * the client asks through it when a chart draws further back than is held.
   * Absent means the client keeps everything its bounds allow.
   */
  requestHistory?(
    topic: string,
    fromUt: number,
    toUt: number,
  ): Promise<StreamData<unknown>[]>;
  /**
   * Optional: `true` when this transport passes on the mod's acknowledgement
   * of each subscription, so a Topic that is never acknowledged can be shown as
   * `"unowned"`. Absent means no, and such Topics stay `"pending"`.
   */
  readonly decidesTopicOwnership?: boolean;
}
