/**
 * Returns the names of a numeric enum's members, indexed by value, for an enum
 * whose values run 0, 1, 2 and so on, as every enum Gonogo defines for itself
 * does: with the SDK's {@link Situation}, `namesOf(Situation)[0]` is
 * `"Landed"`. It is built from the enum, so it covers every member, and an ordinal
 * past the last one gives `undefined`, since the array has no gaps. The
 * contract's mirrors of KSP's own enums (the `Ksp*` enums) may start at -1 or
 * be bitmasks; use {@link namesByValue} for those. Useful for showing the
 * operator a numbered enum from the stream by name. Used to build
 * {@link SITUATION_NAMES} and the other name tables.
 *
 * @category Enum names
 */
export function namesOf(members: object): readonly string[] {
  const byOrdinal = members as Record<number, string | undefined>;
  const names: string[] = [];
  for (let ordinal = 0; byOrdinal[ordinal] !== undefined; ordinal += 1) {
    names.push(byOrdinal[ordinal] as string);
  }
  return names;
}

/**
 * Returns the names of a numeric enum's members, keyed by value, for an enum
 * whose values do not run 0, 1, 2: one with negative values, gaps, or bit
 * flags, as KSP's `PartCategories` and `KSPActionGroup` have. Useful for showing
 * the operator a KSP enum from the stream by name. Used to build {@link CREW_STANDING_NAMES}.
 *
 * @category Enum names
 */
export function namesByValue(members: object): ReadonlyMap<number, string> {
  const byValue = new Map<number, string>();
  for (const [key, value] of Object.entries(members)) {
    // The reverse map's keys are the numeric values, stringified; the forward half (name → value) is what the Number() guard drops.
    const numeric = Number(key);
    if (Number.isInteger(numeric) && typeof value === "string") {
      byValue.set(numeric, value);
    }
  }
  return byValue;
}
