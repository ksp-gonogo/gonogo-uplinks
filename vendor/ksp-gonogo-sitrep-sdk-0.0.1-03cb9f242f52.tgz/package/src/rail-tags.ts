/**
 * What a delay-rail entry is, on three axes, read off the contract instead of
 * assumed.
 *
 * The rail draws several kinds of thing crossing the same gap, and for a long
 * time it could only draw one of them: a command, a point in time, waiting for
 * an ack. Everything else was emulated. Voice was a ribbon because a widget put
 * it in the `ribbons` array; fly-by-wire was continuous because one command id
 * sat in a hardcoded `Set`, and then because that same id sat in a declaration
 * saying the same thing; nothing had ever said `direction` or `delivery` out
 * loud at all. This file is the vocabulary, and the three derivations that fill
 * it in from what the mod already declares and from what a producer knows.
 *
 * | direction | kind       | delivery         | a real example                  |
 * |-----------|------------|------------------|---------------------------------|
 * | command   | event      | acked            | staging, an action group        |
 * | command   | continuous | acked            | fly-by-wire, ack = the readback |
 * | telemetry | continuous | fire-and-forget  | radio voice                     |
 * | telemetry | event      | fire-and-forget  | a science result sent home      |
 *
 * The axes are orthogonal, and each drives exactly one visual property in the
 * kit that draws them (`@ksp-gonogo/ui-kit`'s `railTags.ts`, where the accessors
 * and the renderer table live). Which combinations have a renderer is a
 * question for that file, not this one: an entry can be perfectly well declared
 * here and have nothing yet able to draw it, and saying so out loud is the point
 * of separating the two.
 *
 * **Where each axis comes from, and why it is not a list in this package:**
 *
 * - Direction is the caller's own question, and it is not a judgement call: a
 *   declared command id is a command, and anything else on the rail is
 *   telemetry. The two namespaces are disjoint (asserted in
 *   `rail-tags.test.ts`), and a producer always knows which it holds, so the
 *   axis is set by which derivation you reach for rather than by a lookup that
 *   could go either way
 * - Delivery comes off the generated rail table's `replies`, which codegen
 *   fills in from whether the command replies. Telemetry has no reply channel
 *   at all, so nothing replies to a push
 * - Kind is the same sample kind a channel declares, and a property of the
 *   producer: each of the three derivations below reads it from what the
 *   producer is doing rather than from a declaration. One dispatch of a command
 *   is an event, always: what is continuous is
 *   the axis a widget holds, which is {@link railTagsForControlAxis}, or the
 *   stream a producer is pushing, which is {@link railTagsForTelemetry}. The
 *   command's own id cannot say which, because the same id is both depending on
 *   whether the operator pressed it or is holding it
 */

import { commandRail } from "./commands";
import type { SampleKind } from "./contract-tags";

/**
 * Which way an entry on the delay rail travels: a `"command"` goes out to the
 * craft, `"telemetry"` comes back from it. Sets the direction of the mark and
 * its colour.
 *
 * The delay rail is the row {@link CommandDelay} draws of everything on its way
 * between a command centre and a craft at this moment, each taking one signal
 * delay: commands on their way out, and transmissions such as radio voice or a
 * science result on their way back.
 *
 * Useful for showing the operator which marks on the delay rail are commands on
 * their way out and which are transmissions coming back. Used by {@link
 * CommandDelay}.
 *
 * @category Commands
 */
export type RailDirection = "command" | "telemetry";

/**
 * Whether anything replies to an entry on the delay rail. An `"acked"`
 * (acknowledged) entry is drawn with a return leg for its reply; a
 * `"fire-and-forget"` one gets no reply and ends when it arrives. Commands the
 * contract declares are `"acked"`; `"fire-and-forget"` is what telemetry coming
 * back from a craft is. Useful for showing the operator which marks on the
 * delay rail wait for a reply. Used by {@link CommandDelay}.
 *
 * @category Commands
 */
export type RailDelivery = "acked" | "fire-and-forget";

/**
 * How a command or Topic travels on the delay rail: which way, how it relates
 * in time, and whether anything replies. {@link CommandDelay} chooses how to draw
 * an entry from these. `kind` is the same sample kind a channel declares: a
 * continuous entry is drawn as a ribbon along the rail, a discrete one or an
 * event as a dot travelling it. Useful for showing the operator what is in
 * transit between the command centre and the vessel. Returned by
 * {@link railTagsForCommand}, {@link railTagsForControlAxis} and
 * {@link railTagsForTelemetry}, and read by `<CommandDelay>`.
 *
 * | direction | kind | delivery | example |
 * | --- | --- | --- | --- |
 * | command | event | acked | staging, an action group |
 * | command | continuous | acked | fly-by-wire, acknowledged by the craft's readback |
 * | telemetry | continuous | fire-and-forget | radio voice |
 * | telemetry | event | fire-and-forget | a science result sent home |
 *
 * @category Commands
 */
export interface RailTags {
  /** Which way the entry travels. */
  direction: RailDirection;
  /** How the entry relates in time: a ribbon when continuous, a dot when discrete or an event. */
  kind: SampleKind;
  /** Whether anything replies to the entry. */
  delivery: RailDelivery;
}

/**
 * How one command travels, as an Uplink's generated command map declares it:
 * whether it is answered, whether the mod holds it for the signal delay, and
 * the argument that names the time it acts at. Useful for drawing the command on
 * the delay rail and for refusing one that would arrive too late. Pass an entry
 * from that map to {@link registerUplinkCommand}.
 *
 * @category Commands
 */
export interface CommandRail {
  /**
   * Whether the mod sends a reply for the command. It is `true` for every
   * command a contract declares, and a client reads it here rather than
   * assuming it. Set to `false` in a hand-built rail, it draws the command as
   * `"fire-and-forget"` on the delay rail.
   */
  readonly replies: boolean;

  /**
   * Whether the mod holds this command for the signal delay before running
   * it. A command that is not delayed runs as soon as it arrives, and no
   * countdown is shown for it.
   */
  readonly delayed: boolean;

  /**
   * The name of the argument holding the UT this command acts at, when it has
   * one. `send` refuses the command before it leaves when it would reach the
   * craft at or after that UT.
   */
  readonly arriveBefore?: string;

  /**
   * Whether the command acts on the game or the program itself, so it runs at
   * once whichever command centre is selected. `useCommand` sends such a
   * command from the program's own vantage by itself. Absent for a command that
   * reaches a craft.
   */
  readonly meta?: boolean;
}

/**
 * One instance per combination, frozen, handed back to every caller that asks
 * for it.
 *
 * Interned rather than minted per call, and that is not a micro-optimisation.
 * These triples end up as fields on values that are compared by shallow
 * equality: a command handle is a fresh object literal on most renders, and the
 * delay rail's store only notifies its subscribers when a registered handle
 * actually moved. A freshly-built `tags` object would make every handle look
 * moved on every render, so the rail would re-render at the widget's frame rate
 * to draw the same thing. `useControlStream` has the same exposure through its
 * own `useMemo` dependencies.
 *
 * Fixing it here rather than asking each caller to memoise: there are twelve
 * possible values, they never change, and a caller that forgot would produce a
 * performance regression with no visible symptom.
 */
const INTERNED = new Map<string, RailTags>();

function railTags(
  direction: RailDirection,
  kind: SampleKind,
  delivery: RailDelivery,
): RailTags {
  const key = `${direction}/${kind}/${delivery}`;
  const held = INTERNED.get(key);
  if (held) return held;
  const minted = Object.freeze({ direction, kind, delivery });
  INTERNED.set(key, minted);
  return minted;
}

/**
 * The tags of a command nothing has declared: a command whose id is built at
 * runtime, or one from an Uplink whose client has not loaded. It is drawn as a
 * single `"acked"` command, because a reply is what every declared command
 * gets. Useful for drawing on the delay rail a command that nothing has
 * declared. Used by {@link railTagsForCommand}.
 *
 * @category Commands
 */
export const UNDECLARED_COMMAND_RAIL_TAGS: RailTags = railTags(
  "command",
  "event",
  "acked",
);

/**
 * Returns the tags for a command from its {@link CommandRail}. The result is
 * always a single command going out to the craft: `"acked"` when `rail.replies`
 * is `true` and `"fire-and-forget"` otherwise. Useful for drawing a command on
 * the delay rail the way its declaration says it is delivered. Used by {@link
 * railTagsForCommand}.
 *
 * @category Commands
 */
export function railTagsFromCommandRail(rail: CommandRail): RailTags {
  return railTags(
    "command",
    "event",
    rail.replies ? "acked" : "fire-and-forget",
  );
}

/**
 * Returns the tags for one press of a command, from what its mod or Uplink
 * declared, or {@link UNDECLARED_COMMAND_RAIL_TAGS} when nothing has declared
 * it. Useful for drawing a command the operator has sent on the delay rail. Used
 * by the kit's command list.
 *
 * @category Commands
 */
export function railTagsForCommand(command: string): RailTags {
  const rail = commandRail(command);
  return rail === null
    ? UNDECLARED_COMMAND_RAIL_TAGS
    : railTagsFromCommandRail(rail);
}

/**
 * Returns the tags for a control the operator holds, such as pitch or
 * throttle, sent as a stream of settings and echoed back by the craft.
 * `writeCommand` is the command that sets it. Useful for drawing a held control
 * on the delay rail while the operator moves it. Used by the control stream
 * hook.
 *
 * The result is continuous, unlike {@link railTagsForCommand}, because what
 * crosses the delay is the held control rather than one press. Whether it is
 * acked comes from the command.
 *
 * @category Commands
 */
export function railTagsForControlAxis(writeCommand: string): RailTags {
  const command = railTagsForCommand(writeCommand);
  return railTags(command.direction, "continuous", command.delivery);
}

/**
 * Returns the tags for data coming back from a craft, such as a radio
 * transmission or a science result. It is always fire-and-forget, since nothing
 * replies to telemetry. Pass `"continuous"` for a stream such as an open
 * microphone, and `"event"` for a single result. Useful for drawing a
 * transmission from the vessel on the delay rail. Used by the kit's command
 * delay display.
 *
 * @category Commands
 */
export function railTagsForTelemetry(kind: SampleKind): RailTags {
  return railTags("telemetry", kind, "fire-and-forget");
}
