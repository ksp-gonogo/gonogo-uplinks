import type { LimitBreach, Meta, StreamData } from "../__generated__/contract";
import { CommandErrorCode, FaultCode } from "../__generated__/error-codes";
import { COMMAND_LOST, COMMAND_REFUSED } from "../api/command-rejection";
import type { Transport } from "../api/transport";
import { wrapCommandReply } from "../command-reply-units";
import {
  type DataRateTier,
  fieldsSentOnChange,
  fillUnchangedFields,
} from "../data-rate";
import type { ClientMessage, ServerMessage } from "../envelope";
import { PerfBudget } from "../perf/PerfBudget";
import { dehydrateArgs } from "../wrap-units";
import { warnChannelError } from "./channel-error-warning";
import { type Clock, RealTimeClock } from "./clock";
import { traceCommandOutcome } from "./command-trace";
import { warnConnectionError } from "./connection-error-warning";
import { CommandError, type CommandStatus } from "./lifecycle";
import type { TimelineStore } from "./timeline-store";
import { type TopicOwnership, TopicOwnershipTracker } from "./topic-ownership";
import { ACTIVE_CRAFT_VANTAGE, META_VANTAGE } from "./vantage";

type Callback = (value: unknown) => void;
/** A subscriber that is also handed the `Meta` of the frame that carried the value, where the client still holds it. */
type FrameCallback = (value: unknown, meta: Meta | undefined) => void;
type StoreListener = () => void;

/*
 * **Shared with `classifyRetained`'s `overdueMarginSeconds`, deliberately.** Two
 * layers judge the same silence about the same command, so they judge it on ONE
 * number. Two (2s here, 3s there) is how a command ends up `lost` to an awaiting
 * caller while the queue still calls it merely late.
 *
 * They still differ in purpose, which is why both exist and neither is redundant:
 *
 * - here, the client settles the dispatch promise. That is a liveness guarantee: an
 *   `await` must end, or a caller that loops over dispatches stalls for ever
 * - in `classifyRetained`, the hook diagnoses the silence, distinguishing `lost`
 *   (the path was down) from `overdue` (the path was up and nothing acked). It knows
 *   things the client does not: queue presence and `comms.link` history
 *
 * So: one authority for the delay, one margin, two consumers with different jobs.
 * Do not "unify" them further by deleting one; the promise needs settling whether or
 * not anything is rendering, and the diagnosis needs inputs the client has no
 * business subscribing to.
 */
/**
 * The grace period, in UT seconds, added to a command's predicted `etaConfirm`
 * before silence is read as loss. It absorbs scheduling jitter around the
 * predicted round trip and models no delay of its own. `classifyRetained`'s
 * `overdueMarginSeconds` is the same number, so the client and the queue judge
 * one silence alike. Useful for telling the operator a command was lost only
 * after it is certain no reply is coming. Used by the command delay
 * classification and the commcast reveal logic.
 */
export const LOSS_MARGIN = 3;

/** How long a command sent while the delay is unknown waits for any answer before it is called lost, in seconds on the client's clock. */
const UNKNOWN_DELAY_LOSS_SECONDS = 120;

/** The longest a deadline in game UT waits on the client's clock before it reads the game's UT again, in seconds. */
const GAME_UT_RECHECK_SECONDS = 5;

/** How close to a deadline in game UT counts as reached, in seconds, so that rounding in the clock arithmetic cannot leave a timer one tick short. */
const GAME_UT_TOLERANCE = 1e-6;

/** How far behind the game's UT a frame after a load may be stamped and still belong to the same timeline, in seconds: the mod stamps a withdrawal one float step below the instant it happens at. */
const REWIND_TOLERANCE_SECONDS = 1e-3;

/** The `meta.source` of a reading delivered from a craft's own node, which keeps that craft's own delay. */
const CRAFT_NODE_SOURCE_PREFIX = "fleet.";

/**
 * Dispatch-rate budget for every command this client sends.
 *
 * Recorded in `dispatch()` because that is the one funnel. `useCommand`'s
 * `send`, `useControlStream`'s coalesced write and `dispatchActiveCommandTopic`
 * all arrive here, and nothing else in the tree mints a `command-request`
 * envelope, so a budget here covers the command path a widget has not been
 * written yet as well as the ones that exist.
 *
 * It counts at the dispatch, never at the effect. A command asking the game for
 * the state it is already in is absorbed silently and changes nothing anyone
 * can observe, so a fixture that watches outcomes counts one where the client
 * sent a hundred. That asymmetry is precisely what let a per-tick warp loop run
 * unseen.
 *
 * The threshold is 3x the realistic steady-state ceiling. Discrete commands are
 * operator-paced (a press, a host-service tick at 1 Hz), so the ceiling is set
 * by the only continuous producer: `useControlStream` coalesces at 10 Hz per
 * channel past its deadband and the Navball mounts two of them, so an operator
 * flying hands-on is about 20/sec. 60 is also exactly the Navball's own
 * control-stream threshold, so the funnel and the widget agree on what "too
 * fast" means instead of the funnel firing first on traffic the widget already
 * prices as normal.
 *
 * What it catches: a dispatch per animation frame, a duplicated subscription
 * fanning one control out twice, a widget dispatching from a render body.
 *
 * What a global rate cannot catch, worth knowing before trusting it: a slow
 * loop. The warp storm this was written for was about 120 dispatches at the
 * alarm host's 1 Hz tick across one signal delay, so 1/sec, and a threshold that
 * has to let a 20/sec control stream through can never flag that. Catching a
 * slow loop needs a per-command-id rate, which is a different instrument and
 * not this one.
 */
const COMMAND_DISPATCH_BUDGET = new PerfBudget({
  name: "TelemetryClient command dispatch/sec",
  threshold: 60,
  windowMs: 1000,
  unit: "dispatches",
});

/**
 * One record per `subscribe()` call, not per callback identity, the same
 * callback reference can be passed to `subscribe` multiple times and each
 * call must ref-count independently (see `off()` in `subscribe`).
 */
interface Subscription {
  cb: FrameCallback;
}

/**
 * Bookkeeping for one dispatched command, in-flight or settled.
 *
 * `resolve`/`reject` are nulled once the command settles (confirmed/failed/lost),
 * the Promise they close over has already been settled by then, so
 * holding onto them serves no purpose beyond leaking closures and inviting a
 * duplicate late `command-response`/`error` to re-settle (and silently
 * overwrite) an already-terminal `status`. The entry itself is intentionally
 * not deleted from `commands` on settle: `getCommand` must keep returning
 * the terminal status forever after, and deleting it would make an unknown
 * request look identical to a *known, settled* one (both would read back as
 * `{ phase: "idle" }`), which reverts `useCommand`'s `getSnapshot` to a
 * fresh object identity on every call and infinite-loops
 * `useSyncExternalStore`.
 *
 * That retention is what makes `found` possible, and the two channels this
 * record carries are why it costs no promise gymnastics. The promise is a
 * one-shot await, "did my call settle", and settling it as `lost` is honest and
 * final: the caller genuinely did stop waiting, and nothing here ever settles it
 * twice. The `status`, read through `getCommand` and republished by
 * `notifyStore`, is the living state the delay rail renders, and it is free to
 * move again. So a reply arriving after the loss writes a further status and
 * notifies, while the nulled `resolve`/`reject` keep the promise exactly as it
 * was.
 */
/**
 * What `getCommand` answers for an id this client never saw. One shared object,
 * because a hook that still holds an id from a client since replaced reads it
 * on every render, and `useSyncExternalStore` treats a fresh object each time as
 * a snapshot that never settles.
 */
const UNKNOWN_COMMAND: CommandStatus = Object.freeze({ phase: "idle" });

/** How many answered commands a client keeps a record of. The oldest go first once it holds more. */
const ANSWERED_COMMAND_CAP = 256;

/** The record count at which the oldest answered commands are dropped, set above the cap so a sweep runs once per many dispatches and not on each. */
const ANSWERED_COMMAND_SWEEP_AT = 2 * ANSWERED_COMMAND_CAP;

/**
 * The phases nothing further can happen to. A command still in flight awaits
 * its reply, and one reported lost can still be found, so neither is here.
 */
const FINAL_PHASES: ReadonlySet<CommandStatus["phase"]> = new Set([
  "confirmed",
  "refused",
  "failed",
  "undelivered",
  "found",
]);

interface PendingCommand {
  /**
   * What was dispatched, kept so a refusal can name it. Without these three a
   * refusal could only ever say "command refused: ModeUnavailable": the reply
   * carries a `requestId` and a reason and deliberately no command name, so
   * this is the only place the name still exists once the request has left.
   *
   * Retained client-side rather than added to the wire on purpose. The mod
   * already told us what we asked it; asking it to say so again would be paying
   * for a fact we threw away.
   */
  command: string;
  args: unknown;
  /** The dispatch's own operator-facing description, when it carried one. */
  label: string;
  status: CommandStatus;
  resolve: ((result: unknown) => void) | null;
  reject: ((error: { code: string; message: string }) => void) | null;
  /**
   * Cancels this command's loss-inference timer (only set when the
   * transport predicted an `etaConfirm`). Called whenever the command
   * settles by any other means (response, error, or dispose) so a command
   * that already confirmed/failed can never later flip to `lost`. `null`
   * once cancelled (or if no timer was ever scheduled, e.g. `StubTransport`).
   */
  cancelLossTimer: (() => void) | null;
  /** When the command's reply is expected, in seconds on the client's own clock. */
  etaConfirm: number;
  /** The game UT the reply is expected by, kept so the command can be stored while it is still outstanding. Absent while no frame has said what UT the game is at. */
  replyDueUt?: number;
  /** A deadline the game gave in UT, which the loss timer follows through time warp and a pause. Absent for a command timed on the client's clock alone. */
  gameDeadlineUt?: number;
  /**
   * Set while the command was dispatched with no known delay, so its loss
   * deadline is only the fallback and is replaced from `dispatchedAt` when the
   * delay figure arrives.
   */
  awaitingDelay?: { at: number; ut: number | undefined };
  /** True for a command read back from the outstanding store rather than dispatched by this client. */
  restored: boolean;
  /** The promise a restored command settles, handed to the first `useCommand` that adopts it. */
  restoredResult?: Promise<unknown>;
  /** Whether a `useCommand` has already taken this restored command. */
  taken: boolean;
  /** Set once the mod has said it holds no answer for this command, so it is neither claimed nor stored again. */
  unclaimable: boolean;
}

/**
 * App-side core that wraps a `Transport` and manages topic subscriptions.
 *
 * Ref-counts subscribers per topic so `transport.send` is only asked to
 * subscribe/unsubscribe on the first-in/last-out transition, keeps a sticky
 * last-value store so late subscribers see the current value immediately,
 * and exposes a store-listener channel for `useSyncExternalStore`-style React
 * hooks (added in a later task). Command dispatch is out of scope here.
 */
/**
 * The `CommandErrorCode` a `command-response` payload is refusing with, or
 * `null` if it is not a refusal at all.
 *
 * Structural rather than nominal, because `CommandResult` is only one of the
 * shapes carried on this channel (an Uplink may answer its own). So a payload
 * with no `success` field is "not a CommandResult", never "refused": reading
 * absence as refusal would break every command that answers a bare value. Only
 * an explicit `success: false` counts.
 *
 * A refusal that somehow arrives without a usable `errorCode` still counts as
 * one, reported as `modeUnavailable` (refused, with no reason given): that we
 * were refused is the load-bearing half, and inventing a success out of a
 * missing reason is the bug this whole path exists to stop.
 */
function refusalOf(result: unknown): {
  errorCode: CommandErrorCode;
  reason?: string;
  breach?: LimitBreach;
  detail?: string;
} | null {
  if (typeof result !== "object" || result === null) return null;
  const candidate = result as {
    success?: unknown;
    errorCode?: unknown;
    reason?: unknown;
    breach?: unknown;
    detail?: unknown;
  };
  if (candidate.success !== false) return null;
  return {
    errorCode:
      typeof candidate.errorCode === "string"
        ? (candidate.errorCode as CommandErrorCode)
        : CommandErrorCode.ModeUnavailable,
    reason:
      typeof candidate.reason === "string" && candidate.reason.length > 0
        ? candidate.reason
        : undefined,
    // The comparison behind the code, when the refusal had one. Absent is the
    // shape a reader keys on: an arm with no breach says the general thing
    // rather than rendering zeroes as a real limit of 0.
    breach:
      typeof candidate.breach === "object" && candidate.breach !== null
        ? (candidate.breach as LimitBreach)
        : undefined,
    // The game's own words, when it gave any. Empty is treated as absent for
    // the same reason: a refusal that quotes nothing must not render an empty
    // clause where a sentence was expected.
    detail:
      typeof candidate.detail === "string" && candidate.detail.length > 0
        ? candidate.detail
        : undefined,
  };
}

/**
 * One command of a group sent together to a vessel: its command id, arguments,
 * the label the operator sees and the Topic it acts on. Useful for sending
 * several commands as one message. Taken by `TelemetryClient.dispatchGroup`.
 */
export interface GroupMember {
  command: string;
  args?: unknown;
  label?: string;
  topic?: string;
  /** A request id the caller already holds, as {@link TelemetryClient.dispatch} takes. */
  requestId?: string;
  /** What the sending screen had seen, as {@link TelemetryClient.dispatch} takes. */
  seen?: CommandSeen;
}

/**
 * What a command's sending screen had last received from the mod: the run and
 * timeline it was aimed at, and the vessel it showed. A delayed command or a
 * scene change from an older run or timeline is refused, because a game load
 * replaced what it was aimed at. Passed to {@link TelemetryClient.dispatch} by a
 * host forwarding a station's command, so the station's own view is the one
 * judged and not the host's.
 *
 * @category Commands
 */
export interface CommandSeen {
  seenBootId: string;
  seenEpoch: number;
  seenVesselId?: string;
}

/**
 * One command a client has sent and not yet had answered, as it is stored for
 * its screen: the request id it was sent under, the command, its arguments
 * and label, and the game UT its reply was expected by. Useful for letting a
 * reloaded screen ask the game for the answer to a command held for a craft
 * out of contact. Used by {@link OutstandingCommandStore}.
 */
export interface OutstandingCommand {
  requestId: string;
  command: string;
  args: unknown;
  label: string;
  /** The game UT its reply is expected by. Absent for a command sent before any frame had said what UT the game was at. */
  replyDueUt?: number;
}

/**
 * Where a client keeps the commands it has sent and not yet had answered,
 * one list for each screen. Useful for claiming those commands' answers from
 * the game after a page reload. Used by {@link TelemetryClientOptions}; a
 * client with none still claims its commands after a reconnect, and cannot
 * after a reload.
 */
export interface OutstandingCommandStore {
  read(): readonly OutstandingCommand[];
  write(commands: readonly OutstandingCommand[]): void;
}

/**
 * The most commands stored as outstanding for one screen. The oldest go first
 * once a screen holds more.
 */
export const OUTSTANDING_COMMAND_CAP = 256;

/**
 * Construction options for the Sitrep client: the prefix of the request ids it
 * mints and where it keeps its outstanding commands. Taken by `TelemetryClient`.
 */
export interface TelemetryClientOptions {
  /** Prefix of every request id this client mints. Random per client unless a test pins it. */
  idPrefix?: string;
  /** Keeps the commands this client still waits on across a reload. Used only with a transport that claims answers. */
  outstanding?: OutstandingCommandStore;
}

function randomIdPrefix(): string {
  const bytes = new Uint8Array(6);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * The `seenVesselId` a command carries when the screen has read a
 * `vessel.identity` and the mod has since withdrawn it, because the active
 * vessel changed and the new one has not been heard yet. No vessel has this id,
 * so the mod refuses the order instead of sending it to a vessel the operator
 * has not seen.
 */
const UNKNOWN_CRAFT_ID = "unknown";

/**
 * The vessel the operator's screen shows as active, as the optional
 * `seenVesselId` of a command frame. Nothing when no `vessel.identity` reading
 * has ever arrived; {@link UNKNOWN_CRAFT_ID} when one has arrived and been
 * withdrawn. The mod refuses an order for the active vessel when the game has
 * since switched to another one.
 */
function seenVessel(
  identity: unknown,
  read: boolean,
): { seenVesselId?: string } {
  if (identity === null && read) return { seenVesselId: UNKNOWN_CRAFT_ID };
  if (typeof identity !== "object" || identity === null) return {};
  if (!("vesselId" in identity)) return {};
  const id = identity.vesselId;
  return typeof id === "string" && id !== "" ? { seenVesselId: id } : {};
}

type SampleFrame = Extract<
  ServerMessage,
  { type: "stream-data" | "stream-binary" }
>;

const isSampleFrame = (message: ServerMessage): message is SampleFrame =>
  message.type === "stream-data" || message.type === "stream-binary";

/**
 * `applied` with the `Meta` the mod sent. A station learns its timeline from
 * what the main screen relays and its commands must name the mod's own epoch,
 * so the epoch a client applies for its own stores stays inside that client.
 */
function stampedAsSent(
  applied: ServerMessage,
  incoming: ServerMessage,
): ServerMessage {
  if (applied === incoming) return applied;
  if (!isSampleFrame(applied) || !isSampleFrame(incoming)) return applied;
  return { ...applied, meta: incoming.meta };
}

export class TelemetryClient {
  private readonly transport: Transport;
  private readonly clock: Clock;
  private readonly subscribers = new Map<string, Set<Subscription>>();
  /** How many live {@link requestRate} claims hold each topic at the fast tier. */
  private readonly fastClaims = new Map<string, number>();
  /** The tier last sent for each subscribed topic, base ones left out: the mod drops it on unsubscribe, and so does this. */
  private readonly sentTiers = new Map<string, DataRateTier>();
  /** The subscription to `system.dataRates` held while any claim is live, so a store attached to this client learns each fast Topic's rate. */
  private releaseRateReport: (() => void) | null = null;
  private readonly lastValues = new Map<string, unknown>();
  /** The last payload this connection delivered of each Topic with fields sent only on change, which a later frame's unchanged fields are taken from. */
  private readonly lastDeliveredWithHeldFields = new Map<string, unknown>();
  /** The `Meta` of the frame that carried each topic's `lastValues` entry, so a value replayed on subscribe says which sample it is. */
  private readonly lastMetas = new Map<string, Meta>();

  /**
   * The newest point each subscribed topic has delivered, kept so a store
   * attached after it arrived can be handed it. The wire sends a topic once per
   * subscription, and subscribing is ref-counted, so a second store reading a
   * topic another store already holds would otherwise wait for a change that
   * may never come.
   */
  private readonly lastPoints = new Map<
    string,
    { validAt: number; payload: unknown; meta: Meta; epoch: number }
  >();

  /**
   * The newest sample each topic has handed to `lastValues` and raw
   * subscribers, per timeline epoch and vantage. A sample older than it still
   * reaches the timelines, which put it in order, but never becomes the
   * topic's latest value: a late `comms.delay` taken as current would pull the
   * view clock back and freeze every delayed readout. A new epoch or a new
   * vantage starts the topic afresh, since either legitimately moves which
   * instant is the newest this screen may know.
   */
  private readonly newestRaw = new Map<
    string,
    { epoch: number; vantage: string; validAt: number }
  >();
  private readonly storeListeners = new Set<StoreListener>();
  /** Clients whose commands this one reads as its own screen's, as {@link carryCommandsFrom} lends them. */
  private readonly carriers = new Set<TelemetryClient>();
  private carriedRevision = 0;
  private readonly carriedForOther = new Set<string>();
  /** Reactive-read listeners for the selected vantage: see `onSelectedVantageChange`. */
  private readonly vantageListeners = new Set<() => void>();
  /** Reactive-read listeners for the observed vantage: see `onObservedVantageChange`. */
  private readonly observedVantageListeners = new Set<() => void>();
  private readonly unsubscribeFromTransport: () => void;
  private readonly unsubscribeFromTransportStatus: () => void;
  /** No-op for a transport with no queue to strand anything in: see `Transport.onUndelivered`. */
  private readonly unsubscribeFromUndelivered: () => void;
  /** No-op for a transport carrying nobody else's verdict: see `Transport.onLost`. */
  private readonly unsubscribeFromLost: () => void;
  private readonly commands = new Map<string, PendingCommand>();
  private readonly heldCommands = new Map<string, number>();
  private readonly outstandingStore: OutstandingCommandStore | undefined;
  private outstandingDirty = false;
  private lastOutstanding = "";
  private disposed = false;
  private nextRequestId = 0;
  private readonly idPrefix: string;
  private selectedVantageId: string | undefined;
  private observedVantageId: string | undefined;
  /** The epoch and `deliveredAt` of the frame that last moved the observed vantage. */
  private observedStampedAt: { epoch: number; deliveredAt: number } | undefined;
  /** Whether the mod was asked to keep this connection at the active craft: see {@link followActiveCraft}. */
  private followingActiveCraft = false;
  /** Raw-frame tap listeners: see `onRawMessage`. */
  private readonly rawMessageListeners = new Set<
    (message: ServerMessage) => void
  >();
  /**
   * `TimelineStore`s fed from this client's wire. A `Set`, not a single
   * slot: nothing stops more than one screen from
   * sharing a client, and each gets its own `TimelineStore`/`ViewClock`. In
   * practice `TelemetryProvider` attaches exactly one (the store it
   * auto-builds, or a caller-supplied one).
   */
  private readonly stores = new Set<TimelineStore>();
  /** The game UT of the newest frame, with the reading of the client's clock it arrived at and its timeline. */
  private gameClock: { ut: number; at: number; epoch: number } | undefined;
  /**
   * Whether the newest `time.warp` said the game is paused. A paused game can
   * go quiet on every channel, so its UT is held still rather than carried
   * forward on the client's clock until a frame says it runs again.
   */
  private gamePaused = false;

  /**
   * Whether the newest `game-state` said a scene is loading. UT does not
   * advance through a load, so it holds the game's UT still the same way a
   * pause does.
   */
  private gameLoading = false;
  /** Whether a load has begun since the last live sample that was not behind the game's UT. */
  private loadSinceLastSample = false;

  /** The newest UT a live sample was delivered at, the timeline it was on, and the `seq` of the frame that carried it. */
  private newestDelivered:
    | { ut: number; epoch: number; seq: number | undefined }
    | undefined;
  /** How far the client's timeline epoch runs ahead of the wire's, for rewinds the mod did not announce with a new epoch. */
  private epochShift = 0;
  private lastWireEpoch = 0;
  /** The mod's run this client last heard from, empty until it has. */
  private wireBootId = "";
  private readonly timelineListeners = new Set<() => void>();
  /** The keyframe interval each topic's `subscribed` ack declared, kept so a store attached later is told too. */
  private readonly declaredKeyframeIntervals = new Map<string, number>();

  /**
   * What the mod last said the game is doing, replayed to a store attached
   * afterwards: a load is a fact about the game rather than about a moment, and
   * a store that missed the frame would read every Topic as current through it.
   */
  private gameState: { state: string; scene: string } | undefined;

  /**
   * Whether the mod has acked each subscribed topic, which is what separates
   * "nothing will ever publish this" from "it has not arrived yet".
   *
   * `undefined` when the transport does not relay acks (see
   * `Transport.decidesTopicOwnership`), and then every topic reads `undecided`
   * and no widget is ever told a topic is unowned. That is the safe direction
   * and the common one: only a connection that owns its own session with the
   * mod opts in.
   */
  private readonly ownership: TopicOwnershipTracker | undefined;

  /** Listeners for a topic reaching a verdict of unowned. See `onTopicUnowned`. */
  private readonly unownedListeners = new Set<(topic: string) => void>();
  /** Topic+code pairs already reported by `warnChannelError`, once per session. */
  private readonly channelErrorsWarned = new Set<string>();
  /** Codes already reported by `warnConnectionError`, once per session. */
  private readonly connectionErrorsWarned = new Set<string>();

  /**
   * Which widgets are reading each topic, refcounted, so the unowned warning
   * can name the widget as well as the topic.
   *
   * Diagnostics only: nothing about delivery consults it, and a topic read
   * outside a widget carries no label and simply is not in here. Refcounted
   * rather than a plain set because two instances of one widget id both
   * subscribing and one unmounting must not erase the label for the other.
   */
  private readonly subscriberLabels = new Map<string, Map<string, number>>();

  /**
   * `clock` defaults to `RealTimeClock`: every real transport uses it
   * unmodified. Tests inject a deterministic `Clock` (or a structurally
   * compatible one, like sitrep-server's `ManualClock`) so loss-inference
   * timing is controllable instead of racing real timers.
   *
   * Whichever `Clock` is injected must share the same time domain as the
   * transport's `predictConfirmEta()` (the UT clock the server/courier
   * advances): see the domain note on the `Clock` interface in `./clock`.
   * A mismatched domain makes loss inference meaningless: the
   * `etaConfirm - now()` delta can clamp to zero (false near-instant "lost")
   * or never fire (loss never inferred).
   */
  constructor(
    transport: Transport,
    clock: Clock = new RealTimeClock(),
    options: TelemetryClientOptions = {},
  ) {
    this.idPrefix = options.idPrefix ?? randomIdPrefix();
    this.transport = transport;
    this.outstandingStore =
      transport.claimsAnswers === true ? options.outstanding : undefined;
    this.clock = clock;
    this.ownership = transport.decidesTopicOwnership
      ? new TopicOwnershipTracker((topic) => {
          for (const listener of this.unownedListeners) listener(topic);
          for (const store of this.stores) store.markTopicUnowned(topic);
          this.notifyStore();
        })
      : undefined;
    /* A transport still connecting reports no change until it opens, so the tracker is told here that nothing can ack yet. */
    if (transport.status !== "connected") this.ownership?.handleDisconnected();
    this.unsubscribeFromTransport = transport.onMessage(
      (incoming, delivery) => {
        const replayed = delivery?.replayed === true;
        this.followTimeline(incoming);
        const message = replayed ? incoming : this.followRewind(incoming);
        if (message.type === "stream-data") this.restoreUnchanged(message);
        const asSent = stampedAsSent(message, incoming);
        for (const listener of this.rawMessageListeners) listener(asSent);
        this.handleMessage(message, replayed);
      },
    );
    this.unsubscribeFromUndelivered =
      transport.onUndelivered?.((command) =>
        this.handleUndelivered(command.requestId, command.reason),
      ) ?? (() => undefined);
    this.unsubscribeFromLost =
      transport.onLost?.((command) =>
        this.handleLoss(
          command.requestId,
          "relayed-loss",
          `command unconfirmed: ${command.reason}`,
        ),
      ) ?? (() => undefined);
    this.unsubscribeFromTransportStatus = transport.onStatusChange((status) => {
      if (status === "connected") this.scheduleClaim();
      /* Every attached store reads link-down from here: a reading's grade is
         `disconnected` only while the transport says `connected` is false. */
      for (const store of this.stores) {
        store.setTransportConnected(status === "connected");
      }
      if (!this.ownership) return;
      if (status === "connected") {
        // The transports re-send their whole subscription set on every connect,
        // and the mod's session (with its ack bookkeeping) is new, so every
        // still-subscribed topic needs a fresh window against it.
        this.ownership.handleConnected(this.subscribers.keys());
        return;
      }
      // A subscribe whose ack was still in flight when the link dropped must not mature into a verdict while nothing can answer.
      this.ownership.handleDisconnected();
      for (const store of this.stores) store.clearTopicOwnership();
      this.notifyStore();
    });
    this.restoreOutstanding();
    if (transport.status === "connected") this.scheduleClaim();
  }

  /**
   * Takes back the commands an earlier page of this screen was still waiting
   * on, so the mod can be asked for their answers and a `useCommand` can show
   * them again. Each is tracked as in flight under the id it was sent with.
   */
  private restoreOutstanding(): void {
    const store = this.outstandingStore;
    if (!store) return;
    let stored: readonly OutstandingCommand[] = [];
    try {
      stored = store.read().slice(-OUTSTANDING_COMMAND_CAP);
    } catch {
      return;
    }
    for (const held of stored) {
      if (this.commands.has(held.requestId)) continue;
      const result = new Promise<unknown>((resolve, reject) => {
        this.commands.set(held.requestId, {
          command: held.command,
          args: held.args,
          label: held.label,
          status: {
            phase: "in-flight",
            requestId: held.requestId,
            etaConfirm: this.clock.now(),
          },
          resolve,
          reject,
          cancelLossTimer: null,
          etaConfirm: this.clock.now(),
          replyDueUt: held.replyDueUt,
          gameDeadlineUt: held.replyDueUt,
          restored: true,
          taken: false,
          unclaimable: false,
        });
      });
      result.catch(() => undefined);
      const pending = this.commands.get(held.requestId);
      if (!pending) continue;
      pending.restoredResult = result;
      /*
       * A deadline in game UT cannot be placed until a frame says what UT the
       * game is at, and `noteGameUt` arms it then. One with no such deadline
       * was timed on the last page's clock, which this page cannot read, so it
       * gets the time the claim's answer needs to travel.
       */
      if (pending.gameDeadlineUt !== undefined) continue;
      pending.cancelLossTimer = this.clock.schedule(
        this.clock.now() + LOSS_MARGIN,
        () => this.handleLoss(held.requestId),
      );
    }
    this.lastOutstanding = JSON.stringify(this.outstandingList());
    this.notifyStore();
  }

  /**
   * The commands read back from an earlier page that are for `command` and
   * that no `useCommand` has taken yet, each with the promise it settles, so
   * the hook can show them and their answers as it does its own sends.
   */
  restoredCommands(command: string): {
    requestId: string;
    args: unknown;
    label: string;
    result: Promise<unknown>;
  }[] {
    const taken: {
      requestId: string;
      args: unknown;
      label: string;
      result: Promise<unknown>;
    }[] = [];
    for (const [requestId, pending] of this.commands) {
      if (
        !pending.restored ||
        pending.taken ||
        pending.command !== command ||
        !pending.restoredResult
      ) {
        continue;
      }
      pending.taken = true;
      taken.push({
        requestId,
        args: pending.args,
        label: pending.label,
        result: pending.restoredResult,
      });
    }
    return taken;
  }

  /** The commands still waiting for an answer that the mod has not said it has none for. */
  private outstandingList(): OutstandingCommand[] {
    const list: OutstandingCommand[] = [];
    for (const [requestId, pending] of this.commands) {
      if (pending.unclaimable || this.carriedForOther.has(requestId)) continue;
      const phase = pending.status.phase;
      if (phase !== "in-flight" && phase !== "lost") continue;
      list.push({
        requestId,
        command: pending.command,
        args: pending.args,
        label: pending.label,
        replyDueUt: pending.replyDueUt,
      });
    }
    return list.slice(-OUTSTANDING_COMMAND_CAP);
  }

  /** Writes the outstanding commands to the store when they have changed. */
  private flushOutstanding(): void {
    this.outstandingDirty = false;
    const store = this.outstandingStore;
    if (!store || this.disposed) return;
    const list = this.outstandingList();
    const serialised = JSON.stringify(list);
    if (serialised === this.lastOutstanding) return;
    this.lastOutstanding = serialised;
    try {
      store.write(list);
    } catch {
      /* A full or blocked store costs the reload claim and nothing else. */
    }
  }

  /**
   * Asks the mod for the answers to every command still outstanding, once the
   * transport has re-sent its vantage and subscriptions: a claim is checked
   * against the vantage the connection sits at, so it goes after them.
   */
  private scheduleClaim(): void {
    if (this.transport.claimsAnswers !== true) return;
    queueMicrotask(() => {
      if (this.disposed || this.transport.status !== "connected") return;
      const requestIds = this.outstandingList().map((c) => c.requestId);
      if (requestIds.length === 0) return;
      this.transport.send({ type: "claim", requestIds });
    });
  }

  /**
   * Notified once per topic per connection, the moment the mod's silence has
   * gone on long enough to be an answer.
   *
   * Fires for the diagnostic surfaces (the logged warning) rather than for
   * rendering: a widget learns the same fact through its `Reading` arm, which is
   * the surface that makes it unmissable.
   */
  onTopicUnowned(listener: (topic: string) => void): () => void {
    this.unownedListeners.add(listener);
    return () => this.unownedListeners.delete(listener);
  }

  /**
   * What this connection can say about whether anything will ever publish
   * `topic`. Always `"undecided"` on a transport that does not relay acks.
   */
  topicOwnership(topic: string): TopicOwnership {
    return this.ownership?.ownershipOf(topic) ?? "undecided";
  }

  /**
   * Record that `label` (a widget id) is reading `topic`, for diagnostics.
   * Returns a release function; call it when the read stops.
   */
  noteSubscriberLabel(topic: string, label: string): () => void {
    let labels = this.subscriberLabels.get(topic);
    if (!labels) {
      labels = new Map();
      this.subscriberLabels.set(topic, labels);
    }
    labels.set(label, (labels.get(label) ?? 0) + 1);
    return () => {
      const current = this.subscriberLabels.get(topic);
      const count = current?.get(label);
      if (!current || count === undefined) return;
      if (count > 1) {
        current.set(label, count - 1);
        return;
      }
      current.delete(label);
      if (current.size === 0) this.subscriberLabels.delete(topic);
    };
  }

  /** The widgets currently reading `topic`, by id. Empty outside a widget. */
  readersOf(topic: string): readonly string[] {
    return [...(this.subscriberLabels.get(topic)?.keys() ?? [])];
  }

  /**
   * Tap every raw wire message this client's transport delivers, verbatim
   * and in arrival order: before this class's own topic-routing/store-ingest
   * handling runs on it (`handleMessage` drops `command-response`/`error`
   * after its own bookkeeping and silently ignores `event` frames entirely,
   * so a listener that only used `subscribe`/`getValue` could never observe
   * either). This is the mission-recording tap point (`StreamRecorder`,
   * `./replay-recorder.ts`): recording a session needs the same
   * `stream-data`/`event` frames a `ReplayFixture` replays later, not the
   * flattened last-value view every other consumer of this class sees.
   *
   * Purely additive: does not affect `subscribe`/`getValue`/store-ingest
   * delivery, and costs nothing when no listener is registered (the common
   * case: mission history off, or no recorder attached).
   *
   * A frame keeps the timeline epoch the mod stamped on it, whatever rewind this
   * client has inferred for its own stores.
   */
  onRawMessage(listener: (message: ServerMessage) => void): () => void {
    this.rawMessageListeners.add(listener);
    return () => this.rawMessageListeners.delete(listener);
  }

  /**
   * The command centre this client asked to command from and observe at,
   * or `undefined` until {@link setVantage} asks for one.
   *
   * `undefined` is "wherever the server puts a connection that has not chosen",
   * which is the home command, and not a centre id this client could spell: the
   * server alone knows which centre is home. Where that turned out to be is
   * {@link observedVantage}. After {@link followActiveCraft} it is that observed
   * centre, since the mod chooses it.
   */
  get selectedVantage(): string | undefined {
    // While following, the mod picks the centre, so the one in force is the one the frames name.
    return this.followingActiveCraft
      ? this.observedVantageId
      : this.selectedVantageId;
  }

  /**
   * Whether {@link setVantage} can do anything on this connection. False on a
   * station, whose frames are relayed from a host session it does not own, so a
   * surface there states {@link observedVantage} rather than offering a choice
   * that cannot be made.
   */
  get canSetVantage(): boolean {
    return this.transport.carriesVantage !== false;
  }

  /**
   * The command centre the mod stamped on the most recent ordinary frame, or
   * `undefined` before one has arrived and while the mod says it is at none
   * (no save is loaded, so no command centre is active).
   *
   * Where {@link selectedVantage} is intent (what this client asked for), this
   * is observation (what it is being sent). The two differ wherever a client
   * does not own the session its frames come from, and before a client has
   * chosen at all: a station's own selection never leaves `undefined`, while
   * every frame carries the vantage it was genuinely delayed from.
   *
   * Instant-class topics ride the meta vantage instead of the session's
   * selection, so a frame stamped with it says nothing about where the session
   * is observing from and never moves this.
   */
  get observedVantage(): string | undefined {
    return this.observedVantageId;
  }

  /**
   * Subscribe to selected-vantage changes, so a component can re-render on one
   * without owning the selection itself. Fires after {@link setVantage} updates
   * the selection. Returns an unsubscribe.
   */
  onSelectedVantageChange(cb: () => void): () => void {
    this.vantageListeners.add(cb);
    return () => {
      this.vantageListeners.delete(cb);
    };
  }

  /**
   * Subscribe to observed-vantage changes (for a reactive read). Fires only when
   * an arriving frame names a different centre than the last one did, not on
   * every frame. Returns an unsubscribe.
   */
  onObservedVantageChange(cb: () => void): () => void {
    this.observedVantageListeners.add(cb);
    return () => {
      this.observedVantageListeners.delete(cb);
    };
  }

  /**
   * Select the command centre (vantage) to command from and observe at. Sends a
   * `set-vantage` message and re-subscribes every active topic so its downlink
   * cursor re-points to the new vantage's offset. The server validates the id and
   * errors on one that names no active centre; this optimistically tracks the
   * request.
   */
  setVantage(centreId: string): void {
    // A transport that cannot carry the selection must not have one made
    // against it. Changing `selectedVantageId` anyway would leave every reader
    // of it, the vantage control included, naming a command centre the data is
    // not from; and the re-subscribe below would churn the whole topic set for
    // a request nothing will act on.
    if (!this.canSetVantage) return;
    this.followingActiveCraft = false;
    this.selectedVantageId = centreId;
    for (const listener of this.vantageListeners) listener();
    this.sendVantage(centreId);
  }

  /**
   * Ask the mod to keep this connection at the active craft, and to move it
   * whenever the game changes craft (a switch, an EVA, a docking or an undock),
   * with no further message from this client. While there is no active craft
   * the connection stays at the vantage a fresh connection starts at. Useful for
   * a screen that flies whichever craft is active, which sends this once instead
   * of naming a craft. Used by the pilot screen.
   *
   * Does nothing when the connection is already following, and on a transport
   * that cannot carry a vantage. {@link selectedVantage} then reports the centre
   * the frames name.
   */
  followActiveCraft(): void {
    if (!this.canSetVantage || this.followingActiveCraft) return;
    this.followingActiveCraft = true;
    for (const listener of this.vantageListeners) listener();
    this.sendVantage(ACTIVE_CRAFT_VANTAGE);
  }

  private sendVantage(centreId: string): void {
    this.transport.send({ type: "set-vantage", centreId });
    // Re-point existing subscriptions at the new vantage: the server reads the selected vantage at subscribe time, so an active topic must re-subscribe.
    for (const topic of this.subscribers.keys()) {
      this.transport.send({ type: "unsubscribe", topic });
      this.sentTiers.delete(topic);
      this.transport.send({ type: "subscribe", topic });
      this.ownership?.noteSubscribeSent(topic);
      this.syncRate(topic);
    }
  }

  /**
   * Ask for `topic` at `tier` until the returned release is called. The mod is
   * asked for the fastest tier any live claim on the topic holds, and only while
   * the topic is subscribed: a claim made first waits for the subscribe, and one
   * outliving its subscriptions is asked for again when the topic is next
   * subscribed. A `"base"` claim asks for nothing.
   */
  requestRate(topic: string, tier: DataRateTier): () => void {
    if (topic === "" || tier === "base") return () => {};
    this.fastClaims.set(topic, (this.fastClaims.get(topic) ?? 0) + 1);
    this.releaseRateReport ??= this.subscribe("system.dataRates", () => {});
    this.syncRate(topic);
    let released = false;
    return () => {
      if (released) return;
      released = true;
      const remaining = (this.fastClaims.get(topic) ?? 1) - 1;
      if (remaining > 0) this.fastClaims.set(topic, remaining);
      else this.fastClaims.delete(topic);
      this.syncRate(topic);
      if (this.fastClaims.size === 0) {
        this.releaseRateReport?.();
        this.releaseRateReport = null;
      }
    };
  }

  /**
   * Ask the mod to send `tier` no faster than `samplesPerSecond` while this
   * connection is open, or withdraw the request with `null`. The mod sends the
   * tier at the lowest rate any connection asks for this way, never below the
   * base rate, and `system.dataRates` reports what it sends.
   */
  capRate(tier: DataRateTier, samplesPerSecond: number | null): void {
    this.transport.send(
      samplesPerSecond === null
        ? { type: "cap-rate", tier }
        : { type: "cap-rate", tier, samplesPerSecond },
    );
  }

  /** The tier the live claims on `topic` ask for. */
  claimedTier(topic: string): DataRateTier {
    return (this.fastClaims.get(topic) ?? 0) > 0 ? "fast" : "base";
  }

  /** Send `set-rate` for `topic` when the tier its claims ask for differs from what the mod holds for it. */
  private syncRate(topic: string): void {
    if (!this.subscribers.has(topic)) return;
    const wanted = this.claimedTier(topic);
    if (wanted === (this.sentTiers.get(topic) ?? "base")) return;
    if (wanted === "base") this.sentTiers.delete(topic);
    else this.sentTiers.set(topic, wanted);
    this.transport.send({ type: "set-rate", topic, tier: wanted });
  }

  /**
   * Subscribe to a topic. On the first subscriber for a topic, sends a
   * `subscribe` message to the transport. If a sticky last value already
   * exists for the topic, `cb` is invoked with it synchronously before
   * returning. Returns an unsubscribe function; when the last subscriber for
   * the topic unsubscribes, sends `unsubscribe` and clears local state.
   *
   * An empty topic names nothing the mod can serve, so it never reaches the
   * wire: the call warns once and returns a no-op unsubscribe.
   */
  subscribe(topic: string, cb: Callback): () => void {
    /* Wrapped so the callback is called with the value alone: a caller's own optional second parameter must not be handed a `Meta`. */
    return this.subscribeFrames(topic, (value) => cb(value));
  }

  /**
   * Subscribes as {@link subscribe} does, and hands `cb` the `Meta` of the
   * frame that carried each value as well. The `Meta` is `undefined` for a
   * value replayed on subscribe whose frame the client no longer holds.
   */
  subscribeFrames(topic: string, cb: FrameCallback): () => void {
    if (topic === "") {
      this.warnEmptyTopicOnce();
      return () => {};
    }
    let subs = this.subscribers.get(topic);
    if (!subs) {
      subs = new Set();
      this.subscribers.set(topic, subs);
      this.transport.send({ type: "subscribe", topic });
      this.ownership?.noteSubscribeSent(topic);
      this.syncRate(topic);
    }
    const sub: Subscription = { cb };
    subs.add(sub);

    if (this.lastValues.has(topic)) {
      this.invokeCallback(
        cb,
        this.lastValues.get(topic),
        this.lastMetas.get(topic),
      );
    }

    return () => {
      const current = this.subscribers.get(topic);
      if (!current) return;
      current.delete(sub);
      if (current.size === 0) {
        this.subscribers.delete(topic);
        this.lastValues.delete(topic);
        this.lastMetas.delete(topic);
        this.lastPoints.delete(topic);
        this.newestRaw.delete(topic);
        this.sentTiers.delete(topic);
        this.transport.send({ type: "unsubscribe", topic });
        this.ownership?.noteReleased(topic);
      }
    };
  }

  /** Current sticky last value for a topic, if any has been received. */
  getValue(topic: string): unknown {
    return this.lastValues.get(topic);
  }

  /**
   * Feed this client's raw `stream-data` wire frames into `store`: from
   * this call on, every future `stream-data`
   * message is also delivered to `store.ingest(topic, point)`, in addition
   * to the existing `lastValues`/per-topic-subscriber delivery this class
   * already does, the two delivery paths are independent, neither replaces
   * the other. `point.validAt`/`point.epoch` are read straight off the
   * message's own `meta` (`meta.validAt`/`meta.timelineEpoch`), which is what
   * makes this feed correct for a published processor's epoch-guard/quality-pick
   * machinery without this class needing to know anything about derivation.
   *
   * Does not replay history: a store attached after samples have already
   * arrived only sees samples from that point forward (this class keeps no
   * raw-message log, only the flattened `lastValues` sticky cache), matches
   * `TelemetryProvider`'s own lifecycle, which attaches its store before
   * anything can possibly subscribe through it.
   *
   * Returns a detach function. Safe to attach more than one store to the
   * same client (each gets every message independently); a client is not
   * scoped to exactly one `TimelineStore`.
   */
  attachStore(store: TimelineStore): () => void {
    this.stores.add(store);
    store.setTransportConnected(this.transport.status === "connected");
    for (const [topic, interval] of this.declaredKeyframeIntervals) {
      store.declareKeyframeInterval(topic, interval);
    }
    // Only each topic's newest point is replayed, never the history behind it.
    for (const [topic, point] of this.lastPoints) store.ingest(topic, point);
    const requestHistory = this.transport.requestHistory?.bind(this.transport);
    const releaseHistory = requestHistory
      ? store.setHistorySource({
          request: async (topic, fromUt, toUt) =>
            (await requestHistory(topic, fromUt, toUt)).map((frame) => ({
              validAt: frame.meta.validAt,
              payload: frame.payload,
              meta: frame.meta,
              epoch: frame.meta.timelineEpoch,
            })),
        })
      : undefined;
    if (this.gameState) {
      store.setGameState(this.gameState.state, this.gameState.scene);
    }
    // Unlike sample history, ownership verdicts DO backfill. There are a
    // handful of them, they are facts about the mod rather than about a moment,
    // and a store attached after one was reached would otherwise render a topic
    // as pending forever with the answer already sitting one object away.
    for (const topic of this.ownership?.unownedTopics() ?? []) {
      store.markTopicUnowned(topic);
    }
    return () => {
      releaseHistory?.();
      this.stores.delete(store);
    };
  }

  /**
   * Calls `cb` whenever the client's state changes, whatever the topic. Useful
   * as the subscribe function of `useSyncExternalStore`. Returns an unsubscribe.
   */
  subscribeStore(cb: StoreListener): () => void {
    this.storeListeners.add(cb);
    return () => this.storeListeners.delete(cb);
  }

  /**
   * Dispatch a command to the server. Returns immediately with a
   * `requestId` (`<prefix>-<n>`: a counter that is deterministic within one
   * client, behind a prefix that is random per client so two page loads or two
   * screens never mint the same id) and a `result` Promise that
   * resolves/rejects once the correlated `command-response`/`error` arrives.
   *
   * `transport.send` is called synchronously, the client always hands the
   * request to the transport in the same tick as `dispatch()`. Modeling the
   * round trip (i.e. making sure `in-flight` is observable before the
   * response settles) is the transport's responsibility, not the client's:
   * even a zero-latency stub must answer on a later tick, since a real
   * transport never resolves in the same call stack as the request.
   *
   * Loss inference: the client asks the transport to *predict* an
   * `etaConfirm` (never computes delay itself). When the transport can't
   * predict one (`predictConfirmEta` omitted or returning `undefined`, e.g.
   * `StubTransport`), `etaConfirm` falls back to "now" and no loss timer is
   * started: the command just waits. When a prediction is
   * available, a loss timer is armed for `etaConfirm + LOSS_MARGIN`; if the
   * command is still `in-flight` when it fires, silence is inferred as
   * `lost` and the promise rejects. Any real settle (response or error)
   * cancels that timer first, so a confirmed/failed command can never later
   * flip to `lost`.
   *
   * `label` is a description of the command to show the operator, such as the
   * composed line text of a script terminal keystroke. Defaults to `""`.
   *
   * `topic` addresses the command to one part or route on the craft, such as
   * one script terminal. Defaults to `""`, which leaves it unscoped.
   *
   * `requestId` lets a caller that already holds a unique id (a peer host
   * dispatching a station's command) send it under that id, so the pending
   * queue the mod publishes is keyed by the id the originator knows. An id this
   * client is already tracking is refused.
   */
  /**
   * The authoritative one-way delay, in UT seconds, or `undefined` when nothing has
   * offered one. Set by whoever owns the `DelayAuthority` (see
   * `TelemetryProvider`'s delay-wiring effect, the single wiring point).
   */
  private delaySource: (() => number) | undefined;

  private warnedNoLossDeadline = false;
  private awaitingDelayCount = 0;
  private warnedEmptyTopic = false;

  /**
   * Hand the client the authoritative one-way delay so it can settle a dispatch that
   * is never answered. Returns a detach function; calling it restores the
   * transport-prediction fallback.
   *
   * Takes an accessor rather than a number because the delay changes as a craft moves
   * and a dispatch must be sized against the delay at its moment, not at wiring time.
   * `DelayAuthority.delaySeconds` is a bound arrow field with a stable identity for
   * exactly this hand-off.
   */
  setDelaySource(getOneWaySeconds: () => number): () => void {
    this.delaySource = getOneWaySeconds;
    return () => {
      if (this.delaySource === getOneWaySeconds) this.delaySource = undefined;
    };
  }

  /** The delay source's figure, or nothing while it says the delay is unknown (not finite). */
  private knownSourceDelay(): number | undefined {
    const seconds = this.delaySource?.();
    return seconds !== undefined && Number.isFinite(seconds)
      ? seconds
      : undefined;
  }

  /**
   * Say so, once, when a dispatch gets no loss deadline.
   *
   * Loud on purpose. The whole defect this replaced was a silent fallback to
   * `clock.now()`: no deadline, no timer, no complaint, and a queue that looked like
   * nothing was ever lost. A deployment with neither an authority nor a predicting
   * transport still cannot settle an unanswered promise, and that has to be audible
   * rather than inferred from an absence months later.
   */
  private warnEmptyTopicOnce(): void {
    if (this.warnedEmptyTopic) return;
    this.warnedEmptyTopic = true;
    console.warn(
      "[sitrep] subscribe was called with an empty topic; it was not sent. " +
        "A caller built a topic id from a value it does not have.",
    );
  }

  private warnNoLossDeadlineOnce(): void {
    if (this.warnedNoLossDeadline) return;
    this.warnedNoLossDeadline = true;
    if (this.delaySource === undefined) {
      console.warn(
        "[sitrep] no delay authority and no transport prediction: command promises " +
          "cannot be settled on silence, so an unanswered dispatch will hang. " +
          "Attach a DelayAuthority (TelemetryProvider does this) or implement " +
          "Transport.predictConfirmEta.",
      );
      return;
    }
    console.warn(
      "[sitrep] the command delay is not yet known: a command sent now is timed " +
        "from its dispatch once the figure arrives, and is called lost after " +
        "a fixed wait if none does.",
    );
  }

  dispatch(
    command: string,
    args?: unknown,
    label?: string,
    topic?: string,
    vantage?: string,
    requestIdOverride?: string,
    seen?: CommandSeen,
  ): { requestId: string; result: Promise<unknown> } {
    const { requestId, result, frame } = this.register(
      command,
      args,
      label,
      topic,
      vantage,
      requestIdOverride,
      seen,
    );
    this.transport.send(frame);
    return { requestId, result };
  }

  /**
   * Dispatch several commands as one `command-group` frame: they travel as one
   * message, arrive whole or not at all, are refused whole, and run in order in
   * one physics tick. Each member is tracked, answered and lost exactly as a
   * command sent alone, under its own request id.
   *
   * `vantage` applies to the whole group, since a group is sent from one command
   * centre. An empty group is refused here, before anything is registered.
   */
  dispatchGroup(
    members: readonly GroupMember[],
    vantage?: string,
    groupId?: string,
  ): {
    groupId: string;
    members: { requestId: string; result: Promise<unknown> }[];
  } {
    if (members.length === 0) {
      throw new Error("a command group needs at least one command");
    }
    const overrides = members.flatMap((m) =>
      m.requestId === undefined ? [] : [m.requestId],
    );
    if (
      new Set(overrides).size !== overrides.length ||
      overrides.some((id) => this.commands.has(id))
    ) {
      throw new Error("a request id in the group is already in use");
    }
    const registered = members.map((m) =>
      this.register(
        m.command,
        m.args,
        m.label,
        m.topic,
        vantage,
        m.requestId,
        m.seen,
      ),
    );
    const id = groupId ?? `${this.idPrefix}-g${this.nextRequestId++}`;
    this.transport.send({
      type: "command-group",
      groupId: id,
      members: registered.map((r) => r.frame),
    });
    return {
      groupId: id,
      members: registered.map(({ requestId, result }) => ({
        requestId,
        result,
      })),
    };
  }

  /**
   * Starts tracking one command and builds the frame that carries it, without
   * sending it: {@link dispatch} sends it alone and {@link dispatchGroup} sends
   * several in one frame.
   */
  private register(
    command: string,
    args: unknown,
    label: string | undefined,
    topic: string | undefined,
    vantage: string | undefined,
    requestIdOverride: string | undefined,
    seen: CommandSeen | undefined,
  ): {
    requestId: string;
    result: Promise<unknown>;
    frame: Extract<ClientMessage, { type: "command-request" }>;
  } {
    if (
      requestIdOverride !== undefined &&
      this.commands.has(requestIdOverride)
    ) {
      throw new Error(`request id ${requestIdOverride} is already in use`);
    }
    /* Before anything can fail or be deduplicated downstream: the budget's
       subject is how often this client was ASKED to send, not how many sends
       survived. */
    COMMAND_DISPATCH_BUDGET.record();
    // Quantities down to the numbers the host binds, ONCE, here, because this is
    // the one funnel every command goes through and the mod rejects an object in
    // a numeric slot outright. Kept for the in-flight record too: a refusal names
    // what was SENT, and the wire form is what was sent.
    const wireArgs = dehydrateArgs(args);
    const requestId =
      requestIdOverride ?? `${this.idPrefix}-${this.nextRequestId++}`;
    // Where the round trip comes from, and why in THIS order.
    //
    // A transport that OWNS its delay model is asked first: `CourierTransport` drives
    // the courier's own engine and its prediction is the ground truth for that
    // deployment. Nothing else can know it.
    //
    // Otherwise the delay AUTHORITY answers. `comms.delay.oneWaySeconds` is the
    // server-enforced number that DEFINES the delay, and `DelayAuthority` already
    // holds it live (it subscribes on this very client), so the round trip is
    // `2 * oneWay` and this layer computes it without the transport knowing anything
    // about delay at all. That is the production path: `WebSocketTransport`
    // deliberately does not predict.
    //
    // The order matters because of a typed-absence trap. `DelayAuthority.delaySeconds`
    // fail-safes to 0 (see `readOneWaySeconds`), so "no sample has arrived" and "the
    // delay is genuinely zero" are the same value from here. Asking the authority
    // FIRST therefore let an un-fed 0 override a courier that knew the real answer,
    // which is exactly what three existing courier tests caught. Preferring an
    // explicit transport prediction avoids needing to tell those two cases apart.
    //
    // They are alternatives, never both: one source per deployment rather than two
    // competing ones. See `Transport.predictConfirmEta` for the rule a new transport
    // must follow.
    const sourceDelay = this.knownSourceDelay();
    const predictedEta =
      this.transport.predictConfirmEta?.() ??
      (sourceDelay !== undefined
        ? this.clock.now() + 2 * sourceDelay
        : undefined);
    const etaConfirm = predictedEta ?? this.clock.now();
    /*
     * The authority's delay is in game seconds, so once a frame has said what UT
     * the game is at, the round trip is a game deadline. On the client's clock
     * it would run out early whenever the game runs slower than real time.
     */
    const dispatchUt = this.gameUtNow();
    const delayDeadlineUt =
      this.transport.predictConfirmEta?.() === undefined &&
      sourceDelay !== undefined &&
      dispatchUt !== undefined
        ? dispatchUt + 2 * sourceDelay
        : undefined;
    if (predictedEta === undefined) this.warnNoLossDeadlineOnce();
    const replyDueUt =
      predictedEta === undefined ? undefined : this.gameUtAt(predictedEta);

    const result = new Promise<unknown>((resolve, reject) => {
      this.commands.set(requestId, {
        command,
        args: wireArgs,
        label: label ?? "",
        status: { phase: "in-flight", requestId, etaConfirm },
        resolve,
        reject,
        cancelLossTimer: null,
        etaConfirm,
        replyDueUt,
        restored: false,
        taken: false,
        unclaimable: false,
      });
    });
    /* Another screen sent it under its own id, and only that screen reloads and claims it. */
    if (requestIdOverride !== undefined) this.carriedForOther.add(requestId);
    this.outstandingDirty = true;
    this.dropOldestAnswered();

    const pendingNow = this.commands.get(requestId);
    if (predictedEta !== undefined && pendingNow) {
      if (delayDeadlineUt !== undefined) {
        pendingNow.gameDeadlineUt = delayDeadlineUt;
        this.placeGameDeadline(requestId, pendingNow);
      } else {
        pendingNow.cancelLossTimer = this.clock.schedule(
          predictedEta + LOSS_MARGIN,
          () => this.handleLoss(requestId),
        );
      }
    }

    if (
      predictedEta === undefined &&
      pendingNow &&
      this.delaySource !== undefined
    ) {
      pendingNow.awaitingDelay = { at: this.clock.now(), ut: dispatchUt };
      pendingNow.cancelLossTimer = this.clock.schedule(
        this.clock.now() + UNKNOWN_DELAY_LOSS_SECONDS,
        () => this.handleLoss(requestId),
      );
      this.awaitingDelayCount += 1;
    }

    this.notifyStore();
    return {
      requestId,
      result,
      frame: {
        type: "command-request",
        requestId,
        command,
        label: label ?? "",
        topic: topic ?? "",
        // Per-call vantage override (delay-UX): "" ⇒ the server uses the session vantage; "meta" pins a program-meta command to instant dispatch.
        vantage: vantage ?? "",
        ...(seen ?? this.seen()),
        args: wireArgs,
        sentAt: 0,
      },
    };
  }

  /**
   * Drops the records of the oldest answered commands once the client holds
   * {@link ANSWERED_COMMAND_SWEEP_AT}, down to {@link ANSWERED_COMMAND_CAP}. A
   * continuous control sends ten commands a second, and each record is walked
   * whenever the outstanding list is written.
   */
  private dropOldestAnswered(): void {
    if (this.commands.size < ANSWERED_COMMAND_SWEEP_AT) return;
    let excess = this.commands.size - ANSWERED_COMMAND_CAP;
    for (const [requestId, pending] of this.commands) {
      if (excess <= 0) return;
      if (!FINAL_PHASES.has(pending.status.phase)) continue;
      if (this.heldCommands.has(requestId)) continue;
      if (pending.awaitingDelay) this.awaitingDelayCount -= 1;
      this.commands.delete(requestId);
      excess -= 1;
    }
  }

  /**
   * Keeps the records of these commands past the sweep of answered ones, for a
   * reader that reports their status later (a group of commands). Returns the
   * release, which hands them back to the sweep.
   */
  holdCommands(requestIds: readonly string[]): () => void {
    for (const id of requestIds) {
      this.heldCommands.set(id, (this.heldCommands.get(id) ?? 0) + 1);
    }
    let released = false;
    return () => {
      if (released) return;
      released = true;
      for (const id of requestIds) {
        const left = (this.heldCommands.get(id) ?? 1) - 1;
        if (left > 0) this.heldCommands.set(id, left);
        else this.heldCommands.delete(id);
      }
    };
  }

  /**
   * Reads the commands `carrier` dispatched as ones this screen follows, through
   * {@link getCarriedCommand}. Useful for a main screen whose stations' commands
   * leave through a connection of their own. Returns the release.
   */
  carryCommandsFrom(carrier: TelemetryClient): () => void {
    if (carrier === this) return () => undefined;
    this.carriers.add(carrier);
    const stop = carrier.subscribeStore(() => {
      this.carriedRevision += 1;
      this.notifyStore();
    });
    this.carriedRevision += 1;
    this.notifyStore();
    return () => {
      stop();
      this.carriers.delete(carrier);
    };
  }

  /** Changes whenever a client this one carries commands from changes, so a reader of {@link getCarriedCommand} can tell. */
  carriedCommandsRevision(): number {
    return this.carriedRevision;
  }

  /**
   * The status of a command this client or a client it carries dispatched,
   * preferring this client's own record. `idle` when none holds it.
   */
  getCarriedCommand(requestId: string): CommandStatus {
    const own = this.commands.get(requestId)?.status;
    if (own) return own;
    for (const carrier of this.carriers) {
      const status = carrier.commands.get(requestId)?.status;
      if (status) return status;
    }
    return UNKNOWN_COMMAND;
  }

  /** Current lifecycle status for a dispatched command, or `idle` if the client holds no record of it: it was never sent, or it was answered long enough ago to be dropped. */
  getCommand(requestId: string): CommandStatus {
    return this.commands.get(requestId)?.status ?? UNKNOWN_COMMAND;
  }

  /**
   * Tear down the transport listener and clear all local state.
   *
   * Before clearing: sends `unsubscribe` for every topic that still has
   * active subscribers (the transport doesn't know the client is going
   * away otherwise), and rejects every still-pending command's `result`
   * promise with a disposed error, so callers awaiting `dispatch()` don't
   * hang forever on a client that will never receive their response.
   */
  dispose(): void {
    this.disposed = true;
    this.unsubscribeFromTransport();
    this.unsubscribeFromTransportStatus();
    this.unsubscribeFromUndelivered();
    this.unsubscribeFromLost();
    this.ownership?.dispose();

    for (const topic of this.subscribers.keys()) {
      this.transport.send({ type: "unsubscribe", topic });
    }

    for (const [requestId, pending] of this.commands) {
      pending.cancelLossTimer?.();
      pending.cancelLossTimer = null;
      if (!pending.reject) continue; // already settled, nothing to reject
      const error = {
        code: FaultCode.Disposed,
        message: "TelemetryClient disposed while command was in flight",
      };
      const reject = pending.reject;
      pending.status = { phase: "failed", requestId, error };
      pending.resolve = null;
      pending.reject = null;
      reject(new CommandError(error.code, error.message));
    }

    this.subscribers.clear();
    this.lastValues.clear();
    this.lastMetas.clear();
    this.lastPoints.clear();
    this.newestRaw.clear();
    this.storeListeners.clear();
    this.unownedListeners.clear();
    this.subscriberLabels.clear();
    this.commands.clear();
    this.awaitingDelayCount = 0;
    this.stores.clear();
  }

  /**
   * Record the vantage an arriving frame was delayed from. See
   * {@link observedVantage} for why the meta vantage is not one. A frame with
   * no stamp at all (a transport with nothing to say about vantage) changes
   * nothing, and the mod's empty stamp clears it: no centre is active yet.
   */
  private noteObservedVantage(meta: Meta): void {
    const vantage = meta.vantage;
    if (vantage === undefined || vantage === META_VANTAGE) return;
    /*
     * A host replays a quiet Topic's older frames after its newest, to a
     * station that has just joined, so a frame can arrive stamped from a
     * centre the session has since left. Only a frame from the same or a later
     * timeline epoch, and delivered no earlier than the one that set the
     * vantage within an epoch, may change it.
     */
    const prior = this.observedStampedAt;
    if (
      prior !== undefined &&
      (meta.timelineEpoch < prior.epoch ||
        (prior.epoch === meta.timelineEpoch &&
          meta.deliveredAt < prior.deliveredAt))
    ) {
      return;
    }
    const stamp = { epoch: meta.timelineEpoch, deliveredAt: meta.deliveredAt };
    // The mod's empty stamp says no command centre is active, so the earlier centre no longer describes what arrives.
    if (vantage === "") {
      this.observedStampedAt = stamp;
      if (this.observedVantageId === undefined) return;
      this.observedVantageId = undefined;
      this.notifyObservedVantage();
      return;
    }
    this.observedStampedAt = stamp;
    if (vantage === this.observedVantageId) return;
    this.observedVantageId = vantage;
    this.notifyObservedVantage();
  }

  private notifyObservedVantage(): void {
    for (const listener of this.observedVantageListeners) listener();
    // A following connection's selection is the observed one.
    if (this.followingActiveCraft) {
      for (const listener of this.vantageListeners) listener();
    }
  }

  /**
   * Put back the fields a frame left out as unchanged, from the last frame of its
   * Topic this connection delivered, so every reader past this point sees a whole
   * payload.
   */
  private restoreUnchanged(message: StreamData<unknown>): void {
    const { unchanged } = message;
    if (unchanged !== undefined && unchanged.length > 0) {
      fillUnchangedFields(
        message.payload,
        unchanged,
        this.lastDeliveredWithHeldFields.get(message.topic),
      );
      message.unchanged = undefined;
    }
    if (fieldsSentOnChange(message.topic).length > 0) {
      this.lastDeliveredWithHeldFields.set(message.topic, message.payload);
    }
  }

  private handleMessage(message: ServerMessage, replayed = false): void {
    if (this.awaitingDelayCount > 0) this.timeCommandsAwaitingDelay();
    if (message.type === "command-response") {
      this.handleCommandResponse(message.requestId, message.result);
      return;
    }
    if (message.type === "command-accepted") {
      this.handleCommandAccepted(
        message.requestId,
        message.oneWaySeconds,
        message.predictedReplyUt,
        message.expiresAtUt,
        message.warning,
      );
      return;
    }
    if (message.type === "error") {
      // An error carrying a TOPIC and no requestId is not a reply to any
      // command: it is a channel that was acked and then could not be put on
      // the wire. The command correlator below returns immediately on a
      // missing requestId, so before this branch the frame was discarded and
      // the author was left with the exact silence the mod had just gone to
      // the trouble of explaining. See `channel-error-warning.ts`.
      if (!message.requestId && message.topic) {
        /* `unknownTopic` is the mod refusing the subscribe, not a channel that
           was acked and then broke, so it belongs to the ownership verdict and
           NOT to `warnChannelError`, whose text says the opposite happened. */
        if (message.code === FaultCode.UnknownTopic) {
          this.ownership?.noteRefused(message.topic);
          return;
        }
        warnChannelError(
          this.channelErrorsWarned,
          message.topic,
          message.code,
          message.message,
        );
        return;
      }
      // Neither a command's reply nor a channel's fault: a refusal about the
      // CONNECTION, which correlates to nothing and so used to die one line
      // below, on `handleCommandError`'s `if (!requestId) return`. See
      // `connection-error-warning.ts` for the two producers.
      if (!message.requestId) {
        warnConnectionError(
          this.connectionErrorsWarned,
          message.code,
          message.message,
        );
        return;
      }
      if (message.code === FaultCode.ReplyNotReceived) {
        this.handleNoRecord(message.requestId, message.message);
        return;
      }
      this.handleCommandError(message.requestId, message.code, message.message);
      return;
    }
    if (message.type === "game-state") {
      this.gameState = { state: message.state, scene: message.scene };
      this.noteLoading(message.state === "loading");
      for (const store of this.stores) {
        store.setGameState(message.state, message.scene);
      }
      return;
    }
    // The `subscribed` ack. Every event frame was dropped here until this
    // branch existed, which is why the mod's own answer to "does anything
    // publish this topic" reached nothing that could use it.
    if (message.type === "event") {
      if (message.name === "timeline-reset") {
        const kept: unknown = message.keptThroughUt;
        for (const store of this.stores) {
          store.noteTimelineReset(
            message.topic,
            typeof kept === "number" ? kept : undefined,
          );
        }
      }
      if (message.name === "subscribed") {
        this.ownership?.noteAck(message.topic);
        /* An ack can arrive after the window that called the topic unowned, and it is the mod's own answer. */
        for (const store of this.stores) store.markTopicOwned(message.topic);
        const interval: unknown = message.keyframeIntervalUt;
        if (typeof interval === "number") {
          this.declaredKeyframeIntervals.set(message.topic, interval);
          for (const store of this.stores) {
            store.declareKeyframeInterval(message.topic, interval);
          }
        }
      }
      return;
    }
    /*
     * A BINARY-LANE delivery is routed exactly as a `stream-data` one, with
     * the segment array standing where the payload would: same subscribers,
     * same stores, same `Meta`, so a widget reads it through `useTelemetry`
     * like anything else and gets the same staleness and vantage answers.
     *
     * What it deliberately does NOT get is `wrapTopicPayload`, which is
     * applied in `parseServerMessage` and never runs on this lane. There is
     * nothing to wrap: an opaque payload declares no quantities, so walking it
     * would be walking a megabyte of audio looking for fields that cannot be
     * there.
     */
    if (message.type === "stream-binary") {
      this.ingestTopicPayload(
        message.topic,
        message.segments,
        message.meta,
        replayed,
      );
      return;
    }
    if (message.type !== "stream-data") return;
    this.ingestTopicPayload(
      message.topic,
      message.payload,
      message.meta,
      replayed,
    );
  }

  /** Whether a sample is at least as new as the newest this topic has surfaced, recording it when it is. */
  private isNewestRaw(topic: string, meta: Meta): boolean {
    const epoch = meta.timelineEpoch ?? 0;
    const vantage = meta.vantage ?? "";
    const prior = this.newestRaw.get(topic);
    if (prior !== undefined && prior.epoch > epoch) return false;
    if (
      prior !== undefined &&
      prior.epoch === epoch &&
      prior.vantage === vantage &&
      meta.validAt < prior.validAt
    ) {
      return false;
    }
    this.newestRaw.set(topic, { epoch, vantage, validAt: meta.validAt });
    return true;
  }

  private ingestTopicPayload(
    topic: string,
    payload: unknown,
    meta: Meta,
    replayed: boolean,
  ): void {
    this.noteObservedVantage(meta);
    this.noteGameUt(meta, replayed);
    const newest = this.isNewestRaw(topic, meta);
    /* A replay included: whether the game is paused is a state, and a station's link back to the main screen hands over the current one as replayed history. */
    if (topic === "time.warp" && newest) this.notePaused(payload, meta);
    const point = {
      validAt: meta.validAt,
      payload,
      meta,
      epoch: meta.timelineEpoch,
    };
    if (newest) {
      this.lastValues.set(topic, payload);
      this.lastMetas.set(topic, meta);
      if (this.subscribers.has(topic)) this.lastPoints.set(topic, point);
      const subs = this.subscribers.get(topic);
      if (subs) {
        for (const sub of subs) this.invokeCallback(sub.cb, payload, meta);
      }
    }
    for (const store of this.stores) {
      store.ingest(topic, point, { replayed });
    }
    this.notifyStore();
  }

  /**
   * Arm this command's loss deadline from the number the engine used to send
   * it, replacing whatever was armed at dispatch.
   *
   * The dispatch-time deadline can only ever be built from the delay the client
   * can see, which is the active craft's. A command addressed to another node
   * (a career order held at home, a spend from a distant vessel) travels a
   * different path entirely, so that deadline grades it against the wrong
   * flight and can call it lost while its reply is still legitimately in the
   * air. This is the correction, and it is authoritative because the engine is
   * the thing that actually scheduled the delivery.
   *
   * Silently ignores a request id it does not know: a reply that already
   * arrived, or a command settled some other way, has nothing left to time.
   */
  private handleCommandAccepted(
    requestId: string,
    oneWaySeconds: number | null | undefined,
    predictedReplyUt?: number | null,
    expiresAtUt?: number | null,
    warning?: string | null,
  ): void {
    const pending = this.commands.get(requestId);
    if (!pending) return;
    /*
     * Already settled, which a zero-delay reply can be by beating its own
     * acceptance frame back. There is no deadline left to move, and arming one
     * would schedule a loss for a command that is finished.
     */
    if (!pending.resolve) return;
    /*
     * Null is the centre having no signal delay to quote, because its plan knows
     * no route yet. That is not a zero: the command is timed by its predicted
     * reply or its expiry below, and by nothing here when it has neither.
     */
    const knownOneWay =
      oneWaySeconds != null &&
      Number.isFinite(oneWaySeconds) &&
      oneWaySeconds >= 0
        ? oneWaySeconds
        : undefined;
    const roundTrip =
      knownOneWay !== undefined
        ? this.clock.now() + 2 * knownOneWay
        : undefined;

    /*
     * A held command replies when its route says, waits included, which can be
     * long after twice the one-way time; one with no predicted route can still
     * run up to its expiry. Both figures are game UT, so they are timed against
     * the game's clock and never handed to the client's own.
     */
    const nowUt = this.gameUtNow();
    const gameDeadlineUt =
      predictedReplyUt != null && Number.isFinite(predictedReplyUt)
        ? predictedReplyUt
        : expiresAtUt != null && Number.isFinite(expiresAtUt)
          ? expiresAtUt
          : /* The delay is game seconds too, so the round trip is timed on the game's UT once it is known. */
            knownOneWay !== undefined && nowUt !== undefined
            ? nowUt + 2 * knownOneWay
            : undefined;
    if (pending.status.phase === "in-flight") {
      pending.status = warning
        ? { ...pending.status, accepted: true, warning }
        : { ...pending.status, accepted: true };
    }
    if (gameDeadlineUt !== undefined || roundTrip !== undefined) {
      if (pending.awaitingDelay) {
        pending.awaitingDelay = undefined;
        this.awaitingDelayCount -= 1;
      }
    }
    if (gameDeadlineUt !== undefined) {
      pending.gameDeadlineUt = gameDeadlineUt;
      pending.replyDueUt = gameDeadlineUt;
      this.outstandingDirty = true;
      if (this.placeGameDeadline(requestId, pending)) {
        this.notifyStore();
        return;
      }
    }
    /*
     * Reached with a game deadline only while no frame has said what UT the
     * game is at. The round trip stands in until `noteGameUt` places it.
     */
    if (roundTrip === undefined) {
      this.notifyStore();
      return;
    }
    pending.cancelLossTimer?.();
    pending.etaConfirm = roundTrip;
    pending.replyDueUt ??= this.gameUtAt(roundTrip);
    this.outstandingDirty = true;
    if (pending.status.phase === "in-flight") {
      pending.status = { ...pending.status, etaConfirm: roundTrip };
    }
    pending.cancelLossTimer = this.clock.schedule(roundTrip + LOSS_MARGIN, () =>
      this.handleLoss(requestId),
    );
    this.notifyStore();
  }

  /**
   * Gives each command sent while the delay was unknown its loss deadline, worked
   * from the moment it was dispatched, as soon as the delay source has a figure.
   */
  private timeCommandsAwaitingDelay(): void {
    const sourceDelay = this.knownSourceDelay();
    if (sourceDelay === undefined) return;
    let changed = false;
    for (const [requestId, pending] of this.commands) {
      const waiting = pending.awaitingDelay;
      if (!waiting) continue;
      pending.awaitingDelay = undefined;
      this.awaitingDelayCount -= 1;
      if (!pending.resolve || pending.status.phase !== "in-flight") continue;
      changed = true;
      this.outstandingDirty = true;
      if (waiting.ut !== undefined) {
        pending.gameDeadlineUt = waiting.ut + 2 * sourceDelay;
        pending.replyDueUt = pending.gameDeadlineUt;
        if (this.placeGameDeadline(requestId, pending)) continue;
      }
      pending.cancelLossTimer?.();
      const dueAt = waiting.at + 2 * sourceDelay;
      pending.etaConfirm = dueAt;
      pending.status = { ...pending.status, etaConfirm: dueAt };
      pending.cancelLossTimer = this.clock.schedule(dueAt + LOSS_MARGIN, () =>
        this.handleLoss(requestId),
      );
    }
    if (changed) this.notifyStore();
  }

  /**
   * The game's UT now, carried forward on the client's clock from the newest
   * frame. `undefined` until a frame has arrived.
   */
  private gameUtNow(): number | undefined {
    const anchor = this.gameClock;
    if (!anchor) return undefined;
    if (this.gamePaused || this.gameLoading) return anchor.ut;
    return anchor.ut + (this.clock.now() - anchor.at);
  }

  /**
   * Reads the pause flag off a `time.warp` record; a record that does not carry
   * one leaves it as it was. The game's UT is re-anchored where the flag
   * changes, so neither the stretch before a pause nor the pause itself is
   * counted as game time: a pause starts at the record's own UT, and a game
   * that runs again starts from where it stopped.
   */
  private notePaused(payload: unknown, meta: Meta): void {
    if (typeof payload !== "object" || payload === null) return;
    const paused: unknown = Reflect.get(payload, "paused");
    if (typeof paused !== "boolean" || paused === this.gamePaused) return;
    const anchor = this.gameClock;
    const epoch = meta.timelineEpoch ?? 0;
    if (anchor && epoch >= anchor.epoch) {
      this.gameClock = {
        ut: paused
          ? this.pausedAtUt(anchor, meta, epoch)
          : (this.gameUtNow() ?? anchor.ut),
        at: this.clock.now(),
        epoch,
      };
    }
    this.gamePaused = paused;
  }

  /**
   * Gives a live sample the timeline epoch the client holds it under.
   *
   * A quickload or revert starts a new timeline, which the mod announces with
   * a higher epoch. When a load was seen and the next live sample's UT is
   * behind the game's UT already seen on the same epoch, no epoch came, and
   * the sample is the new timeline: the client bumps its own epoch so every
   * store and the view clock drop the abandoned one. The game's own load is
   * what tells this apart from samples that merely arrive out of order within
   * one timeline, which are still refused. A later epoch from the mod is
   * absorbed into the shift so the two never add up.
   */
  private followRewind(message: ServerMessage): ServerMessage {
    if (message.type !== "stream-data" && message.type !== "stream-binary") {
      return message;
    }
    const meta = message.meta;
    const wire = meta.timelineEpoch ?? 0;
    this.absorbWireEpoch(wire);
    let epoch = wire + this.epochShift;
    /*
     * Behind what has actually been delivered on this timeline, not behind the
     * clock's estimate of the game's UT. The estimate runs on through a dialog
     * or a scene load the game spends paused, such as a switch of craft, so the
     * first frame after one would read as a rewind and empty every Topic.
     */
    const delivered = this.newestDelivered;
    /*
     * A reading delivered from a craft's own node arrives on that craft's clock,
     * after its own delay, so it can trail frames already delivered without any
     * rewind. A rewind takes every Topic back, so the frames the mod sends from
     * its own nodes are enough to tell one.
     */
    const fromACraftsNode =
      typeof meta.source === "string" &&
      meta.source.startsWith(CRAFT_NODE_SOURCE_PREFIX);
    /*
     * The mod numbers frames in the order it builds them, and can send one built
     * earlier after one built later. A frame built before the newest delivered
     * one was built before any load that frame could have come after, so it is
     * not a rewind however far behind its stamp is.
     */
    const builtEarlier =
      Number.isFinite(meta.seq) &&
      delivered?.seq !== undefined &&
      meta.seq < delivered.seq;
    const behind =
      !fromACraftsNode &&
      !builtEarlier &&
      delivered !== undefined &&
      epoch === delivered.epoch &&
      Number.isFinite(meta.deliveredAt) &&
      meta.deliveredAt < delivered.ut - REWIND_TOLERANCE_SECONDS;
    const rewound = this.loadSinceLastSample && behind;
    if (rewound) {
      this.epochShift += 1;
      epoch += 1;
      /* Every Topic starts again on a rewind, so the frame that made the call is named, to be found when one was not a rewind at all. */
      console.warn(
        `[sitrep] read a load as a rewind from ${message.topic} (source ${String(meta.source)}, ` +
          `valid at ${meta.validAt}, delivered at ${meta.deliveredAt}, ` +
          `behind ${delivered?.ut} delivered on this timeline); every Topic starts again.`,
      );
    }
    if (
      Number.isFinite(meta.deliveredAt) &&
      (delivered === undefined ||
        epoch !== delivered.epoch ||
        meta.deliveredAt > delivered.ut)
    ) {
      this.newestDelivered = {
        ut: meta.deliveredAt,
        epoch,
        seq: Number.isFinite(meta.seq) ? meta.seq : undefined,
      };
    }
    if (rewound || (!this.gameLoading && !behind)) {
      this.loadSinceLastSample = false;
    }
    if (epoch === wire) return message;
    return { ...message, meta: { ...meta, timelineEpoch: epoch } };
  }

  /**
   * Learns the mod's run and timeline from the frames that carry them outside a
   * sample. A quiet connection hears no stream data after a load, so without
   * these it would send the old timeline forever and have its commands refused.
   * Replayed frames count: a late station hears the game's state only that way.
   */
  private followTimeline(message: ServerMessage): void {
    if (message.type === "hello" || message.type === "game-state") {
      this.adoptRun(message.bootId);
      this.absorbWireEpoch(message.timelineEpoch ?? 0);
      return;
    }
    if (message.type === "event" && message.name === "timeline-reset") {
      this.absorbWireEpoch(message.meta.timelineEpoch ?? 0);
    }
  }

  /** A new run counts its epochs from zero again, so nothing kept from the old one can be compared with them. */
  private adoptRun(bootId: string | undefined): void {
    if (!bootId || bootId === this.wireBootId) return;
    const restarted = this.wireBootId !== "";
    this.wireBootId = bootId;
    if (!restarted) return;
    this.lastWireEpoch = 0;
    this.epochShift = 0;
    this.notifyTimeline();
  }

  /** Takes a wire epoch, absorbing a rewind the client had inferred for itself into the shift so the two never add up. */
  private absorbWireEpoch(wire: number): void {
    if (wire <= this.lastWireEpoch) return;
    this.epochShift = Math.max(
      0,
      this.epochShift - (wire - this.lastWireEpoch),
    );
    this.lastWireEpoch = wire;
    /*
     * The mod has announced the timeline the load started, so the load needs no
     * inferring. Left set, a frame delayed to an earlier UT than another on the
     * new epoch reads as a second rewind and the client ends one epoch ahead of
     * every frame the mod sends.
     */
    this.loadSinceLastSample = false;
    this.notifyTimeline();
  }

  private notifyTimeline(): void {
    for (const listener of this.timelineListeners) listener();
  }

  /** The raw timeline epoch this screen last received from the mod, as a command sends it. */
  get wireEpoch(): number {
    return this.lastWireEpoch;
  }

  /** Calls `fn` once `seconds` have passed on this client's clock. Returns a function that cancels it. */
  scheduleAfter(seconds: number, fn: () => void): () => void {
    return this.clock.schedule(this.clock.now() + seconds, fn);
  }

  /** Calls `listener` whenever {@link wireEpoch} changes. Returns a function that stops it. */
  onTimelineChange(listener: () => void): () => void {
    this.timelineListeners.add(listener);
    return () => {
      this.timelineListeners.delete(listener);
    };
  }

  /** What this screen has last received from the mod, as a command frame carries it. */
  private seen(): CommandSeen {
    return {
      seenBootId: this.wireBootId,
      seenEpoch: this.lastWireEpoch,
      ...seenVessel(
        this.lastValues.get("vessel.identity"),
        this.lastValues.has("vessel.identity"),
      ),
    };
  }

  /** Holds the game's UT still from the moment a load starts and lets it run again from there when it ends. */
  private noteLoading(loading: boolean): void {
    if (loading === this.gameLoading) return;
    if (loading) this.loadSinceLastSample = true;
    const anchor = this.gameClock;
    const ut = this.gameUtNow();
    if (anchor && ut !== undefined) {
      this.gameClock = { ut, at: this.clock.now(), epoch: anchor.epoch };
    }
    this.gameLoading = loading;
  }

  /** The UT a pause began at: the record's own, never earlier than the estimate on the same timeline. */
  private pausedAtUt(
    anchor: { ut: number; epoch: number },
    meta: Meta,
    epoch: number,
  ): number {
    const ut = meta.deliveredAt;
    if (!Number.isFinite(ut)) return anchor.ut;
    if (epoch > anchor.epoch) return ut;
    return Math.max(anchor.ut, ut);
  }

  /** The game UT that a reading of the client's clock falls on, or `undefined` until a frame has arrived. */
  private gameUtAt(clockSeconds: number): number | undefined {
    const nowUt = this.gameUtNow();
    if (nowUt === undefined) return undefined;
    return nowUt + (clockSeconds - this.clock.now());
  }

  /**
   * Records the game UT a frame was delivered at, which is the only thing that
   * relates a deadline in game UT to the client's clock.
   *
   * Frames keep arriving while the game is paused, each with the same UT, and
   * arrive faster than a second of UT apart under time warp. Taking every one
   * is what lets a deadline wait out a pause and come early under warp. A
   * replayed frame describes the past, and one from an earlier timeline or an
   * earlier UT on the same one would move the estimate backwards.
   */
  private noteGameUt(meta: Meta, replayed: boolean): void {
    const ut = meta.deliveredAt;
    if (replayed || !Number.isFinite(ut)) return;
    const epoch = meta.timelineEpoch ?? 0;
    const prior = this.gameClock;
    if (prior && epoch < prior.epoch) return;
    if (prior && epoch === prior.epoch && ut < prior.ut) return;
    /* A new timeline has its own pause state, which its own `time.warp` will say. */
    if (prior && epoch > prior.epoch) this.gamePaused = false;
    this.gameClock = { ut, at: this.clock.now(), epoch };
    /* The deadlines of commands in flight are in the old timeline's UT, so the mod is asked what became of them. */
    if (prior && epoch > prior.epoch) this.scheduleClaim();
    if (prior) return;
    let placed = false;
    for (const [requestId, pending] of this.commands) {
      if (pending.gameDeadlineUt === undefined) continue;
      /* The claim's answer has to travel first, so a deadline that passed while the page was away starts from now. */
      if (pending.restored) {
        pending.gameDeadlineUt = Math.max(pending.gameDeadlineUt, ut);
      }
      placed = this.placeGameDeadline(requestId, pending) || placed;
    }
    if (placed) this.notifyStore();
  }

  /**
   * Moves a command still in flight onto its deadline in game UT, and says
   * whether it could: it cannot until a frame has said what UT the game is at.
   */
  private placeGameDeadline(
    requestId: string,
    pending: PendingCommand,
  ): boolean {
    const dueUt = pending.gameDeadlineUt;
    const nowUt = this.gameUtNow();
    if (dueUt === undefined || nowUt === undefined) return false;
    if (pending.status.phase !== "in-flight") return false;
    const etaConfirm = this.clock.now() + (dueUt - nowUt);
    pending.etaConfirm = etaConfirm;
    pending.status = { ...pending.status, etaConfirm };
    this.armGameDeadline(requestId, pending);
    return true;
  }

  /**
   * Arms the loss timer for a deadline in game UT. The client's clock cannot
   * count game time through time warp or a pause, so the timer never waits
   * longer than {@link GAME_UT_RECHECK_SECONDS} before it reads the game's UT
   * again.
   */
  private armGameDeadline(requestId: string, pending: PendingCommand): void {
    const dueAt = this.clockTimeOfLoss(pending);
    if (dueAt === undefined) return;
    pending.cancelLossTimer?.();
    const recheckAt = this.clock.now() + GAME_UT_RECHECK_SECONDS;
    pending.cancelLossTimer = this.clock.schedule(
      Math.min(dueAt, recheckAt),
      () => {
        const due = this.clockTimeOfLoss(pending);
        if (due === undefined || this.clock.now() >= due - GAME_UT_TOLERANCE) {
          this.handleLoss(requestId);
          return;
        }
        this.armGameDeadline(requestId, pending);
      },
    );
  }

  /**
   * The reading of the client's clock at which a command's deadline in game UT
   * and its margin run out, were the game to run at normal speed from the
   * newest frame. Worked from that frame's own reading, so a deadline a whole
   * number of seconds away lands on one. Infinite while the game is paused or loading, so
   * the timer keeps rechecking rather than spending the deadline on the pause.
   */
  private clockTimeOfLoss(pending: PendingCommand): number | undefined {
    const anchor = this.gameClock;
    const dueUt = pending.gameDeadlineUt;
    if (!anchor || dueUt === undefined) return undefined;
    if (this.gamePaused || this.gameLoading) return Number.POSITIVE_INFINITY;
    return anchor.at + (dueUt + LOSS_MARGIN - anchor.ut);
  }

  private handleCommandResponse(requestId: string, rawResult: unknown): void {
    const pending = this.commands.get(requestId);
    if (!pending) return;
    this.outstandingDirty = true;
    // A reply's units, here rather than in `parseServerMessage`, because the
    // envelope names a requestId and no type: the command that was dispatched is
    // the only route back to one, and this is the first point that knows it.
    // Above the `found` branch too, so a reply that arrives after a loss is the
    // same shape as one that arrives on time.
    const result = wrapCommandReply(pending.command, rawResult);
    // No live resolve(): the command already settled, so a duplicate must not
    // clobber the terminal status already recorded. With ONE exception, which is
    // the whole of `found`: a command settled as `lost` was never decided, and a
    // reply proving it arrived after all is news rather than a duplicate.
    if (!pending.resolve) {
      if (pending.status.phase === "lost")
        this.handleFound(requestId, pending, result);
      return;
    }
    pending.cancelLossTimer?.();
    pending.cancelLossTimer = null;
    const resolve = pending.resolve;
    const reject = pending.reject;
    pending.resolve = null;
    pending.reject = null;

    // A well-formed refusal arrives on this channel, not as an `"error"`
    // message: the mod answers `CommandResult.Fail(code)` when the handler ran
    // and the game said no. Settling that as `confirmed` told the operator a
    // refused command had worked.
    const refusal = refusalOf(result);
    if (refusal !== null) {
      const { errorCode, reason, breach, detail } = refusal;
      pending.status = {
        phase: "refused",
        requestId,
        errorCode,
        reason,
        command: pending.command,
        args: pending.args,
        label: pending.label,
        breach,
        detail,
      };
      this.traceSettled(pending);
      reject?.(
        new CommandError(
          COMMAND_REFUSED,
          // Names what was refused. The code alone reads identically for every
          // refusal of every command in the mod, so an operator cannot tell
          // which control said no.
          `command ${JSON.stringify(pending.command)} refused: ${reason ?? errorCode}`,
          errorCode,
          {
            command: pending.command,
            args: pending.args,
            label: pending.label,
            breach,
            detail,
            reason,
          },
        ),
      );
      this.notifyStore();
      return;
    }

    pending.status = { phase: "confirmed", requestId, result };
    this.traceSettled(pending);
    resolve(result);
    this.notifyStore();
  }

  /**
   * An `error` frame that names the request it answers. The uncorrelated case
   * is routed to `warnConnectionError` before this is reached, so a missing
   * requestId can no longer arrive here and be silently dropped.
   */
  private handleCommandError(
    requestId: string,
    code: string,
    message: string,
  ): void {
    const pending = this.commands.get(requestId);
    if (!pending) return;
    this.outstandingDirty = true;
    // Same exception as `handleCommandResponse`, and it is not a lesser case: an
    // `error` frame correlated to this requestId is proof the mod RECEIVED the
    // command, so the silence was ours. What it went on to say is that the
    // machinery broke over there, which is news of its own.
    if (!pending.reject) {
      if (pending.status.phase === "lost") {
        pending.status = {
          phase: "found",
          requestId,
          outcome: "errored",
          error: { code, message },
        };
        this.traceSettled(pending);
        this.notifyStore();
      }
      return;
    }
    pending.cancelLossTimer?.();
    pending.cancelLossTimer = null;
    const reject = pending.reject;
    pending.status = { phase: "failed", requestId, error: { code, message } };
    this.traceSettled(pending);
    pending.resolve = null;
    pending.reject = null;
    reject(new CommandError(code, message));
    this.notifyStore();
  }

  /**
   * The mod's answer to a claim for a command it holds nothing for: the
   * command never arrived, or its answer expired or was pushed out. Nothing
   * more will come, so the command is no longer claimed or stored. One still in
   * flight is called lost, as it would be when its deadline passed; one already
   * lost stays lost.
   */
  private handleNoRecord(requestId: string, message: string): void {
    const pending = this.commands.get(requestId);
    if (!pending) return;
    pending.unclaimable = true;
    this.outstandingDirty = true;
    if (pending.status.phase === "in-flight") {
      this.handleLoss(requestId, "reply-not-received", message);
      return;
    }
    this.notifyStore();
  }

  /**
   * A command that was called lost, answered after all.
   *
   * Reached only from the two reply handlers, and only for an entry whose status
   * is still `lost`: a second late reply finds the entry at `found` and is
   * ignored by the same phase check, so this can no more run twice than the
   * settle path it mirrors.
   *
   * The promise is deliberately left alone. It rejected as `E_LOST` when the
   * deadline passed and that was true at the time, so re-settling it is both
   * impossible and unwanted; `resolve`/`reject` are already `null` by the time
   * anything gets here.
   *
   * The refusal split is the same one `handleCommandResponse` makes below,
   * because a refusal that arrives late is still the game's verdict and still
   * carries the only actionable half of the news.
   */
  private handleFound(
    requestId: string,
    pending: PendingCommand,
    result: unknown,
  ): void {
    const refusal = refusalOf(result);
    pending.status =
      refusal === null
        ? { phase: "found", requestId, outcome: "ran", result }
        : {
            phase: "found",
            requestId,
            outcome: "refused",
            errorCode: refusal.errorCode,
            reason: refusal.reason,
            breach: refusal.breach,
            detail: refusal.detail,
          };
    this.traceSettled(pending);
    this.notifyStore();
  }

  /**
   * The one place a command becomes `lost`, whichever of its two callers got
   * here first. A no-op if the command has already settled (or is unknown), the
   * timer is always cancelled on settle, but this guard covers the case where
   * cancellation and firing raced within the same clock-driven callback batch.
   *
   * - our own loss-inference timer reaching `etaConfirm + LOSS_MARGIN` with no
   *   response, which is the local case and the default reason
   * - a transport relaying someone else's verdict (`Transport.onLost`), which is
   *   how the host's loss reaches a station: the station's command is dispatched
   *   to the mod by the host, so the host's timer is the only one measuring that
   *   leg. A station arms its own off the relayed `comms.delay`, timing a
   *   different leg, so the two fire in either order and both must land here
   *
   * Terminal for the promise and not for the entry. The correlation record stays
   * in `commands`, so a reply arriving after this (the transport re-sends what it
   * queued while the socket was down, and a reply can simply be slow) still finds
   * its way home and moves the status to `found`. Nothing here tries to stop the
   * command executing: `lost` is our ignorance, not the game's answer.
   */
  private handleLoss(
    requestId: string,
    reason = "signal-lost",
    message = "command unconfirmed: no reply by the predicted time, it may still run",
  ): void {
    const pending = this.commands.get(requestId);
    if (!pending || pending.status.phase !== "in-flight") return;
    this.outstandingDirty = true;
    const reject = pending.reject;
    /*
     * A no-op when this IS the timer firing, and load-bearing when a relayed
     * loss beat our own deadline: the phase guard above would make the later
     * firing harmless, but the scheduled callback would still be holding a
     * command that is finished with.
     */
    pending.cancelLossTimer?.();
    pending.status = { phase: "lost", requestId, reason };
    this.traceSettled(pending);
    pending.resolve = null;
    pending.reject = null;
    pending.cancelLossTimer = null;
    reject?.(new CommandError(COMMAND_LOST, message));
    this.notifyStore();
  }

  /**
   * A command the transport is never going to send, because it has stopped
   * trying (`Transport.onUndelivered`).
   *
   * Reaches two different states and answers both, which is why it is not a
   * branch of the reply handlers:
   *
   * - the dispatch is still awaiting an answer, because nothing ever armed a
   *   loss timer for it (no delay authority, no transport prediction) or the
   *   deadline has not come round. Its promise is settled here, `failed` with
   *   `undelivered`: `failed` because nothing was decided over there, and a
   *   retry is safe rather than doubling anything
   * - the loss timer already called it `lost` and rejected. That promise is
   *   spent and is deliberately left alone, exactly as `handleFound` leaves it;
   *   what moves is the status, from "we do not know" to "it did not happen",
   *   which is the whole reason a stranded command cannot be answered on the
   *   error channel. `handleCommandError` reads an error correlated to a lost
   *   requestId as proof the mod heard us
   *
   * Any other phase is ignored. A confirmed, refused or found command was
   * answered by the far side and so plainly did leave; a second report for an
   * already-`undelivered` command changes nothing.
   */
  private handleUndelivered(requestId: string, reason: string): void {
    const pending = this.commands.get(requestId);
    if (!pending) return;
    this.outstandingDirty = true;
    const status: CommandStatus = { phase: "undelivered", requestId, reason };
    if (!pending.reject) {
      if (pending.status.phase !== "lost") return;
      pending.status = status;
      this.traceSettled(pending);
      this.notifyStore();
      return;
    }
    pending.cancelLossTimer?.();
    pending.cancelLossTimer = null;
    const reject = pending.reject;
    pending.status = status;
    this.traceSettled(pending);
    pending.resolve = null;
    pending.reject = null;
    reject(new CommandError(FaultCode.Undelivered, reason));
    this.notifyStore();
  }

  private traceSettled(pending: PendingCommand): void {
    traceCommandOutcome(pending.command, pending.label, pending.status);
  }

  private notifyStore(): void {
    if (this.outstandingDirty) this.flushOutstanding();
    for (const listener of this.storeListeners) listener();
  }

  /** Invoke a single subscriber callback, isolating one throw from the rest of fan-out. */
  private invokeCallback(
    cb: FrameCallback,
    payload: unknown,
    meta: Meta | undefined,
  ): void {
    try {
      cb(payload, meta);
    } catch (error) {
      // A throwing subscriber must not break delivery to sibling subscribers
      // or skip the store-notify that follows. TODO: route through the
      // shared logger once one exists for this package.
      console.error("TelemetryClient: subscriber callback threw", error);
    }
  }
}
