import type { ViewClockConfidence } from "./view-clock";

/**
 * The keyframe interval in UT seconds, 30, assumed for a Topic that declares
 * none. It is the interval after which a quiet channel is overdue and its
 * reading is marked held for the operator. Used by `HeartbeatTracker`, which
 * applies it to every Topic unless `HeartbeatTrackerOptions` overrides it.
 */
export const DEFAULT_KEYFRAME_INTERVAL_UT = 30;

/**
 * How many recent inter-arrival gaps `HeartbeatTracker` keeps per topic to
 * learn its cadence (finding B item 2). A small rolling window rather than
 * an all-time average: a channel's real cadence can be assumed roughly
 * stationary over this many arrivals, and a small window lets a genuine
 * cadence change (not just a one-off blackout) actually take effect instead
 * of being diluted forever by history from before the change.
 */
const LEARN_WINDOW = 5;

/**
 * Minimum observed gaps (i.e. `arrivals - 1`) before a learned interval is
 * trusted over the configured default (finding B item 2: "fall back to the
 * default until enough arrivals are seen"). Two gaps is the smallest sample
 * that still lets the median estimator (`medianOf`) be meaningfully
 * "middle" rather than just parroting the one gap seen so far.
 */
const MIN_GAPS_TO_LEARN = 2;

/** The middle value of `values` (average of the two middles for an even-length input), a robust central estimate that isn't dragged by a single outlier the way a mean would be, as long as it stays a minority of the window (finding B item 2: "don't let one long gap poison the learned interval"). */
function medianOf(values: readonly number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0
    ? (sorted[mid - 1] + sorted[mid]) / 2
    : sorted[mid];
}

export interface HeartbeatTrackerOptions {
  /** Fallback keyframe interval (UT seconds) for any topic not listed in `keyframeIntervalUt`. Default `DEFAULT_KEYFRAME_INTERVAL_UT`. */
  defaultKeyframeIntervalUt?: number;
  /** Per-topic keyframe interval (UT seconds) overrides. */
  keyframeIntervalUt?: Record<string, number>;
  /** Multiplier applied to the keyframe interval for the base margin (on top of one full interval of slack). Default 1. */
  marginMultiplier?: number;
  /** Extra flat UT-seconds of jitter allowance, added to the base margin regardless of confidence. Default 0. */
  jitterAllowanceUt?: number;
  /** Multiplier applied to the whole margin when `ViewClock.confidence()` is not `"locked"`, a degraded estimate widens the staleness window rather than false-flagging. Default 3. */
  degradedMarginMultiplier?: number;
}

/**
 * Infers, per Topic, when a channel has gone quiet. It records the UT at which
 * each sample arrived (`meta.deliveredAt`) and reports a Topic overdue once
 * the view UT passes `lastHeartbeatUt + keyframeInterval + margin`. Used by
 * the timeline store to mark a reading held.
 *
 * Only a gap in arrivals counts. `validAt` is never read: a channel whose
 * value has not changed for a long time, but whose keyframes keep arriving on
 * schedule, is not overdue.
 */
export class HeartbeatTracker {
  /*
   * **Deliberately never reads `validAt` anywhere in this file, it isn't even
   * a parameter of `noteArrival`.** That's the structural version of the
   * central warning: an old `validAt` on a change-gated channel is
   * normal... staleness comes from missed heartbeat keyframes... never from
   * `now - validAt`. A channel whose value hasn't changed
   * for a long time (a frozen/old `validAt`) but whose keyframes keep arriving
   * on schedule (a fresh `deliveredAt` every interval, a keyframe
   * unconditionally re-announces even an unchanged value) never gets flagged
   * here; only an actual gap in arrivals does. See `timeline-store.test.ts`'s
   * "the trap" describe block for the end-to-end proof.
   *
   * `deliveredAt` is used as the sole heartbeat signal rather than a
   * `lastPoint.validAt + interval + delaySeconds` sketch, because
   * `deliveredAt` for a given sample already is its post-delay
   * arrival UT: re-adding a separately-modeled `delaySeconds` on top would
   * double-count it, and anchoring on the actually-observed arrival is more
   * robust to delay changes mid-flight than re-deriving delay from a separate
   * authority every time.
   */
  private readonly lastHeartbeatUt = new Map<string, number>();
  /** The keyframe interval (UT seconds) the mod declared for a topic when it confirmed the subscribe. Survives `reset()`: it describes the channel, not the timeline. */
  private readonly declaredIntervalUt = new Map<string, number>();
  /** Rolling window of recent inter-arrival gaps (UT seconds) per topic, the raw material `intervalFor` learns a per-channel cadence from. Capped at `LEARN_WINDOW`, oldest dropped first. */
  private readonly recentGapsUt = new Map<string, number[]>();

  constructor(private readonly options: HeartbeatTrackerOptions = {}) {}

  /**
   * Record a confirmed arrival for `topic` at `deliveredAt` (UT). Call this
   * for every ingested sample on the topic, keyframe or change-emission
   * alike, both count: a change emission also confirms the link is alive,
   * exactly like a keyframe would. Out-of-order arrivals never move the
   * tracked heartbeat backwards, and: since they're not a genuine forward
   * gap: never feed the adaptive cadence learner either.
   */
  noteArrival(topic: string, deliveredAt: number): void {
    const prev = this.lastHeartbeatUt.get(topic);
    if (prev === undefined || deliveredAt > prev) {
      if (prev !== undefined) this.recordGap(topic, deliveredAt - prev);
      this.lastHeartbeatUt.set(topic, deliveredAt);
    }
  }

  /**
   * Record the keyframe interval (UT seconds) the mod declared for `topic`.
   * It is the least gap `intervalFor` will expect, so a change-driven topic
   * that just sent a burst of one-second emissions is not read as overdue
   * until it has been silent past its keyframe. A value that is not a finite
   * positive number is ignored: an absent declaration is unknown, never zero.
   */
  declareKeyframeInterval(topic: string, intervalUt: unknown): void {
    if (
      typeof intervalUt !== "number" ||
      !Number.isFinite(intervalUt) ||
      intervalUt <= 0
    ) {
      return;
    }
    this.declaredIntervalUt.set(topic, intervalUt);
  }

  /**
   * Drop every tracked heartbeat and every learned cadence. Call on an epoch
   * bump (quickload rewind) so pre-reset heartbeat/cadence history can't
   * leak a wrong-epoch expectation into the resynchronizing period that
   * follows (mirrors `ClientTimeline`'s own per-epoch point drop, applied to
   * this tracker's per-topic maps instead). Declared keyframe intervals are
   * kept.
   */
  reset(): void {
    this.lastHeartbeatUt.clear();
    this.recentGapsUt.clear();
  }

  /**
   * The keyframe interval (UT seconds) this tracker uses for `topic`,
   * the adaptive cadence. Precedence, most to least
   * authoritative:
   * 1. An explicit per-topic `keyframeIntervalUt` override: a caller that
   *    declared one always wins, learned or not.
   * 2. The learned interval (`medianOf` of `recentGapsUt`), once at least
   *    `MIN_GAPS_TO_LEARN` genuine forward gaps have been observed for this
   *    topic, or else the configured/default fallback for a topic with too
   *    little history to trust yet (cold start, or right after a `reset()`).
   *    Not less than the keyframe interval the mod declared for the topic
   *    (`declareKeyframeInterval`): a burst of change emissions says nothing
   *    about how long the channel may stay quiet.
   */
  intervalFor(topic: string): number {
    const explicit = this.options.keyframeIntervalUt?.[topic];
    if (explicit !== undefined) return explicit;

    const observed =
      this.learnedIntervalFor(topic) ??
      this.options.defaultKeyframeIntervalUt ??
      DEFAULT_KEYFRAME_INTERVAL_UT;
    return Math.max(observed, this.declaredIntervalUt.get(topic) ?? 0);
  }

  /** The learned interval for `topic`, or `undefined` if too few gaps have been observed yet to trust it (see `intervalFor`'s doc). */
  private learnedIntervalFor(topic: string): number | undefined {
    const gaps = this.recentGapsUt.get(topic);
    if (!gaps || gaps.length < MIN_GAPS_TO_LEARN) return undefined;
    return medianOf(gaps);
  }

  /** Append one observed inter-arrival gap to `topic`'s rolling window, evicting the oldest once it exceeds `LEARN_WINDOW`. */
  private recordGap(topic: string, gapUt: number): void {
    let gaps = this.recentGapsUt.get(topic);
    if (!gaps) {
      gaps = [];
      this.recentGapsUt.set(topic, gaps);
    }
    gaps.push(gapUt);
    if (gaps.length > LEARN_WINDOW) gaps.shift();
  }

  /**
   * The staleness margin (UT seconds) added on top of the raw keyframe
   * interval before a missed heartbeat is flagged, confidence-scaled.
   * Exposed publicly (not just folded into `isOverdue`) so
   * tests can assert directly that the margin widens under a degraded
   * estimate.
   */
  marginUt(
    topic: string,
    confidence: ViewClockConfidence,
    floorGapUt = 0,
  ): number {
    const interval = Math.max(this.intervalFor(topic), floorGapUt);
    const base =
      interval * (this.options.marginMultiplier ?? 1) +
      (this.options.jitterAllowanceUt ?? 0);
    return confidence === "locked"
      ? base
      : base * (this.options.degradedMarginMultiplier ?? 3);
  }

  /**
   * Has `topic` missed its expected next heartbeat as of `viewUt`? A topic
   * with no recorded arrival at all is not reported overdue here, that's
   * the `"resyncing"` case (no point at all), handled one layer up in
   * `TimelineStore.sampleStatus`; a heartbeat miss is specifically about a
   * topic we have heard from before going quiet.
   *
   * `floorGapUt` is the least UT the mod leaves between two keyframes at the
   * current warp: its real-time keyframe floor times the warp rate. The
   * learned cadence can be far shorter, because it was learned at a lower
   * warp, and without the floor a quiet channel reads overdue the moment warp
   * steps up and until the new gaps are learned. The expected interval is
   * whichever is longer.
   */
  isOverdue(
    topic: string,
    viewUt: number,
    confidence: ViewClockConfidence,
    floorGapUt = 0,
  ): boolean {
    const last = this.lastHeartbeatUt.get(topic);
    if (last === undefined) return false;
    const interval = Math.max(this.intervalFor(topic), floorGapUt);
    return (
      viewUt > last + interval + this.marginUt(topic, confidence, floorGapUt)
    );
  }
}
