import { rotateInertialToPerifocal, solve } from "./kepler";
import { buildElements, type WireOrbitElements } from "./kepler-reckoning";
import type { TrajectoryPoint } from "./orbit-trajectory";

/**
 * One `vessel.orbit` sample and the instant it was true. Useful for rebuilding
 * where the vessel has been. Taken by {@link pastTrack}. A `null` payload is a
 * tombstone: the vessel had no orbit then (on the pad).
 */
export interface OrbitSample {
  payload: (WireOrbitElements & { referenceBodyIndex?: number }) | null;
  validAt: number;
}

/**
 * Where the vessel has been, as points solved from the orbit samples received
 * for each instant. Useful for showing the operator the trail behind the vessel.
 * Used by the orbit diagram, which draws it differently from the predicted arc
 * ahead.
 *
 * It is a record of what was reported, never the current elements run backwards.
 * The points are expressed in the perifocal frame of `frame`, the elements the
 * diagram was drawn from. `frame` is required and has no default.
 */
export function pastTrack(
  samples: readonly OrbitSample[],
  options: {
    /**
     * The elements whose perifocal frame the points come back in. The same ones
     * the diagram was drawn from, never the sample's own: osculating elements
     * drift, and a point placed in the frame belonging to its own instant would
     * put every point in a slightly different frame from its neighbour.
     */
    frame: WireOrbitElements;
    centreBodyIndex?: number;
  },
): TrajectoryPoint[] {
  /*
   * **Observed, not propagated backwards.** Each point is solved from the
   * elements that arrived for that instant, so the trail is a record of what was
   * reported rather than a model of what must have happened. Running the current
   * elements backwards would be a different claim and a wrong one under an n-body
   * force model, where the path does not retrace: the craft's real past is only
   * recoverable from what was measured, and that is exactly what the store
   * holds.
   *
   * This is why the forward arc and the trail must be drawn differently. One
   * is a prediction and one is a record, and a single unbroken curve through the
   * craft would assert the same confidence in both.
   *
   * **Expressed in `frame`'s perifocal frame, and that argument is required
   * for a reason.** Each point is solved from its own sample, which is what
   * makes the trail a record, and a solve hands back a body-centred inertial
   * position. The arc it is drawn beside is in the perifocal frame of the elements
   * the diagram was drawn from, so a trail left inertial is a curve of the right
   * shape and the right size sitting rotated away from the path the craft is on by
   * that orbit's own three angles, and out of its plane entirely once the orbit is
   * tilted. Nothing about it looks wrong. Defaulting the frame would let the next
   * caller inherit that silently, so there is no default: naming the elements the
   * points are to be read against is part of asking for them.
   */
  const into = buildElements(options.frame);
  const points: TrajectoryPoint[] = [];
  for (const sample of samples) {
    // A tombstone breaks the trail the way a change of body does: nothing joins across an instant with no orbit.
    if (sample.payload === null) {
      points.length = 0;
      continue;
    }

    // A sample taken about a DIFFERENT body is a different frame, and joining
    // the two would draw a line across the gap between them. A craft that
    // changed sphere of influence has a trail that starts at the transition,
    // which is the truth about what this frame can show.
    if (
      options.centreBodyIndex !== undefined &&
      sample.payload.referenceBodyIndex !== undefined &&
      sample.payload.referenceBodyIndex !== options.centreBodyIndex
    ) {
      points.length = 0;
      continue;
    }

    const elements = buildElements(sample.payload);
    const closed = elements.ecc >= 0 && elements.ecc < 1 && elements.sma > 0;
    const open = elements.ecc > 1 && elements.sma < 0;
    if (!(closed || open) || !Number.isFinite(elements.mu)) {
      // A parabolic orbit has no solution here, and a sample that arrived
      // incomplete cannot be placed. Dropping the point keeps the trail
      // honest about which instants it can speak for.
      continue;
    }

    const [x, y, z] = rotateInertialToPerifocal(
      solve(elements, sample.validAt).position,
      into.inc,
      into.lan,
      into.argPe,
    );
    points.push({ x, y, z, ut: sample.validAt });
  }
  return points;
}
