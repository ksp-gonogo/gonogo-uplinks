import { useMemo } from "react";
import { parentOf } from "./catalogue-elements";
import type { CelestialFacts } from "./celestial-facts";
import {
  bodyOrbitInput,
  type OrbitTrajectory,
  type OrbitTrajectoryInput,
} from "./orbit-trajectory";
import { useOrbitTrajectory } from "./use-orbit-trajectory";

/**
 * Whose path to ask for. Useful for drawing the orbit of either a catalogue body
 * or elements you already hold. Taken by {@link useOrbitCurve}.
 *
 * - `body`: a catalogue body's orbit about its parent, with the horizon its own
 *   provider stated
 * - `orbit`: elements you already hold, a whole `vessel.orbit`-shaped payload with
 *   its horizon, as {@link useOrbitTrajectory} takes them
 *
 * @category Frames of reference
 */
export type OrbitCurveSubject =
  | {
      /** A body's own orbit around its parent. */
      kind: "body";
      /** The system's celestial facts, or `undefined` before they arrive. */
      facts: CelestialFacts | undefined;
      /** The body's index in `trackingStation.bodies`. */
      index: number;
    }
  | {
      /** An orbit given directly, such as a craft's. */
      kind: "orbit";
      /** The orbit's elements, or `undefined` before they arrive. */
      orbit: OrbitTrajectoryInput["orbit"] | undefined;
    };

/**
 * How a subject's path may be drawn at the instant on screen: a conic, the arc its
 * provider vouched for, or a refusal with its reason, as {@link useOrbitTrajectory}
 * answers for a vessel. Useful for drawing the orbit of a body or of elements you
 * already hold. The answer is held for each whole second of the view instant.
 *
 * `null` means the question could not be put: no clock, no catalogue yet, the root
 * star, or a body whose elements are not filled.
 *
 * @category Frames of reference
 */
export function useOrbitCurve(
  subject: OrbitCurveSubject,
  options?: Pick<OrbitTrajectoryInput, "samples" | "readFrame">,
): OrbitTrajectory | null {
  const facts = subject.kind === "body" ? subject.facts : undefined;
  const index = subject.kind === "body" ? subject.index : -1;
  const bodyOrbit = useMemo(() => {
    const body = facts?.bodies.find((b) => b.index === index);
    if (facts === undefined || body === undefined) return null;
    return bodyOrbitInput(body, parentOf(facts, body));
  }, [facts, index]);
  const orbit = subject.kind === "body" ? bodyOrbit : subject.orbit;
  return useOrbitTrajectory(orbit ?? undefined, options);
}
