import { useCallback, useEffect, useRef, useState } from "react";
import {
  type CommsDelayLike,
  deriveRailEntry,
  type InFlightCommand,
  liveOneWaySeconds,
  type RailCrossing,
} from "../command-delay";
import { type RailTags, railTagsForTelemetry } from "../rail-tags";
import { type Value, value } from "../unit-system";
import { useTelemetryStoreOptional } from "./context";
import { useLatestValue } from "./use-stream";

/**
 * A transmission the vessel has sent, as the caller learned of it. Passed to
 * `expect` on the result of `useTransmissions`.
 */
export interface SentTransmission {
  /** What the rail row calls it, e.g. the result's title. */
  label: string;
  /** What is being carried, e.g. the research subject's id. */
  subject: string;
  /** The instant the whole transmission has left the craft. */
  sentAt: Value<"ut">;
}

/**
 * The transmissions crossing from the vessel to the command centre, in the
 * shape of a delay-rail entry. Hand it to ui-kit's `useRailEntry` and the rail
 * draws each transmission as a row, the same as for a command. Returned by
 * `useTransmissions`.
 */
export interface UseTransmissionsResult {
  inFlight: InFlightCommand[];
  tags: RailTags;
  /** The live one-way delay home, `null` when there is none to have. */
  effectiveDelaySeconds: number | null;
  /**
   * Put a transmission on the rail. It crosses under the one-way delay live at
   * this moment, frozen as a queued command's is at dispatch, and leaves the
   * rail when it arrives. With no live delay there is nothing to place it on,
   * so it is not drawn.
   */
  expect(transmission: SentTransmission): void;
}

/** A crossing with the timeline epoch it was expected under; a load that starts a new epoch undoes it. */
interface EpochedCrossing {
  crossing: RailCrossing;
  epoch: number;
}

const TRANSMISSION_TAGS = railTagsForTelemetry("event");
const NO_IN_FLIGHT: InFlightCommand[] = [];
const REREAD_MS = 1000;

/**
 * The transmissions the vessel has sent that have not yet reached the command
 * centre, as delay-rail entries. Useful for showing the operator how long a
 * sent result, such as a science report, still has to travel. Used by the
 * experiments widget.
 *
 * A transmission is sent and never answered, so its row ends at arrival and
 * does not become an outcome.
 */
export function useTransmissions(): UseTransmissionsResult {
  // gonogo:reads none
  const store = useTelemetryStoreOptional();
  const commsDelay = useLatestValue<CommsDelayLike>("comms.delay");
  const oneWay = liveOneWaySeconds(commsDelay);
  const oneWayRef = useRef(oneWay);
  oneWayRef.current = oneWay;
  const [crossings, setCrossings] = useState<EpochedCrossing[]>([]);
  const nextId = useRef(0);
  const [, setReread] = useState(0);

  const expect = useCallback(
    (transmission: SentTransmission) => {
      const oneWaySeconds = oneWayRef.current;
      if (oneWaySeconds === null) return;
      nextId.current += 1;
      const crossing: RailCrossing = {
        id: `transmission-${nextId.current}`,
        label: transmission.label,
        command: transmission.subject,
        topic: "",
        tags: TRANSMISSION_TAGS,
        sentAt: transmission.sentAt,
        oneWaySeconds: value("s", oneWaySeconds),
      };
      setCrossings((prev) => [
        ...prev,
        { crossing, epoch: store?.clock.getEpoch() ?? 0 },
      ]);
    },
    [store],
  );

  // Nothing else re-renders this hook when a row arrives, so it re-reads the clock while anything is crossing.
  const crossing = crossings.length > 0;
  useEffect(() => {
    if (!crossing) return;
    const timer = setInterval(() => {
      const now = store?.clock.utNowEstimate() ?? 0;
      const epoch = store?.clock.getEpoch() ?? 0;
      setCrossings((prev) => {
        const keep = prev.filter(
          (c) =>
            c.epoch === epoch && deriveRailEntry(c.crossing, now) !== undefined,
        );
        return keep.length === prev.length ? prev : keep;
      });
      setReread((n) => n + 1);
    }, REREAD_MS);
    return () => clearInterval(timer);
  }, [crossing, store]);

  const nowUt = store?.clock.utNowEstimate() ?? 0;
  const epoch = store?.clock.getEpoch() ?? 0;
  const rows = crossings.flatMap((c) =>
    c.epoch === epoch ? (deriveRailEntry(c.crossing, nowUt) ?? []) : [],
  );
  return {
    inFlight: rows.length > 0 ? rows : NO_IN_FLIGHT,
    tags: TRANSMISSION_TAGS,
    effectiveDelaySeconds: oneWay,
    expect,
  };
}
