import type { DelayLane } from "../delay-roles";
import { SampleStepTracker } from "../sample-step-tracker";
import {
  type ClockFormulaInputs,
  type ClockFormulaSnapshot,
  computeConfirmedEdgeUt,
  computeUtNowEstimate,
} from "../view-clock-formula";

export type { DelayLane } from "../delay-roles";
export type {
  ClockFormulaInputs,
  ClockFormulaSnapshot,
} from "../view-clock-formula";

/**
 * The signal delay, in seconds, below which SCET (the instant a vessel sent a
 * reading) and the received clock (the instant the command centre gets it) are
 * the same instant as far as anything on screen can show, because instants are
 * printed to the whole second. Useful for deciding whether to show the operator
 * both clocks or only one. Used by the time-context hook and by the check that
 * decides when a reading is shown beyond what has been received.
 *
 * @category Stream fixture
 */
export const VISIBLE_GAP_SECONDS = 1;

/**
 * Whether a reading sits at or before the certainty horizon (`"confirmed"`: a
 * delivered sample, or an interpolation between two of them) or past it
 * (`"predicted"`: a propagated or held-last estimate). Useful for showing the
 * operator whether a figure on screen was delivered by the vessel or is
 * estimated. Used by the certainty hook, and returned by the timeline store's
 * `sampleCertainty`.
 */
export type Certainty = "confirmed" | "predicted";

/**
 * How well the view clock can currently estimate game time: `"locked"` while
 * samples keep arriving, `"coasting"` after a stretch of silence from the
 * vessel, and `"degraded"` when a warp-rate change was detected during silence.
 * Useful for showing the operator how far to trust a time estimate. Used by the
 * heartbeat tracker, which widens its hold margins with it. Only `"locked"` and
 * `"coasting"` are reported today.
 */
export type ViewClockConfidence = "locked" | "coasting" | "degraded";

export interface ViewClockOptions {
  /** One delay authority: the default is a fixed/zero delay; a real `DelayAuthority` can be swapped in. */
  delaySeconds?: () => number;
  /** A count that rises when the delay was a stand-in and a measured figure has replaced it: the view then starts afresh at that figure instead of holding for one delay. Default none. */
  delayEpoch?: () => number;
  /** The game's nominal UT per wall second: its warp rate, 0 while paused. Default 1. The clock scales it by the pace it measures from live deliveries, so a game running slower than its warp rate is followed at the speed it really runs. */
  warpRate?: () => number;
  /** Injectable wall clock (seconds), defaulting to `performance.now() / 1000`. Tests inject a controllable one. */
  nowWall?: () => number;
  /** Small slack added to the sample-clamp side of `confirmedEdgeUt`'s min(). Default 0; keep the clamp tight/exact for testability; a later task may widen it for jitter tolerance. */
  slackSeconds?: number;
  /** Wall-seconds of silence (no `observeSample`) before `confidence()` reports `"coasting"`. Default 5. */
  coastingAfterSeconds?: number;
}

/** Shortest wall-clock span over which the game's own rate is measured, long enough that a physics tick's rounding of `deliveredAt` stays under half a percent. */
const RATE_WINDOW_SECONDS = 10;

/**
 * The range of game-to-nominal rate a measurement may report and still be
 * believed. Outside it the span held something other than a running game: a
 * pause the warp state had not reported yet, or a burst of frames held up in
 * transit.
 */
const MIN_RATE_RATIO = 0.25;
const MAX_RATE_RATIO = 4;

function defaultNowWall(): number {
  return performance.now() / 1000;
}

type FrameTickHandle =
  | { kind: "raf"; id: number }
  | { kind: "timer"; id: ReturnType<typeof setTimeout> };

/**
 * The instant the dashboard is showing, one per client: an estimate of game time
 * in UT, advanced by the wall clock, and held back to the delay between the
 * vessel and the command centre. Useful for keeping every widget on screen at
 * the same moment of the mission. Created by `TelemetryProvider`, which hands it
 * to widgets through the hooks that read the view time.
 *
 * It never shows past what has arrived: `confirmedEdgeUt()` is held at the
 * latest sample instant actually observed, so a wrong estimate makes the view
 * lag and never run ahead of the data.
 *
 * A rewind, seen as a new `epoch` passed to `observeSample`, starts the
 * estimate afresh and drops samples from before it.
 *
 * @category Stream fixture
 */
export class ViewClock {
  private epoch = 0;
  private anchorWall: number | undefined;
  private anchorUt: number | undefined;
  private maxSampleUt = Number.NEGATIVE_INFINITY;
  private readonly sampleSteps = new SampleStepTracker();
  private lastObservedWall: number | undefined;
  /**
   * Monotonic cursor behind {@link viewUt}, kept apart from {@link scetUt}'s so
   * a present that runs ahead can never pin the received edge ahead of what
   * has been delivered.
   *
   * One per lane, because the two cursors run a whole signal delay apart: a
   * shared one would let the first true-now read of a frame pin the delayed
   * cursor at true now, and every delayed topic would then be read a signal delay
   * into its own future, which is the failure the delay clock exists to
   * prevent.
   */
  private readonly lastConfirmedViewUt: Record<DelayLane, number> = {
    delayed: Number.NEGATIVE_INFINITY,
    "true-now": Number.NEGATIVE_INFINITY,
  };
  /** Monotonic cursor for {@link scetUt}, reset with the others on an epoch bump. */
  private lastScetUt = Number.NEGATIVE_INFINITY;
  /**
   * The game's measured pace as a fraction of its nominal warp rate. A game
   * the machine cannot keep up with runs slower than its warp rate says, and
   * an estimate carried forward at the nominal rate through a silence (a loss
   * of signal, where the craft's own readings stop) runs ahead of the game by
   * the difference, so the view would show instants light has not yet carried.
   */
  private rateRatio = 1;
  /** The live delivery the current rate measurement started from, with the nominal rate in force then. */
  private rateFrom: { wall: number; ut: number; warp: number } | undefined;
  /** Manual history-scrub target, `null` = live. Set via `scrubTo`. */
  private scrubTarget: number | null = null;

  /** Every live `onFrame` callback: one shared loop notifies the lot. */
  private readonly frameSubscribers = new Set<(viewUt: number) => void>();
  /** The one pending tick, tagged with the scheduler that minted it so cancelling matches. */
  private frameHandle: FrameTickHandle | undefined;
  /** Set by `suspendFrames`: the loop stays stopped and only `emitFrame` mints frames. */
  private framesSuspended = false;

  constructor(private readonly options: ViewClockOptions = {}) {}

  /**
   * Feed one delivered sample's timing into the UT↔wall fit and the sample
   * clamp. Call this for every delivered sample on every topic (not just
   * one): it's what lets `confirmedEdgeUt` know "the max buffered sample
   * UT" without itself owning any per-topic buffer.
   */
  observeSample(
    validAt: number,
    deliveredAt: number,
    epoch = 0,
    replayed = false,
  ): void {
    if (epoch < this.epoch) return; // stale-epoch straggler, discard
    if (epoch > this.epoch) {
      this.epoch = epoch;
      this.maxSampleUt = Number.NEGATIVE_INFINITY;
      this.sampleSteps.reset();
      this.lastConfirmedViewUt.delayed = Number.NEGATIVE_INFINITY;
      this.lastConfirmedViewUt["true-now"] = Number.NEGATIVE_INFINITY;
      this.lastScetUt = Number.NEGATIVE_INFINITY;
      this.anchorWall = undefined;
      this.anchorUt = undefined;
      this.rateFrom = undefined;
      // A scrub target from the dead pre-rewind timeline must not survive, same per-epoch hygiene as every other reset here.
      this.scrubTarget = null;
    }

    const wallNow = this.now();
    /*
     * A replayed sample describes the past, so it anchors the estimate only
     * when nothing anchors it yet or it is the newest delivery seen. Taken
     * after newer samples it would pull the horizon back behind them. It still
     * proves the link is alive.
     */
    if (
      !replayed ||
      this.anchorUt === undefined ||
      deliveredAt >= this.anchorUt
    ) {
      this.anchorWall = wallNow;
      this.anchorUt = deliveredAt;
    }
    if (!replayed) this.measureRate(wallNow, deliveredAt);
    this.lastObservedWall = wallNow;
    if (validAt > this.maxSampleUt) this.maxSampleUt = validAt;
    this.sampleSteps.observe(this.maxSampleUt, wallNow);
  }

  /*
   * One live delivery's contribution to the measured game rate: the UT the
   * game advanced over at least RATE_WINDOW_SECONDS of wall time, against the
   * nominal rate. A change of nominal rate (a warp step, a pause) starts the
   * span again, since a span across it measures neither rate.
   */
  private measureRate(wallNow: number, deliveredAt: number): void {
    const warp = this.nominalWarpRate();
    const from = this.rateFrom;
    if (
      from === undefined ||
      warp <= 0 ||
      warp !== from.warp ||
      deliveredAt < from.ut
    ) {
      this.rateFrom = { wall: wallNow, ut: deliveredAt, warp };
      return;
    }
    const wallSpan = wallNow - from.wall;
    if (wallSpan < RATE_WINDOW_SECONDS) return;
    const ratio = (deliveredAt - from.ut) / wallSpan / warp;
    if (ratio >= MIN_RATE_RATIO && ratio <= MAX_RATE_RATIO) {
      this.rateRatio = ratio;
    }
    this.rateFrom = { wall: wallNow, ut: deliveredAt, warp };
  }

  /** How often the latest sample time advances, in wall-clock seconds, or `undefined` until two advances have been seen. */
  sampleStepSeconds(): number | undefined {
    return this.sampleSteps.stepSeconds();
  }

  /** The client's epoch generation: bumped by `observeSample` on a rewind. Read-only mirror of `ClientTimeline.epoch`'s reset generation. */
  getEpoch(): number {
    return this.epoch;
  }

  /** One delay authority: feeds media release too. */
  delaySeconds(): number {
    return this.options.delaySeconds?.() ?? 0;
  }

  /** Estimated "vessel now": a piecewise-linear UT(wall) fit, coasting
   *  between observations at the game's own measured rate. Delegates to the shared
   *  pure formula (`view-clock-formula.ts`) so a second context (the
   *  kerbcast per-frame video-delay worker) can mirror this exactly; see
   *  that module's doc. */
  utNowEstimate(): number {
    return computeUtNowEstimate(this.formulaInputs(), this.now());
  }

  /**
   * The certainty horizon: `min(utNowEstimate() - delaySeconds(),
   * maxBufferedSampleUt + slack)`. Never ahead of the max sample UT actually
   * observed; see the class doc. Returns `-Infinity` before any sample has ever
   * been observed (nothing confirmed yet: the "resynchronizing" state after a
   * rewind). Delegates to the shared pure formula: see `utNowEstimate()`'s doc.
   */
  confirmedEdgeUt(lane: DelayLane = "delayed"): number {
    return computeConfirmedEdgeUt(this.formulaInputs(lane), this.now());
  }

  /** This clock's formula inputs, as of right now, the shared shape both
   *  `utNowEstimate`/`confirmedEdgeUt` (via `view-clock-formula.ts`) and
   *  `snapshot()` (below) read from, so the two can never drift apart.
   *
   *  The lane is the whole of the difference between the two horizons: a
   *  true-now read is the same formula with no delay subtracted, so it stays
   *  clamped to the max sample UT actually observed exactly like the delayed
   *  one. That clamp is why this is safe before any true-now channel has
   *  arrived: with nothing newer delivered, the lane is held at the delayed
   *  edge rather than running ahead of the wire. */
  private formulaInputs(lane: DelayLane = "delayed"): ClockFormulaInputs {
    return {
      anchorWall: this.anchorWall,
      anchorUt: this.anchorUt,
      maxSampleUt: this.maxSampleUt,
      delaySeconds: lane === "true-now" ? 0 : this.delaySeconds(),
      warpRate: this.warpRate(),
      slackSeconds: this.options.slackSeconds ?? 0,
    };
  }

  /**
   * Serializable snapshot of this clock's formula inputs, for a second
   * context to mirror `confirmedEdgeUt()`/`utNowEstimate()` locally against
   * its own wall clock, such as a video-delay worker. The
   * receiving side evaluates the exact same `view-clock-formula.ts`
   * functions this class uses, so there is one implementation, never a
   * fork. `epoch` lets a snapshot from an earlier epoch be discarded the same way
   * `observeSample` discards a straggler from before a rewind.
   */
  snapshot(): ClockFormulaSnapshot {
    return { epoch: this.epoch, ...this.formulaInputs() };
  }

  /**
   * The certainty horizon: a first-class alias for
   * `confirmedEdgeUt()`. A `viewUt` at-or-before this is confirmed (a
   * delivered sample or an honest interpolation between two of them);
   * strictly after it is predicted (propagated / held-last). It's the exact
   * same sample-clamped quantity as `confirmedEdgeUt()`: exposed under its
   * own name because callers (the SDK surface, `TimelineStore.beginFrame`'s
   * per-frame certainty classification) reason about it as a first-class
   * value, not as "confirmedEdgeUt renamed".
   */
  certaintyHorizonUt(lane: DelayLane = "delayed"): number {
    return this.confirmedEdgeUt(lane);
  }

  /** Classify `ut` against the certainty horizon: `<=` is confirmed, matching `viewUt() === confirmedEdgeUt()` exactly (never falsely "predicted" while merely tracking live). Classified against the same lane the `ut` was drawn from, or a true-now read lands a signal delay past the delayed horizon and every one of them reports `"predicted"`. */
  certaintyFor(ut: number, lane: DelayLane = "delayed"): Certainty {
    return ut <= this.certaintyHorizonUt(lane) ? "confirmed" : "predicted";
  }

  /**
   * Manual history scrub: pins `viewUt()` to `ut`, for exploring history (a
   * scrub bar). The live cursor keeps advancing underneath while scrubbed (the
   * confirmed edge and the estimate both keep updating from `observeSample`
   * and wall-clock flow): so `scrubTo(null)` resumes live tracking with a
   * monotonic catch-up, picking up wherever the live cursor has reached by
   * then, never a backward jump. Cleared automatically on an epoch bump
   * (see `observeSample`): a scrub target from a dead timeline must not
   * survive a rewind.
   */
  scrubTo(ut: number | null): void {
    this.scrubTarget = ut;
  }

  /**
   * The view time: every read in a frame uses this (via the frozen
   * `FrameToken`, see `timeline-store.ts`).
   *
   * - **Live**: tracks `confirmedEdgeUt()`, monotonic non-decreasing within
   *   an epoch (mirrors `Archive.ReadAtVantage`'s cursor clamp server-side):
   *   the cursor resets to `-Infinity` on an epoch bump via `observeSample`,
   *   so "monotonic" is scoped per-epoch, not across a rewind.
   * - **Scrubbed**: `scrubTo`'s target wins outright, but the live cursor
   *   still advances underneath (see `scrubTo`'s doc).
   *
   * The lane picks which of the two confirmed edges is tracked, and the store
   * asks for whichever one the topic being read declared. It changes nothing
   * while scrubbed, where a scrub target is a past instant both lanes agree on.
   */
  viewUt(lane: DelayLane = "delayed"): number {
    this.rebaseOnDelayEpoch();
    const live = Math.max(
      this.lastConfirmedViewUt[lane],
      this.confirmedEdgeUt(lane),
    );
    this.lastConfirmedViewUt[lane] = live;
    return this.scrubTarget !== null ? this.scrubTarget : live;
  }

  private seenDelayEpoch: number | undefined;

  /*
   * The monotonic cursor never lets the view fall back, so a delay that grows
   * from a stand-in zero to its measured size would hold the view for the whole
   * of that size. The stand-in was never a lag the view had, so the cursors
   * start again when the figure replaces it.
   */
  private rebaseOnDelayEpoch(): void {
    const epoch = this.options.delayEpoch?.();
    if (epoch === undefined) return;
    if (this.seenDelayEpoch !== undefined && epoch !== this.seenDelayEpoch) {
      this.lastConfirmedViewUt.delayed = Number.NEGATIVE_INFINITY;
      this.lastConfirmedViewUt["true-now"] = Number.NEGATIVE_INFINITY;
    }
    this.seenDelayEpoch = epoch;
  }

  /**
   * The craft's present (SCET) for a frame whose delayed view time is `viewUt`:
   * the instant every reading is reckoned to.
   *
   * - Never behind `viewUt`, and monotonic within an epoch, because the estimate
   *   re-anchors on each delivery and can step back
   * - `viewUt` itself while scrubbed, since history is observed rather than
   *   modelled
   * - `viewUt` itself when the signal delay is under one second
   *   (`VISIBLE_GAP_SECONDS`), where the two clocks read the same on screen,
   *   and before anything has been received
   */
  scetUt(viewUt: number): number {
    if (!Number.isFinite(viewUt)) return viewUt;
    if (this.scrubTarget !== null) return viewUt;
    if (this.delaySeconds() < VISIBLE_GAP_SECONDS) return viewUt;
    const scet = Math.max(this.lastScetUt, this.utNowEstimate(), viewUt);
    this.lastScetUt = scet;
    return scet;
  }

  /**
   * When a command sent now reaches the craft: {@link scetUt} plus the one-way
   * signal delay, for a surface that plans what a command will find on arrival.
   * The SCET itself while scrubbed, where nothing is being sent.
   */
  commandArrivalUt(scetUt: number): number {
    if (!Number.isFinite(scetUt)) return scetUt;
    if (this.scrubTarget !== null) return scetUt;
    return scetUt + this.delaySeconds();
  }

  /** Estimator health: `"locked"` recently observed, `"coasting"` during silence. `"degraded"` (warp-change-during-silence) is a later task. */
  confidence(): ViewClockConfidence {
    if (this.lastObservedWall === undefined) return "coasting";
    const silence = this.now() - this.lastObservedWall;
    return silence > (this.options.coastingAfterSeconds ?? 5)
      ? "coasting"
      : "locked";
  }

  /**
   * Best-effort per-frame notification, driven by `requestAnimationFrame`
   * when available (browser) and a ~60Hz timer fallback otherwise (SSR/test
   * environments without rAF). Not what enforces the single-view-time
   * invariant: that's `TimelineStore`'s frozen `FrameToken` (structural);
   * this is just a convenience scheduling hook for callers that want to
   * drive `TimelineStore.beginFrame()` from wall-clock frames.
   *
   * One loop serves every subscriber, so the whole tree sees the same frame
   * rather than one animation-frame loop per `useViewUt`. The loop starts on
   * the first subscription and stops on the last unsubscribe, and
   * {@link suspendFrames} stops it without disturbing who is subscribed.
   */
  onFrame(cb: (viewUt: number) => void): () => void {
    this.frameSubscribers.add(cb);
    this.scheduleFrameTick();
    return () => {
      this.frameSubscribers.delete(cb);
      if (this.frameSubscribers.size === 0) this.cancelFrameTick();
    };
  }

  /**
   * Notify every {@link onFrame} subscriber once, synchronously, off whatever
   * the caller is doing rather than off an animation frame.
   *
   * Written for tests that have called {@link suspendFrames}: a mount driven
   * by explicit frames settles the same way on every machine, where one racing
   * a live loop settles only when the loop happens to lose. Safe alongside a
   * running loop too (a frame is idempotent), it just isn't useful there.
   */
  emitFrame(): void {
    if (this.frameSubscribers.size === 0) return;
    const ut = this.viewUt();
    /*
     * Snapshot, then re-check membership: a callback is free to subscribe or
     * unsubscribe from inside the frame (a React effect cleanup does exactly
     * that), and one unsubscribed earlier in this same frame must not be called.
     */
    for (const cb of Array.from(this.frameSubscribers)) {
      if (this.frameSubscribers.has(cb)) cb(ut);
    }
  }

  /**
   * Stop minting frames until {@link resumeFrames}. Subscriptions are
   * untouched: {@link emitFrame} still reaches all of them.
   *
   * The frame loop has no stopping condition by design, so a quiet link still
   * advances view time. That makes it unquiescable, and React's async `act()`
   * drains its queue and then requires the queue to be empty: a frame landing
   * in that window means it never is, and the mount hangs until the test times
   * out. A test harness that needs `act()` to return has to stop the clock and
   * drive it, not race it.
   */
  suspendFrames(): void {
    this.framesSuspended = true;
    this.cancelFrameTick();
  }

  /** Resume the loop {@link suspendFrames} stopped, if anything is still subscribed. */
  resumeFrames(): void {
    if (!this.framesSuspended) return;
    this.framesSuspended = false;
    this.scheduleFrameTick();
  }

  /** Whether {@link suspendFrames} is in force. */
  get framesAreSuspended(): boolean {
    return this.framesSuspended;
  }

  private scheduleFrameTick(): void {
    if (this.framesSuspended) return;
    if (this.frameHandle !== undefined) return;
    if (this.frameSubscribers.size === 0) return;
    const tick = () => {
      this.frameHandle = undefined;
      this.emitFrame();
      this.scheduleFrameTick();
    };
    /*
     * The handle carries which scheduler minted it rather than a flag captured
     * at subscribe time, so cancelling still uses the right one when the two
     * globals are swapped underneath a live loop (which is exactly what a test
     * substituting the frame clock does).
     */
    this.frameHandle =
      typeof requestAnimationFrame === "function"
        ? { kind: "raf", id: requestAnimationFrame(tick) }
        : { kind: "timer", id: setTimeout(tick, 16) };
  }

  private cancelFrameTick(): void {
    const handle = this.frameHandle;
    if (handle === undefined) return;
    this.frameHandle = undefined;
    if (handle.kind === "raf") cancelAnimationFrame(handle.id);
    else clearTimeout(handle.id);
  }

  /**
   * The page's own clock in seconds, which runs on at one second a second
   * while the game is paused or warping: the `nowWall` option when one was
   * given, else `performance.now()`. Useful for timing something the operator
   * waits on in real time whatever the game's clock is doing. Used by
   * `useCommand` to stop tracking a command no queue snapshot ever listed.
   */
  wallNow(): number {
    return (this.options.nowWall ?? defaultNowWall)();
  }

  private now(): number {
    return this.wallNow();
  }

  /** Game seconds per wall second as the game is actually running: the nominal rate scaled by the measured pace. */
  private warpRate(): number {
    return this.nominalWarpRate() * this.rateRatio;
  }

  private nominalWarpRate(): number {
    return this.options.warpRate?.() ?? 1;
  }
}
