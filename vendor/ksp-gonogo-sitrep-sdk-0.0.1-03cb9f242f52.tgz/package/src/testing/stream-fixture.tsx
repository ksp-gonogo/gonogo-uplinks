import type { JSX, ReactNode } from "react";
import type { Meta } from "../__generated__/contract";
import {
  CORE_PUBLISHED_PROCESSORS,
  DYNAMIC_WHOLE_TOPIC_PREFIXES,
  TelemetryClient,
  TelemetryProvider,
  TimelineStore,
  ViewClock,
} from "../spine";
import { createFakeWallClock, type FakeWallClock } from "./fake-wall-clock";
import { StubTransport } from "./stub-transport";

/**
 * Options for {@link setupStreamFixture}.
 *
 * The fixture runs the app's own telemetry pipeline, with every derived Topic
 * registered, over a {@link StubTransport} a test feeds by hand:
 *
 * - `emit` delivers only once something has subscribed, as the mod does, so a
 *   widget that shows an emitted value has really subscribed
 * - A key under a dynamic prefix, such as `trackingStation.vessel.<guid>.link`, is read whole,
 *   as the app reads it
 * - With a nonzero `delaySeconds`, leave `pinnedUt` unset, since a pinned
 *   clock ignores the delay. Move time with `fixture.wall.advanceBy(seconds)`
 *   and then `fixture.store.beginFrame()`. A mounted provider also starts a
 *   frame on every animation frame, whether or not anything arrived
 *
 * Useful for choosing the instant and the signal delay that a widget under test
 * sees.
 *
 * @category Stream fixture
 */
export interface StreamFixtureOptions {
  /** UT to pin the view clock at. Omit it to leave the clock running, which `delaySeconds` needs: a pinned clock ignores the delay. */
  pinnedUt?: number;
  /** Fixed network/display delay in seconds (`ViewClock`'s delay authority). Defaults to 0. */
  delaySeconds?: number;
}

/**
 * What `setupStreamFixture` returns: the stub transport, the real client and
 * store behind it, a fake wall clock, and a `Provider` to render widgets
 * inside. Useful for testing how a widget responds as readings and replies
 * arrive. Used by the test setup of the app and the components package.
 *
 * @category Stream fixture
 */
export interface StreamFixture {
  /** The transport the test feeds by hand. */
  transport: StubTransport;
  /** The telemetry client built over it. */
  client: TelemetryClient;
  /** The store the client fills. */
  store: TimelineStore;
  /** The wall clock the fixture runs on, which the test advances. */
  wall: FakeWallClock;
  /** Wraps `children` in the `TelemetryProvider` this fixture built. */
  Provider: (props: { children: ReactNode }) => JSX.Element;
  /**
   * Opens a standing subscription to `topic`, as a mounted widget does. An
   * `emit` before anything has subscribed is dropped, so call this for a Topic no
   * widget under test reads, such as a presence check or the inputs of a derived
   * Topic.
   */
  subscribe: (topic: string, cb?: (payload: unknown) => void) => void;
  /** `transport.emit`, forwarded for convenience: subscription-gated, same as calling it directly. */
  emit: (
    topic: string,
    payload: unknown,
    metaOverrides?: Partial<Meta>,
  ) => void;
}

/**
 * Builds a real telemetry pipeline over a `StubTransport`, for a test to feed
 * by hand. Render the widget under test inside `Provider`, then `emit` payloads
 * to it. Useful for testing how a widget shows readings, commands and held
 * values to the operator. Used by the test setup of the app and the components
 * package.
 *
 * @category Stream fixture
 * @categoryDescription Stream fixture
 * Running a widget against a scripted stream in a test: a real telemetry client
 * over a stub transport, the values it delivers, and the commands it records.
 */
export function setupStreamFixture(
  opts: StreamFixtureOptions = {},
): StreamFixture {
  const wall = createFakeWallClock();
  const transport = new StubTransport();
  const client = new TelemetryClient(transport);
  const clock = new ViewClock({
    nowWall: wall.now,
    warpRate: () => 1,
    delaySeconds: () => opts.delaySeconds ?? 0,
  });
  const store = new TimelineStore(clock, {
    dynamicWholeTopicPrefixes: DYNAMIC_WHOLE_TOPIC_PREFIXES,
  });
  // The production list itself rather than a hand-picked four of it. The four
  // were the ones some Uplink's widget happened to need, so a widget reading any
  // of the other four got `undefined` from a store the app would have answered
  // from, and the test agreed with itself. Registering the same list the provider
  // registers is the only version of this that stays true as the list grows.
  for (const processor of CORE_PUBLISHED_PROCESSORS) {
    store.publishProcessor(processor);
  }
  if (opts.pinnedUt !== undefined) clock.scrubTo(opts.pinnedUt);

  function Provider({ children }: { children: ReactNode }) {
    return (
      <TelemetryProvider client={client} store={store}>
        {children}
      </TelemetryProvider>
    );
  }

  return {
    transport,
    client,
    store,
    wall,
    Provider,
    subscribe: (topic, cb) => {
      client.subscribe(topic, cb ?? (() => {}));
    },
    emit: (topic, payload, metaOverrides) =>
      transport.emit(topic, payload, metaOverrides),
  };
}

/**
 * Drops the connection to the mod, for a test of how a widget shows held
 * readings: the transport disconnects and a new frame starts, so every reading
 * the widget drew is held rather than current. What a fixture's `"_stream": {
 * "stopsArriving": true }` asks for. Call it after the scene's emits. Useful
 * for testing how a widget shows the operator that readings have stopped
 * arriving. Used by the storybook's scenes.
 *
 * @category Stream fixture
 */
export function stopArriving(stream: StreamFixture): void {
  stream.store.setTransportConnected(false);
  stream.store.beginFrame();
}
