// ---------------------------------------------------------------------------
// Contribution-registry mirror: the `ContributionRegistry` declaration-merge
// for every first-party (packages/components-owned) contribution slot,
// carried by the sdk leaf itself. Same reasoning, same file-identity caveat,
// same "components-owned only, Uplink-owned slots stay in the Uplink's own
// file" scope split as `slots.ts` (see that file's header for the long
// form).
//
// Merges into the `ContributionRegistry {}` base declared in `./types.ts`,
// exactly like `slots.ts` merges into that file's `SlotRegistry {}` base: TS
// module augmentation with a relative specifier only attaches to an EXISTING
// export of the target module (an augmentation of a name types.ts hasn't
// declared is instead treated as a brand new ambient module declaration,
// which TS rejects outright for a relative path), so the base interface has
// to live in types.ts itself even while it stays empty.
//
// The `export {}` below is load-bearing, not decorative: it is what makes
// this FILE a module in TS's eyes. `slots.ts` gets that status for free from
// its own top-level `export interface` declarations (its real slot context
// types); this scaffold has no such content yet, so without an explicit
// export TS would treat it as a global script and reject the relative
// `declare module` specifier below with "Ambient module declaration cannot
// specify relative module name". Drop this line once the first real
// contribution slot's context type gives the file a natural export.
//
// The first two first-party contribution slots landed here (the
// framework's self-contribution flagship): ShipMap's `ship-map.part-meters`
// and `ship-map.part-meta`, both owned by `packages/components/src/ShipMap`.
// Every OTHER first-party contribution to date rides the automatic
// `${componentId}.badges` slot, which is a runtime string, never a member of
// this declaration-merged registry (see `useWidgetBadges`'s own doc
// comment); these two are the first GENUINELY typed, declared slots.
//
// `MeterTone` is duplicated rather than imported from `@ksp-gonogo/ui-kit`:
// ui-kit's own `Meter.tsx` imports `value` from this package, so importing
// ui-kit back here would be the exact same leaf-cycle this file's header
// (and `./slots.ts`'s) already explains for `@ksp-gonogo/components`.
//
// `ShipMapPartMeterEntry` deliberately carries no `tone`: the meter's fill is
// the resource's IDENTITY colour, derived by the renderer from `resource` via
// ui-kit's `resourceColor`, never chosen by a contributor. `status` is the
// SEPARATE, level-driven signal (a border tint or badge), and a single `tone`
// would conflate it with the fill hue. `ShipMapMeterTone` IS exported, for
// `ShipMapPartMetaEntry`: that is a different kind of row (process
// running/broken, habitat pressure, ...) whose `tone` genuinely is a status
// colour rather than an identity.
// ---------------------------------------------------------------------------

import type { Reading } from "../reading";
import type { ReadFrameChoice } from "../spine/reference-frame";
import type { Value } from "../unit-system/value";
import type { MeterEntry, StatEntry } from "./types";

/** Mirrors ui-kit's `MeterTone` (`packages/ui-kit/src/Meter.tsx`). */
export type ShipMapMeterTone = "neutral" | "go" | "warn" | "nogo" | "info";

/** Mirrors `ShipMapPartMeterEntry` (`ShipMap/shipTopology.ts`). */
export interface ShipMapPartMeterEntry {
  partId: string;
  resource: string;
  displayName: string;
  /**
   * Current stored amount, as a quantity or the whole {@link Reading} of one.
   *
   * A `Reading` is how a contributed meter says more than where the bar is.
   * The host's `Meter` draws the figure the same either way; what the reading
   * adds is whether it is a reading of NOW, and the band, which it draws as one
   * mark per bound on the bar's own track. That lookup belongs to the
   * primitive and never to the contributor, which is what keeps one visual
   * language across every Uplink filling this slot.
   */
  amount: Value<"units"> | Reading<Value<"units">>;
  /**
   * Max storage capacity, same terms as {@link ShipMapPartMeterEntry.amount}.
   * A renderer drops any entry whose capacity is not positive: nothing to fill.
   *
   * A capacity carries currency too, because a tank's size is read off the
   * craft like anything else, and a meter marks the TRACK rather than the fill
   * when it is the axis that has aged.
   */
  capacity: Value<"units"> | Reading<Value<"units">>;
  status?: "low" | "critical" | null;
}

/** Mirrors `ShipMapPartMetaEntry` (`ShipMap/shipTopology.ts`). */
export interface ShipMapPartMetaEntry {
  partId: string;
  label: string;
  tone: ShipMapMeterTone;
  kind: "ratio" | "text";
  value?: number;
  text?: string;
}

/**
 * One `comm-signal.hop-rates` entry: a single hop's forward band rate, keyed by
 * the SAME node ids `comms.path` carries (`fromNodeId`/`toNodeId`), so
 * CommSignal's route schedule can join a rate onto the hop it already renders
 * WITHOUT importing any backend-aware code or naming a provider. The join key is
 * derived once, in `CommSignal/commsRoute.ts`; a contributor relays the node ids
 * verbatim off its own Topic. `bitsPerSec` is a plain magnitude (bits/sec); the
 * schedule wraps it in `<Unit>` for display and compares magnitudes to flag the
 * bottleneck (minimum-rate) hop. Owned by `packages/components/src/CommSignal`;
 * the built-in RealAntennas contribution fills it off `realantennas.hopRates`.
 */
export interface CommSignalHopRateEntry {
  fromNodeId: string;
  toNodeId: string;
  bitsPerSec: number;
}

// SystemView (packages/components/src/SystemView)
//
// `system-view.entities` (the shape-contribution foundation: vessel orbits,
// the CommNet graph, selection, a future CME front all ride this one slot).
// Mirrors `SystemEntity` and its position/shape unions from
// `SystemView/systemEntities.ts`.

export type SystemEntityEmphasis = "faint" | "normal" | "bright";

/** Mirrors `SystemEntitySeverity`. */
export type SystemEntitySeverity = "info" | "warning" | "critical";

/** Mirrors `SystemEntityStyle`. A contribution names `emphasis` and
 *  `severity`; `colour` is the host's own decoration channel. */
export interface SystemEntityStyle {
  emphasis?: SystemEntityEmphasis;
  severity?: SystemEntitySeverity;
  colour?: string;
}

/** Mirrors `SystemEntityMeta`. */
export type SystemEntityMeta = Readonly<
  Record<string, string | number | boolean>
>;

/** Mirrors `SystemEntityOrbitPosition`. Both `inclination` and the fixed
 *  position's `zMetres` are REQUIRED: SystemView's arithmetic is
 *  three-dimensional and the frame it draws in is a rotation about an arbitrary
 *  axis, so a two-component position is not a position it can turn. An orbit
 *  that really is equatorial says `0`. */
export interface SystemEntityOrbitPosition {
  kind: "orbit";
  parentName: string;
  sma: number;
  ecc: number;
  lan: number;
  argPe: number;
  /** Inclination to the parent's reference plane, degrees. */
  inclination: number;
  trueAnomaly: number;
}

/** Mirrors `SystemEntityFixedPosition`. */
export interface SystemEntityFixedPosition {
  kind: "fixed";
  parentName: string;
  xMetres: number;
  yMetres: number;
  /** Out of the parent's reference plane, metres. */
  zMetres: number;
}

/** Mirrors `SystemEntityPosition`. */
export type SystemEntityPosition =
  | SystemEntityOrbitPosition
  | SystemEntityFixedPosition;

/** Mirrors `SystemEntityShape`. */
export type SystemEntityShape =
  | { kind: "point"; radiusPx?: number }
  | { kind: "orbit-path" }
  | { kind: "connection-line"; to: SystemEntityPosition }
  | { kind: "blob"; radiusMetres: number }
  | {
      kind: "travelling-pulse";
      to: SystemEntityPosition;
      segmentLengthMetres: number;
      /** UT the leading edge reaches `to`. */
      arriveUt: number;
      /** UT the trailing edge fully clears `to`. */
      clearUt: number;
    };

/** Mirrors `SystemEntity`. */
export interface SystemEntity {
  id: string;
  position: SystemEntityPosition;
  shape: SystemEntityShape;
  style?: SystemEntityStyle;
  meta?: SystemEntityMeta;
  vesselId?: string;
  zHint?: number;
}

/** Mirrors `SystemViewVesselStatusEntry` (SystemView/vesselStatusContribution.ts). */
export interface SystemViewVesselStatusEntry {
  /** The vessel this entry decorates: `vessel.identity`'s `vesselId`. */
  target: string;
  severity: "info" | "warning" | "critical";
  /** Every entry from this contribution is a model's opinion, never a direct observation. */
  emphasis: "observed" | "reckoned";
  label: string;
  tooltip?: string;
}

/** Mirrors `SystemProjectionExtent` (SystemView/projection.ts). */
export type SystemProjectionExtent =
  | { kind: "auto-fit-metres" }
  | { kind: "fixed-units"; units: number };

/** Mirrors `SystemViewProjection` (SystemView/projection.ts): one frame SystemView draws its whole picture in. */
export interface SystemViewProjection {
  /** Stable id. The operator's pinned choice is stored as this. */
  id: string;
  /** What an operator calls it. */
  label: string;
  /** The frame, for the host to resolve at the instant it is drawing. */
  choice: ReadFrameChoice;
  extent: SystemProjectionExtent;
  /** The body the diagram must be centred on for this projection to be one it can draw. */
  frameBodyIndex: number;
}

/**
 * One entry of a `crew-status.row-tone` contribution: how alarming one kerbal's
 * situation is.
 *
 * A contributor names the severity and nothing else; the widget owns the
 * palette. Omit a kerbal entirely for nothing to report, rather than
 * contributing an `info` entry.
 */
export interface CrewRowToneEntry {
  /** The crew member this entry is about; matched to a roster row by name. */
  crewName: string;
  /** How alarming the situation is. The widget decides what that looks like. */
  severity: SystemEntitySeverity;
}

// The plot SUBJECTS `packages/components` draws, declared so a contributor
// enriching one gets it as a completion and a typo fails to compile rather than
// quietly making a second plot. Same reasoning as the slot ids below, one
// registry per declaration-merge seam.
/**
 * One SCREEN the Administration Building offers, on `strategies.screens`.
 * Mirrors `StrategiesScreenEntry` (`Strategies/screens.ts`).
 *
 * <para>The widget draws a FACILITY, and which screens a facility owns is a
 * property of the elected career model rather than of the widget: RP-1's
 * building has Programs and Leaders where a stock one has neither. So the
 * contributor owns which screens exist, what each is called, where it sits and
 * what it lists, and the host owns the tab strip's behaviour, because no Uplink
 * should have to reimplement a tablist.</para>
 *
 * <para>There is deliberately no COUNT in this shape, and no way to express one.
 * A count cannot be ordered, cannot be labelled, and cannot be locked, and those
 * are the three things a screen has to be able to say about itself.</para>
 */
export interface StrategiesScreenEntry {
  /** Stable id, unique within the contributing client. */
  id: string;
  /** What the operator reads on the tab, e.g. RP-1's "Programs". */
  label: string;
  /**
   * Ascending, ties keeping contribution order; a screen without one sorts
   * after every screen that has one. Stated rather than derived, because the
   * order a career model wants its screens in is not on the wire: RP-1 declares
   * its departments in a config file and the file's order does not travel.
   */
  order?: number;
  /**
   * The strategy DEPARTMENTS this screen lists, matched against `department` on
   * each entry of `career.status`'s strategy list. The host draws its own
   * strategy cards for whatever matches, so a contributor never reimplements
   * one. A screen naming none lists nothing and is chrome for its augments.
   */
  departments?: readonly string[];
  /**
   * False for a screen that exists but cannot be opened yet.
   *
   * <para>The tab is still drawn AND still selectable, because `disabledReason`
   * is then the only thing on that screen worth reading and a tab that cannot be
   * reached cannot deliver it. This is the whole reason a screen is contributed
   * rather than inferred from whoever happens to have registered a body: an
   * unavailable screen that is simply ABSENT tells the operator nothing, and
   * absence is indistinguishable from a bundle that failed to load.</para>
   */
  enabled?: boolean;
  /** Why `enabled` is false, in the operator's own terms. */
  disabledReason?: string;
}

/** Mirrors `MissionLogAmount`. */
export interface MissionLogAmount {
  readonly magnitude: number;
  /** The contract unit, e.g. `"funds"`, `"rep"`. */
  readonly unit: string;
}

/** Mirrors `MissionLogSourceState`. */
export type MissionLogSourceState =
  | "recording"
  | "not-recording"
  | "unreadable";

/** Mirrors `MissionLogEventEntry`. */
export interface MissionLogEventEntry {
  id: string;
  /** An INSTANT, so a UT, in seconds. */
  ut: number;
  label: string;
  detail?: string;
  /** Short chip text, e.g. "FAILURE"; upper-cased by the host, "LOG" when absent. */
  kindLabel?: string;
  /** The same three words every other contribution in the app uses. */
  severity?: "info" | "warning" | "critical";
  /**
   * A figure the row moved: what a leader cost, what a contract paid in
   * reputation.
   *
   * Typed rather than formatted into `detail`, so the HOST renders it through
   * `Unit` and a contributor never hand-formats a quantity. A magnitude and its
   * unit rather than a `Value`, because the two sides of this mirror must
   * declare structurally IDENTICAL types to merge, and a `Value` resolved
   * through two different module paths is not identical to itself; the same
   * reason `MeterTone` is duplicated above. A contributor can pass a contract
   * `Value` straight in, since it already has both members.
   *
   * Singular, because no career-log row carries two figures.
   */
  amount?: MissionLogAmount;
  /**
   * The occurrence several rows belong to. Rows sharing one are marked, so a
   * failure and the launch it happened on can be seen to be the same flight.
   */
  groupId?: string;
}

/**
 * One `experiments.instruments` entry: a science instrument aboard the active
 * vessel that Experiments cannot observe for itself.
 *
 * <para>The widget reads `science.instruments`, which is the STOCK experiment
 * list. A mod that runs its own experiment parts through its own science module
 * rather than the stock one never appears there, so without this slot those
 * instruments are invisible to the one widget whose whole subject is "what
 * science hardware is aboard".</para>
 *
 * <para>Already normalised, and deliberately so: plain booleans rather than the
 * wire's optionals, because a contributor has already parsed its own Topic and
 * the host must not have to guess what a missing flag meant. `partId` is a
 * string for the same reason it is one on the widget's own parsed shape: every
 * consumer interpolates it into a key and none compares it numerically.</para>
 *
 * <para>The four booleans are the instrument's LIFECYCLE, and a contributor
 * whose domain has no such lifecycle says so plainly rather than omitting them:
 * a survey scanner that can be neither deployed nor made inoperable says
 * `false` to both and `true` to `rerunnable`. There is no field for "this
 * instrument's state is unknown", because the host draws a badge per flag and a
 * third state would be a badge that means nothing.</para>
 *
 * <para>Contributed instruments render READ-ONLY. The host's Deploy and
 * Transmit controls dispatch `science.experiment.deploy`/`.transmit`, which
 * reach a part through the stock science module; a part the stock list never
 * mentioned is not one those commands can act on, so the host renders no
 * control rather than one that would arm and do nothing. A contributor wanting
 * commands of its own has `experiments.instrument`, the per-instrument AUGMENT
 * slot, which is a different mechanism for a different job: an augment renders,
 * a contribution supplies.</para>
 *
 * Mirrors `ExperimentsInstrumentEntry` (`packages/components/src/Experiments/index.tsx`).
 */
export interface ExperimentsInstrumentEntry {
  /** Stable within the contributing client; the row's React key. */
  partId: string;
  /** What the operator reads on the row, e.g. "2HOT Thermometer". */
  partTitle: string;
  /** KSP experiment id, e.g. `"temperatureScan"`. Groups the rows. */
  expId: string;
  deployed: boolean;
  /** The instrument currently holds collectable data. */
  hasData: boolean;
  rerunnable: boolean;
  inoperable: boolean;
}

/**
 * One building of the space centre, on `space-center-status.facilities`.
 *
 * <para>Every tier here is KSP's own zero-based facility level, the same index
 * `career.status.facilities` carries: `maxTier` is the TOP tier's own index, so
 * a three-tier building says 2. The host adds one for display, because operators
 * count from one and so does KSP's own R&amp;D dialog, which calls a fully
 * upgraded VAB "Level 3". A contributor passes the index straight through and
 * converts nothing.</para>
 *
 * <para>Both tiers are REQUIRED, and that is the shape of the rule rather than
 * an oversight: absent and zero are different readings, tier 0 is where every
 * career starts, and a building whose tier could not be read is not a building
 * at tier 0. A contributor that cannot read one omits the building.</para>
 */
export interface SpaceCenterFacilityEntry {
  /** KSP's `SpaceCenterFacility` enum name, e.g. `"VehicleAssemblyBuilding"`. */
  facility: string;
  /** The tier it is at, zero-based. */
  currentTier: number;
  /** The top tier's own index, so a three-tier building says 2. */
  maxTier: number;
  /**
   * What the next tier costs in funds. Absent at the ceiling, and absent when
   * the price is not readable, which the host draws the same way: no price
   * beside the control rather than a zero that would read as free.
   */
  upgradeCost?: number;
  /**
   * KSP's own description of the tier the building is at, as its upgrade dialog
   * writes it: newline-separated `* Property: setting` lines. The host parses it
   * into a list; anything it cannot read as a property stays a plain line.
   */
  currentTierText?: string;
  /** The same, for the tier an upgrade would buy. */
  nextTierText?: string;
}

declare module "./plots" {
  interface PlotSubjectRegistry {
    /** LandingStatus's velocity-height descent corridor: speed across, height
     *  above ground up. The suicide-burn band and any better terminal-velocity
     *  model belong on this one rather than beside it. */
    "descent-envelope": true;
    /** The terrain slice along the ground track through the predicted site. */
    "landing-cross-section": true;
    /** The top-down view around the predicted touchdown point. */
    "touchdown-site": true;
  }
}

declare module "./types" {
  interface ContributionRegistry {
    /*
     * A slot declares the entry its contributors produce, and nothing about the
     * data they read. A contribution asks for Topics through its own `deps`, any
     * Topic is valid there, and `deps` is the only thing that feeds `compute`.
     */
    "ship-map.part-meters": {
      entry: ShipMapPartMeterEntry;
    };
    "ship-map.part-meta": {
      entry: ShipMapPartMetaEntry;
    };
    "system-view.entities": {
      entry: SystemEntity;
    };
    "system-view.vessel-status": {
      entry: SystemViewVesselStatusEntry;
    };
    "system-view.projection": {
      entry: SystemViewProjection;
    };
    /**
     * Tints a whole crew row by severity; the widget picks the colour. The
     * first entry for a name wins.
     */
    "crew-status.row-tone": {
      entry: CrewRowToneEntry;
    };
    /**
     * Meters under each crew row, such as life-support levels. Set `row` to the
     * kerbal's name; an entry with no `row` is not drawn.
     */
    "crew-status.meters": {
      entry: MeterEntry;
    };
    "comm-signal.hop-rates": {
      entry: CommSignalHopRateEntry;
    };
    "strategies.screens": {
      entry: StrategiesScreenEntry;
    };
    "experiments.instruments": {
      entry: ExperimentsInstrumentEntry;
    };
    /**
     * The Astronaut Complex's core-stat strip, beside funds, hire price and
     * roster occupancy: what the career model running the save considers as core
     * as those three. Drawn by the host's own `Stat`, in the same cell treatment
     * and the same row, so a contributed figure is indistinguishable from a
     * vanilla one.
     *
     * The strip is where an operator reads the state of the whole complex, and a
     * career overhaul owns half of that state: how many nauts are in training,
     * how many qualifications are about to lapse.
     */
    "astronaut-complex.readouts": {
      entry: StatEntry;
    };
    /**
     * The tiers SpaceCenterStatus draws in its facility grid.
     *
     * <para>The widget contributes its own reading of `career.status` here at
     * priority 0, so an ordinary contributor DISPLACES the grid rather than
     * adding a second copy of it below. That is what the slot is for: away from
     * the space centre the stock reading has nothing to give, and a career model
     * that keeps its own tier table does.</para>
     *
     * <para>KSP puts the space centre's buildings in the SPACECENTER scene only,
     * and stock offers no way round it. `ProtoUpgradeable.GetLevel()` does parse
     * the level persisted in the save when the scene is empty, but its sibling
     * `GetLevelCount()` returns -1 there, and that level is NORMALISED: without
     * a tier count it cannot be turned back into a tier. A career overhaul that
     * carries its own tier counts (RP-1 parses the CustomBarnKit upgrade lists
     * at load and bills the career off them in all four scenes) can answer
     * wherever the operator is standing.</para>
     */
    "space-center-status.facilities": {
      entry: SpaceCenterFacilityEntry;
    };
  }
}
