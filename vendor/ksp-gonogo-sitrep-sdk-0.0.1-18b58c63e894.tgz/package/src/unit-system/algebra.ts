import type { DeclaredUnit, UnitDeclarations } from "./declarations";
import type { UNIT_DEFINITIONS } from "./definitions";
import type { UnknownUnit } from "./value";

/**
 * Multiplication and division, at the type level.
 *
 * `plus` has been type-safe since the model shipped: `CombinableWith<Unit>` refuses
 * to add metres to seconds. `times` and `per` were not, because they can produce a
 * unit neither operand names, and until this module the interface said
 * `times(other: Value | number): Value` and gave up. Dimensional correctness
 * was enforced only at runtime, so `value("m",10).per(value("s",2))` was
 * `Value<string>` at compile time while the runtime knew perfectly well it had
 * made an `m/s`.
 *
 * This closes that, for everything the catalogue can name.
 *
 * ## The one thing it does NOT do
 *
 * Name an UNDECLARED composite. `rep.per(funds)` is `{rep:1, funds:-1}`, the
 * runtime calls it `"rep/funds"`, and this type says `string`. Reproducing that
 * glyph needs type-level string SORTING (to canonicalise the numerator and
 * denominator ordering), which measured at roughly three times the cost of an
 * entire multiply-and-look-up, before parsing signed exponents and mapping
 * superscripts. For a string nobody type-checks against, that is a bad trade.
 *
 * The gap is exactly "this dimension has no declared unit". It is not a
 * special-case list, it cannot rot as the catalogue grows, and it never yields
 * a WRONG answer, only a less specific one identical to today's. That same
 * measurement is why dimensions are object types here rather than canonical
 * string keys: the string representation would make sorting mandatory
 * everywhere instead of nowhere.
 *
 * ## Everything degrades to `string`, never to `never`
 *
 * `Value<string>` is the status quo, and it is safe: `CombinableWith<string>`
 * collapses to `never` and falls back to `string`, so `plus` on a degraded value
 * accepts anything, exactly as before. An unknown unit is never made LESS safe
 * by this module and using one is never a compile error. That is the rule
 * `CombinableWith` already set, followed literally.
 */

/* ────────────────────────────────────────────────────────────────────────────
 * Exponents
 * ─────────────────────────────────────────────────────────────────────────── */

/**
 * TypeScript has no type-level arithmetic, so exponents are tuple lengths, and
 * negative exponents need a bias: an exponent `e` is stored as `e + 9`.
 *
 * The domain is -9..9. The catalogue's largest magnitude is 3, and nine
 * successive divisions is far past anything real. Outside it the answer is
 * `never`, which propagates to `string`: degrade, never lie.
 */
type Bias = [-9, -8, -7, -6, -5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

/**
 * The valid indices of {@link Bias}, spelled out.
 *
 * **Do not replace this with `N extends keyof Bias`.** `keyof` on a TUPLE
 * includes `number`, so `27 extends keyof Bias` is `true` and `Bias[27]`
 * quietly returns the whole `-9 | ... | 9` union instead of `never`. Overflow
 * then stops being detected and a nonsense exponent reads as "every exponent
 * at once". This is the failure mode the whole `.test-d` suite exists to pin.
 */
type Slot =
  | 0
  | 1
  | 2
  | 3
  | 4
  | 5
  | 6
  | 7
  | 8
  | 9
  | 10
  | 11
  | 12
  | 13
  | 14
  | 15
  | 16
  | 17
  | 18;

type Unbias = {
  "-9": 0;
  "-8": 1;
  "-7": 2;
  "-6": 3;
  "-5": 4;
  "-4": 5;
  "-3": 6;
  "-2": 7;
  "-1": 8;
  "0": 9;
  "1": 10;
  "2": 11;
  "3": 12;
  "4": 13;
  "5": 14;
  "6": 15;
  "7": 16;
  "8": 17;
  "9": 18;
};

type Negate = {
  "-9": 9;
  "-8": 8;
  "-7": 7;
  "-6": 6;
  "-5": 5;
  "-4": 4;
  "-3": 3;
  "-2": 2;
  "-1": 1;
  "0": 0;
  "1": -1;
  "2": -2;
  "3": -3;
  "4": -4;
  "5": -5;
  "6": -6;
  "7": -7;
  "8": -8;
  "9": -9;
};

type Tup<
  Length extends number,
  Built extends unknown[] = [],
> = Built["length"] extends Length ? Built : Tup<Length, [unknown, ...Built]>;

type At<Biased> = Biased extends Slot ? Bias[Biased] : never;

/**
 * `(a+9) + (b+9) - 9 = a+b+9`.
 *
 * The template-literal index (`` `${Left}` ``) is what turns a numeric literal
 * into something that can key `Unbias`, and it is also the guard: a
 * non-literal `number` produces the key `"number"`, which is not in `Unbias`,
 * so `Add<number, 1>` is `never` rather than a guess. Underflow is caught by
 * the concatenation being shorter than 9 and failing to match; overflow by
 * `At`.
 */
export type Add<
  Left extends number,
  Right extends number,
> = `${Left}` extends keyof Unbias
  ? `${Right}` extends keyof Unbias
    ? [...Tup<Unbias[`${Left}`]>, ...Tup<Unbias[`${Right}`]>] extends [
        ...Tup<9>,
        ...infer Remainder,
      ]
      ? At<Remainder["length"]>
      : never
    : never
  : never;

export type Neg<Exponent extends number> = `${Exponent}` extends keyof Negate
  ? Negate[`${Exponent}`]
  : never;

/* ────────────────────────────────────────────────────────────────────────────
 * Dimensions
 * ─────────────────────────────────────────────────────────────────────────── */

/**
 * The identity test the rest of the module is built on, and the same one
 * `SameDimensionAs` already uses.
 *
 * It relies on how tsc relates two conditional types rather than on a
 * documented feature. That is a bet, but not a NEW bet: the SDK has made it
 * since `CombinableWith` (née `Addend`) shipped.
 */
type Equal<Left, Right> =
  (<Probe>() => Probe extends Left ? 1 : 2) extends <
    Probe,
  >() => Probe extends Right ? 1 : 2
    ? true
    : false;

/**
 * Canonical form: readonly, required, no zero exponents.
 *
 * **Every one of those three is load-bearing**, and getting any wrong makes
 * every `Equal` below silently return `false`, which degrades the whole
 * feature to `Value<string>` without producing a single error. That is a safe
 * failure but an invisible one, which is why `algebra.test-d.ts` asserts
 * against the whole catalogue rather than a handful of samples.
 *
 * - `readonly`, because `UNIT_DEFINITIONS` is `as const` and
 *   `Equal<{readonly m:1}, {m:1}>` is `false`.
 * - `-?`, because `Equal<{m?:1}, {m:1}>` is `false` and a mapped type over a
 *   union of keys can introduce optionality.
 * - dropping zeroes, because `m.per(m)` must equal the dimensionless `{}` and
 *   not `{m:0}`. This mirrors the runtime's `normalise`.
 */
type Norm<Dimension> = {
  readonly [Base in keyof Dimension as Dimension[Base] extends 0
    ? never
    : Base]-?: Dimension[Base];
};

type ExpOf<Dimension, Base extends string> = Base extends keyof Dimension
  ? Dimension[Base] extends number
    ? Dimension[Base]
    : 0
  : 0;

type Combine<Left, Right> = Norm<{
  readonly [Base in (keyof Left | keyof Right) & string]: Add<
    ExpOf<Left, Base>,
    ExpOf<Right, Base>
  >;
}>;

type NegD<Dimension> = {
  readonly [Base in keyof Dimension]: Dimension[Base] extends number
    ? Neg<Dimension[Base]>
    : never;
};

/**
 * The `[X] extends [never]` guards are not defensive padding.
 *
 * A mapped type does not distribute over `never`, so without them
 * `Mul<never, {s:1}>` takes `keyof never`, which is `string | number | symbol`,
 * and produces garbage instead of propagating the unknown. One unknown operand
 * has to make the whole result unknown.
 */
export type Mul<Left, Right> = [Left] extends [never]
  ? never
  : [Right] extends [never]
    ? never
    : Combine<Left, Right>;

export type Div<Left, Right> = [Left] extends [never]
  ? never
  : [Right] extends [never]
    ? never
    : Combine<Left, NegD<Right>>;

/* ────────────────────────────────────────────────────────────────────────────
 * Symbols in, dimensions out
 * ─────────────────────────────────────────────────────────────────────────── */
type StaticUnit = keyof typeof UNIT_DEFINITIONS;
type Def<Unit extends StaticUnit> = (typeof UNIT_DEFINITIONS)[Unit];

/**
 * A unit declared through {@link UnitDeclarations} that the static table does
 * not carry: an Uplink's own.
 *
 * Declared in the one place every unit is, in the shape a first-party one is:
 *
 * ```ts
 * declare module "@ksp-gonogo/sitrep-sdk" {
 *   interface UnitDeclarations {
 *     "snacks:snack": { kind: "snacks"; dim: { readonly resSnack: 1 }; ratio: 1 };
 *   }
 * }
 * ```
 *
 * The static table is consulted first, so an augmentation cannot change what a
 * first-party symbol resolves to, and neither can a runtime registration:
 * `resetUnitRegistry` seeds `UNIT_DEFINITIONS` first and `declaredUnitFor`
 * returns the FIRST ratio-1 match.
 */
type ExtUnit = Exclude<DeclaredUnit, StaticUnit>;

/**
 * The resource names an Uplink knows when it is built, each declared by
 * augmenting this interface:
 *
 * ```ts
 * declare module "@ksp-gonogo/sitrep-sdk" {
 *   interface ResourceNamespaces {
 *     Food: true;
 *   }
 * }
 * ```
 *
 * A declared resource's units then have dimensions of their own:
 * `"Food:u"` is an amount of Food, `"Food:u/s"` a rate of it, `"Food:kg/u"` its
 * mass per unit and `"Food:f/u"` its price per unit. Food and Oxygen are both
 * shown as `u`, but adding one to the other does not compile.
 *
 * @category Units and values
 */
/*
 * It must stay an INTERFACE, and empty is the point. `declare module` can only
 * augment an interface, never a type alias, so biome's autofix to
 * `type ResourceNamespaces = {}` silently turns every consumer's augmentation
 * into a duplicate-identifier error. That is not hypothetical: the autofix ran
 * on its sibling, and it took every resource assertion in the test-d suite down
 * with it.
 */
// biome-ignore lint/suspicious/noEmptyInterface: augmentable by design, see above
export interface ResourceNamespaces {}

type Res<Resource extends string> = Resource extends keyof ResourceNamespaces
  ? Resource
  : never;

/**
 * The per-resource token grammar: `<Resource>:u`, `:u/s`, `:kg/u`, `:f/u`.
 *
 * The resource NAMES are discovered when the game loads and cannot be known to
 * the compiler, but the token GRAMMAR is fixed, and that is enough. Each
 * resource gets its own base dimension (`resFood`), which is what stops Food
 * being added to Oxygen while both still read `u` on screen.
 *
 * Two mechanisms carry this:
 *
 * - **Template-literal inference is anchored.** `` `${infer R}:u` `` requires
 *   the string to END in `:u`, so `"Food:u/s"` and `"Food:kg/u"` do not match
 *   that arm. The four arms are unambiguous and order-independent.
 * - **A heterogeneous map must be ONE mapped type, not an intersection.**
 *   `{ readonly [K in `res${R}` | "s"]: K extends "s" ? -1 : 1 }` has the same
 *   identity as a hand-written `{ readonly resFood: 1; readonly s: -1 }`. An
 *   intersection would not compare `Equal` and everything downstream would
 *   quietly degrade.
 *
 * The base symbol for currency is `funds`, not `f`: `f` is the display glyph.
 */
type ResourceDim<Token> = Token extends `${infer Resource}:u`
  ? [Res<Resource>] extends [never]
    ? never
    : { readonly [Base in `res${Resource}`]: 1 }
  : Token extends `${infer Resource}:u/s`
    ? [Res<Resource>] extends [never]
      ? never
      : { readonly [Base in `res${Resource}` | "s"]: Base extends "s" ? -1 : 1 }
    : Token extends `${infer Resource}:kg/u`
      ? [Res<Resource>] extends [never]
        ? never
        : {
            readonly [Base in `res${Resource}` | "kg"]: Base extends "kg"
              ? 1
              : -1;
          }
      : Token extends `${infer Resource}:f/u`
        ? [Res<Resource>] extends [never]
          ? never
          : {
              readonly [Base in
                | `res${Resource}`
                | "funds"]: Base extends "funds" ? 1 : -1;
            }
        : never;

/**
 * The dimension a unit token denotes, or `never` if nothing declares it.
 *
 * `UnknownUnit` is checked first, ahead of the three real lookups, and forced
 * to `never` on its own branch rather than left to fall out of them by
 * accident. Today it WOULD fall out the same way unassisted: `UnknownUnit` is
 * a branded, non-literal `string`, so it fails `extends StaticUnit` and
 * `extends ExtUnit` the same way any unrecognised token does, and it fails
 * `ResourceDim`'s template-literal patterns for the same reason (a non-literal
 * string cannot be proven to end in `:u`, `:u/s`, etc.), confirmed by deleting
 * this branch and rerunning `algebra.test-d.ts`, which still passed.
 *
 * The branch stays anyway. That pass is an accident of what the other three
 * happen to reject today, not a commitment, and this module's own rule is
 * "narrow first": a future change to `ResourceDim`'s grammar or a new
 * `ExtUnit` shape could start matching a branded string without anyone
 * noticing, silently letting an unknown unit compose. `algebra.test-d.ts`
 * pins the OUTCOME (`Product`/`Quotient` on `UnknownUnit` degrade to
 * `string`), and that outcome would still catch such a regression even if
 * this branch is currently redundant with it.
 */
export type DimOf<Unit> = [Unit] extends [UnknownUnit]
  ? never
  : Unit extends StaticUnit
    ? Norm<Def<Unit>["dim"]>
    : Unit extends ExtUnit
      ? Norm<
          UnitDeclarations[Unit] extends { dim: infer Dimension }
            ? Dimension
            : never
        >
      : [ResourceDim<Unit>] extends [never]
        ? never
        : Norm<ResourceDim<Unit>>;

/* ────────────────────────────────────────────────────────────────────────────
 * Dimensions in, a symbol out
 * ─────────────────────────────────────────────────────────────────────────── */

/**
 * Ratio-1 and not an alias: the same rule `declaredUnitFor` applies at runtime.
 *
 * `Def<Candidate>["ratio"] extends 1` works because `as const` gives a literal type to
 * a literal ratio, while a COMPUTED one (`1/3.6`, `Math.PI/180`, `1/21_600`)
 * widens to `number`, which does not extend `1`. So the filter picks out
 * exactly the base units without anyone maintaining a list.
 */
type CanonicalUnit = {
  [Candidate in StaticUnit]: Def<Candidate>["ratio"] extends 1
    ? Def<Candidate> extends { alias: true }
      ? never
      : Candidate
    : never;
}[StaticUnit];

type StaticSymbolFor<Dimension> = {
  [Candidate in CanonicalUnit]: Equal<DimOf<Candidate>, Dimension> extends true
    ? Candidate
    : never;
}[CanonicalUnit];

type ExtSymbolFor<Dimension> = {
  [Candidate in ExtUnit]: Equal<DimOf<Candidate>, Dimension> extends true
    ? Candidate
    : never;
}[ExtUnit];

type ResName<Dimension> =
  Extract<keyof Dimension, `res${string}`> extends `res${infer Resource}`
    ? Resource
    : never;

/**
 * A computed dimension back to a resource token.
 *
 * The round-trip `Equal` is the safety net rather than a formality: a
 * dimension mentioning TWO resources makes `ResName` a union, every arm fails,
 * and the result degrades to `string`. That is what stops
 * `Food:u × Oxygen:kg/u` inventing a token for something incoherent.
 */
type ResSymbolFor<Dimension, Resource extends string = ResName<Dimension>> = [
  Resource,
] extends [never]
  ? never
  : Equal<DimOf<`${Resource}:u`>, Dimension> extends true
    ? `${Resource}:u`
    : Equal<DimOf<`${Resource}:u/s`>, Dimension> extends true
      ? `${Resource}:u/s`
      : Equal<DimOf<`${Resource}:kg/u`>, Dimension> extends true
        ? `${Resource}:kg/u`
        : Equal<DimOf<`${Resource}:f/u`>, Dimension> extends true
          ? `${Resource}:f/u`
          : never;

/**
 * The declaration ladder, ending in `string`.
 *
 * Never `never` and never a guess: "we do not know" has exactly one spelling,
 * and it is the one that behaves like today.
 */
export type SymbolFor<Dimension> = [Dimension] extends [never]
  ? string
  : [StaticSymbolFor<Dimension>] extends [never]
    ? [ExtSymbolFor<Dimension>] extends [never]
      ? [ResSymbolFor<Dimension>] extends [never]
        ? string
        : ResSymbolFor<Dimension>
      : ExtSymbolFor<Dimension>
    : StaticSymbolFor<Dimension>;

/** The unit of `a × b`, or `string` when nothing declares that dimension. */
export type Product<Left extends string, Right extends string> = SymbolFor<
  Mul<DimOf<Left>, DimOf<Right>>
>;

/** The unit of `a ÷ b`, or `string` when nothing declares that dimension. */
export type Quotient<Left extends string, Right extends string> = SymbolFor<
  Div<DimOf<Left>, DimOf<Right>>
>;
