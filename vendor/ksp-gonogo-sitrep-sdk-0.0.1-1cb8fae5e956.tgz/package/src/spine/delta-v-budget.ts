import { observedAt } from "../reading";
import { dynamicValue, isValue } from "../unit-system/value";
import type { Value } from "../value";
import type { ReadingState, TopicCurrency } from "./client-reading";
import { CORE_UPLINK_CLIENT } from "./uplink-clients";

// ---------------------------------------------------------------------------
// "How much ΔV have we got?", answered once, in one place.
//
// Four widgets asked it and got three different answers, and the answers could disagree about the same craft in flight:
//
//   FuelStatus        its own stage parser for the rows, `dv.summary.totalDv*` for the
//                     total, the observed arm only (withholds when held)
//   ManeuverPlanner   `useProcessor(DELTA_V_BUDGET)` (this processor), which
//                     SUMS `dv.stages` client-side for the total, spells an
//                     absent per-stage field `0`, and also withholds when held
//   TransferWindow    `dv.summary.totalDvVac` raw, carried and dated
//   LandingStatus     the active `dv.stages` row for the rocket-equation solve,
//                     `dv.summary` as the whole-vessel fallback
//
// Each of the three got a different third of it right, so this takes one third from each:
//
// THE TOTAL COMES OFF THE WIRE, never from summing `dv.stages`. The two are not
// the same figure. `dv.stages` is built from `VesselDeltaV.OperatingStageInfo`
// (KspHost.BuildDeltaV), which in flight is filtered to the stages at or below
// `StageManager.CurrentStage`; `dv.summary.totalDv*` is `TotalDeltaVVac`/ASL/
// Actual, accumulated over `WorkingStageInfo`, which is unfiltered. Summing the
// one and presenting it as the other is a client-side re-derivation of a number
// the game already computed, off a different list, and it under-reports.
//
// AN ABSENT PER-STAGE FIELD IS `NaN`, never `0`. They are opposite facts: a
// stage with no engine has no ΔV figure, and a spent stage has 0 m/s. Spelling
// both `0` is the same mistake the processor above avoids one level up by
// making its total nullable. NaN is affordable here precisely BECAUSE the total does
// not come from summing these rows.
//
// THE BUDGET IS CARRIED AND DATED, never withheld. A ΔV budget only falls by
// burning and only rises by staging or docking, all of which are events the
// operator caused, so a dated budget is still the budget and wants a caption
// rather than a blank. Withholding is also the DANGEROUS direction: ManeuverPlanner
// disables its commit only on `feasible === false`, so a budget that goes
// `undefined` mid-blackout turns a craft that is demonstrably short into one we
// merely have no opinion about, and re-enables the button. `budget` below carries
// the arm and the age so a consumer can hollow a verdict instead of losing it.
// ---------------------------------------------------------------------------

/**
 * One stage of the active vessel's delta-v, from `dv.stages`, as plain numbers
 * for drawing and arithmetic. Useful for showing the operator what each stage
 * can still deliver. Held in the stages of a {@link DeltaVBudget}, which the
 * fuel status widget draws.
 *
 * A field is `NaN` when the game gave no figure, so check with
 * `Number.isFinite`: a stage with no engine has no delta-v, while a spent stage
 * has 0.
 *
 * @category Orbits and trajectories
 */
export interface DeltaVStage {
  /** The stage number this row describes. */
  stage: number;
  /** Stage dry mass, in tonnes. */
  dryMass: number;
  /** Stage fuel mass, in tonnes. */
  fuelMass: number;
  /** Stage mass at ignition, in tonnes. */
  startMass: number;
  /** Stage mass at burnout, in tonnes. */
  endMass: number;
  /** Full-throttle burn time of the stage, in seconds. */
  burnTime: number;
  /** Stage delta-v in vacuum, in metres per second. */
  deltaVVac: number;
  /** Stage delta-v at sea level, in metres per second. */
  deltaVASL: number;
  /** Stage delta-v in the craft's current situation, in metres per second. */
  deltaVActual: number;
  /** Thrust-to-weight ratio in vacuum. */
  TWRVac: number;
  /** Thrust-to-weight ratio at sea level. */
  TWRASL: number;
  /** Thrust-to-weight ratio in the craft's current situation. */
  TWRActual: number;
  /** Stage thrust in vacuum, in kilonewtons. */
  thrustVac: number;
  /** Stage thrust at sea level, in kilonewtons. */
  thrustASL: number;
  /** Stage thrust in the craft's current situation, in kilonewtons. */
  thrustActual: number;
}

/**
 * How current a {@link DeltaVBudget} is, from its `dv.summary` reading. Useful
 * for showing the operator whether the delta-v figures are live or held. Held in
 * the provenance of a {@link DeltaVBudget}, which the fuel status widget draws.
 *
 * @category Orbits and trajectories
 */
export interface BudgetProvenance {
  /** The state of the `dv.summary` reading. */
  state: ReadingState;
  /** UT the summary was observed at; undefined when nothing has been observed. */
  asOfUt: Value<"ut"> | undefined;
  /** Seconds between that observation and the frame this was derived for. */
  ageSec: number | undefined;
  /**
   * Whether the game confirmed it has no delta-v for this craft, as for a craft
   * with no engines, rather than none having arrived yet. Show the two
   * differently.
   */
  confirmedAbsent: boolean;
}

/**
 * The active vessel's delta-v, in total and per stage, built from the game's own
 * figures. Useful for showing the operator how much delta-v the vessel has left
 * and when it was last measured. Returned by {@link DELTA_V_BUDGET} and
 * `deriveDeltaVBudget`, and drawn by the fuel status widget.
 *
 * @category Orbits and trajectories
 */
export interface DeltaVBudget {
  /**
   * Vessel-total ΔV per situation, straight off `dv.summary`: the game's own
   * accumulator, never a client-side sum of {@link stages}.
   *
   * `null` means no usable figure, which is not `0`: a spent craft really has
   * 0 m/s and that is a statement about the vessel, while `null` is a statement
   * about the link. A caller must branch, and the branch is where "we do not
   * know" gets said out loud instead of being spelled `0`.
   */
  totalVac: Value<"m/s"> | null;
  /** Vessel-total delta-v at sea level, with the same `null` rule as `totalVac`. */
  totalAsl: Value<"m/s"> | null;
  /** Vessel-total delta-v in the current situation, with the same `null` rule as `totalVac`. */
  totalActual: Value<"m/s"> | null;
  /** Total burn time across the budget, or `null` when the wire carries none. */
  totalBurnTime: Value<"s"> | null;
  /** How many stages the summary counted, or `null`. Not `stages.length`: see {@link stages}. */
  stageCount: Value<"count"> | null;
  /**
   * Per-stage rows in wire order (high stage number first, matching the
   * stack-top-down render order).
   *
   * Empty is not a zero-ΔV vessel: `dv.stages` is null-not-empty when the stock
   * sim has nothing (`StageDeltaVViewProvider.BuildStages`), so an array that
   * arrived with no entries still means "no figure to break down".
   */
  stages: DeltaVStage[];
  /**
   * The row whose `stage` matches `vessel.structure.currentStage`: the engines
   * actually flying right now, and the only ones whose mass ratio fixes a real
   * exhaust velocity. `null` when no row matches or the structure has not
   * arrived.
   */
  activeStage: DeltaVStage | null;
  /** How current the budget is. */
  budget: BudgetProvenance;
}

/**
 * The wire shape of a `dv.stages` row: `Sitrep.Contract.StageDeltaVEntry` and
 * only it, read by the contract's own names (`dvActual`, `twrActual`,
 * `thrustAsl`, ...).
 *
 * Deliberately no alias set (`deltaVActual`, `TWRActual`, ...). A fixture that
 * spells a field the mod never sends should read as absent, which is the only
 * reason an e2e spelling one another way is ever found.
 */
type StageWireEntry = Record<string, unknown>;

/** A number, a `Value`'s magnitude, or `NaN` when the field carries neither. */
function magnitudeOrNaN(raw: unknown): number {
  if (typeof raw === "number") return raw;
  if (isValue(raw)) return raw.magnitude;
  return Number.NaN;
}

/** One wire field's magnitude, or `NaN` when it carries no finite figure. */
function field(entry: StageWireEntry, key: string): number {
  return magnitudeOrNaN(entry[key]);
}

/**
 * One `dv.stages` entry as a {@link DeltaVStage}, or `null` when it is not one.
 * Useful for reading the stages of the active vessel's delta-v from the raw
 * payload. Used by `deriveDeltaVBudget`.
 *
 * @category Orbits and trajectories
 */
export function normaliseStage(raw: unknown): DeltaVStage | null {
  if (!raw || typeof raw !== "object") return null;
  const e = raw as StageWireEntry;
  return {
    stage: field(e, "stage"),
    dryMass: field(e, "dryMass"),
    fuelMass: field(e, "fuelMass"),
    startMass: field(e, "startMass"),
    endMass: field(e, "endMass"),
    burnTime: field(e, "burnTime"),
    deltaVVac: field(e, "dvVac"),
    deltaVASL: field(e, "dvAsl"),
    deltaVActual: field(e, "dvActual"),
    TWRVac: field(e, "twrVac"),
    TWRASL: field(e, "twrAsl"),
    TWRActual: field(e, "twrActual"),
    thrustVac: field(e, "thrustVac"),
    thrustASL: field(e, "thrustAsl"),
    thrustActual: field(e, "thrustActual"),
  };
}

/** A wire total to a `Value<"m/s">`, or `null` when there is no usable figure. */
function totalOf<Unit extends "m/s" | "s" | "count">(
  raw: unknown,
  unit: Unit,
): Value<Unit> | null {
  const magnitude = magnitudeOrNaN(raw);
  return Number.isFinite(magnitude) ? dynamicValue(unit, magnitude) : null;
}

/** The wire subset of `dv.summary` this derivation reads. */
interface SummaryWire {
  stageCount?: unknown;
  totalDvVac?: unknown;
  totalDvAsl?: unknown;
  totalDvActual?: unknown;
  totalBurnTime?: unknown;
}

const NO_BUDGET: DeltaVBudget = {
  totalVac: null,
  totalAsl: null,
  totalActual: null,
  totalBurnTime: null,
  stageCount: null,
  stages: [],
  activeStage: null,
  budget: {
    state: "pending",
    asOfUt: undefined,
    ageSec: undefined,
    confirmedAbsent: false,
  },
};

/**
 * A {@link DeltaVBudget} built from the `dv.summary` reading, the raw
 * `dv.stages` payload, the vessel's current stage and the view time. It is the
 * computation {@link DELTA_V_BUDGET} runs each frame, available without a
 * running telemetry stream, such as in a test. Useful for showing the operator
 * how much delta-v the vessel has left.
 *
 * @category Orbits and trajectories
 */
export function deriveDeltaVBudget(
  summaryReading: TopicCurrency<SummaryWire>,
  stagesRaw: unknown,
  currentStage: number | undefined,
  viewUt: number,
): DeltaVBudget {
  // Carried, not withheld: every arm that has a value gives one up. See this
  // file's header for why the alternative is the dangerous direction.
  const summary =
    summaryReading.state === "observed" || summaryReading.state === "held"
      ? summaryReading.value
      : undefined;
  const observedAtUt = observedAt(summaryReading);
  const stages: DeltaVStage[] = [];
  if (Array.isArray(stagesRaw)) {
    for (const raw of stagesRaw) {
      const row = normaliseStage(raw);
      if (row) stages.push(row);
    }
  }
  const activeStage =
    currentStage === undefined
      ? null
      : (stages.find((s) => s.stage === currentStage) ?? null);
  if (summary === undefined && stages.length === 0) {
    return summaryReading.state === "pending"
      ? NO_BUDGET
      : {
          ...NO_BUDGET,
          budget: {
            state: summaryReading.state,
            asOfUt: observedAtUt,
            ageSec: undefined,
            confirmedAbsent: summaryReading.state === "absent",
          },
        };
  }

  return {
    totalVac: totalOf(summary?.totalDvVac, "m/s"),
    totalAsl: totalOf(summary?.totalDvAsl, "m/s"),
    totalActual: totalOf(summary?.totalDvActual, "m/s"),
    totalBurnTime: totalOf(summary?.totalBurnTime, "s"),
    stageCount: totalOf(summary?.stageCount, "count"),
    stages,
    activeStage,
    budget: {
      state: summaryReading.state,
      asOfUt: observedAtUt,
      // Never negative: a sample can sit marginally ahead of the frame's view time, and a negative age is not a thing to render.
      ageSec:
        observedAtUt === undefined
          ? undefined
          : Math.max(0, viewUt - observedAtUt.magnitude),
      confirmedAbsent: summaryReading.state === "absent",
    },
  };
}

/**
 * The processor that computes the active vessel's {@link DeltaVBudget} once per
 * frame. Useful for showing the operator how much delta-v the vessel has left.
 * Used by the maneuver planner.
 *
 * Read it with `useProcessor(DELTA_V_BUDGET)`, or list it in a contribution's
 * `deps`. Do not register a processor with the same id.
 *
 * @category Orbits and trajectories
 */
export const DELTA_V_BUDGET = CORE_UPLINK_CLIENT.registerProcessor({
  id: "delta-v-budget",
  deps: [
    // A READING for the summary, because the budget's currency IS part of the
    // answer: every verdict drawn from it (affordable, reachable, enough to land
    // on) has to know whether the number is now or was.
    { reading: "dv.summary" },
    "dv.stages",
    "vessel.structure",
  ] as const,
  compute: ([summaryReading, stagesRaw, structure], frame): DeltaVBudget =>
    deriveDeltaVBudget(
      summaryReading,
      stagesRaw,
      structure?.currentStage ?? undefined,
      frame.viewUt,
    ),
});
