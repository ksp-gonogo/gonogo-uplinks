/**
 * Libration points as places: the five positions a body pair holds still, and
 * how far off one of them a craft is.
 *
 * ## The pair is the frame, and that is the whole shape of this module
 *
 * A libration point is a fixed location only in a frame co-rotating with two
 * bodies. All five of one pair's points stand still in that pair's frame at the
 * same time, so five markers in one frame is exactly right, and Kerbin-Mun's
 * points and Kerbol-Kerbin's points cannot both stand still at once. Naming the
 * pair therefore is naming the frame: there is one choice here, not two, and
 * every function below takes the secondary body and derives the rest.
 *
 * ## Why the pulsating frame rather than a plain rotating one
 *
 * The frame this module works in is {@link ReadFrameChoice} `rotating-pulsating`
 * (reference-frame.ts): origin at the two sides' combined mass centre, first
 * axis on the bearing between them, and every coordinate divided by their
 * separation. That last part is what makes the points constants rather than
 * merely slow: for a pair on an eccentric orbit the equilibrium positions are
 * fixed in the NON-DIMENSIONALISED rotating frame and are not fixed in a
 * metre-scaled one, because the whole configuration breathes with the
 * separation. Divide by the separation and the breathing goes out of the
 * coordinates; keep metres and the five points walk in and out once per orbit.
 *
 * That is also why a metre-scaled diagram cannot host these markers, whatever
 * else it does well: it would draw them moving, which is the one thing a
 * libration point is defined not to do.
 *
 * ## What the numbers are, stated rather than implied
 *
 * The five positions are the restricted three-body problem's equilibria for the
 * pair's mass ratio: L4 and L5 in closed form, L1 to L3 as the roots of the
 * collinear equilibrium equation, solved numerically. The mass ratio comes from
 * the two sides' summed gravitational parameters, the same sides the frame is
 * built on, so the points and the frame cannot disagree about where the origin
 * is.
 *
 * Declared fidelity: **restricted three-body equilibria for the pair, in the
 * pair's own pulsating frame.** The other thirty-odd bodies move the true
 * equilibria slightly and are not solved for here; they do enter through the
 * frame, whose angular velocity is summed over the whole catalogue as point
 * masses. A craft is never at a mathematical equilibrium anyway, which is what
 * the offset below is for.
 */

import { PerfBudget } from "../perf/PerfBudget";
import type { CelestialBody, CelestialFacts } from "./celestial-facts";
import type { Vec3Tuple } from "./kepler";
import {
  type FrameInstant,
  frameInstantAt,
  frameSides,
  fromFrame,
  type ReadFrameChoice,
  type SystemInstant,
  systemInstantAt,
  toFrame,
} from "./reference-frame";

export const LAGRANGE_POINT_NAMES = ["L1", "L2", "L3", "L4", "L5"] as const;

/**
 * One of a pair's five libration points: `L1` between the two bodies, `L2`
 * beyond the secondary, `L3` opposite it, and `L4` and `L5` leading and trailing
 * it by sixty degrees. Useful for labelling a point on a diagram of a pair of
 * bodies for the operator. Held in each {@link LibrationPoint}.
 *
 * @category Frames of reference
 */
export type LagrangePointName = (typeof LAGRANGE_POINT_NAMES)[number];

/**
 * Why a pair has no five points, or that it has them, as {@link LibrationAnswer}'s
 * `refusal`. Useful for telling the operator what to pick or why a pair cannot
 * be drawn.
 *
 * Zero is `NotAttempted`, "no pair was named": the state before an operator
 * picks one, and while the catalogue has not arrived. It is not a refusal, so
 * say what to pick rather than showing it as a fault. Only `NotRefused` comes
 * with points.
 *
 * The three refusals differ in what an operator would do about them: a body the
 * catalogue does not carry, a body that cannot have a pair at all, and a real
 * pair whose states at this instant do not determine its points. The answer's
 * `because` carries the sentence for each.
 *
 * @category Frames of reference
 */
export const LIBRATION_REFUSALS = {
  /** No pair was named, so no points were sought. Not a fault and not a complaint. */
  NotAttempted: 0,
  /** A pair was named and the catalogue does not carry that body this frame. */
  PairUnknown: 1,
  /** The named body is the root star. It orbits nothing, so there is no pair to turn about. */
  RootHasNoPair: 2,
  /**
   * The pair is real and this instant does not determine its points: a parent
   * chain the solver cannot walk, a side with no gravitational parameter on the
   * wire, or a separation too degenerate to give the frame a bearing. The
   * answer's own sentence says which.
   */
  NotComputable: 3,
  /** The five points were computed. Only ever beside a present set of five. */
  NotRefused: 4,
} as const;

/**
 * One value of {@link LIBRATION_REFUSALS}. Useful for branching on why a pair has
 * no libration points. Held in the `refusal` of a {@link LibrationAnswer}.
 *
 * @category Frames of reference
 */
export type LibrationRefusal =
  (typeof LIBRATION_REFUSALS)[keyof typeof LIBRATION_REFUSALS];

/**
 * A body and its parent, the pair whose five libration points are wanted. Named
 * for the secondary, the smaller body: choosing the Mun means the Kerbin-Mun
 * pair. Useful for letting the operator pick the pair to draw. Returned in a list
 * by {@link librationPairsOf}.
 *
 * @category Frames of reference
 */
export interface LibrationPair {
  /** The body the pair is named for, and the one whose system is the secondary side. */
  secondaryIndex: number;
  /** The secondary body's name, or `null` when it is not known. */
  secondaryName: string | null;
  /** Its parent, whose system is the primary side. Null when the parent could not be identified. */
  primaryIndex: number | null;
  /** The primary body's name, or `null` when it is not known. */
  primaryName: string | null;
}

/**
 * One libration point of an answered pair, in the pair's own frame and in
 * inertial metres. Useful for drawing the point on a diagram of the pair. Held
 * in a {@link LibrationAnswer}.
 *
 * @category Frames of reference
 */
export interface LibrationPoint {
  /** Which of the five points this is, `L1` to `L5`. */
  name: LagrangePointName;
  /**
   * The point in the pair's rotating-pulsating frame: multiples of the pair's
   * separation, and constant for as long as the pair's mass ratio is.
   */
  frame: Vec3Tuple;
  /** The same point in root-centred inertial metres at the answer's `ut`. */
  inertial: Vec3Tuple;
}

/**
 * What {@link lagrangePointsAt} found for a pair at one instant: the five points
 * and the frame they stand still in, or a refusal saying why there are none.
 * Useful for showing the operator where the libration points of a pair are.
 *
 * Branch on `refusal` before reading anything else. Every field below it is
 * empty, `NaN` or null unless it is `NotRefused`.
 *
 * @category Frames of reference
 */
export interface LibrationAnswer {
  /** Why no points were found, or `NotRefused` when there are some. */
  refusal: LibrationRefusal;
  /** Which pair, as far as it is known. Null only when no body was named at all. */
  pair: LibrationPair | null;
  /**
   * Why, in words, for a reader. Empty on `NotRefused` and on `NotAttempted`:
   * one has nothing to explain and the other has nothing to explain yet.
   */
  because: string;
  /** L1 to L5 in that order. Empty unless `NotRefused`. */
  points: readonly LibrationPoint[];
  /**
   * The secondary side's share of the pair's mass, `m2 / (m1 + m2)`, which is
   * the only parameter the five positions depend on. `NaN` unless `NotRefused`.
   */
  massRatio: number;
  /** The frame the points stand still in. Null unless `NotRefused`. */
  frame: FrameInstant | null;
  /** The frame that was sought, whether or not it was formed. */
  frameChoice: ReadFrameChoice;
  /** The instant the answer is for, in UT seconds. */
  ut: number;
}

/**
 * Libration point sets computed, per second.
 *
 * One per second per widget in steady state, because the set only changes when
 * the view instant does and a caller buckets the instant. The regression is a
 * widget recomputing on every render instead: at display rate that is sixty a
 * second from one widget, a hundred and twenty once the development build's
 * double render is counted, and either of those crosses this while eight
 * widgets drawing normally do not come near it.
 */
const LIBRATION_BUDGET = new PerfBudget({
  name: "Libration point sets computed/sec",
  threshold: 100,
  windowMs: 1000,
  unit: "sets",
});

/**
 * Where a vessel sits against an answered pair's points: which one it is nearest
 * and how far off it. Useful for showing the operator how far a vessel is from a
 * libration point. Returned by {@link librationOffsetOf}.
 *
 * Distance alone does not say whether a vessel is station-keeping on the point:
 * that also needs its velocity relative to the point in the pair's rotating
 * frame, which {@link toFrame} gives.
 *
 * @category Frames of reference
 */
export interface LibrationOffset {
  /** The Lagrange point the craft is nearest. */
  nearest: LagrangePointName;
  /** The craft in the pair's frame: multiples of the separation. */
  vesselFrame: Vec3Tuple;
  /** Straight-line distance from the craft to that point at the answer's `ut`, metres. */
  distanceMetres: number;
  /** The same distance as a multiple of the pair's separation. */
  distanceUnits: number;
}

const NO_PAIR_CHOICE = (
  bodyIndex: number | null | undefined,
): ReadFrameChoice => ({
  kind: "rotating-pulsating",
  bodyIndex: bodyIndex ?? null,
});

function refused(
  refusal: LibrationRefusal,
  because: string,
  pair: LibrationPair | null,
  bodyIndex: number | null | undefined,
  ut: number,
): LibrationAnswer {
  return {
    refusal,
    pair,
    because,
    points: [],
    massRatio: Number.NaN,
    frame: null,
    frameChoice: NO_PAIR_CHOICE(bodyIndex),
    ut,
  };
}

function parentOf(
  facts: CelestialFacts,
  body: CelestialBody,
): CelestialBody | null {
  if (body.referenceBody === null) return null;
  const parent = facts.bodies.find((b) => b.name === body.referenceBody);
  // A body listed as its own parent is the root saying so, not a cycle.
  return parent === undefined || parent.index === body.index ? null : parent;
}

function sideMass(system: SystemInstant, side: readonly number[]): number {
  let mass = 0;
  for (const index of side) mass += system.muByIndex.get(index) ?? 0;
  return mass;
}

/**
 * `x` where the collinear equilibrium condition vanishes, in frame units along
 * the first axis, with the combined mass centre at the origin.
 *
 * The primary sits at `-mu` and the secondary at `1 - mu`. The condition is the
 * rotating frame's radial balance: the centrifugal term `x` against each body's
 * pull. It diverges at either body, which is what gives each of the three roots
 * a bracket with a sign change across it.
 */
function collinearResidual(x: number, mu: number): number {
  const toPrimary = x + mu;
  const toSecondary = x - 1 + mu;
  const dp = Math.abs(toPrimary);
  const ds = Math.abs(toSecondary);
  return (
    x -
    ((1 - mu) * toPrimary) / (dp * dp * dp) -
    (mu * toSecondary) / (ds * ds * ds)
  );
}

/** Bisection, or null when the bracket does not straddle a root. */
function bisectCollinear(
  mu: number,
  lower: number,
  upper: number,
): number | null {
  let lo = lower;
  let hi = upper;
  let fLo = collinearResidual(lo, mu);
  const fHi = collinearResidual(hi, mu);
  if (!Number.isFinite(fLo) || !Number.isFinite(fHi)) return null;
  if (fLo === 0) return lo;
  if (fHi === 0) return hi;
  if (fLo > 0 === fHi > 0) return null;
  // A hundred halvings of a bracket at most three units wide is well past double precision, and costs nothing at five points a second.
  for (let i = 0; i < 100; i++) {
    const mid = (lo + hi) / 2;
    const fMid = collinearResidual(mid, mu);
    if (!Number.isFinite(fMid)) return null;
    if (fMid > 0 === fLo > 0) {
      lo = mid;
      fLo = fMid;
    } else {
      hi = mid;
    }
  }
  return (lo + hi) / 2;
}

/** How close to a body the collinear brackets stop. Small enough not to exclude a root, large enough that the divergent term stays finite. */
const COLLINEAR_BRACKET_GAP = 1e-9;

/**
 * The five equilibria for a mass ratio, in the pair's frame, or null when the
 * collinear roots do not bracket. Useful for finding the libration points of
 * any pair of bodies from their masses alone. Used by {@link lagrangePointsAt}.
 */
export function librationPositionsFor(
  massRatio: number,
): readonly { name: LagrangePointName; frame: Vec3Tuple }[] | null {
  const mu = massRatio;
  if (!(mu > 0 && mu < 1)) return null;
  const primaryX = -mu;
  const secondaryX = 1 - mu;
  const l1 = bisectCollinear(
    mu,
    primaryX + COLLINEAR_BRACKET_GAP,
    secondaryX - COLLINEAR_BRACKET_GAP,
  );
  const l2 = bisectCollinear(
    mu,
    secondaryX + COLLINEAR_BRACKET_GAP,
    secondaryX + 1,
  );
  const l3 = bisectCollinear(
    mu,
    primaryX - 1,
    primaryX - COLLINEAR_BRACKET_GAP,
  );
  if (l1 === null || l2 === null || l3 === null) return null;
  // L4 and L5 need no solving: each forms an equilateral triangle with the two
  // bodies, so in these units they sit half a separation along the axis from the
  // primary and root-three-over-two off it.
  const triangleX = 0.5 - mu;
  const triangleY = Math.sqrt(3) / 2;
  return [
    { name: "L1", frame: [l1, 0, 0] },
    { name: "L2", frame: [l2, 0, 0] },
    { name: "L3", frame: [l3, 0, 0] },
    { name: "L4", frame: [triangleX, triangleY, 0] },
    { name: "L5", frame: [triangleX, -triangleY, 0] },
  ];
}

/**
 * The five libration points of the pair the given body belongs to, at `ut`.
 * Useful for showing the operator where the points of a pair of bodies are.
 *
 * `secondaryIndex` names the body, and its parent completes the pair. Pass the
 * `system` when the caller already solved the whole catalogue at this instant,
 * which is the ordinary case for a widget also placing a vessel.
 *
 * The points stand still only in the pair's rotating-pulsating frame, the
 * answer's `frame`, whose coordinates are multiples of the bodies' separation.
 * Draw them there; on a metre-scaled diagram they would move.
 *
 * @category Frames of reference
 */
export function lagrangePointsAt(
  facts: CelestialFacts | undefined,
  secondaryIndex: number | null | undefined,
  ut: number,
  system?: SystemInstant,
): LibrationAnswer {
  if (facts === undefined || secondaryIndex == null || !Number.isFinite(ut)) {
    return refused(
      LIBRATION_REFUSALS.NotAttempted,
      "",
      null,
      secondaryIndex,
      ut,
    );
  }
  const secondary = facts.bodies.find((b) => b.index === secondaryIndex);
  if (secondary === undefined) {
    return refused(
      LIBRATION_REFUSALS.PairUnknown,
      `The catalogue does not carry body ${secondaryIndex}, so there is no pair to name.`,
      null,
      secondaryIndex,
      ut,
    );
  }
  const pairOf = (primary: CelestialBody | null): LibrationPair => ({
    secondaryIndex: secondary.index,
    secondaryName: secondary.name,
    primaryIndex: primary?.index ?? null,
    primaryName: primary?.name ?? null,
  });
  if (secondary.referenceBody === null) {
    return refused(
      LIBRATION_REFUSALS.RootHasNoPair,
      `${secondary.name ?? "That body"} orbits nothing, so it is not half of a pair and has no libration points.`,
      pairOf(null),
      secondaryIndex,
      ut,
    );
  }
  const primary = parentOf(facts, secondary);
  if (primary === null) {
    return refused(
      LIBRATION_REFUSALS.PairUnknown,
      `${secondary.name ?? "That body"} is listed as orbiting ${secondary.referenceBody}, which the catalogue does not carry.`,
      pairOf(null),
      secondaryIndex,
      ut,
    );
  }

  const pair = pairOf(primary);
  const choice = NO_PAIR_CHOICE(secondaryIndex);
  const sides = frameSides(facts, choice);
  if (sides === null) {
    return refused(
      LIBRATION_REFUSALS.NotComputable,
      `The ${pair.primaryName}-${pair.secondaryName} pair has no two sides the catalogue can name this frame.`,
      pair,
      secondaryIndex,
      ut,
    );
  }
  LIBRATION_BUDGET.record();
  const state = system ?? systemInstantAt(facts, ut);
  const frame = frameInstantAt(facts, choice, ut, state);
  if (frame === null) {
    return refused(
      LIBRATION_REFUSALS.NotComputable,
      `The ${pair.primaryName}-${pair.secondaryName} frame could not be formed at this instant: the pair's states give it no bearing or no mass.`,
      pair,
      secondaryIndex,
      ut,
    );
  }
  const primaryMass = sideMass(state, sides.primary);
  const secondaryMass = sideMass(state, sides.secondary);
  const total = primaryMass + secondaryMass;
  const massRatio = total > 0 ? secondaryMass / total : Number.NaN;
  const positions = librationPositionsFor(massRatio);
  if (positions === null) {
    return refused(
      LIBRATION_REFUSALS.NotComputable,
      `The ${pair.primaryName}-${pair.secondaryName} mass ratio is not a ratio the equilibrium equation has roots for; at least one side carries no gravitational parameter on the wire.`,
      pair,
      secondaryIndex,
      ut,
    );
  }

  return {
    refusal: LIBRATION_REFUSALS.NotRefused,
    pair,
    because: "",
    points: positions.map(({ name, frame: inFrame }) => ({
      name,
      frame: inFrame,
      inertial: fromFrame(frame, inFrame),
    })),
    massRatio,
    frame,
    frameChoice: choice,
    ut,
  };
}

/**
 * Which point a vessel is nearest, and how far off it is. Useful for showing
 * the operator how close a vessel is to a libration point.
 *
 * Pass the vessel's root-centred inertial position, in metres, at the answer's
 * own instant. `null` when the answer is a refusal or the position is not
 * finite. The metre distance is measured between inertial positions, so it is a
 * real distance even though the frame's coordinates are ratios.
 *
 * @category Frames of reference
 */
export function librationOffsetOf(
  answer: LibrationAnswer,
  vesselInertial: Vec3Tuple | null | undefined,
): LibrationOffset | null {
  if (answer.refusal !== LIBRATION_REFUSALS.NotRefused) return null;
  if (answer.frame === null || vesselInertial == null) return null;
  if (!vesselInertial.every((c) => Number.isFinite(c))) return null;
  const unitLength = answer.frame.unitLength;
  if (!(unitLength > 0) || !Number.isFinite(unitLength)) return null;

  let nearest: LibrationPoint | null = null;
  let best = Number.POSITIVE_INFINITY;
  for (const point of answer.points) {
    const dx = vesselInertial[0] - point.inertial[0];
    const dy = vesselInertial[1] - point.inertial[1];
    const dz = vesselInertial[2] - point.inertial[2];
    const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (!Number.isFinite(distance)) continue;
    if (distance < best) {
      best = distance;
      nearest = point;
    }
  }
  if (nearest === null || !Number.isFinite(best)) return null;

  return {
    nearest: nearest.name,
    vesselFrame: toFrame(answer.frame, vesselInertial).position,
    distanceMetres: best,
    distanceUnits: best / unitLength,
  };
}

/**
 * Every pair the catalogue can form, in the catalogue's body order. Useful for
 * building the control with which the operator picks a pair.
 *
 * A pair needs a body with a parent and a gravitational parameter on both sides.
 * The list leaves out every body {@link lagrangePointsAt} would refuse, so a
 * control built from it never offers a choice that cannot be drawn.
 *
 * @category Frames of reference
 */
export function librationPairsOf(
  facts: CelestialFacts | undefined,
): readonly LibrationPair[] {
  if (facts === undefined) return [];
  const out: LibrationPair[] = [];
  for (const body of facts.bodies) {
    if (body.referenceBody === null) continue;
    const primary = parentOf(facts, body);
    if (primary === null) continue;
    if (!(Number(body.gravParameter) > 0)) continue;
    if (!(Number(primary.gravParameter) > 0)) continue;
    out.push({
      secondaryIndex: body.index,
      secondaryName: body.name,
      primaryIndex: primary.index,
      primaryName: primary.name,
    });
  }
  return out;
}

/**
 * A pair's name as an operator reads it, primary first ("Kerbin-Mun"), the way
 * libration pairs are written. `"no pair"` for null. Useful for labelling the
 * pair the operator picked.
 *
 * @category Frames of reference
 */
export function librationPairLabel(pair: LibrationPair | null): string {
  if (pair === null) return "no pair";
  const primary = pair.primaryName ?? "?";
  const secondary = pair.secondaryName ?? "?";
  return `${primary}-${secondary}`;
}
