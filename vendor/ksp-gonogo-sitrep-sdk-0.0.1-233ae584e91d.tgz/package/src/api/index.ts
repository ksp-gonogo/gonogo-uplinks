// The curated author-facing barrel: the one framework, data and hook surface a
// third-party Uplink author imports. It carries the author-facing TYPES
// (declared here rather than re-exported, see ./types for why this leaf cannot
// reach the app's) and fail-loud SHIMS for the stateful members, every
// `registerX` and every hook, which delegate to the app-injected host and throw
// a named error naming the fix when no host is installed. No stateful member
// reaches the app, so a packed Uplink never carries a second registry, which is
// the whole point.
//
// The export list is not frozen. `./api-shape.gate.test.ts` records it, so any change to it is a deliberate one.
//
// EVERY Uplink goes through this barrel, including the ones bundled with the
// mod. There is no first-party path: bundling changes how an Uplink ships, not
// what it may import, and an Uplink that reaches past this barrel stops
// modelling what an outside author can actually build.

import type { ReactElement } from "react";
import { createElement } from "react";
import type { ModSettingsModel } from "../__generated__/contract";
import type {
  AnyCommandReply,
  CommandArgs,
  CommandId,
  CommandReply,
} from "../commands";
import type { Reading, ReckonableReading, TopicReading } from "../reading";
import type { ReckonableFields, ReckonableTopic } from "../reckonability";
import type { TopicId, TopicPayload } from "../topics";
import type { Value } from "../value";
import { getHost } from "./host";
// Carries the `SlotRegistry` declaration-merge for every first-party slot into any program that imports this barrel.
import "./slots";
// Carries the first-party `ContributionRegistry` declaration-merge, the same way.
import "./contribution-slots";
// Side-effect only: carries the `ContributionRegistry` declaration-merge for
// the `plots` slot. Same reasoning as the two imports above, one merge target
// per declaration-merge seam. `./plot-layers` needs no such import: it is
// `PlotEntry`'s contents rather than a slot of its own, so it merges nothing.
import "./plots";
import type {
  ActionDefinition,
  ActionHandlers,
  AnyContribution,
  AugmentDefinition,
  LateTelemetrySubscribe,
  PerfBudgetHandle,
  PerfBudgetOptions,
  SettingDefinition,
  SettingDefinitionOf,
  SettingsTabDefinition,
  SettingType,
  SlotProps,
  TelemetryClient,
  UplinkClientHandle,
  UseCommandOptions,
  UseCommandResult,
  UseRouteCommandsResult,
} from "./types";

// The alarm request surface: an Uplink asks the app to create an alarm and the
// app owns the result. See `./alarm-request.ts` for why it cannot arm one for
// itself.
export type {
  UplinkAlarmRequest,
  UplinkAlarmThresholdOp,
  UplinkAlarmThresholdTrigger,
  UplinkAlarmTimeTrigger,
  UplinkAlarmTrigger,
  UplinkAlarmVantage,
} from "./alarm-request";
export { useAlarmRequest } from "./alarm-request";
export type {
  CommSignalHopRateEntry,
  CrewRowToneEntry,
  ExperimentsInstrumentEntry,
  ShipMapPartMetaEntry,
  ShipMapPartMeterEntry,
  SpaceCenterFacilityEntry,
  StrategiesScreenEntry,
  SystemEntity,
  SystemEntityEmphasis,
  SystemEntityFixedPosition,
  SystemEntityMeta,
  SystemEntityOrbitPosition,
  SystemEntityPosition,
  SystemEntityShape,
  SystemEntityStyle,
  SystemProjectionExtent,
  SystemViewProjection,
  SystemViewVesselStatusEntry,
} from "./contribution-slots";
export type { GonogoHost } from "./host";
export { GONOGO_HOST_KEY, hasHost } from "./host";
export type { LogContext, Logger, TaggedLogger } from "./logger-contract";
// The plot-layer vocabulary. Its own module rather than a line in `./types`,
// because the union is the whole surface a contributor writes against and it
// carries the reasoning for the data-space and tone-not-colour rules.
export type {
  PlotAnnotationLayer,
  PlotCaptionLayer,
  PlotEmphasis,
  PlotFieldLayer,
  PlotLayer,
  PlotMarkerLayer,
  PlotPoint,
  PlotRegionLayer,
  PlotReliefLayer,
  PlotRuleLayer,
  PlotSeriesLayer,
} from "./plot-layers";
// The `plots` contribution slot's own types: the frame a plot pins and the
// entry it contributes. Its own module for the reason `./plot-layers` is one.
export type {
  PlotEntry,
  PlotFrame,
  PlotSubject,
  PlotSubjectRegistry,
} from "./plots";
export type {
  ActionGroupSlotContext,
  ActionGroupSlotId,
  AstronautComplexCrewContext,
  CrewAvatarContext,
  CrewBadgeContext,
  DeployedExperimentContext,
  DeployedScienceExperiment,
  ExperimentsInstrument,
  ExperimentsInstrumentSlotContext,
  FleetRosterUpdatesContext,
  LaunchDirectorPadContext,
  LaunchDirectorSlotContext,
  MapBaseLayerContext,
  MapCoverageGate,
  MapOverlayContext,
  ObjectiveSlotItem,
  ObjectiveSlotSection,
  ObjectiveSlotState,
  ObjectiveSourceContext,
  OrbitOverlayContext,
  ScienceDataAboardRowContext,
  ShipMapBounds,
  ShipMapOverlayContext,
  ShipMapPart,
  ShipMapPartStateModule,
  ShipMapPartType,
  StrategiesScreenBodyContext,
  SystemOverlayContext,
  TargetingHudContext,
} from "./slots";
export { type AlertTone, TONES, type Tone } from "./tone";
// The message-pipe contract. Defined entirely in terms of this package's own
// wire messages, so it belongs here rather than in `sitrep-client`, and living
// here is what lets the transport double ship from `/testing`.
export type {
  LostCommand,
  Transport,
  TransportStatus,
  UndeliveredCommand,
} from "./transport";
export type {
  ActionDefinition,
  ActionHandlers,
  ActionInputKind,
  ActionInputPayload,
  AnyContribution,
  AtmosphereModel,
  AugmentDefinition,
  AugmentSettingField,
  BadgeEntry,
  BodyDefinition,
  BodyMapConfig,
  BodyMask,
  ClientPrefSetting,
  ClientPrefSettingOf,
  CommandStatus,
  ComponentBehavior,
  ComponentDefinition,
  ComponentProps,
  ComponentRequirement,
  ComponentSlotRegistry,
  ComponentSlotSegment,
  ConfigComponentProps,
  ConfigField,
  Contributed,
  ContributionDefinition,
  ContributionDep,
  ContributionEntry,
  ContributionRegistry,
  ContributionSlotId,
  CoverageSourceDefinition,
  DataKey,
  DataRequirement,
  DataSource,
  DataSourceStatus,
  DelayClockLike,
  DelayMode,
  DepTopics,
  HostIceServers,
  InFlightCommand,
  LateTelemetrySubscribe,
  MapPoi,
  MapPoiAction,
  MapPoiProviderContext,
  MapPoiProviderDefinition,
  MeterEntry,
  NamespacedAugmentSettings,
  PerfBudgetHandle,
  PerfBudgetOptions,
  PredictedPhase,
  Screen,
  Seat,
  SettingDefinition,
  SettingDefinitionBase,
  SettingDefinitionOf,
  SettingsTabDefinition,
  SettingType,
  SettingValue,
  SettingValueByType,
  SlotId,
  SlotProps,
  SlotRegistry,
  StatEntry,
  StationBroker,
  StationBrokerAttach,
  StreamBackedSetting,
  StreamBackedSettingOf,
  StreamStatusValue,
  TelemetryClient,
  ThemeDefinition,
  TinyEssential,
  TinyEssentialTone,
  TinyMode,
  UplinkClientHandle,
  UplinkClientIdentity,
  UplinkRelay,
  UseCommandOptions,
  UseCommandResult,
  UseCommandResultFor,
  UseMapPois,
  UseRouteCommandsResult,
  WidgetScope,
  WidgetScopeRegistry,
} from "./types";

/**
 * The shared settings key for the host every Uplink dials (design:
 * `@ksp-gonogo/core`'s `settings/gameHost.ts`). A stable string literal, not a
 * value that ever changes at runtime, mirrored directly rather than imported
 * (the sdk leaf cannot depend on core; see `./types.ts`'s DataSource
 * type-mirror comment for the full constraint) and kept honest by
 * `packages/core/src/sdk-facade.conformance.test-d.ts`.
 *
 * @category Host and runtime
 */
export const GAME_HOST_KEY = "gameHost" as const;

// A burn's clock. Five calendar fields rather than one seconds box, because a
// burn is scheduled against a date and nudged against a minute, and the
// countdown runs to IGNITION rather than to the node: counting to the node puts
// ignition half a burn in the past by the time it reaches zero.
export type { BurnInstantParts } from "../burn-clock";
export {
  composeUt,
  decomposeUt,
  isBurning,
  timeToIgnition,
} from "../burn-clock";
// What the frame in force does to a readout. A physics rule rather than a
// wording choice, so it lives once here instead of in each widget that quotes a
// length or an apsis, and it is on the author surface because a widget cannot
// qualify its own numbers without it.
export type { FrameValidity, QualifiedFrame } from "../frame-qualifier";
export {
  apsidesExist,
  controlFrameLabel,
  frameCaveat,
  lengthsAreLengths,
} from "../frame-qualifier";

// The component / data-source / theme registry is NOT a shim: it lives in this
// package (`./registry.ts`). It was the LAST place the shim story did not hold up,
// because registration was published and nothing else about the registry was: an
// Uplink could add a widget through `registerComponent` and then had no supported
// way to reset the registry between test cases (18 Uplink files call
// `clearRegistry`) or to read back what it had added.
//
// Only the author-and-test half is here. The ORCHESTRATION reads
// (`getResolvedComponents`, `getReplacementConflicts`, `getComponents`,
// `getThemes`, `getTheme`) are on the `/registry` subpath
// instead, for the same reason `/spine` keeps `TimelineStore` off this barrel:
// nothing about writing an Uplink needs the dashboard's widget-resolution rules,
// and publishing them here would freeze app orchestration as third-party API.
export {
  clearRegistry,
  getComponent,
  getDataSource,
  getDataSources,
  registerComponent,
  registerDataSource,
  registerTheme,
  unregisterDataSource,
} from "./registry";

/*
 * These three, and `AugmentSlot` below, are also exported from
 * `@ksp-gonogo/ui-kit`, and there the declaration is the registry itself rather
 * than a shim onto the host. Both spellings now reach ONE registry: ui-kit
 * holds it in a global slot precisely so that a second loaded copy of that
 * package cannot fork it, which is what a mis-bundled Uplink used to do
 * silently. The pair is worth knowing about anyway, because the two differ with
 * no host installed: these throw a named error naming the fix, ui-kit's carry
 * on.
 */

/**
 * Every augment bound into `slot`, in render order. The read half of
 * {@link registerAugment}: an Uplink's test observes what it registered through
 * the same host it registered into.
 *
 * @category Extensions
 */
export const getAugmentsForSlot = (slot: string) =>
  getHost().getAugmentsForSlot(slot);
/**
 * Empty the augment registry. For tests; a running app never calls it.
 *
 * @category Extensions
 */
export const clearAugments = (): void => {
  getHost().clearAugments();
};
/**
 * Renders a component inside another widget's slot. Call it once, when the
 * module loads. Several augments may fill one slot, and all of them render,
 * ordered by `priority`.
 *
 * `component` is checked against the props the slot passes, so an augment of a
 * misspelled slot does not typecheck.
 *
 * @category Extensions
 */
export const registerAugment = <Slot extends string>(
  def: AugmentDefinition<Slot>,
): void => getHost().registerAugment(def);

// Registries that are NOT shims: they live in this package. None of them named
// anything above this leaf (provider definitions, opaque handles, one payload
// type), so the host indirection bought nothing and cost an Uplink the read half:
// it could register a POI provider, a handle or an action handler and then had no
// published way to fire or observe it. See `./map-poi.ts` for why their state sits
// in a `globalThis` slot rather than a module static.
//
// `dispatchAction` is the one an Uplink TEST reaches for most: it is how a widget's action is exercised with no serial device attached.
export {
  type ActionHandler,
  clearActionHandlers,
  dispatchAction,
  registerActionHandler,
  unregisterActionHandler,
} from "./action-dispatch";
// The body registry, likewise owned rather than shimmed. `getBody` WAS a shim, and
// its doc argued the case for this move without taking it: a bundled copy of a
// module-static map reads its own permanently-empty version. A `globalThis` slot
// closes that rather than routing around it, and `registerBody` /
// `registerStockBodies` become reachable for a planet pack at the same time.
export {
  clearBodies,
  getAllBodies,
  getBody,
  getImagingWindow,
  imagingQuality,
  registerBody,
} from "./bodies";
export {
  clearCoverageSources,
  getCoverageSourceSettings,
  getCoverageSources,
  onCoverageSourcesChange,
  registerCoverageSource,
  unregisterCoverageSource,
} from "./coverage-source";
export {
  clearMapPoiProviders,
  getMapPoiProviders,
  onMapPoiProvidersChange,
  registerMapPoiProvider,
} from "./map-poi";
// The settings store, its service and its React CONTEXT, likewise owned. `gameHost`
// has to have one answer, which is why `setSetting` and `subscribeSetting` were
// shims already; the context is the part a second copy breaks in silence, because a
// provider from one copy is invisible to a consumer of the other. With one context
// in one published package there is no second copy, so `useSetting`'s shim retires
// too.
export {
  SettingsProvider,
  useSetting,
  useSettingsService,
} from "./settings/SettingsContext";
export { SettingsService } from "./settings/SettingsService";

import { getSetting as readSetting } from "./settings/store";

export {
  getSetting,
  resetSettingsForTests,
  seedSetting,
  setSetting,
  subscribeSetting,
} from "./settings/store";
export {
  clearStationBrokers,
  registerStationBroker,
  unregisterStationBroker,
} from "./station-brokers";
export { registerStockBodies } from "./stock-bodies";
export {
  clearUplinkHandles,
  getUplinkHandle,
  registerUplinkHandle,
  unregisterUplinkHandle,
} from "./uplink-handles";

/**
 * Declares an Uplink client and returns its handle. Call it once per client.
 *
 * Pass the handle as `owner` to every `registerComponent` and
 * {@link registerAugment} call the client makes, and register contributions
 * through the handle's own `registerContribution`.
 *
 * @category Registering
 */
export const defineUplinkClient = (cfg: {
  id: string;
  version: string;
  name: string;
  /** What the Uplink does, in one or two sentences. See `UplinkClientHandle`. */
  description?: string;
}): UplinkClientHandle => getHost().defineUplinkClient(cfg);

/**
 * Adds a custom tab to the app's Settings. Prefer `registerSetting`, which the
 * app renders for you.
 *
 * @category Settings
 */
export const registerSettingsTab = (def: SettingsTabDefinition): void =>
  getHost().registerSettingsTab(def);

/**
 * Declare a setting the app renders in its Settings surface, the PREFERRED
 * path over a custom tab (`registerSettingsTab`). A client-pref setting
 * persists to localStorage; a stream-backed one shows a value the mod
 * publishes on a Topic and cannot be written at all. Rows may be `boolean`, `text` or
 * `number`, `readOnly`, and filed into a named `group` inside their category.
 * See `SettingDefinition`.
 *
 * Generic so the row's `type` decides what `defaultValue` and `select` are
 * allowed to be: declare `type: "number"` and a `defaultValue` of
 * `true` is a compile error at the call site rather than a `Switch` rendering
 * a tolerance.
 *
 * @category Settings
 */
export function registerSetting<
  SettingKind extends SettingType = "boolean",
  Topic extends TopicId = TopicId,
>(def: SettingDefinitionOf<SettingKind, Topic>): void;
/**
 * Register an ALREADY-TYPED definition, for a client that built its rows as a
 * list and registers them in a loop. Mixed rows collapse to
 * `SettingDefinition` the moment they share an array, and `select`'s
 * parameter is contravariant, so the generic form rejects exactly the shape a
 * list has.
 */
export function registerSetting(def: SettingDefinition): void;
export function registerSetting(
  def: SettingDefinitionOf<SettingType, TopicId> | SettingDefinition,
): void {
  // The cast collapses an unresolved T to the union the host takes. Every
  // instantiation of T IS a member of that union, but TypeScript will not
  // prove it while T is still a parameter.
  getHost().registerSetting(def as SettingDefinition);
}

/**
 * Whether a registered row is one the operator can change. The renderer's own
 * rule, exported so an Uplink asking the same question of its own definitions
 * gets the same answer: a `stream-backed` row is read-only whether or not it
 * said so.
 */
export { isReadOnlySetting, settingTypeOf } from "../spine/settings-registry";

/**
 * Subscribes to a Topic and returns its latest {@link TopicReading}: the
 * payload together with how current it is.
 *
 * The payload is only there when `state` is `"observed"`, or `"held"` for a
 * held value, so check `state` before reading it. Every payload field is also a
 * {@link Reading} of its own, so a single field can be passed on without
 * checking the whole reading first.
 *
 * For a Topic whose contract declares a forward model, such as
 * `vessel.flight`, it returns a {@link ReckonableReading}.
 *
 * A Topic with no `TopicId`, a per-subject namespace such as
 * `vessel.partActions.<flightId>`, is read with `useStream` instead.
 *
 * Where a payload is expected, pass the checked `value`, never the reading
 * itself: a payload type whose fields are all optional accepts a whole reading
 * without a type error, and then finds none of its fields.
 *
 * @param topic - The Topic to read, such as `"vessel.flight"`.
 *
 * @example A field passed on whole
 * ```tsx
 * function VerticalSpeed() {
 *   const flight = useTelemetry("vessel.flight");
 *   return <Unit value={flight.verticalSpeed} />;
 * }
 * ```
 *
 * @example Checking the state, for something only a current value may decide
 * ```tsx
 * function DescentFlag() {
 *   const flight = useTelemetry("vessel.flight");
 *   if (flight.state !== "observed") return null;
 *   return flight.value.verticalSpeed.lessThan(0) ? <Text>Descending</Text> : null;
 * }
 * ```
 *
 * @category Reading telemetry
 */
export function useTelemetry<Topic extends TopicId>(
  topic: Topic,
): Topic extends ReckonableTopic
  ? ReckonableReading<
      TopicPayload<Topic>,
      ReckonableFields<Topic> & keyof TopicPayload<Topic>
    >
  : TopicReading<TopicPayload<Topic>> {
  // The declared return must stay what the host returns: a narrower one typechecks every client and breaks at runtime.
  return getHost().useTelemetry(topic);
}

/**
 * The frame's view instant. See `GonogoHost.useViewUt` for why an Uplink needs
 * it and why it returns `undefined` rather than guessing.
 *
 * @category Delay and vantage
 */
export function useViewUt(): Value<"ut"> | undefined {
  return getHost().useViewUt();
}

/**
 * Canonical overload: keyed by `CommandId`, returns a handle whose `send` takes
 * that command's arguments and resolves that command's reply.
 *
 *   const setSas = useCommand("vessel.control.setSas");
 *   const result = await setSas.send({ enabled: true });
 *   // result: CommandResult
 *
 * `send` RESOLVES only when the command ran. The game refusing is a REJECTION,
 * carrying a `CommandErrorCode` a caller can switch on, so a resolved reply is
 * never a polite no. A dispatch the mod never replied to rejects too, once the
 * loss deadline passes; a `void`ed `send` is safe, the hook marks its own
 * rejection handled and surfaces refusals on `refusals` instead.
 *
 *   try {
 *     await setThrottle.send({ value: 1.2 });
 *   } catch (err) {
 *     // CommandErrorCode.Range: validated at admission, never clamped
 *   }
 *
 * Every command is DELAYED unless it is sim-meta, so a dispatch is not an event
 * that has happened, it is one that is travelling. The handle carries the whole
 * delay surface for that (`inFlight`, `effectiveDelaySeconds`, `delayMode`,
 * `gate`, `refusals`), and `<CommandDelay handle={cmd}>` renders it; in
 * development the hook throws on a dispatch made without one, so a delayed
 * command cannot ship with no delay UX.
 *
 * The full command vocabulary is `COMMAND_IDS`, generated from the mod's own
 * `[SitrepCommand]` declarations.
 *
 * @category Commands
 */
export function useCommand<Command extends CommandId>(
  command: Command,
  options?: UseCommandOptions,
): UseCommandResult<CommandArgs<Command>, CommandReply<Command>>;
/**
 * Escape-hatch overload, for a command id this SDK's map does not carry: an
 * Uplink's own before its client package has augmented `CommandArgsMap`, or a
 * DYNAMIC command whose id is computed per subject and so can have no static
 * member. Args stay `unknown` unless the caller names them; the reply falls back
 * to `AnyCommandReply`, the result envelope every command replies with, so even
 * a command nobody could name is not readable as though it were its own payload.
 *
 *   const reset = useCommand<{ id: string }>(`my-uplink.probe.${probeId}.reset`);
 *
 * An Uplink declaring its OWN commands should not live here. Augment
 * `CommandArgsMap`/`CommandReplyMap` from the client package and call
 * `registerUplinkCommand`, and the first overload covers them like any other.
 */
export function useCommand<Args = unknown, Reply = AnyCommandReply>(
  command: string,
  options?: UseCommandOptions,
): UseCommandResult<Args, Reply>;
export function useCommand(
  command: string,
  options?: UseCommandOptions,
): UseCommandResult {
  return getHost().useCommand(command, options);
}

/**
 * Call one of an Uplink's own methods from a widget, on either screen.
 *
 * A Topic carries what the game is doing and a command changes it; this is
 * neither. It is for the calls an Uplink's client makes to its own host-side
 * object: a WebRTC offer to answer, an inventory to fetch, anything whose shape
 * only that Uplink knows. Register the object with `registerUplinkHandle`, then
 * call it from anywhere with this.
 *
 * The hook is the screen boundary. On the main screen the call reaches the
 * handle directly. On a station it is relayed through the main screen, which is
 * the only thing a station ever talks to, and the Uplink's code is identical
 * either way.
 *
 *   const relay = useUplinkRelay("my-uplink");
 *   const cameras = await relay("listCameras", { vesselId });
 *
 * The returned function is stable for as long as the route is, so it is safe in
 * a dependency array. It rejects, rather than hanging, when no route exists.
 *
 * @category Host and runtime
 */
export function useUplinkRelay(uplinkId: string) {
  return getHost().useUplinkRelay(uplinkId);
}

/**
 * The ICE servers the main screen is handing out, for an Uplink opening a media
 * connection from a station.
 *
 * A station has no route to the relay that issues TURN credentials, so the main
 * screen broadcasts them and this is where they are read. Empty on the main
 * screen itself, which reaches the relay directly.
 *
 *   const ice = useHostIceServers(); const pc = new RTCPeerConnection({
 *   iceServers: ice.current() }); useEffect(() => ice.onChange((servers) =>
 *   reconfigure(pc, servers)), [ice, pc]);
 *
 * Credentials rotate, so a long-lived connection has to watch `onChange` rather
 * than read `current()` once.
 *
 * @category Host and runtime
 */
export function useHostIceServers() {
  return getHost().useHostIceServers();
}

/**
 * Cross-origin route reader: every currently-pending command addressed to
 * `topic`, regardless of which command centre dispatched it, the
 * companion to `useCommand`'s own-dispatch `inFlight`. See
 * `@ksp-gonogo/sitrep-client`'s `useRouteCommands` for the full contract.
 *
 * @category Commands
 */
export function useRouteCommands(topic: string): UseRouteCommandsResult {
  return getHost().useRouteCommands(topic);
}

/**
 * Reactively read `topic`, raw wire Topic or client-side derived channel alike,
 * as a {@link TopicReading} sampled at the current view instant: the latest
 * payload and how current it is. `pending` with no stream mounted and before
 * the first sample, `unowned` for a topic nothing publishes, and `held` once a
 * topic that was arriving stops, carrying the last real observation.
 *
 * `topic` is a `string` rather than a {@link TopicId} because the ids this
 * resolves are a superset of the generated union in two directions: a derived
 * channel (`"system.state"`, `"system.uplinkHealth"`) is computed in the
 * browser and has no `[SitrepTopic]` type for codegen to reflect, and a
 * third-party Uplink's own topics are declared at runtime and appear in no
 * union at all. {@link WidgetChannelId} is the closed union of the two
 * first-party halves, and is the type to annotate a first-party read with.
 *
 * Unlike {@link useTelemetry}, `Payload` is whatever the caller supplies with
 * nothing checking it was right. Reach for it when the topic has no
 * {@link TopicId} entry (a derived channel, or your own Uplink's), and for a wire
 * Topic prefer `useTelemetry`, whose payload type comes from the contract.
 *
 * @category Reading telemetry
 */
export function useStream<Payload>(topic: string): TopicReading<Payload> {
  return getHost().useStream<Payload>(topic);
}

/**
 * One Uplink's host mod settings, as the Uplink read them off the mod: the
 * typed read over `settings.<uplinkId>`, which is declared per Uplink at
 * runtime and so has no `TopicId`. Change a writable one with the
 * `settings.mod.write` command, and read whether it landed here rather than
 * from the reply.
 *
 * @category Reading telemetry
 */
export function useModSettings(
  uplinkId: string,
): TopicReading<ModSettingsModel> {
  return getHost().useStream<ModSettingsModel>(`settings.${uplinkId}`);
}

/**
 * Reactively read a Processor's current, frame-memoised value. Pass the handle
 * `defineUplinkClient(...).registerProcessor` returned: `Result` is inferred from
 * its brand, so `useProcessor(SHIP_SYSTEMS)` is typed as the processor's own
 * result. One evaluation per Sitrep frame is shared across every widget reading
 * the same handle (and any contribution that lists it in `deps`). Returns
 * `undefined` with no provider mounted, or before the first frame lands.
 *
 * A processor whose own deps include a reading returns a `Reading<Result>`,
 * because its inputs carried currency and so its result is datable. One
 * depending only on raw topic ids returns the bare `Result`: there is nothing
 * to date it by, and inventing an instant would be a claim nothing supports.
 * The handle's own brand decides which, so the two cannot be confused at a call
 * site.
 *
 * @category Processors
 */
export function useProcessor<Result, Carried extends boolean>(handle: {
  readonly id: string;
  readonly __resultType?: Result;
  readonly __carriesCurrency?: Carried;
}): (Carried extends true ? Reading<Result> : Result) | undefined {
  return getHost().useProcessor(handle);
}

/**
 * The shared view clock the whole dashboard renders against, for a widget that
 * needs the clock OBJECT rather than a reactive time: to schedule against a
 * frame tick, or to read the confirmed edge separately from a scrub target.
 * THROWS when no stream is mounted, so a widget that renders on a disconnected
 * dashboard wants {@link useViewClockOptional} instead, and one that just needs
 * the current time wants {@link useViewUt}, which is reactive per frame.
 *
 * Opaque here for the same reason as {@link useTelemetryStoreOptional}'s
 * return: narrow or cast at the call site.
 *
 * @category Delay and vantage
 */
export function useViewClock(): unknown {
  return getHost().useViewClock();
}

/**
 * Bind a widget's declared actions to handlers, so a mapped serial input can
 * fire them. Keyed by action id off the `actions` array the widget registered:
 *
 *     const actions = [
 *       { id: "toggle", label: "Toggle", accepts: ["button"] },
 *     ] as const satisfies readonly ActionDefinition[];
 *
 *     useActionInput<typeof actions>({
 *       toggle: () => { handleToggle(); return { on: isOn }; },
 *     });
 *
 * The instance id comes from the enclosing dashboard item, so no call site
 * passes it. An inline handler object is the expected shape: the latest one is
 * held in a ref behind stable proxies registered once on mount, so a handler
 * closing over fresh state needs no memoisation and re-registers nothing. A
 * handler's return value is fed back to the device's render style, which is how
 * a display on the hardware follows the widget.
 *
 * @category Actions
 */
export function useActionInput<Actions extends readonly ActionDefinition[]>(
  handlers: ActionHandlers<Actions>,
): void {
  getHost().useActionInput(handlers);
}

/**
 * Every registered data source with its live connection status, re-rendering on
 * each status change. `DataSourceState[]`, opaque here for the same reason as
 * {@link useViewClock}'s return.
 *
 * For a connection banner or a diagnostics panel. It says nothing about the
 * Sitrep stream itself, which is not a registered source: a widget asking
 * whether ITS data is current reads that off the {@link Reading} its
 * {@link useTelemetry} call already returns.
 *
 * @category Registering
 */
export function useDataSources(): unknown {
  return getHost().useDataSources();
}

/**
 * Real-time (non-delayed) read of `topic`, bypassing the certainty-gated
 * `TimelineStore` frame `useStream` samples through: for command-centre
 * bookkeeping topics (dispatch timestamps, link facts), never delayed craft
 * telemetry. See `GonogoHost.useLatestValue`'s doc for the raw-vs-derived
 * distinction.
 *
 * @category Reading telemetry
 */
export function useLatestValue<Payload = unknown>(
  topic: string,
): Payload | undefined {
  return getHost().useLatestValue<Payload>(topic);
}

/**
 * Fires `handler` once per discrete event delivered on a `ReliableOrdered`
 * channel topic: the event-consumption counterpart to `useStream`'s
 * sticky-latest-value read.
 *
 * @category Reading telemetry
 */
export function useStreamEvent<Payload = unknown>(
  topic: string,
  handler: (payload: Payload) => void,
): void {
  getHost().useStreamEvent(topic, handler);
}

/**
 * Returns a stable, imperative subscribe function for topics only known
 * after some async setup resolves, in a count decided at runtime. See
 * `LateTelemetrySubscribe`'s own doc for the full contract.
 *
 * @category Reading telemetry
 */
export function useLateTelemetrySubscribe(): LateTelemetrySubscribe {
  return getHost().useLateTelemetrySubscribe();
}

/**
 * The current view time (UT seconds), reactive per-frame.
 *
 * @category Delay and vantage
 */
export function useUtNow(): number | undefined {
  return getHost().useUtNow();
}

/**
 * The nearest `TelemetryProvider`'s `TimelineStore`, or `undefined` with none
 * mounted. Opaque (`unknown`), same reasoning as `useViewClock`, narrow/cast
 * at the call site if the concrete shape is needed.
 *
 * @category Reading telemetry
 */
export function useTelemetryStoreOptional(): unknown {
  return getHost().useTelemetryStoreOptional();
}

/**
 * Non-throwing variant of `useViewClock`: `undefined` with no provider mounted.
 *
 * @category Delay and vantage
 */
export function useViewClockOptional(): unknown {
  return getHost().useViewClockOptional();
}

/**
 * The most recently mounted `TelemetryProvider`'s `TelemetryClient`, or
 * `undefined` when none is mounted, for imperative use outside a hook
 * context (e.g. a `DataSource`'s own connect/dispatch bookkeeping).
 *
 * @category Reading telemetry
 */
export function getActiveTelemetryClient(): TelemetryClient | undefined {
  return getHost().getActiveTelemetryClient();
}

/**
 * Non-throwing hook variant of reading the nearest `TelemetryProvider`'s
 * `TelemetryClient`: `undefined` with no provider mounted.
 *
 * @category Reading telemetry
 */
export function useTelemetryClientOptional(): TelemetryClient | undefined {
  return getHost().useTelemetryClientOptional();
}

/**
 * Whether a recorded-flight replay session is currently active.
 *
 * @category Delay and vantage
 */
export function useReplaySessionActive(): boolean {
  return getHost().useReplaySessionActive();
}

/**
 * The authoritative host every Uplink dials: `saved ?? build-default`, where
 * the build default is `VITE_SITREP_HOST` or `localhost`. Ports are per-service
 * and NOT part of this, callers append their own.
 *
 * Implemented here rather than forwarded to the host. It was a shim while the
 * implementation lived in `@ksp-gonogo/core`, and the only thing it needed was
 * `getSetting`, which this package has owned since the settings store moved. A
 * host member for a two-line read of a setting this package already holds is
 * indirection with nothing on the other end, so the member retires with the
 * shim.
 *
 * @category Host and runtime
 */
export function getGameHost(): string {
  /* Spelled `import.meta.env` on purpose: Vite substitutes that exact text,
     and a read it cannot see (`Reflect.get(import.meta, "env")`) is undefined
     in both the dev server and the bundle. */
  const configured: unknown = (
    import.meta as ImportMeta & { env?: Record<string, unknown> }
  ).env?.VITE_SITREP_HOST;
  const buildDefault =
    typeof configured === "string" && configured ? configured : "localhost";
  return readSetting(GAME_HOST_KEY) ?? buildDefault;
}
// The read half of the contribution registry. The WRITE half stays on
// `defineUplinkClient`'s handle rather than appearing here: the handle stamps
// `${clientId}:` onto every id, and a bare `registerContribution` on this
// barrel would be a way to opt out of the namespacing that stops two Uplinks
// colliding.

/**
 * Every contribution that wins a slot: the highest priority band present, in
 * registration order.
 *
 * @category Extensions
 */
export function getContributionsForSlot(slot: string): AnyContribution[] {
  return getHost().getContributionsForSlot(slot);
}

/**
 * Subscribe to any change (register/unregister) in the contribution registry.
 *
 * @category Extensions
 */
export function onContributionsChange(cb: () => void): () => void {
  return getHost().onContributionsChange(cb);
}

/**
 * Empty the contribution registry. For tests; a running app never calls it.
 *
 * @category Extensions
 */
export function clearContributions(): void {
  getHost().clearContributions();
}

// The logger shim lives in `./logger`, not here: `perf/PerfBudget` needs it, and
// reaching it through this barrel made `perf/PerfBudget -> api/index ->
// api/settings/SettingsService -> perf/PerfBudget` a cycle. That cycle resolved
// only while api/index happened to load first; `SettingsService` constructs a
// budget at MODULE SCOPE, so anything importing `perf/PerfBudget` before this
// barrel got a half-initialised module and "PerfBudget is not a constructor".
// Same reason `safeRandomUuid` came out of the barrel.
export { logger } from "./logger";

/**
 * The composition point a widget OWNING a slot drops in for other Uplinks'
 * augments to fill. An Uplink that only fills someone else's slot never renders
 * this; it calls {@link registerAugment} and the owning widget renders it.
 *
 * Generic over the slot id, so `props` is checked against that slot's declared
 * {@link SlotProps} rather than a loose bag. Resolves to the app's own component
 * at render, which is what applies each augment's presence gating: an augment
 * whose Domain is absent contributes nothing here rather than being filtered at
 * registration.
 *
 * `@ksp-gonogo/ui-kit` exports this name too, and that one is the component
 * this resolves to. A widget should take it from there: same registry, and it
 * renders with no host installed, which an Uplink's own test wants.
 *
 * @category Extensions
 */
export function AugmentSlot<Slot extends string>(props: {
  name: Slot;
  props: SlotProps<Slot>;
}): ReactElement {
  /* The host's slot takes the erased form, because it renders slots for every
     widget and cannot know which one it holds. */
  const erased: { name: string; props?: Record<string, unknown> } = {
    name: props.name,
    props: props.props as Record<string, unknown>,
  };
  return createElement(getHost().AugmentSlot, erased);
}

// `ContributionsProvider` is NOT a shim here any more. It is
// `@ksp-gonogo/ui-kit`'s, directly: the aggregation moved there to sit beside the
// per-widget store it writes, and ui-kit is published, so an Uplink hosting its own
// slot imports it from the package that owns it. A shim would have made the name
// declared in two published packages, which
// `styleguide-shared-published-surface.test.ts` fails the build for, and it would
// have been indirection with one implementation on the other end.

/**
 * Construct a performance budget on the app's single registry (design: every
 * new data source MUST register one). A factory, not a re-exported class, so the
 * budget self-registers into the host's registry rather than a bundled copy.
 *
 * @category Logging and performance
 */
export function createPerfBudget(opts: PerfBudgetOptions): PerfBudgetHandle {
  return getHost().createPerfBudget(opts);
}

/**
 * Sort a caught `send()` rejection into refused / lost / failed. Published
 * because the alternative for an author is `instanceof` against a class in the
 * unpublished spine, or matching a code string they could only have read in our
 * source. The three names match the `CommandStatus` phases deliberately.
 */
export {
  COMMAND_LOST,
  type CommandRejection,
  classifyCommandRejection,
  commandRefusalSubject,
} from "./command-rejection";
// The coverage mask store, its in-memory cache and the React context that
// carries them. Owned here for the same reason the settings context is: a second
// copy of a context is invisible to the other side's provider, and `useCoverageMaskCache`
// was a shim precisely so an Uplink's hook would read the app's. With one context in
// one published package there is no second copy, so that shim retires too.
/**
 * Every `X as FogY` below is a deprecated alias of the name beside it. There is
 * no fog of war in this product: a coverage source contributes per-body masks
 * and a base-layer augment gates its own paint on them, so the fog names
 * described a model that no longer exists.
 *
 * They stay exported because a coverage-contributing Uplink lives in a separate
 * repository and calls `registerFogRevealSource` and `useFogMaskCache` against a
 * published sdk. Drop them once that Uplink has shipped a release built on the
 * coverage names, along with the two `Fog` type aliases at the foot of this file,
 * the matching entries in `api-shape.gate.test.ts`, and
 * `deprecated-fog-aliases.test.ts` entire.
 */
export {
  CoverageMaskCache,
  CoverageMaskCache as FogMaskCache,
  DEFAULT_MASK_HEIGHT,
  DEFAULT_MASK_WIDTH,
} from "./coverage/CoverageMaskCache";
export {
  CoverageMaskCacheProvider,
  CoverageMaskCacheProvider as FogMaskCacheProvider,
  CoverageMaskStoreProvider,
  CoverageMaskStoreProvider as FogMaskStoreProvider,
  DEFAULT_PROFILE_ID,
  useBodyCoverageMask,
  useBodyCoverageMask as useBodyFogMask,
  useCoverageMaskCache,
  useCoverageMaskCache as useFogMaskCache,
  useCoverageMaskStore,
  useCoverageMaskStore as useFogMaskStore,
} from "./coverage/CoverageMaskContext";
export {
  type CoverageMaskChangeListener,
  type CoverageMaskChangeListener as FogMaskChangeListener,
  CoverageMaskStore,
  CoverageMaskStore as FogMaskStore,
  MASK_SCHEMA_VERSION,
  type StoredMask,
} from "./coverage/CoverageMaskStore";
export {
  clearCoverageSources as clearFogRevealSources,
  getCoverageSourceSettings as getFogRevealSourceSettings,
  getCoverageSources as getFogRevealSources,
  onCoverageSourcesChange as onFogRevealSourcesChange,
  registerCoverageSource as registerFogRevealSource,
  unregisterCoverageSource as unregisterFogRevealSource,
} from "./coverage-source";
/**
 * The error vocabulary: every refusal and fault code, typed, and the sentence
 * and meaning behind any id a client meets, including an Uplink's refinements.
 */
export {
  describeErrorCode,
  noteRosterErrorCodes,
  registerErrorCodes,
  registeredErrorCodes,
} from "./error-codes";
/*
 * Root providers: how an Uplink mounts a context Provider at the top of a
 * screen's tree without the app importing it to hand-wire one in. Published
 * here rather than in `core` because `core` is not an author surface: an
 * Uplink may import this package and `ui-kit` and nothing else of the repo.
 */
/*
 * Revealed event sources: how an Uplink feeds the `event` alarm trigger with
 * the occurrences behind its own Topic, without the app importing it to build
 * the reader.
 */
export {
  clearRevealedEventSources,
  getRevealedEventSources,
  type RevealedEventSourceDefinition,
  readRevealedEvents,
  registerRevealedEventSource,
} from "./event-reveal";
/**
 * A small typed wrapper around `localStorage`. Stateless (no module-global
 * registry): a byte-for-byte port of `@ksp-gonogo/data`'s implementation,
 * not a re-export. See `./localStorageStore.ts`'s module header for why.
 */
export { LocalStorageStore } from "./localStorageStore";
export {
  clearRootProviders,
  getRootProviders,
  type RootProviderDefinition,
  RootProviders,
  registerRootProvider,
} from "./root-providers";
export { safeRandomUuid } from "./safe-random-uuid";
/** The type half of the deprecated fog aliases; see the value half above. */
export type {
  CoverageMaskCacheHandle as FogMaskCacheHandle,
  CoverageSourceDefinition as FogRevealSourceDefinition,
} from "./types";
