// ---------------------------------------------------------------------------
// Slot-registry mirror: the `SlotRegistry` declaration-merge for every
// first-party (packages/components-owned) augment slot, carried by the sdk
// leaf itself.
//
// Why this lives HERE and not beside the widgets that own the slots: an earlier
// revision had each slot-owning
// widget carry a SECOND `declare module "@ksp-gonogo/sitrep-sdk"` block
// alongside its existing `declare module "@ksp-gonogo/core"` one (see e.g.
// MapView/index.tsx). That doesn't work: TypeScript only applies ambient
// module augmentation from files that are actually part of the compiled
// PROGRAM, and a facade-sealed client (which must not import
// `@ksp-gonogo/components`) never pulls those files in: so
// `SlotProps<"map-view.overlay">` etc. resolve to `never` for a sealed
// client, exactly the failure mode this seam exists to prevent.
//
// The fix is NOT `import type` from `@ksp-gonogo/components`, same leaf
// constraint documented at length in `./types.ts`'s header: sitrep-sdk is
// the dependency-graph LEAF (core, components, data, and sitrep-client all
// depend on the sdk already), so naming `@ksp-gonogo/components` here, even
// as a type-only import, would form a turbo `^build` cycle. Every slot
// context type below is therefore MIRRORED (duplicated), same as every
// other author-facing type in `./types.ts`: self-contained, kept honest by
// eyeball + the widget's own doc comments, not a live import.
//
// `index.ts` imports this module for its ambient side effect only (no named
// exports added to the barrel) so every consumer of the facade, sealed or
// not: gets the full merge automatically, without a per-file side-effect
// import.
//
// Scope: every slot OWNED by a `packages/components` widget. Slots owned by
// an UPLINK's own client package (SCANsat's `Scanning`, "scanning.sections"
// /".badges"; kerbcast's `CameraFeed`: "camera-feed.overlay"/".badges") are
// deliberately NOT mirrored here: mirroring them would require the sdk to
// import type shapes from an Uplink client package, which, since every
// Uplink client already depends on the sdk, would be the exact same cycle.
// Those slots stay owned/declared entirely inside the Uplink's own file
// (once sealed, its `declare module "@ksp-gonogo/sitrep-sdk"` block lives
// right there, which works fine: the owning file is always part of its OWN
// package's compiled program, so no cross-package reachability problem
// exists for a slot's OWNER, only for a FOREIGN filler, which is exactly
// the packages/components case this file solves).
// ---------------------------------------------------------------------------

// --- SpaceCenterStatus (packages/components/src/SpaceCenterStatus) ---------

// "space-center-status.sections" / ".badges" carry no props today.

// --- ManeuverPlanner (packages/components/src/ManeuverPlanner) -------------

// "maneuver-planner.sections" / ".badges" carry no props today
// (ManeuverPlannerSectionsSlotProps / ManeuverPlannerBadgesSlotProps are
// both `Record<string, never>` aliases in the real widget).

// --- TargetPicker (packages/components/src/TargetPicker) -------------------

// "target-picker.sections" / ".badges" carry no props today.

// --- WarpControl (packages/components/src/WarpControl) ---------------------

// "warp-control.stepper" carries no props today.

// --- Targeting (packages/components/src/Targeting) -----------

/** Mirrors `TargetingHudContext` (Targeting/index.tsx). */
export interface TargetingHudContext {
  /** Half-range in degrees the reticle box maps to; the reticle clamps at the edge. */
  maxDeg: number;
  /**
   * Reticle-centre offset from HUD centre, each component in −1..1 (clamped
   * alignment angle ÷ `maxDeg`; `y` already flipped for screen coords so
   * positive is downward).
   */
  reticleOffset: { x: number; y: number };
  /**
   * Pixels the reticle travels per unit of `reticleOffset`, the same on both
   * axes and measured from the centre of the HUD's frame. An overlay places a
   * marker at `calc(50% + offset.x·reticleTravelPx px)` across and
   * `calc(50% + offset.y·reticleTravelPx px)` down to sit in the same space,
   * so a degree is as far across as it is down.
   */
  reticleTravelPx: number;
  /**
   * For the `targeting.camera` slot: report the aspect (width over height) of
   * the picture the augment paints with `object-fit: cover`, or `null` once it
   * paints none. The reticle's degree scale then follows the camera's visible
   * field rather than the frame. An overlay has no picture and never calls it.
   */
  reportPictureAspect: (aspect: number | null) => void;
  /** True while the two ports are within docking-alignment tolerance. */
  aligned: boolean;
  /** Raw docking alignment angles in degrees; undefined outside a docking scenario. */
  ax: number | undefined;
  ay: number | undefined;
  /** Range to the target in metres; undefined until the stream reports position. */
  distance: number | undefined;
  /**
   * Camera id the operator pinned for the backdrop, or unset to let the
   * augment choose. Opaque to this widget: the filling augment interprets it.
   */
  cameraFlightId: number | null | undefined;
}

// --- CommSignal (packages/components/src/CommSignal) -----------------------

// "comm-signal.sections" / ".badges" carry no props today.

// --- ShipMap (packages/components/src/ShipMap) -----------------------------

/** Mirrors `PartStateModule` (`packages/core/src/schemas/vessel-parts.ts`): the
 * only core-owned nested type `ShipMapPart` actually references. */
export interface ShipMapPartStateModule {
  type:
    | "solarPanel"
    | "radiator"
    | "antenna"
    | "parachute"
    | "engine"
    | "drill"
    | "cargoBay"
    | "landingGear";
  state: string;
  tracking?: boolean;
  flameout?: boolean;
}

/** Mirrors `PartType` (ShipMap/shipTopology.ts). */
export type ShipMapPartType =
  | "engine"
  | "booster"
  | "tank"
  | "decoupler"
  | "nose-cone"
  | "fin"
  | "rcs"
  | "capsule"
  | "solar"
  | "parachute"
  | "wheel"
  | "fuel-line"
  | "other";

/** Mirrors `ShipMapPart` (ShipMap/shipTopology.ts). */
export interface ShipMapPart {
  flightId: number;
  parentFlightId: number | null;
  name: string;
  title: string;
  type: ShipMapPartType;
  lat: number;
  axial: number;
  depth: number;
  rotationRad: number;
  size: { x: number; y: number; z: number };
  latHalfExtent: number;
  axialHalfExtent: number;
  dryMass: number;
  stage: number;
  maxTemp: number;
  temperatureK?: number;
  maxTemperatureK?: number;
  resources?: { n: string; a: number; c: number }[];
  ecFlowSign?: "producer" | "consumer" | null;
  fuelLineTarget?: number | null;
  partState?: ShipMapPartStateModule[];
}

/** Mirrors `ShipBounds` (ShipMap/ShipDiagramSvg.tsx). */
export interface ShipMapBounds {
  cx: number;
  cy: number;
  w: number;
  h: number;
}

/** Mirrors `ShipMapOverlayContext` (ShipMap/index.tsx). */
export interface ShipMapOverlayContext {
  /** The projected parts (per-part `lat`/`axial`/`flightId`/geometry). */
  parts: readonly ShipMapPart[];
  /** Overlay layer width in px (matches the diagram canvas). */
  width: number;
  /** Overlay layer height in px (matches the diagram canvas). */
  height: number;
  /** Metre-space fit bounds of the projected vessel. */
  bounds: ShipMapBounds;
  /** Base (identity-camera) metres→px scale. */
  baseScale: number;
  /** Screen-space margin (px) reserved around the fit-scaled diagram. */
  padding: number;
}

// --- CrewStatus (packages/components/src/CrewStatus) -------------------

/**
 * Props passed to every `crew-status.row-badges` augment, once per crew row.
 *
 * @category Extensions
 */
export interface CrewBadgeContext {
  /** The crew member this badge row belongs to, its identity for the augment. */
  crewName: string;
  /** Position in the roster; disambiguates duplicate names. */
  crewIndex: number;
}

/**
 * Props passed to every `crew-status.avatar` augment, once per crew row.
 *
 * @category Extensions
 */
export interface CrewAvatarContext {
  /** The crew member this avatar belongs to, its identity for the augment. */
  crewName: string;
  /** Position in the roster; disambiguates duplicate names. */
  crewIndex: number;
}

// --- AstronautComplex (packages/components/src/AstronautComplex) -----------

/** Mirrors `AstronautComplexCrewContext` (AstronautComplex/index.tsx). */
export interface AstronautComplexCrewContext {
  /** `ProtoCrewMember.name`: the join key to the augment's own crew channel. */
  kerbalName: string;
  /** `CrewStanding`, or null when the producer sent none. */
  standing: number | null;
  /** Whether this row is a hireable candidate rather than owned crew. */
  isApplicant: boolean;
}

// --- LaunchDirector (packages/components/src/LaunchDirector) ---------------

/** Mirrors `LaunchDirectorSlotContext` (LaunchDirector/index.tsx). */
export interface LaunchDirectorSlotContext {
  /**
   * Current KSP scene ("Flight", "Editor", ...), undefined until telemetry
   * arrives and while the mod cannot name the scene it is in.
   */
  scene: string | undefined;
  /** True while a vessel is in flight (scene === "Flight"). */
  inFlight: boolean;
  /** The saved craft selected in the pre-launch picker, or null when none. */
  selectedShip: string | null;
  /** The chosen launch-site name (e.g. "LaunchPad"). */
  selectedSite: string;
  /** Crew names the operator has selected for the launch. */
  selectedCrew: string[];
  /** Career funds balance; undefined in sandbox/science or before telemetry. */
  funds: number | undefined;
}

/** Mirrors `LaunchDirectorPadContext` (LaunchDirector/index.tsx). */
export interface LaunchDirectorPadContext {
  /** The site's internal `LaunchSite.name`: the stable key an Uplink joins on. */
  siteName: string;
  /** The site's human-facing name, as the row shows it. */
  displayName: string;
  /** KSP's `EditorFacility` name for this site: a `VAB` site is a pad, an `SPH` site a runway. */
  editorFacility: string;
  /** Whether a vessel is standing on this pad; `null` when this site reports no occupancy. */
  occupied: boolean | null;
  /** The occupying vessel's name, `null` when none is reported. */
  occupantName: string | null;
  /** Whether this is the pad the operator has opened, so an augment can spend more room on it. */
  expanded: boolean;
  /** Career funds balance; undefined in sandbox/science or before telemetry. */
  funds: number | undefined;
}

// --- Objectives (packages/components/src/Objectives) -----------------------

/** Mirrors `ObjectiveState` (Objectives/index.tsx). */
export type ObjectiveSlotState = "pending" | "active" | "reached" | "failed";

/** Mirrors `ObjectiveItem` (Objectives/index.tsx). */
export interface ObjectiveSlotItem {
  id: string;
  title: string;
  description?: string;
  state: ObjectiveSlotState;
  /** Parent label: the mission or contract this objective belongs to. */
  source: string;
  optional?: boolean;
  /** Set for contract parameters: enables the "alarm on completion" toggle. */
  contractId?: string;
}

/** Mirrors `ObjectiveSection` (Objectives/index.tsx). */
export interface ObjectiveSlotSection {
  /** The source's objectives. */
  items: ObjectiveSlotItem[];
  /**
   * Optional per-item alarm affordance a source may offer. Returns a
   * control for an item, or `null` for items that cannot be alarmed.
   *
   * `ReactNode`, not `unknown`. It was `unknown`, and that was the one mirrored
   * field in this file that a merged `SlotRegistry` proved inaccurate: this type
   * reaches the registry inside a `ComponentType<...>`, which is CONTRAVARIANT in
   * its props, so the mirror has to be assignable to the real type as well as the
   * other way round. `(item) => ReactNode` widens to `(item) => unknown` happily;
   * nothing narrows back. Every other field in this file compares as identical.
   */
  renderAlarm?: (item: ObjectiveSlotItem) => import("react").ReactNode;
}

/** Mirrors `ObjectiveSourceContext` (Objectives/index.tsx). `ComponentType` is
 * the same react type used throughout this leaf's other slot/component types. */
export interface ObjectiveSourceContext {
  Section: import("react").ComponentType<ObjectiveSlotSection>;
}

// --- Strategies (packages/components/src/Strategies) -----------------------

/**
 * The BODY of one Administration Building screen, below whatever strategy cards
 * the screen's own departments put there.
 *
 * <para>The sibling of the `strategies.screens` contribution slot in
 * `./contribution-slots.ts`, and the division of labour between them is the
 * point: a contribution says which screens the building has, an augment draws
 * what one of them contains beyond its department listing, and the host owns
 * the tab strip so nothing else has to.</para>
 */
export interface StrategiesScreenBodyContext {
  /** Which screen is being drawn. An augment bound for more than one branches on it. */
  screenId: string;
}

// --- ActionGroup (packages/components/src/ActionGroup) ---------------------

/** Mirrors `ActionGroupId` (`packages/core/src/actionGroups.ts`): the eight
 * known stock names, widened to admit an arbitrary custom (AGX) id. */
export type ActionGroupSlotId =
  | "SAS"
  | "RCS"
  | "Light"
  | "Gear"
  | "Brake"
  | "Abort"
  | "Precision Control"
  | "Stage"
  | (string & {});

/** Mirrors `ActionGroupSlotContext` (ActionGroup/index.tsx). */
export interface ActionGroupSlotContext {
  /** The KSP action group this instance controls (e.g. "AG1", "SAS", "Gear"). */
  groupId: ActionGroupSlotId;
  /** The display label: custom override or the official group name. */
  label: string;
  /** The group's current Value (boolean or numeric readout); `undefined` if unknown. */
  value: unknown;
  /** Rendered state readout: "ON", "OFF", a numeric string, or the null-display placeholder. */
  stateLabel: string;
}

// --- SystemView (packages/components/src/SystemView) -----------------------

/**
 * Mirrors `SystemOverlayContext` (SystemView/index.tsx). Draw in a `width` by
 * `height` origin-centred viewBox: `d` metres from the parent body is
 * `d * plotScale` user units from `center`. Both follow the diagram's pan and
 * zoom, so an overlay drawn this way moves with it.
 */
export interface SystemOverlayContext {
  /** Name of the parent body the diagram is centred on. */
  parentName: string;
  /** Diagram pixel width (origin-centred SVG frame). */
  width: number;
  /** Diagram pixel height. */
  height: number;
  /** Metres → SVG-user-unit plot scale at the diagram's current zoom. */
  plotScale: number;
  /** Where the parent body is drawn, after the diagram's pan: the origin until it is panned. */
  center: { x: number; y: number };
}

// "system-view.actions" carries no props today.

// --- MapView (packages/components/src/MapView) ------------------------------

/** Mirrors `MapOverlayContext` (MapView/index.tsx). */
export interface MapOverlayContext {
  /** Pixel width of the overlay layer (== the map canvas container). */
  width: number;
  /** Pixel height of the overlay layer. */
  height: number;
  /** Live pan/zoom camera driving the equirectangular projection. */
  camera: { zoom: number; panX: number; panY: number };
  /** Equirectangular world-canvas width the camera maps from. */
  worldW: number;
  /** Equirectangular world-canvas height the camera maps from. */
  worldH: number;
  /** The mapped body (may diverge from the active vessel under a pin). */
  bodyName: string | undefined;
  /** Mapped body physical radius, metres, when known. */
  bodyRadius: number | undefined;
  /**
   * Project geographic lat/lon (degrees) to a pixel coordinate in the
   * overlay layer's own space.
   */
  project: (lat: number, lon: number) => { x: number; y: number };
  /** The active vessel's RAW (unadjusted) lat/lon; undefined with no fix. */
  vesselLat: number | undefined;
  vesselLon: number | undefined;
}

/** Mirrors `MapViewScope` (MapView/index.tsx): what the widget is currently
 *  looking at, read with `useWidgetScope("map-view")`. */
export interface MapViewScope {
  /** The mapped body (may diverge from the active vessel under a pin). */
  bodyName: string | undefined;
}

/** Mirrors `CoverageGate` (MapView/useCoverageGate.ts). */
export interface MapCoverageGate {
  /** Composite reveal intensity, one byte per cell, row-major. */
  data: Uint8Array | null;
  version: number;
  width: number;
  height: number;
  /** True when at least one coverage source is registered AND a
   *  `CoverageMaskCacheProvider` is mounted to actually resolve its masks. */
  hasAnySource: boolean;
}

/** Mirrors `MapBaseLayerContext` (MapView/index.tsx). Stackable: any number
 *  of registered augments may fill this slot at once. */
export interface MapBaseLayerContext {
  /** The mapped body (may diverge from the active vessel under a pin). */
  bodyId: string | undefined;
  width: number;
  height: number;
  /** Per-namespace augment settings, keyed by augment id. Read straight off
   *  the host widget instance's saved config. */
  augmentSettings: Record<string, Record<string, unknown>> | undefined;
  /** The paint-gate (T4) for this body. */
  coverageGate: MapCoverageGate;
  /** Called by the augment whenever it has a fresh canvas to contribute (or
   *  `null` to withdraw one): MUST pass the augment's OWN id first, since
   *  more than one augment may hold a canvas at once. */
  onLayer: (
    id: string,
    canvas: HTMLCanvasElement | null,
    version: number,
  ) => void;
}

// --- TechTree (packages/components/src/TechTree) ---------------------------

/** Mirrors `TechNodeState` (TechTree/index.tsx). */
export type TechNodeSlotState = "Available" | "Researchable" | "Unavailable";

/** Mirrors `TechPart` (TechTree/index.tsx). */
export interface TechSlotPart {
  name: string;
  title: string;
  manufacturer: string;
  category: string;
  entryCost: number;
  purchased: boolean;
}

/** Mirrors `TechNode` (TechTree/index.tsx). */
export interface TechSlotNode {
  id: string;
  title: string;
  description: string;
  scienceCost: number;
  state: TechNodeSlotState;
  parents: string[];
  parts: TechSlotPart[];
}

// --- ScienceData (packages/components/src/ScienceData) ----------------------

/** Mirrors `ScienceDataAboardRowContext` (ScienceData/index.tsx). */
export interface ScienceDataAboardRowContext {
  /** The subject this Aboard row represents; an augment joins its own
   *  `science.experiments` read against this id to find the file and/or
   *  sample backing it. */
  subjectId: string;
}

// --- LandingStatus (packages/components/src/LandingStatus) ------------------
//
// `landing-status.envelope` is GONE, and it is worth saying why rather than
// leaving a hole. It was an overlay slot handing a guest a projection function,
// a coordinate space and the host's own descent integrator, and the host drew
// its curve, its wash and its marks through geometry that slot could not reach.
// The descent envelope is a whole contributed PLOT now, on the app-wide `plots`
// slot (see `./plots.ts`), and this widget's own is one of them: it arranges
// what it is handed and owns no projection a contributor cannot reach. What the
// guest lost was pixels; what it gained is that there is no host privilege left
// to out-draw it with.

// --- OrbitView (packages/components/src/OrbitView) --------------------------

/** Mirrors `OrbitOverlayContext` (OrbitView/index.tsx). */
export interface OrbitOverlayContext {
  /** Semi-major axis, distance units (metres from body centre). */
  sma: number;
  /** Eccentricity. */
  ecc: number;
  /**
   * Apoapsis radius from body centre, same units. `undefined` on a hyperbolic
   * orbit (`ecc >= 1`): there is no apoapsis to report.
   */
  apoapsis?: number;
  /** Periapsis radius from body centre, same units. */
  periapsis: number;
  /** Argument of periapsis, degrees (rotates the ellipse in-plane). */
  argPe: number;
  /** Current vessel true anomaly, degrees. */
  trueAnomaly: number;
  /** Parent body physical radius, same units, when known. */
  bodyRadius?: number;
  /** The body's position in the diagram's SVG frame (its origin). */
  center: { x: number; y: number };
  /** Visible half-extent of the frame, distance units (apoapsis-driven). */
  scale: number;
}

// --- Navball (packages/components/src/Navball) ------------------------------

// "navball.badges" carries no props today.

// --- Experiments (packages/components/src/Experiments) ---------------

/** Mirrors `Instrument` (Experiments/index.tsx). */
export interface ExperimentsInstrument {
  partId: string;
  partTitle: string;
  expId: string;
  deployed: boolean;
  hasData: boolean;
  rerunnable: boolean;
  inoperable: boolean;
}

/** Mirrors `ExperimentsInstrumentSlotContext` (Experiments/index.tsx). */
export interface ExperimentsInstrumentSlotContext {
  /** The instrument the augmented row is rendering. */
  instrument: ExperimentsInstrument;
}

// --- DeployedScience (mod/GonogoBreakingGroundUplink/client/src/DeployedScience) ---

/**
 * Mirrors `DeployedExperiment` (DeployedScience/index.tsx).
 *
 * The science figures and the `collecting` verdict are nullable because the mod
 * withholds each of them rather than substituting a zero, and a zero here is a
 * reading: a freshly planted experiment reports 0%. An augment rendering into
 * this slot has to branch on the null rather than draw it, the same as the
 * widget's own card does.
 */
export interface DeployedScienceExperiment {
  partId: number;
  id: string;
  name: string;
  total: number | null;
  limit: number | null;
  progress: number | null;
  stored: number | null;
  transmitted: number | null;
  collecting: boolean | null;
}

/** Mirrors `DeployedExperimentContext` (DeployedScience/index.tsx). */
export interface DeployedExperimentContext {
  /** The deployed experiment this card renders, the augment's datum. */
  experiment: DeployedScienceExperiment;
  /** The body the parent base sits on, for context. */
  body: string;
}

// "deployed-science.badges" carries no props today.

// --- FuelStatus (packages/components/src/FuelStatus) -----------------------

// "fuel-status.sections" / ".badges" carry no props today.

// --- PowerSystems (packages/components/src/PowerSystems) -------------------

/** Mirrors `PowerSystemsScope` (PowerSystems/index.tsx): what the widget is
 *  currently looking at, read with `useWidgetScope("power-systems")`. */
export interface PowerSystemsScope {
  /**
   * The resource the widget is currently focused on (the picker/action-cycle
   * selection). Lets an augment scope its breakdown/badge to the same
   * resource the operator is viewing rather than assuming ElectricCharge.
   */
  resource: string;
}

// --- FleetRoster (packages/components/src/FleetRoster) ---------------------

/**
 * Mirrors the props `FleetRoster` hands its per-vessel update line: which craft
 * this row is, and how much room the augment has.
 */
export interface FleetRosterUpdatesContext {
  /** The craft this row is about, so an active-vessel-scoped augment can bind to it. */
  vesselId: string;
  vesselName: string;
  /** The body the craft is at; empty when the roster does not know. */
  body: string;
  /**
   * The roster is too narrow for a per-row detail line, so an augment renders a
   * BADGE and nothing else.
   */
  compact: boolean;
}

// ---------------------------------------------------------------------------
// The merge itself: every first-party (packages/components-owned) slot id,
// enumerated by grepping every `declare module "@ksp-gonogo/core"` /
// `"@ksp-gonogo/sitrep-sdk"` SlotRegistry block across packages/components.
// ---------------------------------------------------------------------------

// Targets `./types` (relative), NOT the package specifier
// "@ksp-gonogo/sitrep-sdk": both resolve to the exact same file (this
// package's own `SlotRegistry` is declared in `./types.ts`, and TS module
// augmentation merges by resolved FILE IDENTITY, not by specifier string),
// but the relative form sidesteps a real self-referencing-package
// resolution flake: augmenting your own package by ITS OWN NAME from
// inside itself resolves inconsistently depending on which files happen to
// be program ROOTS (verified: succeeds under this package's own
// `tsconfig.json` full-`src` compile, fails under `tsconfig.test-d.json`'s
// narrower root set with "module cannot be found", even though `slots.ts`
// is transitively reachable in both). The relative specifier has no such
// ambiguity.
declare module "./types" {
  interface SlotRegistry {
    "space-center-status.sections": Record<string, never>;

    "maneuver-planner.sections": Record<string, never>;

    "target-picker.sections": Record<string, never>;

    "warp-control.stepper": Record<string, never>;

    "targeting.camera": TargetingHudContext;
    "targeting.overlay": TargetingHudContext;

    "comm-signal.sections": Record<string, never>;

    "ship-map.overlay": ShipMapOverlayContext;

    /**
     * Inline badges at the end of each crew row, keyed by `crewName`. Distinct
     * from the widget's `crew-status.badges` header segment.
     */
    "crew-status.row-badges": CrewBadgeContext;
    /**
     * A leading avatar cell on each crew row. The cell is reserved only while
     * an augment is bound, and stays blank for a kerbal the augment has nothing
     * for.
     */
    "crew-status.avatar": CrewAvatarContext;
    /**
     * One whole-widget section above the roster, for crew-wide status. Passes no
     * props.
     */
    "crew-status.summary": Record<string, never>;

    "astronaut-complex.crew": AstronautComplexCrewContext;
    "astronaut-complex.crew-badge": AstronautComplexCrewContext;
    // A whole tab, which passes nothing.
    "astronaut-complex.training": Record<string, never>;

    "launch-director.preflight": LaunchDirectorSlotContext;
    "launch-director.pad": LaunchDirectorPadContext;

    "objectives.source": ObjectiveSourceContext;

    "action-group.subsystem": ActionGroupSlotContext;

    "system-view.actions": Record<string, never>;
    "system-view.overlay": SystemOverlayContext;

    "map-view.overlay": MapOverlayContext;
    "map-view.base": MapBaseLayerContext;
    // Mounted by `Panel`'s universal segments, not by the widget. Declared so a
    // binder types against the propless contract, not the loose fallback.
    "map-view.sections": Record<string, never>;
    "map-view.actions": Record<string, never>;

    // Same universal segment, and the reason it is worth naming a second one:
    // the tech tree looked like a widget that needed a slot ADDED to it (it
    // declares no `augmentSlots` of its own), which is a first-party edit an
    // Uplink author cannot make. It does not, because `Panel` mounts
    // `${componentId}.sections` for every widget. Declared here so a binder
    // gets the propless contract rather than the loose fallback.
    "tech-tree.sections": Record<string, never>;

    "science-data.aboard-row": ScienceDataAboardRowContext;

    "orbit-view.overlay": OrbitOverlayContext;

    // Mounted by `Panel`'s universal segments, not by the widget.
    "landing-status.sections": Record<string, never>;
    "landing-status.actions": Record<string, never>;

    "experiments.instrument": ExperimentsInstrumentSlotContext;
    // Mounted by `Panel`'s universal `actions` segment, not by the widget.
    "experiments.actions": Record<string, never>;

    "deployed-science.experiment": DeployedExperimentContext;

    "fuel-status.sections": Record<string, never>;

    // Mounted by `Panel`'s universal `sections` segment; the resource in focus reaches an augment through `WidgetScopeRegistry` below instead.
    "power-systems.sections": Record<string, never>;

    "fleet-roster.updates": FleetRosterUpdatesContext;

    "strategies.screen-body": StrategiesScreenBodyContext;
  }

  // What each widget publishes about its own current focus, for an augment to
  // read with `useWidgetScope`. Mirrored here for the same reachability reason
  // the slot props above are: a widget in `packages/components` declaring its
  // scope is invisible to a sealed client that cannot see that package.
  interface WidgetScopeRegistry {
    "map-view": MapViewScope;
    "power-systems": PowerSystemsScope;
  }
}
