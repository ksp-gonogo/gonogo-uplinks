/**
 * The Topics this client knows about because a client package said so at
 * module load, as opposed to the ones a generated map or a hand-written list in
 * the gonogo repo names.
 *
 * An Uplink's Topics can never appear in a list written in this repo: it ships
 * separately, on its own schedule, and the first-party build has never heard of
 * it. What it does do, because narrowing and decode already require it, is call
 * `registerUplinkTopic` for each Topic id when its client package loads.
 * That call is the only runtime advertisement of an Uplink's Topics that
 * exists, so it is what everything downstream that needs "which Topics are real
 * right now" has to read.
 *
 * `registerTopicUnits` deliberately does not enrol a Topic here: a
 * client-derived channel declares its fields through it too, and nothing puts a
 * derived channel on the wire, so a units declaration is not evidence that
 * anything sends the Topic.
 *
 * Read by the field catalogue every value picker offers from, so an Uplink's
 * Topic reaches the pickers the moment its client package loads.
 *
 * Snapshot-shaped and subscribable because registration happens when the
 * Uplink's bundle loads, which is after the app has rendered. A consumer that
 * read this once at module load would be back to a fixed list, just a
 * differently-sourced one.
 */

const runtimeTopicIds = new Set<string>();
const listeners = new Set<() => void>();
let snapshot: readonly string[] = Object.freeze([]);

function invalidate(): void {
  snapshot = Object.freeze([...runtimeTopicIds]);
  for (const listener of listeners) listener();
}

/**
 * Record that `id` is a real Topic on this client. Called by
 * `registerUplinkTopic`, never directly by an Uplink: an author
 * registers the way they already do and this follows.
 */
export function noteRuntimeTopic(id: string): void {
  if (runtimeTopicIds.has(id)) return;
  refuseIfAlreadySplit(id, (key) => key === id || key.startsWith(`${id}.`));
  runtimeTopicIds.add(id);
  invalidate();
}

/** Whether a client package has registered `id` as a Topic. */
export function isRuntimeRegisteredTopic(id: string): boolean {
  return runtimeTopicIds.has(id);
}

/**
 * Record that a registration changed what a Topic enumerates without vouching
 * for a new Topic: `registerTopicUnits` and `registerTypeUnits`. The id list is
 * unchanged and the snapshot's identity still moves, because a catalogue built
 * between an Uplink's Topic registration and its unit registration would
 * otherwise hold that Topic's fields as empty until something else invalidated
 * it.
 */
export function noteRuntimeTopicMetadata(): void {
  invalidate();
}

/**
 * Every Topic id a client package has registered with
 * {@link registerUplinkTopic}, in registration order. Useful for listing the
 * Topics an operator can pick a value from, including the ones an Uplink adds
 * after the app has rendered. Used by the picker in which the operator chooses
 * one field of a Topic to plot.
 *
 * The array is the same object until the next registration, so it can be a
 * `useSyncExternalStore` snapshot or a `useMemo` dependency. Pair it with
 * {@link subscribeRuntimeTopicRegistry}.
 *
 * @category Reading telemetry
 */
export function getRuntimeRegisteredTopicIds(): readonly string[] {
  return snapshot;
}

/**
 * Calls `listener` whenever a registration changes
 * {@link getRuntimeRegisteredTopicIds}, including a registration of units for
 * a Topic already listed. Returns a function that unsubscribes. Useful for
 * keeping a list of Topics an operator can pick from current as Uplinks load.
 * Used by the hook behind the picker in which the operator chooses one field of
 * a Topic to plot.
 *
 * @category Reading telemetry
 */
export function subscribeRuntimeTopicRegistry(
  listener: () => void,
): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * The prefixes, each ending in `.`, under which Topic ids are built at runtime
 * from something such as a vessel id or a part's flight id:
 * `trackingStation.vessel.<guid>.link`. A key under one of them is read as a Topic of its
 * own, never as a field of a shorter Topic.
 *
 * Gonogo's own prefixes are listed here, and an Uplink adds its own with
 * {@link registerDynamicTopicPrefix} when its client package loads. The array
 * always holds every prefix registered so far.
 *
 * Useful for letting the operator read each vessel's or part's data as a Topic
 * of its own. Used by the telemetry provider when it opens the stream.
 *
 * @category Reading telemetry
 */
export const DYNAMIC_WHOLE_TOPIC_PREFIXES: readonly string[] = [
  /*
   * trackingStation.vessel.<guid>.link and .resources. One prefix carries the
   * whole per-craft namespace, so the store timelines each craft's link and
   * resources as Topics of their own.
   */
  "trackingStation.vessel.",
  /*
   * currency.<guid>.science (+ .reputation): source-attributed currency events,
   * revealed after the signal delay from their source vessel.
   */
  "currency.",
  /*
   * vessel.partActions.<flightId>: the per-part PAW action lists (the mod's
   * PartActionsViewProvider.TopicPrefix). The keys are per-part and only ever
   * computed at interaction time, and the mod only produces a part's channel
   * while that part is subscribed, so covering the whole prefix costs nothing
   * for parts nobody has open.
   */
  "vessel.partActions.",
  /*
   * eva.kerbal.<vessel id>.state: one kerbal outside a craft, recorded on that
   * kerbal's own node so its own link decides whether it is held. Each kerbal's
   * Topic is listed on eva.crew.
   */
  "eva.kerbal.",
  /*
   * spaceCenter.craft.<facility>.<file>.parts: one saved craft file's part
   * tree. The mod measures a craft file only while its topic is subscribed.
   */
  "spaceCenter.craft.",
  /*
   * alarm.game.craft.<guid>.list: the game alarms whose time the game works
   * out from that craft, revealed after the signal delay from it.
   */
  "alarm.game.craft.",
];

const dynamicPrefixes = DYNAMIC_WHOLE_TOPIC_PREFIXES as string[];

/** The registered dynamic prefix `topic` sits under, or undefined. */
export function dynamicPrefixOf(topic: string): string | undefined {
  return dynamicPrefixes.find(
    (prefix) => topic.startsWith(prefix) && topic.length > prefix.length,
  );
}

/**
 * Registers a prefix under which an Uplink builds Topic ids at runtime, so
 * every key under it is read as a Topic of its own. Useful for an Uplink whose
 * Topics are one per vessel, part or body, so the operator's widgets receive
 * each one's readings. Call it when the client
 * package loads, with the same prefix the Uplink's mod passes to
 * `IUplinkHost.RegisterDynamicNamespace`. Registering a prefix twice does
 * nothing.
 *
 * Without it, a Topic such as `myuplink.forecast.250000` is read as the field
 * `250000` of a Topic `myuplink.forecast` that nothing publishes, and its
 * reading never arrives.
 *
 * Throws for a prefix that does not end in `.`, has an empty segment, or has
 * fewer than two segments before the trailing dot (which would swallow a whole
 * domain), and for one registered after something has already been read
 * under it.
 *
 * @category Reading telemetry
 */
export function registerDynamicTopicPrefix(prefix: string): void {
  if (dynamicPrefixes.includes(prefix)) return;
  const segments = prefix.split(".");
  if (
    !prefix.endsWith(".") ||
    segments.length < 3 ||
    segments.slice(0, -1).some((segment) => segment.length === 0)
  ) {
    throw new Error(
      `registerDynamicTopicPrefix("${prefix}"): a dynamic prefix is at least two segments ending in ".", such as "myuplink.forecast."`,
    );
  }
  refuseIfAlreadySplit(prefix, (key) => key.startsWith(prefix));
  dynamicPrefixes.push(prefix);
  invalidate();
}

/**
 * Every key the splitter has already cut into a Topic and a field path, with
 * the Topic it chose. A registration that would now cut one of them elsewhere
 * is refused rather than left to resolve the same key two ways in one session.
 */
const splitsHandedOut = new Map<string, string>();

/** Record that `key` was split with `rawTopic` as its Topic. */
export function noteSplitHandedOut(key: string, rawTopic: string): void {
  splitsHandedOut.set(key, rawTopic);
}

function refuseIfAlreadySplit(
  registered: string,
  wouldChange: (key: string) => boolean,
): void {
  for (const [key, rawTopic] of splitsHandedOut) {
    if (rawTopic.length >= registered.length || !wouldChange(key)) continue;
    throw new Error(
      `"${registered}" was registered after "${key}" had already been read as a field of "${rawTopic}". A client package registers its Topics and dynamic prefixes when it loads, before anything reads them.`,
    );
  }
}
