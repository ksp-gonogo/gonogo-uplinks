/**
 * Extra fields attached to one log entry, such as the id of the command it is
 * about. Useful for finding the entries of one request among the operator's
 * logs. Passed as the last argument of the {@link Logger} methods.
 *
 * @category Logging and performance
 */
export interface LogContext {
  /** The id of the command or request the entry is about, so its entries can be found together. */
  requestId?: string;
  /** An id for the operator the entry concerns, as a string; leave it out when there is none. */
  userId?: string;
  /** Which part of the code wrote the entry, such as an Uplink's id. */
  service?: string;
  [key: string]: unknown;
}

/**
 * A logger whose entries carry a tag, returned by `tag` on a {@link Logger}.
 * Its `debug` entries reach the console only while the tag is switched on,
 * which an operator does in the browser with
 * `localStorage.LOG_TAGS = "peer,camera"` (or `"*"` for every tag) and a
 * reload. Its `info`, `warn` and `error` entries always print. Every entry,
 * tagged or not, is kept in the log buffer and sent on either way. Useful for
 * tracing too chatty to print by default.
 *
 * @category Logging and performance
 */
export interface TaggedLogger {
  /** Detail for someone tracing a problem. Printed only while the tag is on. */
  debug(message: string, context?: LogContext): void;
  /** Something that happened and is worth a line. Always printed. */
  info(message: string, context?: LogContext): void;
  /** Something wrong that the code carried on past. Always printed. */
  warn(message: string, context?: LogContext): void;
  /** Something that failed, with the error that says how. Always printed. */
  error(message: string, error?: Error, context?: LogContext): void;
}

/**
 * The app's logger, with a method for each severity. Useful for leaving a line
 * in the operator's log buffer that is also sent on to the app's log service.
 * Reached through the `logger` export of this package.
 *
 * @category Logging and performance
 */
export interface Logger {
  /** Detail for someone tracing a problem. */
  debug(message: string, context?: LogContext): void;
  /** Something that happened and is worth a line. */
  info(message: string, context?: LogContext): void;
  /** Something wrong that the code carried on past. */
  warn(message: string, context?: LogContext): void;
  /** Something that failed, with the error that says how. */
  error(message: string, error?: Error, context?: LogContext): void;
  /** Returns a {@link TaggedLogger} for the tag `name`. */
  tag(name: string): TaggedLogger;
}
