import type { Meta, StreamBinary } from "./__generated__/contract";

/**
 * The binary lane, read side: how a frame carrying opaque bytes is told apart
 * from the JSON every other frame on this socket is, and taken apart.
 *
 * The C# writer is `Sitrep.Contract.Serialization.BinaryFrameCodec`, and
 * `Sitrep.Contract.BinaryLane` carries the full rationale. What matters here:
 *
 * ```
 * offset  size          field
 * 0       1             MAGIC (0x9E)
 * 1       1             LANE  (0x01 = stream-binary)
 * 2       2             u16 big-endian header length H
 * 4       H             UTF-8 JSON header, a StreamBinary
 * 4+H     sum(segments) the segments, concatenated, in declaration order
 * ```
 *
 * **This module is the whole dependency.** A third party can decode the lane
 * with the four lines the layout above describes and no gonogo package at all,
 * which is the point: tuning in must not require an SDK. This exists so
 * consumers that do have the SDK are not each writing their own, and so the two
 * ends of the format have exactly one place to drift apart at.
 */

/**
 * First byte of every binary-lane frame, the value that tells it from a JSON
 * text frame. Useful for code that reads the socket itself and must route each
 * received frame to the right decoder. Used by {@link isBinaryFrame}.
 *
 * @category Binary lane
 */
export const BINARY_LANE_MAGIC = 0x9e;

/**
 * The lane byte of a `stream-binary` frame, the only lane in use. The other
 * values of that byte are left free for lanes to come. Used by
 * {@link decodeBinaryFrame} to refuse a frame whose lane this build does not
 * know.
 *
 * @category Binary lane
 */
export const BINARY_LANE_STREAM_BINARY = 0x01;

/**
 * The length of a binary frame's fixed prefix, in bytes. A frame is laid out
 * as the magic byte, the lane byte, the header's length as a big-endian
 * unsigned 16-bit number, the header as UTF-8 JSON of that length, and then
 * the segments one after another, each as long as the header says. Useful for
 * code that slices a received frame by hand. Used by {@link decodeBinaryFrame}.
 *
 * @category Binary lane
 */
export const BINARY_LANE_PREFIX_BYTES = 4;

/**
 * One binary frame, decoded: the fields of its {@link StreamBinary} header,
 * with `segments` holding the segments' bytes in place of their lengths. Each
 * segment is a `Uint8Array`. Useful for handing a received binary payload, such
 * as radio audio, to the code that plays or stores it. Returned by
 * {@link decodeBinaryFrame}.
 *
 * @category Binary lane
 */
export type StreamBinaryMessage = Omit<StreamBinary, "segments"> & {
  /** The bytes of each segment, in the order the header listed them. */
  segments: Uint8Array[];
};

/**
 * Why a frame could not be decoded. Every case carries a `reason` to log;
 * branch on `kind` to decide what to do, such as reading the frame as text
 * instead. A frame with zero segments decodes successfully, as a producer with
 * nothing to send. Carried by {@link BinaryFrameResult} when decoding fails.
 * Useful for deciding whether to read a frame as text or to report why it was
 * dropped.
 *
 * @category Binary lane
 */
export type BinaryFrameFailure =
  /** Not a binary-lane frame at all. The caller should treat it as text. */
  | {
      /** Which way the bytes failed to be a frame. */
      kind: "not-binary";
      /** A sentence to log. */
      reason: string;
    }
  /** A lane byte this build does not know: refuse it, never fall back to text. */
  | {
      /** Which way the bytes failed to be a frame. */
      kind: "unknown-lane";
      /** The lane byte this build does not know. */
      lane: number;
      /** A sentence to log. */
      reason: string;
    }
  /** Well-formed prefix, unreadable frame. */
  | {
      /** Which way the bytes failed to be a frame. */
      kind: "malformed";
      /** A sentence to log. */
      reason: string;
    };

/**
 * What {@link decodeBinaryFrame} returns: the decoded message, or the reason the
 * bytes are not one. Useful for code that reads the socket itself and must
 * either deliver the message or log why a frame was refused.
 *
 * @category Binary lane
 */
export type BinaryFrameResult =
  | {
      /** The bytes decoded. */
      ok: true;
      /** The decoded message. */
      message: StreamBinaryMessage;
    }
  | ({
      /** The bytes did not decode. */
      ok: false;
    } & BinaryFrameFailure);

/**
 * Whether `bytes` start with the binary frame's magic byte. A text frame never
 * does, since it starts with `{`. Useful for choosing, per received frame,
 * between reading it as JSON text and calling {@link decodeBinaryFrame}. Used
 * by the stream's WebSocket transport.
 *
 * @category Binary lane
 */
export function isBinaryFrame(bytes: Uint8Array): boolean {
  return bytes.length >= 1 && bytes[0] === BINARY_LANE_MAGIC;
}

const HEADER_TEXT_DECODER = new TextDecoder("utf-8", { fatal: false });

/**
 * Decodes one binary frame into a {@link StreamBinaryMessage}, or says why it
 * could not. Useful for code that reads the socket itself and receives opaque
 * payloads such as radio audio. Used by the stream's WebSocket transport.
 *
 * Each segment is a view onto `bytes`, not a copy, so decoding is cheap. Copy a
 * segment you keep after `bytes` may be reused.
 *
 * @category Binary lane
 * @categoryDescription Binary lane
 * The stream's binary frames, which carry bulk payloads as raw bytes beside
 * the JSON text frames everything else arrives in: how to tell a binary frame from a text one and read its header and
 * body. Only code that reads the socket itself meets these: a widget that
 * reads Topics with `useTelemetry` or `useStream` can skip this page.
 *
 * @concept Binary lane
 * The binary lane is how the stream carries a payload that is opaque bytes,
 * such as radio audio, without encoding it as JSON. Every other server frame is
 * UTF-8 JSON and opens with `{`; a binary-lane frame opens with
 * {@link BINARY_LANE_MAGIC} instead, then a lane byte
 * ({@link BINARY_LANE_STREAM_BINARY}, the only lane defined), a two-byte header
 * length, a JSON {@link StreamBinary} header, and the payload as one or more
 * segments laid end to end.
 *
 * - it is wire level: a widget reading Topics never meets a binary frame. Only
 *   code that reads the socket itself does, and checks the first byte with
 *   {@link isBinaryFrame} before parsing anything
 * - its bytes are delayed like any value: the header carries the same meta as a
 *   JSON data frame, so a binary delivery observes the signal delay, the
 *   vantage and the timeline exactly as a JSON one does
 * - no segments is not no message: a frame with zero segments decodes
 *   successfully, while a frame whose segment lengths do not add up is refused
 *   with a reason ({@link BinaryFrameFailure}) and never replaced by an empty
 *   payload
 *
 * {@link decodeBinaryFrame} reads a frame into a {@link StreamBinaryMessage}.
 * What each segment means belongs to the Uplink that sends it.
 */
export function decodeBinaryFrame(bytes: Uint8Array): BinaryFrameResult {
  if (!isBinaryFrame(bytes)) {
    return {
      ok: false,
      kind: "not-binary",
      reason: "frame does not lead with the binary-lane magic byte",
    };
  }
  if (bytes.length < BINARY_LANE_PREFIX_BYTES) {
    return {
      ok: false,
      kind: "malformed",
      reason: `frame is shorter than the ${BINARY_LANE_PREFIX_BYTES}-byte binary-lane prefix`,
    };
  }

  const lane = bytes[1];
  if (lane !== BINARY_LANE_STREAM_BINARY) {
    /*
     * Named, and never decoded as text. Handing an unknown lane's bytes to a
     * UTF-8 decoder produces replacement characters that then fail JSON
     * parsing somewhere else entirely, by which point the one fact worth
     * reporting (this build does not know this lane) has been thrown away.
     */
    return {
      ok: false,
      kind: "unknown-lane",
      lane,
      reason: `unknown binary lane 0x${lane.toString(16).toUpperCase().padStart(2, "0")}`,
    };
  }

  const headerLength = (bytes[2] << 8) | bytes[3];
  const available = bytes.length - BINARY_LANE_PREFIX_BYTES;
  if (headerLength > available) {
    return {
      ok: false,
      kind: "malformed",
      reason: `header claims ${headerLength} bytes, only ${available} remain in the frame`,
    };
  }

  const headerText = HEADER_TEXT_DECODER.decode(
    bytes.subarray(
      BINARY_LANE_PREFIX_BYTES,
      BINARY_LANE_PREFIX_BYTES + headerLength,
    ),
  );

  let header: {
    type?: unknown;
    topic?: unknown;
    segments?: unknown;
    meta?: unknown;
  };
  try {
    header = JSON.parse(headerText);
  } catch (error) {
    return {
      ok: false,
      kind: "malformed",
      reason: `header is not readable JSON: ${String(error)}`,
    };
  }

  if (header.type !== "stream-binary") {
    return {
      ok: false,
      kind: "malformed",
      reason: `header type is ${JSON.stringify(header.type)}, not "stream-binary"`,
    };
  }
  if (typeof header.topic !== "string") {
    return { ok: false, kind: "malformed", reason: "header has no topic" };
  }
  if (!Array.isArray(header.segments)) {
    return {
      ok: false,
      kind: "malformed",
      reason: "header has no segment table",
    };
  }
  if (typeof header.meta !== "object" || header.meta === null) {
    return { ok: false, kind: "malformed", reason: "header has no meta" };
  }

  let declared = 0;
  for (const length of header.segments) {
    /* A byte count, so a fractional or negative one is not a short frame: it
       is a producer that has lost track of its own buffer, and computing an
       offset from it would read whatever the next frame's bytes happen to be. */
    if (typeof length !== "number" || !Number.isInteger(length) || length < 0) {
      return {
        ok: false,
        kind: "malformed",
        reason: `segment length must be a non-negative integer, got ${String(length)}`,
      };
    }
    declared += length;
  }

  const payloadStart = BINARY_LANE_PREFIX_BYTES + headerLength;
  const payloadAvailable = bytes.length - payloadStart;
  // Exact, in both directions. Short is truncation; long means the header and
  // the bytes disagree about what was sent, and delivering the prefix that
  // does line up would hand a listener a fragment of a transmission with
  // nothing to say it is one.
  if (declared !== payloadAvailable) {
    return {
      ok: false,
      kind: "malformed",
      reason: `segment table sums to ${declared} bytes, frame carries ${payloadAvailable}`,
    };
  }

  const segments: Uint8Array[] = [];
  let cursor = payloadStart;
  for (const length of header.segments as number[]) {
    segments.push(bytes.subarray(cursor, cursor + length));
    cursor += length;
  }

  return {
    ok: true,
    message: {
      type: "stream-binary",
      topic: header.topic,
      meta: header.meta as Meta,
      segments,
    },
  };
}

/**
 * The bytes of a frame, from an `ArrayBuffer` (a socket with
 * `binaryType = "arraybuffer"`) or a view. A `Blob` is not accepted: reading
 * one is asynchronous, which would put frames out of order. Useful for turning
 * what the socket delivered into the input {@link isBinaryFrame} and
 * {@link decodeBinaryFrame} take. Used by the stream's WebSocket transport.
 *
 * @category Binary lane
 */
export function frameBytes(data: ArrayBuffer | ArrayBufferView): Uint8Array {
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
}
