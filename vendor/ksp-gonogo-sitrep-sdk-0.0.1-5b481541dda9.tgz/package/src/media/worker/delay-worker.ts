/// <reference path="../webcodecs-track-io.d.ts" />
/**
 * The shared worker's entry point: cross-browser video-delay
 * design, 2026-07-16, "one long-lived worker; each feed is a pipeline keyed
 * by id" (locked decision 2). Deliberately THIN: everything it does routes
 * straight into already-unit-tested pieces:
 * `runFrameDelayPipeline`/`DelayedPlayoutBuffer` (unchanged, F1),
 * `createWorkerDelayClock` (`worker-delay-clock.ts`), `createNowWall`
 * (`time-base.ts`), `interpolateCaptureUt` (`../capture-clock.ts`), and
 * `startPacingTicker` (`../frame-delay.ts`, shared with the main-thread
 * backend). This file itself is message plumbing only.
 *
 * NOT unit-tested: jsdom has neither real Workers nor WebCodecs (per this
 * task's brief), so there is no way to exercise `self.onmessage` / a real
 * `MediaStreamTrackProcessor` in vitest. Correctness here rests on (a) every
 * piece it calls being independently tested, and (b) a manual cross-browser
 * verification, 2026-07-16, of the actual browser behaviour this file assumes:
 * Safari/WebKit transfers a `MediaStreamTrack` into a worker and supports
 * `MediaStreamTrackProcessor` + `VideoTrackGenerator` there; Chrome and
 * Firefox (as of that verification) do not support the transfer at all,
 * `postMessage(..., [track])` throws SYNCHRONOUSLY on the MAIN thread
 * before this file ever runs, which is exactly why `createPipeline` never
 * needs to handle "the transfer silently failed": if we're executing this
 * handler at all, the track objectively arrived.
 *
 * Message protocol (see `delay-worker-client.ts` for the main-thread
 * side of each of these):
 *  - `init`           : once, at worker startup, reconciles wall-clock bases.
 *  - `clockSnapshot`   : ~60Hz, worker-global, the ONE shared ViewClock's
 *                          formula inputs (every pipeline reads the same
 *                          `WorkerDelayClock`, matching the app's ONE real
 *                          `ViewClock` instance).
 *  - `captureSample`   : per-pipeline, whenever that camera's low-rate
 *                          capture-clock sample changes.
 *  - `createPipeline`  : per-pipeline, carries the transferred input track.
 *  - `flush` / `dispose`: per-pipeline lifecycle control.
 *
 * Worker -> main:
 *  - `pipelineReady`        : success; carries the transferred output track.
 *  - `pipelineError`        : construction failed (feature absent, or the
 *                               processor/generator pair threw), the
 *                               "can't delay -> no video" case (decision 5).
 *  - `pipelineNonFatalError`: a post-construction read/write rejection,
 *                               mirrors `runFrameDelayPipeline`'s `onError`.
 *
 * Encoded-transform path (2026-07-16):
 * `self.onrtctransform` (native platform event, NOT one of the message
 * types above) is the entry point for the encoded-domain backend; see
 * `handleRtcTransform`'s doc. It reuses the SAME `pipelines` map,
 * `sharedClock`, and `captureSample`/`clockSnapshot` messages this file
 * already handles; only pipeline CONSTRUCTION differs (no handshake, no
 * transferred track). NOT YET REACHABLE from the real app, the main thread
 * has no `RTCRtpReceiver` to call `receiver.transform = new
 * RTCRtpScriptTransform(worker, {pipelineId})` on (the camera SDK
 * discards it in `onTrack` today): see the report's "what's blocked"
 * section. This handler is therefore unreachable in production until that
 * SDK seam exists, but is structurally complete and ready to wire the
 * moment it does.
 */

import type { ClockFormulaSnapshot } from "../../view-clock-formula";
import type { CaptureClockSample } from "../capture-clock";
import { interpolateCaptureUt } from "../capture-clock";
import {
  attachEncodedFrameDelayTransform,
  type EncodedTransformerLike,
} from "../encoded-frame-delay";
import {
  type FrameDelayPipeline,
  runFrameDelayPipeline,
  startPacingTicker,
} from "../frame-delay";
import { createNowWall } from "./time-base";
import {
  createWorkerDelayClock,
  type WorkerDelayClock,
} from "./worker-delay-clock";

// --- Wire message shapes -----------------------------------------------

export interface InitMessage {
  type: "init";
  /** The main thread's `performance.timeOrigin` (ms): see `time-base.ts`. */
  mainTimeOriginMs: number;
}

export interface ClockSnapshotMessage {
  type: "clockSnapshot";
  snapshot: ClockFormulaSnapshot;
}

export interface CaptureSampleMessage {
  type: "captureSample";
  pipelineId: string;
  sample: CaptureClockSample;
}

export interface CreatePipelineMessage {
  type: "createPipeline";
  pipelineId: string;
  track: MediaStreamTrack;
  maxBufferedFrames?: number;
  maxPacingBacklogSeconds: number;
}

export interface FlushMessage {
  type: "flush";
  pipelineId: string;
}

export interface DisposePipelineMessage {
  type: "dispose";
  pipelineId: string;
}

export type MainToWorkerMessage =
  | InitMessage
  | ClockSnapshotMessage
  | CaptureSampleMessage
  | CreatePipelineMessage
  | FlushMessage
  | DisposePipelineMessage;

export interface PipelineReadyMessage {
  type: "pipelineReady";
  pipelineId: string;
  track: MediaStreamTrack;
}

export interface PipelineErrorMessage {
  type: "pipelineError";
  pipelineId: string;
  reason: string;
}

export interface PipelineNonFatalErrorMessage {
  type: "pipelineNonFatalError";
  pipelineId: string;
  reason: string;
}

export type WorkerToMainMessage =
  | PipelineReadyMessage
  | PipelineErrorMessage
  | PipelineNonFatalErrorMessage;

// --- Minimal worker-global surface --------------------------------------
// This package's shared tsconfig targets the default DOM lib (not
// "webworker": the two are mutually exclusive libs, and swapping the
// whole package to "webworker" would break every non-worker file that
// touches Window-only globals). Rather than fork a second tsconfig just
// for this one file, cast the ambient `self` down to the narrow slice this
// file actually needs, the same "minimal ambient surface" spirit as
// `webcodecs-track-io.d.ts`.
// `RTCTransformEvent`/`RTCRtpScriptTransform` are the standard WebRTC
// Encoded Transform API (see `../encoded-frame-delay.ts`'s module doc).
// Declared locally, narrowed to just what `handleRtcTransform` reads, for the same "minimal ambient
// surface, no full webworker lib" reason as `WorkerGlobalSurface` itself,
// this repo's default DOM lib doesn't reliably ship these types across TS
// versions, and a full declaration isn't needed.
interface RtcTransformEventLike {
  transformer: EncodedTransformerLike & {
    /** Structured-cloned from `new RTCRtpScriptTransform(worker, options)`'s
     *  second argument: the main thread's only channel to key this
     *  pipeline, since (unlike `createPipeline`) attaching a script
     *  transform has no message-based handshake of its own. */
    options?: {
      pipelineId?: string;
      maxBufferedBytes?: number;
      maxPacingBacklogSeconds?: number;
    };
  };
}

interface WorkerGlobalSurface {
  postMessage(message: WorkerToMainMessage, transfer?: Transferable[]): void;
  onmessage: ((ev: MessageEvent<MainToWorkerMessage>) => void) | null;
  /** Fires once per `receiver.transform = new RTCRtpScriptTransform(worker,
   *  options)` on the main thread: see `handleRtcTransform`. */
  onrtctransform: ((ev: RtcTransformEventLike) => void) | null;
}
/* The worker global, by the same "declare the surface, no full webworker lib"
   reasoning as `WorkerGlobalSurface` itself: the repo's DOM lib types `self` as
   a window, which this file never runs in. */
declare const self: WorkerGlobalSurface;
const workerSelf = self;

// --- State ---------------------------------------------------------------

let sharedClock: WorkerDelayClock | null = null;
/** Set once by `handleInit`: the SAME time-origin-corrected wall clock the
 *  shared `WorkerDelayClock` uses, reused for `captureUt` interpolation so
 *  both read the main thread's basis consistently (`sample.atMs` is a raw
 *  `performance.now()` reading taken ON the main thread). */
let nowWall: (() => number) | null = null;

interface PipelineEntry {
  /** Null only between the entry being made and the pipeline that closes over
   *  it being built, which is the same turn. */
  pipeline: FrameDelayPipeline | null;
  captureSample: CaptureClockSample;
  stopPacingTicker: () => void;
}
const pipelines = new Map<string, PipelineEntry>();

const DEFAULT_MS = { ut: null, warpRate: 1, atMs: 0 } as const;

function nowWallMs(readNowWall: () => number): number {
  return readNowWall() * 1000;
}

/** Feature-detect the writer, standard shape first (`VideoTrackGenerator`)
 *  then the fallback; see
 *  `webcodecs-track-io.d.ts`. Returns the constructed generator's OWN
 *  writable/output-track pair, uniformly, regardless of which shape won. */
function buildWriter(): {
  writable: WritableStream<VideoFrame>;
  outputTrack: MediaStreamTrack;
} | null {
  if (typeof VideoTrackGenerator !== "undefined") {
    const gen = new VideoTrackGenerator();
    return { writable: gen.writable, outputTrack: gen.track };
  }
  if (typeof MediaStreamTrackGenerator !== "undefined") {
    const gen = new MediaStreamTrackGenerator({ kind: "video" });
    return { writable: gen.writable, outputTrack: gen };
  }
  return null;
}

function handleInit(msg: InitMessage): void {
  // `createNowWall` expects `localTimeOrigin - mainTimeOrigin`, see
  // `time-base.ts`'s worked example. This worker's own
  // `performance.timeOrigin` IS `localTimeOrigin`, and `msg.mainTimeOriginMs`
  // IS `mainTimeOrigin`.
  const offsetMs = performance.timeOrigin - msg.mainTimeOriginMs;
  nowWall = createNowWall(offsetMs, () => performance.now());
  sharedClock = createWorkerDelayClock({ nowWall });
}

function handleClockSnapshot(msg: ClockSnapshotMessage): void {
  sharedClock?.applySnapshot(msg.snapshot);
}

function handleCaptureSample(msg: CaptureSampleMessage): void {
  const entry = pipelines.get(msg.pipelineId);
  if (entry) entry.captureSample = msg.sample;
}

function handleCreatePipeline(msg: CreatePipelineMessage): void {
  // Captured into locals immediately: `sharedClock` and `nowWall` are
  // module-level `let`s, so TS can't narrow them past the `buildWriter()` call
  // below. Neither can actually change between this check and the `try` block
  // regardless, a plain synchronous WebWorker having a single message queue.
  const clock = sharedClock;
  const clockNowWall = nowWall;
  if (!clock || !clockNowWall) {
    workerSelf.postMessage({
      type: "pipelineError",
      pipelineId: msg.pipelineId,
      reason: "worker clock not initialised (init message never arrived)",
    });
    return;
  }
  if (typeof MediaStreamTrackProcessor === "undefined") {
    workerSelf.postMessage({
      type: "pipelineError",
      pipelineId: msg.pipelineId,
      reason: "no MediaStreamTrackProcessor in this worker context",
    });
    return;
  }
  const writer = buildWriter();
  if (!writer) {
    workerSelf.postMessage({
      type: "pipelineError",
      pipelineId: msg.pipelineId,
      reason:
        "no VideoTrackGenerator/MediaStreamTrackGenerator in this worker context",
    });
    return;
  }

  try {
    const processor = new MediaStreamTrackProcessor({ track: msg.track });
    const entry: PipelineEntry = {
      // Filled in immediately below. The `captureUt` closure is passed to
      // `runFrameDelayPipeline` before `pipeline` exists, but it closes over
      // `entry` rather than the local `pipeline` const, so it always reads the
      // current sample even mid-construction.
      pipeline: null,
      captureSample: DEFAULT_MS,
      stopPacingTicker: () => {},
    };
    pipelines.set(msg.pipelineId, entry);

    const pipeline = runFrameDelayPipeline<VideoFrame>({
      view: clock,
      // Same time-origin-corrected wall clock the shared clock itself uses,
      // see the module-level `nowWall` doc. Since `sample.atMs` is a raw
      // main-thread `performance.now()` reading, the comparison has to land on
      // that same basis and not the worker's own uncorrected clock.
      captureUt: () =>
        interpolateCaptureUt(entry.captureSample, nowWallMs(clockNowWall)) ?? 0,
      maxBufferedFrames: msg.maxBufferedFrames,
      source: processor.readable.getReader(),
      sink: writer.writable.getWriter(),
      pacing: { maxBacklogSeconds: msg.maxPacingBacklogSeconds },
      onError: (err) => {
        workerSelf.postMessage({
          type: "pipelineNonFatalError",
          pipelineId: msg.pipelineId,
          reason: String(err),
        });
      },
    });
    entry.pipeline = pipeline;
    entry.stopPacingTicker = startPacingTicker(
      pipeline.tickPacing,
      clockNowWall,
    );

    workerSelf.postMessage(
      {
        type: "pipelineReady",
        pipelineId: msg.pipelineId,
        track: writer.outputTrack,
      },
      [writer.outputTrack],
    );
  } catch (err) {
    pipelines.delete(msg.pipelineId);
    workerSelf.postMessage({
      type: "pipelineError",
      pipelineId: msg.pipelineId,
      reason: String(err),
    });
  }
}

/**
 * Encoded-transform attach (encoded-transform video-delay work,
 * 2026-07-16). UNLIKE `handleCreatePipeline`, there is no message-based
 * handshake: `receiver.transform = new RTCRtpScriptTransform(worker,
 * options)` on the main thread fires this event directly, synchronously
 * from the platform's perspective: there is no "pipelineReady"/
 * "pipelineError" round trip to send, because attaching a script transform
 * either works (this handler runs) or the constructor itself throws on the
 * MAIN thread, before this file ever sees anything (mirrors this file's own
 * module-doc note about `MediaStreamTrack` transfer failures).
 *
 * Reuses the exact same `pipelines` map, `sharedClock`, and `captureSample`
 * per-pipeline state as `handleCreatePipeline`: `attachEncodedFrameDelayTransform`
 * returns the same `FrameDelayPipeline` shape (`flush`/`dispose`/
 * `tickPacing`) `runFrameDelayPipeline` does, so `handleFlush`/`handleDispose`/
 * `handleCaptureSample` all work unchanged regardless of which kind of
 * pipeline `pipelineId` maps to.
 */
function handleRtcTransform(event: RtcTransformEventLike): void {
  const clock = sharedClock;
  const clockNowWall = nowWall;
  if (!clock || !clockNowWall) {
    // No `pipelineError` channel to report through here (see doc above),
    // the transform is attached either way; frames will simply never
    // release (no clock to gate on) until `init` arrives. Matches
    // `handleCreatePipeline`'s equivalent guard in spirit, not in wire shape.
    return;
  }

  const options = event.transformer.options ?? {};
  const pipelineId =
    typeof options.pipelineId === "string"
      ? options.pipelineId
      : `encoded-${pipelines.size}-${Date.now()}`;

  const entry: PipelineEntry = {
    // Filled in immediately below: same "closes over `entry`, not the
    // local `pipeline` const" reasoning as `handleCreatePipeline`.
    pipeline: null,
    captureSample: DEFAULT_MS,
    stopPacingTicker: () => {},
  };
  pipelines.set(pipelineId, entry);

  const pipeline = attachEncodedFrameDelayTransform(event.transformer, {
    view: clock,
    captureUt: () =>
      interpolateCaptureUt(entry.captureSample, nowWallMs(clockNowWall)) ?? 0,
    maxBufferedBytes: options.maxBufferedBytes,
    maxPacingBacklogSeconds: options.maxPacingBacklogSeconds,
    onError: (err) => {
      workerSelf.postMessage({
        type: "pipelineNonFatalError",
        pipelineId,
        reason: String(err),
      });
    },
  });
  entry.pipeline = pipeline;
  entry.stopPacingTicker = startPacingTicker(pipeline.tickPacing, clockNowWall);
}

function handleFlush(msg: FlushMessage): void {
  pipelines.get(msg.pipelineId)?.pipeline?.flush();
}

function handleDispose(msg: DisposePipelineMessage): void {
  const entry = pipelines.get(msg.pipelineId);
  if (!entry) return;
  entry.stopPacingTicker();
  entry.pipeline?.dispose();
  pipelines.delete(msg.pipelineId);
}

workerSelf.onmessage = (ev) => {
  const msg = ev.data;
  switch (msg.type) {
    case "init":
      handleInit(msg);
      return;
    case "clockSnapshot":
      handleClockSnapshot(msg);
      return;
    case "captureSample":
      handleCaptureSample(msg);
      return;
    case "createPipeline":
      handleCreatePipeline(msg);
      return;
    case "flush":
      handleFlush(msg);
      return;
    case "dispose":
      handleDispose(msg);
      return;
  }
};

workerSelf.onrtctransform = handleRtcTransform;
