import {
  createContext,
  type ReactNode,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import type {
  CareerContract,
  CommandErrorCode,
  SystemBodies,
  VesselIdentity,
  VesselOrbit,
  VesselTarget,
  WarpState,
} from "../__generated__/contract";
import { DYNAMIC_CARRIED_TOPIC_PREFIXES } from "../default-carried-topics";
import { magnitudeOf } from "../magnitude";
import type { TopicReading } from "../reading";
import { topicReading } from "../reading";
import {
  getRuntimeRegisteredTopicIds,
  subscribeRuntimeTopicRegistry,
} from "../runtime-topic-registry";
import { isValue, value } from "../unit-system/value";
import type { Value } from "../value";
import type { TelemetryClient } from "./client";
import {
  getContributedDerivedChannels,
  onContributedChannelsChange,
} from "./contributed-channels";
import { noteUndeclaredRead } from "./contribution-scope";
import { registerCoreReckoners } from "./core-reckoners";
import { DelayAuthority } from "./delay-authority";
import {
  dvCurrentStageResourceChannel,
  dvCurrentStageResourceMaxChannel,
} from "./dv-stage-resources";
import { resolveValueTopic } from "./map-topic";
import { type OrbitalSolve, solveSelfOrbit } from "./orbital-solve";
import { OwnCraftDelayGate } from "./own-craft-vantage";
import {
  setActiveTimelineStore as setProcessorEvaluatorStore,
  setProcessorTopicSubscriber,
} from "./processorEvaluator";
import { StreamRecorder, type StreamRecorderOptions } from "./replay-recorder";
import { spaceCenterStateChannel } from "./space-center-state";
import { type ReadTopicResolver, subscribeTopicRead } from "./subscribe-read";
import { systemStateChannel } from "./system-state";
import type { DerivedChannelDefinition } from "./timeline-store";
import { TimelineStore } from "./timeline-store";
import { installUnownedTopicWarning } from "./unowned-warning";
import { systemUplinkHealthChannel } from "./uplink-health";
import type { VesselState } from "./vessel-state";
import { vesselStateChannel } from "./vessel-state";
import { ViewClock, type ViewClockOptions } from "./view-clock";

const TelemetryClientContext = createContext<TelemetryClient | undefined>(
  undefined,
);
const TimelineStoreContext = createContext<TimelineStore | undefined>(
  undefined,
);
const CarriedChannelsContext = createContext<ReadonlySet<string> | undefined>(
  undefined,
);

/**
 * Union `additions` into `previous`, returning `previous` UNCHANGED
 * (referentially) when nothing new was added, the monotonic-growth seam
 * behind `TelemetryProvider`'s carried-channels allowlist: adding a topic
 * can only move it from legacy->stream, never blank a widget. Never used
 * to shrink: a caller whose next render passes a SMALLER explicit
 * `carriedChannels` prop (or
 * whose transport's own `declaredChannels` shrinks: not expected in
 * practice, but not relied upon either) does not lose previously-carried
 * topics. This is what makes "promoting a topic" a one-way ratchet for the
 * lifetime of one mounted provider, never a mid-session reversal.
 */
function unionGrow(
  previous: ReadonlySet<string>,
  additions: Iterable<string>,
): ReadonlySet<string> {
  let next: Set<string> | undefined;
  for (const topic of additions) {
    if (previous.has(topic)) continue;
    if (!next) next = new Set(previous);
    next.add(topic);
  }
  return next ?? previous;
}

/**
 * Schedule `cb` to run on the next animation frame, falling back to a
 * microtask when `requestAnimationFrame` isn't available (SSR, or a bare
 * jsdom constructed without `pretendToBeVisual`).
 *
 * **Under vitest's jsdom environment `pretendToBeVisual` defaults to true, so
 * tests DO get a real `requestAnimationFrame` and exercise the frame path, not
 * the microtask fallback.** Worth stating plainly: believing otherwise sends an
 * act-warning investigation into the microtask branch, and an act warning here
 * originates in test teardown ordering instead.
 *
 * The coalescing primitive behind `TelemetryProvider`'s ingest ->
 * `beginFrame()` scheduling below. Returns a cancel function.
 */
function scheduleFrame(cb: () => void): () => void {
  if (typeof requestAnimationFrame === "function") {
    const handle = requestAnimationFrame(cb);
    return () => cancelAnimationFrame(handle);
  }
  let cancelled = false;
  queueMicrotask(() => {
    if (!cancelled) cb();
  });
  return () => {
    cancelled = true;
  };
}

export interface TelemetryProviderProps {
  client: TelemetryClient;
  children: ReactNode;
  /**
   * Advanced override: supply a pre-built `TimelineStore` (e.g. one with
   * extra derived channels registered, or non-default `ViewClock` options,
   * a scrub UI, a fixed replay delay) instead of the default one this
   * provider builds. When omitted, `TelemetryProvider` builds one itself,
   * see this component's own doc comment.
   */
  store?: TimelineStore;
  /** Only consulted when `store` is omitted, options for the default `ViewClock` this provider builds. */
  viewClockOptions?: ViewClockOptions;
  /**
   * Explicit per-topic promotion list (the carried-channels allowlist gate,
   * `./carried-channels.ts`): the "dev-first per-topic opt-in" half of the
   * allowlist, alongside `client.declaredChannels` (the transport's own
   * served-channel declaration). Union of the two is what `isTopicCarried`
   * consults before a read resolves against the stream, so a topic nothing
   * delivers reads as absent rather than as a fabricated blank. Monotonic:
   * a topic named here (or ever declared by the transport) stays carried for
   * the life of this mounted provider even if a later render omits it; see
   * `unionGrow`. Omit entirely to carry only whatever the transport itself
   * declares.
   */
  carriedChannels?: Iterable<string>;
}

/**
 * Supplies a `TelemetryClient`: and a `TimelineStore` fed from that
 * client's wire: to the component tree via context.
 *
 * **The bridge:** without this provider, nothing in production ever
 * constructed a `TimelineStore` or registered a derived channel on one, so
 * `vessel.state.*` (and any future derived channel) was permanently
 * unreachable through `useStream` even once a provider was mounted: the
 * derivation machinery in `vessel-state.ts`/`timeline-store.ts` existed but
 * was wired to nothing. This provider is what closes that gap:
 *
 * - Unless `store` is supplied, it builds ONE `TimelineStore` (backed by a
 *   `ViewClock`) per `client` and registers the production derived channels
 *   (`vesselStateChannel` today; extend `PRODUCTION_DERIVED_CHANNELS` below
 *   as more land) on it.
 * - `client.attachStore(store)` feeds every incoming `stream-data` wire
 *   frame into the store's per-topic timelines.
 * - `client.subscribeStore(...)` schedules a `store.beginFrame()` via
 *   `scheduleFrame`: a `requestAnimationFrame`
 *   (falling back to a microtask off the main thread when rAF isn't
 *   available). Multiple ingests landing before that scheduled callback
 *   fires are coalesced into the ONE `beginFrame()` call it makes, honoring
 *   `TimelineStore.beginFrame`'s own doc ("call once per animation frame /
 *   read cycle... never once per read") instead of re-minting a fresh
 *   `FrameToken` and re-running `deriveVesselState`'s Kepler solve, on
 *   every single message in a burst. This is what makes `useStream`, and every
 *   other `useSyncExternalStore` subscription keyed off
 *   `store.subscribeFrame`, actually re-render.
 *
 * `useStream` reads through `store.sample(topic, store.currentFrame())`
 * (never `client.getValue` directly) so raw AND derived topics resolve
 * through the exact same surface: see `use-stream.ts`.
 */
export function TelemetryProvider({
  client,
  children,
  store: providedStore,
  viewClockOptions,
  carriedChannels: carriedChannelsProp,
}: TelemetryProviderProps) {
  // biome-ignore lint/correctness/useExhaustiveDependencies: viewClockOptions is deliberately read only ONCE, at construction of a store this provider owns, a caller passing a fresh inline options object every render must not tear down and rebuild the store/clock each time. `client` IS a dependency for the auto-built branch below; see that branch's own comment for why; it's listed here (rather than split into two memos) so a `providedStore` caller's `client` swap still re-triggers the (no-op, `providedStore`-returning) factory, keeping this one memo the single source of truth `store` identity is derived from.
  const { store, delayAuthority } = useMemo(() => {
    if (providedStore) return { store: providedStore, delayAuthority: null };
    // Auto-built store must rebuild on `client` identity change, so `client`
    // has to stay in this memo's deps. It looks droppable, on the theory that
    // the store "isn't tied to a specific client instance", but an AUTO-BUILT
    // store has no owner other than this provider: dropped, a reconnect or
    // client-swap that hands in a fresh `TelemetryClient` leaves the previous
    // store (topics and timelines still keyed off the previous client's wire)
    // permanently attached instead of resetting. A
    // caller-`providedStore` is still exempt, that store is the caller's
    // own, its lifetime is deliberately independent of `client` (see the
    // `attachStore`/ `subscribeStore` effects below, which still re-wire IT
    // to a new `client` without rebuilding it).
    // The SINGLE delay-wiring point. The auto-built clock's `delaySeconds`
    // reads the `DelayAuthority` (fed from `comms.delay` by the effect
    // below) instead of the `() => 0` stub, so the certainty horizon /
    // predicted-present lead is sized to the real
    // one-way light-time. This is legibility over the already-server-delayed
    // wire, NOT enforcement (the mod's reveal gate already withheld the
    // samples). A caller who passes an explicit `viewClockOptions.delaySeconds`
    // (e.g. a fixed replay delay) still wins, the authority is only the
    // default. Media (kerbcast) reads this same clock, so it aligns for free.
    const authority = new DelayAuthority();
    const built = new TimelineStore(
      new ViewClock({
        ...viewClockOptions,
        delaySeconds: viewClockOptions?.delaySeconds ?? authority.delaySeconds,
      }),
      // Resolve the injected per-(body,type) dynamic namespaces as WHOLE raw
      // topics, not `<domain.channel>.<field>` splits: the same list the carried
      // set below folds in, so subscribe + carry agree on the topic.
      { dynamicWholeTopicPrefixes: DYNAMIC_CARRIED_TOPIC_PREFIXES },
    );
    for (const channel of PRODUCTION_DERIVED_CHANNELS) {
      built.registerDerivedChannel(channel);
    }
    /*
     * Core's own forward models, through the same registry an Uplink's go
     * through. Idempotent, and re-asserted here rather than left to the module
     * side effect alone so a suite that cleared the registry between tests gets
     * the vanilla back with its store.
     */
    registerCoreReckoners();
    // Uplink-contributed channels register AFTER the first-party ones, so a
    // topic core already owns cannot be taken over by an Uplink importing
    // itself later. Contributions are per (topic, owner) and a contested topic
    // arrives from nobody: see `contributed-channels.ts`.
    for (const channel of getContributedDerivedChannels()) {
      built.registerDerivedChannel(channel);
    }
    return { store: built, delayAuthority: authority };
  }, [providedStore, client]);

  // The carried-channels allowlist (see `./carried-channels.ts`): seeded
  // from `client.declaredChannels` (the transport's own served-topic
  // declaration) unioned with the explicit `carriedChannels` promotion-list
  // prop. Persists and only ever GROWS across renders of this same provider
  // INSTANCE (`unionGrow`, the one-way ratchet: "monotonic... adding a
  // topic can only move it from legacy->stream, never blank a widget"),
  // even if a later render's `carriedChannelsProp` shrinks. Only resets on
  // a genuine `client` identity change (`carriedClientRef` tracks which
  // client the current set belongs
  // to): a fresh session, matching the auto-built store's own
  // client-identity reset above; a client swap starts a new allowlist rather
  // than carrying stale entries from a transport that's no longer attached.
  //
  // The Topics a client package registered at runtime are folded in on the same
  // footing. A promotion list written in the gonogo repo can never name an
  // Uplink's Topic, so without this an Uplink's data is reachable only through
  // the canonical Topic read (which skips this gate) and is invisible to
  // everything routed through it: the graph series, the note tags, the alarm
  // subjects. The gate exists to keep a MAPPED key on its working legacy
  // fallback rather than blanking it, and an Uplink Topic has no legacy
  // fallback to protect, so withholding promotion buys nothing and costs the
  // whole surface.
  const carriedClientRef = useRef<TelemetryClient | null>(null);
  // Registration happens when an Uplink's bundle loads, which is after this
  // provider mounts, so the fold has to be live rather than read once.
  const registeredTopics = useSyncExternalStore(
    subscribeRuntimeTopicRegistry,
    getRuntimeRegisteredTopicIds,
    getRuntimeRegisteredTopicIds,
  );
  const [carriedChannels, setCarriedChannels] = useState<ReadonlySet<string>>(
    () => {
      carriedClientRef.current = client;
      return unionGrow(new Set(client.declaredChannels), [
        ...(carriedChannelsProp ?? []),
        // The dynamic-namespace prefixes (trailing `.`): `isTopicCarried`
        // matches them by `startsWith`, carrying the per-(body,type) topics the
        // literal allowlist can't enumerate. Folded in here (not left to the app's
        // prop) so any TelemetryProvider carries them, matching the store's
        // `dynamicWholeTopicPrefixes` resolution above.
        ...DYNAMIC_CARRIED_TOPIC_PREFIXES,
        ...registeredTopics,
      ]);
    },
  );

  useEffect(() => {
    const additions = [
      ...client.declaredChannels,
      ...(carriedChannelsProp ?? []),
      ...DYNAMIC_CARRIED_TOPIC_PREFIXES,
      ...registeredTopics,
    ];
    if (carriedClientRef.current !== client) {
      carriedClientRef.current = client;
      setCarriedChannels(new Set(additions));
      return;
    }
    setCarriedChannels((previous) => unionGrow(previous, additions));
  }, [client, carriedChannelsProp, registeredTopics]);

  // A store is built with the channels contributed so far, which on a station
  // is none of them: its Uplink bundles cannot load until there is a
  // peer-backed client to read the roster off, so `StationScreen` mounts the
  // provider as the parent of the loader. Keep draining as contributions
  // arrive, skipping any topic the store already has so a channel never
  // changes meaning under a widget that is already reading it.
  useEffect(() => {
    const drain = () => {
      for (const channel of getContributedDerivedChannels()) {
        if (store.hasDerivedChannel(channel.topic)) continue;
        store.registerDerivedChannel(channel);
      }
    };
    drain();
    return onContributedChannelsChange(drain);
  }, [store]);

  useEffect(() => client.attachStore(store), [client, store]);
  // The author-facing half of the unowned mechanism. Mounted here because this
  // is where the client's lifetime is owned: one installation per client, so a
  // topic is warned about once however many widgets are reading it.
  useEffect(() => installUnownedTopicWarning(client), [client]);
  // Registers this provider's clock as the non-React `getViewUt()` accessor's
  // source: see `activeViewClock`'s doc comment above. Also registers the
  // store itself as `getVesselOrbit()`/`getVesselTarget()`/
  // `getVesselIdentity()`/`getVesselState()`'s source: see
  // `activeTimelineStore`'s doc comment.
  useEffect(() => {
    activeViewClock = store.clock;
    setActiveTimelineStore(store);
    // Same store, same lifecycle: point the Processor evaluator (Phase 3) at
    // this provider's frame source so useProcessor / contribution Processor
    // deps evaluate against it. Cleared on unmount so a torn-down provider
    // never leaves the evaluator reading a dead store.
    setProcessorEvaluatorStore(store);
    return () => {
      if (activeViewClock === store.clock) activeViewClock = undefined;
      if (activeTimelineStore === store) setActiveTimelineStore(undefined);
      setProcessorEvaluatorStore(undefined);
    };
  }, [store]);
  // A Processor that declares raw Topic deps must SUBSCRIBE them to stream, not
  // just sample them (see processorEvaluator's setProcessorTopicSubscriber):
  // wire the evaluator's subscribe seam to this provider's client, the same
  // `client.subscribe` path useStream uses. Cleared on unmount / client swap so
  // the evaluator never holds a dead client's subscribe.
  useEffect(() => {
    setProcessorTopicSubscriber((topic) => client.subscribe(topic, () => {}));
    return () => setProcessorTopicSubscriber(undefined);
  }, [client]);
  // The same seam for a reckoner's PER-SUBJECT dep, and it has to be here for
  // the same reason: the subject is not known when a read subscribes, so
  // `subscribeTopicRead`'s set cannot contain `fleet.<guid>.orbit` and only the
  // store, which resolved the subject, can hold it up. Without this wiring the
  // model names an input nothing asked the wire for and declines on it for
  // ever.
  useEffect(() => {
    store.setDynamicSubscriber((topic) => client.subscribe(topic, () => {}));
    return () => store.setDynamicSubscriber(undefined);
  }, [client, store]);
  // Registers the client itself as `getActiveTelemetryClient()`'s source,
  // the plain-class (non-hook) command-dispatch equivalent of
  // `useTelemetryClientOptional()`, same rationale as `activeViewClock`/
  // `activeTimelineStore` above. Notifies `activeTelemetryClientListeners`
  // on both mount and unmount so `useActiveTelemetryClient()` (the reactive
  // counterpart used by call sites that render BEFORE a provider mounts,
  // e.g. a modal opened during the app's connect-in-progress window) picks
  // up the change instead of staying stuck on whatever it read at its own
  // first render.
  useEffect(() => {
    activeTelemetryClient = client;
    notifyActiveTelemetryClientListeners();
    syncTopicHolds();
    return () => {
      if (activeTelemetryClient === client) activeTelemetryClient = undefined;
      notifyActiveTelemetryClientListeners();
      syncTopicHolds();
    };
  }, [client]);
  // Registers the carried-channels allowlist as `getActiveCarriedChannels()`'s
  // source: the plain-class equivalent of `useCarriedChannelsOptional()`.
  // Re-runs on every allowlist growth (not just client identity change) so a
  // plain-class caller's routing decision sees the same monotonically-growing
  // set a hook-based reader would.
  useEffect(() => {
    activeCarriedChannels = carriedChannels;
    return () => {
      if (activeCarriedChannels === carriedChannels)
        activeCarriedChannels = undefined;
    };
  }, [carriedChannels]);
  // Keep the auto-built clock's delay value current by subscribing the
  // `DelayAuthority` to `comms.delay`. Skipped when
  // the caller supplied their own `store` (they own its clock's delay wiring),
  // matching the auto-built store's client-identity lifetime above.
  useEffect(() => {
    if (!delayAuthority) return;
    const detach = delayAuthority.attach(client);
    // The SAME authority also sizes command loss inference, so a dispatch nothing
    // answers settles instead of hanging. One wiring point, one number: the client
    // does not compute delay and the transport is not asked about it.
    const clearDelaySource = client.setDelaySource(delayAuthority.delaySeconds);
    return () => {
      clearDelaySource();
      detach();
    };
  }, [client, delayAuthority]);
  /*
   * The store decides every declared topic's lane from the roles block on
   * `system.uplinks`, so the roster is held for the provider's life rather than
   * only while something happens to be drawing Uplink health.
   */
  useEffect(() => client.subscribe("system.uplinks", () => {}), [client]);
  /*
   * Staleness is inferred from keyframe cadence, and under warp the mod floors
   * that cadence in real time: the gap a client must allow is published on
   * `time.warp`. Held for the provider's life so a dashboard that draws no warp
   * readout still judges every other channel's staleness against it.
   */
  useEffect(() => client.subscribe("time.warp", () => {}), [client]);
  useEffect(() => {
    // Coalesce to (at most) one `beginFrame()` per animation-frame tick,
    // instead of one per `stream-data` message: see
    // `scheduleFrame` and this component's own doc comment above.
    let scheduled = false;
    let cancelScheduled: (() => void) | null = null;

    const runBeginFrame = () => {
      scheduled = false;
      cancelScheduled = null;
      store.beginFrame();
    };

    const scheduleBeginFrame = () => {
      if (scheduled) return; // already coalescing this frame's ingests
      scheduled = true;
      cancelScheduled = scheduleFrame(runBeginFrame);
    };

    const unsubscribe = client.subscribeStore(scheduleBeginFrame);
    // A frame also has to arrive when NOTHING does. Ingest alone was the frame
    // source, and a quiet link mints no frames, so every quantity that is a
    // function of the frame's view time froze exactly when it mattered: a
    // reckoning stopped advancing at the instant the last packet landed while
    // the age rendered beside it kept climbing off `useViewUt`'s own rAF tick,
    // and a model's horizon could never fire because withdrawing needs a frame
    // to withdraw on.
    //
    // `onFrame` is the animation-frame tick, which is the cadence
    // `beginFrame`'s own doc asks for; coalescing to ingest was an optimisation
    // that happened to be wrong for silence. It routes through the SAME
    // `scheduled` gate, so an ingest and a tick in one animation frame still
    // mint one frame between them, and the ingest path is untouched.
    const unsubscribeClock = store.clock.onFrame(scheduleBeginFrame);
    return () => {
      unsubscribe();
      unsubscribeClock();
      cancelScheduled?.();
    };
  }, [client, store]);

  return (
    <TelemetryClientContext.Provider value={client}>
      <TimelineStoreContext.Provider value={store}>
        <CarriedChannelsContext.Provider value={carriedChannels}>
          {delayAuthority ? (
            <OwnCraftDelayGate authority={delayAuthority} />
          ) : null}
          {children}
        </CarriedChannelsContext.Provider>
      </TimelineStoreContext.Provider>
    </TelemetryClientContext.Provider>
  );
}

/**
 * FIRST-PARTY derived channels every `TelemetryProvider`-built default store
 * registers. A caller that needs a channel NOT in this list yet (or wants to
 * omit one) supplies its own pre-built `store` prop instead of relying on the
 * default.
 *
 * An Uplink does NOT belong here and cannot edit it: it calls
 * `defineUplinkClient(...).registerDerivedChannel` and its contribution is
 * drained alongside this list when the store is built. A derived channel is
 * the only mechanism that can join two Topics, and a model that needs two
 * Topics is exactly the kind core must not own.
 */
export const PRODUCTION_DERIVED_CHANNELS: DerivedChannelDefinition<unknown>[] =
  [
    vesselStateChannel as DerivedChannelDefinition<unknown>,
    systemStateChannel as DerivedChannelDefinition<unknown>,
    systemUplinkHealthChannel as DerivedChannelDefinition<unknown>,
    spaceCenterStateChannel as DerivedChannelDefinition<unknown>,
    dvCurrentStageResourceChannel as DerivedChannelDefinition<unknown>,
    dvCurrentStageResourceMaxChannel as DerivedChannelDefinition<unknown>,
  ];

/** Reads the `TelemetryClient` supplied by the nearest `TelemetryProvider`. */
export function useTelemetryClient(): TelemetryClient {
  const client = useContext(TelemetryClientContext);
  if (!client) {
    throw new Error(
      "useTelemetryClient must be used within a TelemetryProvider",
    );
  }
  return client;
}

/**
 * Non-throwing variant of `useTelemetryClient`: `undefined` when no
 * `TelemetryProvider` is mounted, instead of throwing.
 *
 * For a caller that must render whether or not a stream exists: a widget in
 * a probe harness, a station screen before its provider is up, an augment
 * whose panel is there either way. Ordinary SDK-native call sites should
 * keep using `useTelemetryClient` so a missing provider fails loudly.
 */
export function useTelemetryClientOptional(): TelemetryClient | undefined {
  return useContext(TelemetryClientContext);
}

/**
 * Sibling hook to `TelemetryProvider`: the mission-recording tap point
 * (`StreamRecorder`, `./replay-recorder.ts`). Builds (and memoizes) a
 * `StreamRecorder` bound to the nearest `TelemetryProvider`'s client;
 * `undefined` when no provider is mounted, matching every other
 * `*Optional`-shaped read in this file.
 *
 * Zero overhead when unused: a `StreamRecorder` registers no listener on the
 * client until its own `start()` is called, so a caller that never presses
 * "record" (or has mission history disabled) pays nothing beyond the one
 * object allocation: no wire subscription, no message tap.
 *
 * `recordAllTopics` is read once at construction (like
 * `viewClockOptions` on `TelemetryProvider` itself): flip it by
 * `stop()`ping any in-progress recording and letting this hook rebuild a
 * fresh recorder on the next render with the new option.
 */
export function useStreamRecorder(
  options?: StreamRecorderOptions,
): StreamRecorder | undefined {
  const client = useTelemetryClientOptional();
  const recordAllTopics = options?.recordAllTopics ?? false;
  return useMemo(
    () =>
      client ? new StreamRecorder(client, { recordAllTopics }) : undefined,
    [client, recordAllTopics],
  );
}

/**
 * Reads the `TimelineStore` supplied by the nearest `TelemetryProvider`.
 * Always mounted alongside the client by `TelemetryProvider` (auto-built
 * if the `store` prop was omitted), throws if no provider is in
 * the tree, matching `useTelemetryClient`'s contract.
 */
export function useTelemetryStore(): TimelineStore {
  const store = useContext(TimelineStoreContext);
  if (!store) {
    throw new Error(
      "useTelemetryStore must be used within a TelemetryProvider",
    );
  }
  return store;
}

/**
 * Non-throwing variant of `useTelemetryStore`: `undefined` when no
 * `TelemetryProvider` is mounted. Same rationale as
 * `useTelemetryClientOptional`, and a caller usually wants both: the client
 * says whether a stream exists, the store says what it is carrying.
 */
export function useTelemetryStoreOptional(): TimelineStore | undefined {
  return useContext(TimelineStoreContext);
}

/**
 * The nearest `TelemetryProvider`'s **one** `ViewClock`: THE single delay
 * authority. Every surface that must stay delay-consistent with telemetry
 * (staleness, predicted-view, and crucially the kerbcast media
 * `DelayedPlayoutBuffer`) reads its release/certainty edge off
 * THIS clock instance, never a second one it constructs itself. A media frame
 * and a telemetry sample stamped the same UT therefore surface at the same
 * `confirmedEdgeUt()` crossing: a shared common-mode property.
 *
 * The returned `ViewClock` is structurally the `DelayClockLike` surface
 * (`confirmedEdgeUt` + `onFrame`) the media buffer depends on, so it can be
 * handed straight to `DelayedPlayoutBuffer`/`useKerbcastStream`: kerbcast
 * stays decoupled (it imports no sitrep-client type; the app passes this in).
 *
 * Throws if no `TelemetryProvider` is mounted, matching `useTelemetryStore`.
 */
/**
 * The read-only slice of `ViewClock` that delay-consistent consumers actually
 * need: the `viewUt` view time, the `confirmedEdgeUt` release/certainty edge,
 * and the `onFrame` subscription. Narrowing the hook return to this `Pick`
 * keeps consumers (the kerbcast `DelayedPlayoutBuffer` seam, camera widgets)
 * from reaching for the clock's mutating surface, they observe, they never
 * drive it.
 *
 * `viewUt` is an observation, not a driver (the scrub/mode setters are what
 * "drive" the clock, and those stay out of this Pick), it belongs here for the
 * same reason `activeViewClock` below is deliberately typed on it: it is the
 * quantity `onFrame` hands its callback, and the ONLY one that honours a scrub
 * target, so anything mirroring `useViewUt`'s contract has to read it rather
 * than `confirmedEdgeUt`.
 *
 * `utNowEstimate` is an observation on the same footing, and it is here for a
 * consumer `confirmedEdgeUt` cannot serve: a human message carries a SEND UT
 * minted at the sender's present, so the recipient reveals it against their own
 * present rather than their delayed certainty horizon. Gating that on
 * `confirmedEdgeUt` would hold it for `sentUt + 2 x delay`, a round trip for a
 * one-way utterance. `useUtNow` reads the same quantity reactively; this is the
 * callable form a `DelayClockLike` adapter needs.
 */
/*
 * `delaySeconds` is on the view for the SCET/received distinction: it is the
 * gap between the two clocks this view exposes, so a surface that must say
 * which one an instant is on reads it here rather than re-deriving it from
 * `comms.delay`. A second derivation would have to re-implement
 * `DelayAuthority`'s hold-through-a-blackout rule, and would report a craft as
 * having come closer the moment it became unreachable.
 */
export type ViewClockView = Pick<
  ViewClock,
  "viewUt" | "confirmedEdgeUt" | "onFrame" | "utNowEstimate" | "delaySeconds"
>;

/**
 * The most recently mounted `TelemetryProvider`'s clock, tracked outside
 * React for non-hook callers (plain classes: trigger/alarm services, that
 * can't call `useViewUt`). Set/cleared by the registration effect in
 * `TelemetryProvider` below. In practice only one provider is mounted at a
 * time (the main screen's single stream); a guard on unmount stops a stale
 * provider's teardown from clobbering a still-live one's registration.
 *
 * Deliberately typed as `Pick<ViewClock, "viewUt">`, NOT the narrower
 * `ViewClockView` (`confirmedEdgeUt` + `onFrame`) `useViewClockOptional`
 * returns: `useViewUt`'s reactive value tracks `onFrame`'s per-frame
 * `viewUt()` callback argument, not `confirmedEdgeUt()` directly (the two
 * diverge whenever a scrub target is set, `viewUt()` honours it outright,
 * `confirmedEdgeUt()` never does, per that method's own doc comment), so
 * `getViewUt()` below must read the exact same method to match `useViewUt`'s
 * contract, including under a pinned/scrubbed test clock.
 */
let activeViewClock: Pick<ViewClock, "viewUt"> | undefined;

export function useViewClock(): ViewClockView {
  return useTelemetryStore().clock;
}

/**
 * Non-throwing variant of `useViewClock`: `undefined` when no
 * `TelemetryProvider` is mounted. The natural call shape for an optional
 * consumer like a camera widget: it wires delayed playout onto the shared
 * clock when streaming is live and falls back to strict passthrough (the
 * `delaySeconds() === 0` case) otherwise, with no hard dependency on a
 * provider being in the tree.
 */
export function useViewClockOptional(): ViewClockView | undefined {
  return useTelemetryStoreOptional()?.clock;
}

/**
 * The current view time (UT seconds) as a reactive value, the ergonomic
 * "read view-UT directly" surface widgets need after the `t.universalTime`
 * DROP (it was never a stream; it IS the SDK view time the propagation already
 * evaluates at). Subscribes to the shared `ViewClock`'s per-frame `onFrame`
 * tick and returns the frozen `viewUt` for the current frame (respecting
 * scrub/predicted mode). `undefined` when no `TelemetryProvider` is mounted or
 * before the first confirmed sample (the view time isn't finite yet), the
 * natural "no stream / not synced" signal a widget can `??`-fall-back on.
 *
 * Per-frame reactive by design (the same rAF cadence the media buffer runs
 * on): a widget that reads view-UT for a live countdown re-renders each frame,
 * which is exactly what a live countdown requires. Callers that only need the
 * clock object (not a reactive value) should use `useViewClock` instead.
 */
export function useViewUt(): Value<"ut"> | undefined {
  const clock = useViewClockOptional();
  // Seed from `viewUt()`: the SAME quantity `onFrame` hands the tick below,
  // not `confirmedEdgeUt()`. The two only agree on a free-running clock:
  // `viewUt()` returns `scrubTo`'s target outright when one is set (see its
  // own doc), whereas `confirmedEdgeUt()` ignores the scrub and keeps
  // tracking live. Seeding off the latter made a scrubbed clock render its
  // first frame at the live confirmed edge and snap to the scrub target only
  // one frame later: a flash of the wrong view time in a scrub UI, and a
  // guaranteed state transition on every mount.
  const [viewUt, setViewUt] = useState<number | undefined>(() => {
    const seed = clock?.viewUt();
    return seed !== undefined && Number.isFinite(seed) ? seed : undefined;
  });
  // `onFrame` notifies unconditionally at ~60Hz whether or not the view time
  // actually moved (a paused, scrubbed or between-samples clock reports the
  // same UT every frame). Dispatching `setViewUt` regardless leaned on
  // React's *eager bailout* to swallow the no-op, an optimisation React only
  // applies while the fiber has no other pending work, so an unlucky frame
  // still schedules a full render pass for an unchanged value. Comparing here
  // means an unchanged frame costs no dispatch at all.
  const lastDelivered = useRef(viewUt);
  useEffect(() => {
    if (!clock) {
      lastDelivered.current = undefined;
      setViewUt(undefined);
      return;
    }
    return clock.onFrame((ut) => {
      const next = Number.isFinite(ut) ? ut : undefined;
      if (next === lastDelivered.current) return;
      lastDelivered.current = next;
      setViewUt(next);
    });
  }, [clock]);
  /*
   * Wrapped at the RETURN, not carried as a `Value` through the state above. The
   * frame bailout compares the incoming UT against the last delivered one, and two
   * `Value`s holding the same instant are different objects, so comparing them would
   * dispatch a render every frame and undo the thing that comment is about.
   *
   * Memoised for the same reason from the other side: an unchanged view time must
   * hand back an unchanged reference, or every `useMemo` downstream that depends on
   * it recomputes each frame.
   */
  return useMemo(
    () => (viewUt === undefined ? undefined : value("ut", viewUt)),
    [viewUt],
  );
}

/**
 * The current REAL-time "vessel now" (UT seconds) as a reactive value,
 * `ViewClock.utNowEstimate()`, NOT the delay-gated `confirmedEdgeUt()`
 * `useViewUt` tracks. Every other live countdown in the app is rightly
 * delay-consistent (it's timing DELAYED craft telemetry, so it must lag by
 * the one-way light-time same as the data it's counting against), but a
 * few channels are command-centre real-time bookkeeping instead of delayed
 * craft telemetry (e.g. `system.uplink.pending`'s dispatch/prediction
 * timestamps, stamped in real UT the instant a command leaves the ground
 * station). Timing THOSE against `useViewUt` makes them appear, and clear,
 * one whole one-way-delay late; this hook is the fix: it reads the same
 * `ViewClock` instance's `utNowEstimate()` (the undelayed UT(wall) fit)
 * instead, so a real-time bookkeeping value renders in step with the real
 * event, not the delayed view.
 *
 * Modeled directly on `useViewUt`: same `onFrame` subscription, same
 * seed-then-subscribe shape: except the per-frame callback recomputes
 * `clock.utNowEstimate()` itself rather than using the `viewUt` argument
 * `onFrame` hands it (that argument IS `clock.viewUt()`, the delayed/
 * scrubbable value `useViewUt` wants: not what this hook needs).
 *
 * `undefined` when no `TelemetryProvider` is mounted. Unlike `useViewUt`,
 * this is NOT gated on "before the first confirmed sample", `utNowEstimate()`
 * has a well-defined value (0, or the last observed sample UT) from the
 * moment a clock exists, since real-time bookkeeping has no "confirmed vs.
 * predicted" distinction to wait out.
 */
export function useUtNow(): number | undefined {
  const store = useTelemetryStoreOptional();
  const clock = store?.clock;
  const [utNow, setUtNow] = useState<number | undefined>(() => {
    const seed = clock?.utNowEstimate();
    return seed !== undefined && Number.isFinite(seed) ? seed : undefined;
  });
  // Same unchanged-frame guard as `useViewUt`: see its comment.
  const lastDelivered = useRef(utNow);
  useEffect(() => {
    if (!clock) {
      lastDelivered.current = undefined;
      setUtNow(undefined);
      return;
    }
    return clock.onFrame(() => {
      const estimate = clock.utNowEstimate();
      const next = Number.isFinite(estimate) ? estimate : undefined;
      if (next === lastDelivered.current) return;
      lastDelivered.current = next;
      setUtNow(next);
    });
  }, [clock]);
  return utNow;
}

/**
 * Non-React `useViewUt()` equivalent: for callers that can't use hooks, the
 * plain classes behind the maneuver-trigger and alarm host services among
 * them. Reads `viewUt()` off whichever `TelemetryProvider`
 * most recently mounted (`activeViewClock`), the same method `onFrame`
 * hands `useViewUt`'s per-frame callback: so it follows the exact same
 * delay-consistent, scrub-respecting clock, just polled on demand instead of
 * per-frame. `undefined` when no provider has ever mounted, or before any
 * live/scrubbed value is available, the same "no stream / not synced"
 * contract `useViewUt` returns before its first frame.
 */
export function getViewUt(): number | undefined {
  noteUndeclaredRead("getViewUt");
  const ut = activeViewClock?.viewUt();
  return ut !== undefined && Number.isFinite(ut) ? ut : undefined;
}

/**
 * Test-only escape hatch: registers `clock` as `getViewUt()`'s source
 * directly, without mounting a `TelemetryProvider`: for a host-service unit
 * test (`AlarmHostService`, `ManeuverTriggerHostService`) that drives its own
 * fake telemetry reader and has no React tree to render at all. Pass
 * `undefined` to clear; a test's `afterEach` should always do this so a
 * later, unrelated suite's `getViewUt()` call can't see a stale clock left
 * over from this one.
 */
export function setActiveViewClockForTests(
  clock: Pick<ViewClock, "viewUt"> | undefined,
): void {
  activeViewClock = clock;
}

/**
 * The most recently mounted `TelemetryProvider`'s `TimelineStore`, tracked
 * outside React for the same non-hook callers `activeViewClock` serves,
 * plain classes (`LocalManeuverTriggerService`, the maneuver-trigger and
 * alarm host services) that need a point-in-time read of a fixed Topic
 * (`vessel.orbit`, `vessel.target`, `vessel.identity`, the derived
 * `vessel.state`) without subscribing. Narrowed to the methods an on-demand
 * sample needs, matching `activeViewClock`'s narrowing to just `viewUt`.
 * `sampleReading` is among them because the orbital solve is gated on a model
 * and a payload carries none. Set/cleared by the same registration effect in
 * `TelemetryProvider` above.
 */
type ActiveTimelineStore = Pick<
  TimelineStore,
  "sample" | "sampleReading" | "currentFrame" | "subscribeFrame"
>;

let activeTimelineStore: ActiveTimelineStore | undefined;

/**
 * Every `onActiveTimelineFrame` caller, held independently of whichever store
 * is currently active so that a caller's subscription outlives a provider
 * mount and does not depend on one existing when it subscribes.
 */
const timelineFrameListeners = new Set<() => void>();

/**
 * The single `subscribeFrame` registration standing in for all of
 * `timelineFrameListeners`, and the store it is against, so that a store
 * arriving, swapping or going away moves every listener with it.
 */
let timelineFrameBridge: (() => void) | undefined;
let bridgedTimelineStore:
  | Pick<TimelineStore, "sample" | "currentFrame" | "subscribeFrame">
  | undefined;

/**
 * Points the bridge at the active store, or tears it down when there is no
 * store or nothing listening. Called on both edges: a listener arriving or
 * leaving, and the active store changing.
 */
function syncTimelineFrameBridge(): void {
  const target =
    timelineFrameListeners.size > 0 ? activeTimelineStore : undefined;
  if (target === bridgedTimelineStore) return;
  timelineFrameBridge?.();
  timelineFrameBridge = undefined;
  bridgedTimelineStore = target;
  if (!target) return;
  timelineFrameBridge = target.subscribeFrame(() => {
    // Copied: a listener is free to unsubscribe itself from inside the
    // callback, which would otherwise mutate the set mid-iteration.
    for (const listener of [...timelineFrameListeners]) listener();
  });
}

/**
 * The active store's topic resolution, which `holdActiveTopicRead` needs and
 * an on-demand sample does not. Undefined for a test double that does not
 * implement it, so a hold simply waits rather than subscribing wrongly.
 */
let activeReadResolver: ReadTopicResolver | undefined;

/**
 * The one way `activeTimelineStore` changes, so that the frame bridge and the
 * topic holds are never left pointing at a store that is no longer the active
 * one.
 */
function setActiveTimelineStore(
  store: (ActiveTimelineStore & Partial<ReadTopicResolver>) | undefined,
): void {
  activeTimelineStore = store;
  activeReadResolver =
    typeof store?.resolveSubscriptionTopics === "function" &&
    typeof store.reckonerDepTopics === "function"
      ? (store as ReadTopicResolver)
      : undefined;
  syncTimelineFrameBridge();
  syncTopicHolds();
}

/**
 * Every hold `holdActiveTopicRead` has handed out and not yet released, by the
 * token only its own release function knows.
 */
const topicHolds = new Map<symbol, { topic: string; label?: string }>();

/** What each hold has subscribed against the pair below. */
const topicHoldReleases = new Map<symbol, () => void>();
let heldClient: TelemetryClient | undefined;
let heldResolver: ReadTopicResolver | undefined;

/**
 * Points every hold at the active client and store, moving all of them when
 * either changes and dropping them while either is missing.
 */
function syncTopicHolds(): void {
  if (
    activeTelemetryClient !== heldClient ||
    activeReadResolver !== heldResolver
  ) {
    for (const release of topicHoldReleases.values()) release();
    topicHoldReleases.clear();
    heldClient = activeTelemetryClient;
    heldResolver = activeReadResolver;
  }
  if (!heldClient || !heldResolver) return;
  for (const [token, hold] of topicHolds) {
    if (topicHoldReleases.has(token)) continue;
    topicHoldReleases.set(
      token,
      subscribeTopicRead(heldClient, heldResolver, hold.topic, hold.label),
    );
  }
}

/**
 * The most recently mounted `TelemetryProvider`'s `TelemetryClient`, tracked
 * outside React for the same non-hook callers `activeViewClock`/
 * `activeTimelineStore` serve: the plain-class equivalent of
 * `useTelemetryClientOptional()`. Paired with `activeCarriedChannels` below,
 * this is what lets a plain class (`GoNoGoHostService`) dispatch a command
 * through the new stream (`dispatchActiveCommand`) with the exact same
 * carried-gated routing decision `useCommand` (`@ksp-gonogo/core`) makes for
 * a hook-based widget.
 */
let activeTelemetryClient: TelemetryClient | undefined;

/**
 * Listeners notified whenever `activeTelemetryClient` changes (a
 * `TelemetryProvider` mounts, unmounts, or swaps its `client` prop). Backs
 * `subscribeActiveTelemetryClient`/`useActiveTelemetryClient`: the reactive
 * counterpart to the plain `getActiveTelemetryClient()` read, for a call
 * site that renders before any provider is mounted (e.g. a modal opened
 * during the app's connect-in-progress window) and needs to pick up the
 * client the moment it appears rather than staying stuck on the `undefined`
 * it captured at its own first render.
 */
const activeTelemetryClientListeners = new Set<() => void>();

function notifyActiveTelemetryClientListeners(): void {
  for (const listener of activeTelemetryClientListeners) listener();
}

/**
 * The most recently mounted `TelemetryProvider`'s carried-channels allowlist,
 * tracked outside React: the plain-class equivalent of
 * `useCarriedChannelsOptional()`. See `activeTelemetryClient`'s doc comment.
 */
let activeCarriedChannels: ReadonlySet<string> | undefined;

/**
 * Reads `topic` off whichever `TelemetryProvider` most recently mounted
 * (`activeTimelineStore`), the same `store.sample(topic, store.currentFrame())`
 * call `useStream`/`useTelemetry`'s canonical overload make: so a non-hook
 * caller sees the exact same value a widget's `useTelemetry(topic)` would on
 * the same frame, just polled on demand instead of reactively. Returns
 * `undefined` when no provider has ever mounted, or before any point has
 * landed for `topic`: the same "not synced yet" contract `useStream`
 * returns before its first frame. Does NOT itself ensure `topic` is
 * subscribed on the wire (unlike `useStream`'s `subscribe`, which ref-counts
 * a `client.subscribe` for the resolved raw inputs), a plain-class caller
 * relies on some OTHER live subscriber (typically a mounted widget reading
 * the same topic) already keeping the data flowing, exactly like
 * `getViewUt()` relies on the provider's own `ViewClock` ticking regardless
 * of subscribers.
 *
 * Exported (beyond the fixed `getVesselOrbit`/`getVesselTarget`/
 * `getVesselIdentity`/`getVesselState` wrappers below, each just this
 * function bound to one Topic) for plain-class callers that need an
 * ARBITRARY topic decided at call time: `GoNoGoHostService`'s
 * `vessel.state.met` read, the same "dynamic topic" shape `useTelemetry`'s
 * own doc comment already documents for the hook case.
 *
 * Answers a DISPLAY value, and a hold-last one: this cannot say how old it is,
 * or whether anything is still feeding the topic. Anything ACTING on the
 * answer rather than drawing it wants {@link sampleActiveReading} instead.
 */
export function sampleActiveTopic<T>(topic: string): T | undefined {
  noteUndeclaredRead("sampleActiveTopic", topic);
  if (!activeTimelineStore) return undefined;
  const point = activeTimelineStore.sample<T>(
    topic,
    activeTimelineStore.currentFrame(),
  );
  return point ? (point.payload as T | undefined) : undefined;
}

/**
 * One shared `pending` for the no-provider answer, so repeated calls hand back
 * one object rather than a fresh one each time.
 */
const NO_PROVIDER_READING = topicReading<never>({
  state: "pending",
  reckoning: { status: "none" },
});

/**
 * `sampleActiveTopic`'s currency-carrying twin: the same on-demand read off
 * whichever `TelemetryProvider` mounted last, answering the whole
 * `TopicReading` a widget's `useTelemetry(topic)` would get on the same frame
 * rather than the bare payload.
 *
 * A bare payload is a DISPLAY value. The store is hold-last by design, and a
 * timeline is never dropped when its last subscriber lets go, so
 * `sampleActiveTopic` answers a released topic's final payload for as long as
 * the epoch stands. That is the right answer for a readout under a staleness
 * mark and the wrong one for a headless caller deciding something: a decision
 * taken on a payload has no way to ask how old it is, and the last holder's
 * unmount is not an event the caller sees.
 *
 * So anything acting on a reading rather than drawing it reads here, branches
 * on `state`, and treats `stale` as a reason to stop. One store call, the same
 * `sampleReading` the hook path uses, so the two cannot drift.
 *
 * Answers `pending` when no provider has ever mounted, matching what
 * `useTelemetry` returns outside a provider.
 */
export function sampleActiveReading<T>(topic: string): TopicReading<T> {
  if (!activeTimelineStore) return NO_PROVIDER_READING as TopicReading<T>;
  return activeTimelineStore.sampleReading<T>(
    topic,
    activeTimelineStore.currentFrame(),
  );
}

/**
 * Non-React equivalent of `useTelemetry("vessel.orbit")`: the vessel's own
 * Keplerian orbit elements (`sma`/`ecc`/`inc`/`lan`/`argPe`/`mu`/...). For
 * plain-class callers (the maneuver-trigger host service among them), which get
 * the whole record in one read rather than a field at a time off
 * `getDataSource(...)`.
 */
export function getVesselOrbit(): VesselOrbit | undefined {
  return sampleActiveTopic<VesselOrbit>("vessel.orbit");
}

/**
 * Non-React equivalent of `useTelemetry("vessel.target")`: the current
 * target's identity, relative kinematics, and (when it has one) orbit. The
 * replacement for the legacy `tar.o.*` keys' per-field reads.
 */
export function getVesselTarget(): VesselTarget | undefined {
  return sampleActiveTopic<VesselTarget>("vessel.target");
}

/**
 * Non-React equivalent of `useTelemetry("vessel.identity")`: vessel name,
 * type, situation, parent body index. The replacement for the legacy
 * `v.name` read.
 */
export function getVesselIdentity(): VesselIdentity | undefined {
  return sampleActiveTopic<VesselIdentity>("vessel.identity");
}

/**
 * Non-React equivalent of `useTelemetry("system.bodies")`: the body tree, by
 * STABLE index.
 *
 * Wanted by anything turning an orbital radius into an ALTITUDE, which needs
 * the reference body's own radius, and by the body-name display maps. A plain
 * class reaching for those had no route to this channel and read them off
 * `vessel.state` instead, which is the coupling `vessel.state`'s retirement
 * removes.
 */
export function getSystemBodies(): SystemBodies | undefined {
  return sampleActiveTopic<SystemBodies>("system.bodies");
}

/**
 * Non-React equivalent of `useTelemetry("vessel.state")`: the derived
 * apoapsis/periapsis/time-to-apsis/true-anomaly/orbital-speed/radius/period/
 * body-name fields `vessel-state.ts` computes from `vessel.orbit` +
 * `vessel.target` + `vessel.identity` + `system.bodies`. The replacement for
 * the legacy `o.ApR`/`o.PeR`/`o.timeToAp`/`o.timeToPe`/`o.trueAnomaly`/
 * `o.orbitalSpeed`/`o.radius`/`o.period`/`v.body`/`tar.o.PeA`/`tar.o.period`/
 * `tar.o.trueAnomaly` per-field reads.
 */
export function getVesselState(): VesselState | undefined {
  return sampleActiveTopic<VesselState>(vesselStateChannel.topic);
}

/**
 * The self vessel's apsides, their altitudes, the apsis countdowns, true
 * anomaly, period and orbital radius at the frame's view time, or `null` where
 * the conic behind them has withdrawn. For a caller that cannot use hooks.
 *
 * The other non-hook accessors here hand back a payload, which carries no
 * model, and the model's refusal is the whole of when these figures may be
 * drawn. This samples the READING instead and applies the same rule a hook
 * would, so a maneuver plan and the panel drawing the orbit it plans against
 * cannot disagree about whether there is an orbit to plan against.
 */
export function getOrbitSolve(): OrbitalSolve | null {
  if (!activeTimelineStore) return null;
  const reading =
    activeTimelineStore.sampleReading<VesselOrbit>("vessel.orbit");
  /* Stale carries its elements too: see `solveSelfOrbit` for why that is as
     good a starting point as an observed one, and for what decides whether
     they may be advanced. */
  const elements =
    reading.state === "observed" || reading.state === "stale"
      ? reading.value
      : undefined;
  return solveSelfOrbit(
    elements,
    reading.reckoning,
    getSystemBodies(),
    getViewUt(),
    reading.state === "observed" ? reading.atUt : undefined,
  );
}

/**
 * Non-hook, Value-restricted equivalent of `useTelemetry(dataSourceId, key)`'s
 * legacy overload: for a plain-class caller (alarm/maneuver-trigger threshold
 * evaluation) that needs to read an OPERATOR-PICKED legacy key, not one of a
 * fixed set decided at call time. `key` is resolved through the same routing
 * `useTelemetry` consults, covering both a flat legacy key and a field path, and
 * the resulting Topic is sampled off the active `TimelineStore`. Answers a
 * MAGNITUDE: the one type every threshold comparison needs, taken off the
 * `Value` a unit-carrying field arrives as, so a non-numeric or not-yet-arrived
 * read is a plain `undefined`.
 *
 * Deliberately restricted to keys the routing actually resolves: the alarm and
 * trigger pickers (see `@ksp-gonogo/data`'s `useValueKeys`) only ever offer keys
 * in that resolvable set, so an unresolvable key here is a stale persisted
 * `dataKey` naming a retired subject. `undefined` is the correct answer, and the
 * surface that stored it is responsible for showing the operator that its
 * subject no longer resolves rather than drawing a reading it never got.
 */
export function getValue(
  dataSourceId: string,
  key: string,
): number | undefined {
  const topic = resolveValueTopic(dataSourceId, key);
  if (topic === undefined) return undefined;
  return pickedKeyMagnitude(sampleActiveTopic<unknown>(topic));
}

/**
 * `getValue` for a caller DECIDING something rather than drawing it: the same
 * key resolution and the same unwrap, answered only while the reading is
 * `observed`. A held last payload, a topic nothing has sent yet and a
 * tombstone all answer `undefined`, because a threshold compared against a
 * number nobody can date is a decision taken on a guess.
 */
export function getObservedValue(
  dataSourceId: string,
  key: string,
): number | undefined {
  const topic = resolveValueTopic(dataSourceId, key);
  if (topic === undefined) return undefined;
  const reading = sampleActiveReading<unknown>(topic);
  return reading.state === "observed"
    ? pickedKeyMagnitude(reading.value)
    : undefined;
}

/**
 * The magnitude of a picked key's payload, in both shapes it can arrive in. A
 * field of a RAW Topic carries its unit by the time it reaches the store,
 * because the decode wraps every declared quantity (`wrapTopicPayload`) and the
 * store's field-subtopic walk hands back whatever the parent record holds; a
 * field of a client-DERIVED channel is computed here and never met the wrap, so
 * it is a plain number. `magnitudeOf` owns the finite check for both, which is
 * the point of routing through it: a second spelling of "absent or non-finite"
 * beside it is how one of them came to answer NaN.
 */
function pickedKeyMagnitude(payload: unknown): number | undefined {
  const quantity =
    isValue(payload) || typeof payload === "number" ? payload : null;
  return magnitudeOf(quantity) ?? undefined;
}

/**
 * Non-React equivalent of `useTelemetry("time.warp")`: the whole `WarpState`
 * record (`warpRate`/`warpRateIndex`/`warpMode`/`paused`). `WarpObserver` reads
 * it here, in one go, rather than four per-field reads against the `"data"`
 * `DataSource`.
 */
export function getWarpState(): WarpState | undefined {
  return sampleActiveTopic<WarpState>("time.warp");
}

/**
 * Non-React equivalent of `useTelemetry("career.status.contracts.active")`: the
 * career mode's currently-active contract list, off `career.status`'s
 * `contracts.active` raw-field subtopic.
 */
export function getContractsActive(): CareerContract[] | undefined {
  return sampleActiveTopic<CareerContract[]>("career.status.contracts.active");
}

/**
 * Non-hook equivalent of `useTelemetryClientOptional()`: the currently
 * mounted `TelemetryProvider`'s `TelemetryClient`, or `undefined` when none
 * is mounted. See `activeTelemetryClient`'s doc comment.
 */
export function getActiveTelemetryClient(): TelemetryClient | undefined {
  return activeTelemetryClient;
}

/**
 * Registers `listener` to fire whenever `activeTelemetryClient` changes.
 * Backs `useActiveTelemetryClient`; exported directly for any non-React
 * subscriber that needs the same live notification. Returns an unsubscribe
 * function.
 */
export function subscribeActiveTelemetryClient(
  listener: () => void,
): () => void {
  activeTelemetryClientListeners.add(listener);
  return () => {
    activeTelemetryClientListeners.delete(listener);
  };
}

/**
 * Reactive equivalent of `getActiveTelemetryClient()`: re-renders the
 * calling component whenever the active `TelemetryProvider` mounts,
 * unmounts, or swaps its `client`. Use this (instead of the plain getter)
 * from any component that might render BEFORE a `TelemetryProvider` mounts,
 * the plain getter reads once and never updates, so a component like
 * `ModalTelemetryBridge` that opens during the app's connect-in-progress
 * window would otherwise be stuck rendering its children with no telemetry
 * context for its entire lifetime, even after the real client connects.
 */
export function useActiveTelemetryClient(): TelemetryClient | undefined {
  return useSyncExternalStore(
    subscribeActiveTelemetryClient,
    getActiveTelemetryClient,
  );
}

/**
 * Non-hook equivalent of `useCarriedChannelsOptional()`. See
 * `activeCarriedChannels`'s doc comment.
 */
export function getActiveCarriedChannels(): ReadonlySet<string> | undefined {
  return activeCarriedChannels;
}

/**
 * Why a command that DID route came back unsuccessful: the mod's own code and
 * message, as it wrote them.
 *
 * Carried rather than swallowed because a refusal is frequently the only place
 * a fact lives. The SCET alarm arm refuses a threshold naming a Topic the
 * simulation cannot resolve, and the message names the Topic; a caller that
 * cannot read it has an alarm sitting armed that will never fire and nothing to
 * say about why.
 */
export interface DispatchCommandRefusal {
  code: string;
  message: string;
  /**
   * The mod's TYPED reason, when the refusal came from a command handler rather
   * than from the transport. Absent on a transport-level failure, which has no
   * contract code to carry.
   *
   * This is the field to branch on. `code` is the constant every refusal of
   * every command shares, so it distinguishes nothing, and the message is prose
   * that names the subject it refused.
   */
  errorCode?: CommandErrorCode;
  /**
   * The mod's own words about this refusal, when it quoted the game. `message`
   * is synthesised from the code and names the command, so it reads the same
   * for every refusal of that command; this is the half that names the subject
   * the operator chose.
   */
  detail?: string;
}

/** Outcome of {@link dispatchActiveCommandTopic}: see its doc comment. */
export type DispatchActiveCommandResult =
  | { routed: true; settled: Promise<DispatchCommandRefusal | undefined> }
  | { routed: false };

/**
 * A dispatch rejection as its two readable halves, whatever threw it.
 *
 * Read structurally rather than by `instanceof CommandError`: the rejection can
 * cross a bundle boundary, and the class the value was minted from is not
 * necessarily the class this copy holds. `code` and `message` are own
 * properties on it for exactly this reason.
 */
function describeDispatchRejection(error: unknown): DispatchCommandRefusal {
  if (typeof error === "object" && error !== null) {
    const candidate = error as {
      code?: unknown;
      message?: unknown;
      errorCode?: unknown;
      detail?: unknown;
    };
    return {
      code: typeof candidate.code === "string" ? candidate.code : "",
      message:
        typeof candidate.message === "string"
          ? candidate.message
          : String(error),
      errorCode:
        typeof candidate.errorCode === "number"
          ? (candidate.errorCode as CommandErrorCode)
          : undefined,
      detail:
        typeof candidate.detail === "string" ? candidate.detail : undefined,
    };
  }
  return { code: "", message: String(error) };
}

/**
 * Dispatch a command through the stream, for a plain-class caller with no render
 * tree to call {@link useCommand} from.
 *
 * **Deliberately SYNCHRONOUS in its routing decision.** A caller must be able to
 * check `routed` in the SAME tick as the call, so it can say at once that a
 * command did not go rather than a microtask later. Only the routed case is
 * genuinely asynchronous, and its `settled` promise never rejects: it resolves
 * with the refusal when there was one and with `undefined` when the command
 * succeeded, so a caller that does not care can keep ignoring it.
 *
 * `routed: false` means one thing only: no provider is mounted, so there is no
 * stream to put the command on.
 *
 * Whether the simulation will TAKE a command is the simulation's to answer, and
 * it does: `settled` carries its refusal, code and message as it wrote them.
 */
export function dispatchActiveCommandTopic(
  command: string,
  args: unknown,
): DispatchActiveCommandResult {
  const client = activeTelemetryClient;
  if (!client) return { routed: false };
  const { result } = client.dispatch(command, args);
  return {
    routed: true,
    settled: result.then(
      () => undefined,
      (error: unknown) => describeDispatchRejection(error),
    ),
  };
}

/**
 * Test-only escape hatch: registers `store` as
 * `getVesselOrbit()`/`getVesselTarget()`/`getVesselIdentity()`/
 * `getVesselState()`'s source directly, without mounting a
 * `TelemetryProvider`: mirrors `setActiveViewClockForTests`. Pass
 * `undefined` to clear; a test's `afterEach` should always do this so a
 * later, unrelated suite can't see a stale store left over from this one.
 */
export function setActiveTimelineStoreForTests(
  store: (ActiveTimelineStore & Partial<ReadTopicResolver>) | undefined,
): void {
  setActiveTimelineStore(store);
}

/**
 * Test-only escape hatch: registers `client` as `dispatchActiveCommand`'s
 * source directly, without mounting a `TelemetryProvider`: for a
 * host-service unit test that needs to exercise the ROUTED (stream) branch
 * of a command dispatch (`WarpControl`, `AlarmHostService`'s onFire
 * action-group dispatch, the maneuver-trigger fire path) without a React
 * tree to render. Mirrors `setActiveTimelineStoreForTests`. Pass `undefined`
 * to clear.
 */
export function setActiveTelemetryClientForTests(
  client: TelemetryClient | undefined,
): void {
  activeTelemetryClient = client;
  notifyActiveTelemetryClientListeners();
  syncTopicHolds();
}

/**
 * Test-only escape hatch: registers `channels` as the carried-channels
 * allowlist a mounted `TelemetryProvider` would, for a test exercising the
 * one thing that still reads it through `getActiveCarriedChannels`: the
 * topic-field CATALOGUE, which decides the vocabulary of fields a picker
 * offers. Pass `undefined` to clear.
 *
 * It is NOT a dispatch precondition and never usefully was. Command dispatch
 * consulted this set until `7e186ab3c`, and because nothing in production
 * ever put a command id in it, four command paths were dead while their own
 * tests passed, each installing its own command here by hand. Do not reach
 * for this to make a command route.
 */
export function setActiveCarriedChannelsForTests(
  channels: ReadonlySet<string> | undefined,
): void {
  activeCarriedChannels = channels;
}

/**
 * Non-React equivalent of subscribing to `store.subscribeFrame`: for a
 * plain-class caller that needs to re-run its own on-demand reads
 * (`getVesselOrbit()`/`getVesselTarget()`/`getVesselIdentity()`/
 * `getVesselState()`) whenever the active `TelemetryProvider` ingests a new
 * frame, the same "vessel/orbit data changed" signal a widget's
 * `useTelemetry` re-render would ride. Unlike `getViewUt()`/the sample
 * accessors above (pure point-in-time reads), this one DOES need a live
 * subscription: a plain class has no render loop to poll on.
 *
 * The subscription is against whichever store is active at each frame rather
 * than the one active at call time, so it may be taken out before any
 * provider is mounted and it follows a provider that unmounts and remounts.
 * This is what lets a caller own its own lifetime: a service built once for
 * the app's lifetime keeps its frames across a provider rebuild, and one built
 * in a `useState` initialiser, which React runs before any effect in the tree,
 * starts receiving frames when the provider's registration effect runs.
 *
 * Unlike `getViewUt()` and the sample accessors above, therefore, there is no
 * "read at construction" limitation here.
 */
export function onActiveTimelineFrame(cb: () => void): () => void {
  timelineFrameListeners.add(cb);
  syncTimelineFrameBridge();
  return () => {
    timelineFrameListeners.delete(cb);
    syncTimelineFrameBridge();
  };
}

/**
 * Holds `topic` up on the wire for a caller with no component to mount: a
 * standing subscription through the same seam every read path uses, so a
 * derived topic or a field path holds the raw topics that feed it. Returns the
 * release.
 *
 * The non-hook twin of what `useTelemetry` does while mounted, and the answer
 * to a headless service that samples a topic nothing else is holding: without
 * it the read is `pending` for ever, or after a widget lets go, the widget's
 * last payload. Like `onActiveTimelineFrame` it outlives the provider: taken
 * before one mounts it subscribes when one does, and it follows a provider
 * that unmounts and remounts.
 *
 * A hold makes the topic ARRIVE; it says nothing about how current the next
 * read is. Until the first frame lands after subscribing, a sample still
 * answers the previous holder's point, so a caller deciding anything reads
 * through `sampleActiveReading` and branches on `state`.
 */
export function holdActiveTopicRead(
  topic: string,
  subscriberLabel?: string,
): () => void {
  const token = Symbol(topic);
  topicHolds.set(token, { topic, label: subscriberLabel });
  syncTopicHolds();
  return () => {
    topicHolds.delete(token);
    topicHoldReleases.get(token)?.();
    topicHoldReleases.delete(token);
  };
}

/**
 * Reads the carried-channels allowlist supplied by the nearest
 * `TelemetryProvider` (see `./carried-channels.ts`): throws if no
 * provider is in the tree, matching `useTelemetryStore`'s contract. Ordinary
 * SDK-native call sites needing to know "is this topic actually live right
 * now" should combine this with `isTopicCarried` rather than reading the raw
 * set directly.
 */
export function useCarriedChannels(): ReadonlySet<string> {
  const carriedChannels = useContext(CarriedChannelsContext);
  if (!carriedChannels) {
    throw new Error(
      "useCarriedChannels must be used within a TelemetryProvider",
    );
  }
  return carriedChannels;
}

/**
 * Non-throwing variant of `useCarriedChannels`: `undefined` when no
 * `TelemetryProvider` is mounted. Same rationale as
 * `useTelemetryClientOptional`/`useTelemetryStoreOptional`: a caller that
 * renders without a provider still has to ask whether a topic is carried,
 * and must get "no" rather than an exception.
 */
export function useCarriedChannelsOptional(): ReadonlySet<string> | undefined {
  return useContext(CarriedChannelsContext);
}
