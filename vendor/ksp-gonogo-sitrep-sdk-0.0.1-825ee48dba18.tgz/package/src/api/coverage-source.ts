// Straight from `./host` rather than `./index`'s `logger` Proxy, which would be a
// cycle: the barrel re-exports this module. Same reasoning, and the same `hasHost`
// guard, as `./registry.ts`: a source registers at module load, which can run
// before the app installs its host.
import { getHost, hasHost } from "./host";
import type {
  CoverageSourceDefinition,
  NamespacedAugmentSettings,
} from "./types";

/**
 * Mod-agnostic registry for coverage sources.
 *
 * A coverage source contributes data (coverage bytes for a body under some layer
 * id), not a renderable component, which is why it is a registry parallel to the
 * augment one rather than another slot kind. Consumed by GroundTrack's own coverage
 * gate as a PAINT-GATE: there is no darkening overlay layer in this design, only
 * surface content whose alpha is modulated per-tile by the composite of every
 * enabled source here.
 *
 * Registering was already published as a host shim, and reading was too, but
 * `clearCoverageSources` was not, so an Uplink contributing coverage could not
 * reset the registry between test cases without reaching an unpublished package.
 */

/**
 * The single global slot the sources live in, keyed by a string rather than a
 * symbol so two different builds of this package still find the same state. See
 * `map-poi.ts` for why a module static is not safe once this can be bundled.
 *
 * The key still says fog because it is a cross-build rendezvous identifier, not a
 * name: an Uplink bundled against an older copy of this package registers into
 * whatever string that copy holds, so changing it would split the registry in two
 * and the sources from one half would never be seen by the other. It can be
 * renamed once no released Uplink builds against a pre-rename sdk.
 */
const COVERAGE_SOURCE_REGISTRY_KEY = "__GONOGO_FOG_REVEAL_SOURCES__" as const;

interface CoverageSourceRegistry {
  sources: Map<string, { def: CoverageSourceDefinition; order: number }>;
  counter: number;
  listeners: Set<() => void>;
}

function registry(): CoverageSourceRegistry {
  const slot = globalThis as typeof globalThis & {
    [COVERAGE_SOURCE_REGISTRY_KEY]?: CoverageSourceRegistry;
  };
  slot[COVERAGE_SOURCE_REGISTRY_KEY] ??= {
    sources: new Map(),
    counter: 0,
    listeners: new Set(),
  };
  return slot[COVERAGE_SOURCE_REGISTRY_KEY];
}

function notifyChange(): void {
  for (const cb of registry().listeners) cb();
}

/**
 * Calls `cb` whenever a coverage source is registered or removed, and returns
 * the function that stops it. Useful for redrawing a body map when the set of
 * scanned-ground layers changes. Used by the ground track widget's coverage gate.
 *
 * @category Maps and coverage
 */
export function onCoverageSourcesChange(cb: () => void): () => void {
  const { listeners } = registry();
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/**
 * Adds a coverage source: a layer of the body map that reveals the cells the
 * source reports as covered, such as the ground a scanner has mapped. Useful
 * for showing the operator which parts of a body have been surveyed. Read back
 * by {@link getCoverageSources}.
 * Registering a second source with an id already in use replaces the first.
 *
 * @category Maps and coverage
 * @categoryDescription Maps and coverage
 * Drawing on a body's map: the map's configuration, the points of interest an
 * Uplink adds, and the coverage sources and masks that show what has been
 * scanned.
 */
export function registerCoverageSource(def: CoverageSourceDefinition): void {
  if (hasHost()) {
    getHost().logger.info(`REGISTERED coverage source ${def.id}`);
  }
  const state = registry();
  state.sources.set(def.id, { def, order: state.counter++ });
  notifyChange();
}

/**
 * Removes the coverage source registered under `id`, so its layer no longer
 * reveals ground on the body map. Does nothing if there is none.
 * Useful for taking a scanner's layer off the map when the Uplink that supplied
 * it stops.
 *
 * @category Maps and coverage
 */
export function unregisterCoverageSource(id: string): void {
  if (registry().sources.delete(id)) notifyChange();
}

/**
 * Every registered coverage source, in registration order. Useful for deciding
 * which parts of a body map to reveal. Used by the ground track widget's coverage gate.
 *
 * @category Maps and coverage
 */
export function getCoverageSources(): CoverageSourceDefinition[] {
  return Array.from(registry().sources.values())
    .sort((a, b) => a.order - b.order)
    .map((entry) => entry.def);
}

/**
 * The settings each coverage source adds to the map's settings panel, one block
 * per source that declares any. Useful for letting the operator adjust each
 * coverage layer. Used by the ground track widget's settings. Each block is keyed by the
 * source's id, so two sources' settings with the same key never collide.
 *
 * @category Maps and coverage
 */
export function getCoverageSourceSettings(): NamespacedAugmentSettings[] {
  return getCoverageSources()
    .filter((def) => def.settings && def.settings.length > 0)
    .map((def) => ({
      augmentId: def.id,
      namespace: def.id,
      fields: def.settings ?? [],
    }));
}

/**
 * Removes every coverage source, so a test starts with none.
 *
 * @category Maps and coverage
 */
export function clearCoverageSources(): void {
  const state = registry();
  state.sources.clear();
  state.counter = 0;
  notifyChange();
}
