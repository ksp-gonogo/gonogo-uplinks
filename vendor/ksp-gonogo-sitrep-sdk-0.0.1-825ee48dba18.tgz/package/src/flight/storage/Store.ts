import type { FlightRecord, SeriesRange } from "../types";

/**
 * Sorts flights most recently launched first, as every {@link FlightStore}
 * lists them. Useful for showing the operator their flights newest first.
 *
 * @category Flight recording
 */
export const FLIGHTS_DESC = (a: FlightRecord, b: FlightRecord): number =>
  b.launchedAt - a.launchedAt;

/**
 * Where flights and their samples are saved. The app uses IndexedDB;
 * {@link MemoryStore} keeps them in memory. Every method returns a promise.
 * Useful for keeping the operator's recorded flights available to review later.
 * Taken by {@link BufferedDataSource}, {@link exportFlightToFixture} and
 * {@link importFixtureToStore}.
 *
 * @category Flight recording
 * @categoryDescription Flight recording
 * The record of past flights: how samples are buffered and kept, the stores
 * that hold them, how a flight is detected and what ended it, and the fixture
 * format a flight is exported to and replayed from.
 */
export interface FlightStore {
  /** Saves a flight record, replacing one with the same id. */
  upsertFlight(record: FlightRecord): Promise<void>;
  /** The flight with this id, or `null`. */
  getFlight(id: string): Promise<FlightRecord | null>;
  /** Every saved flight. */
  listFlights(): Promise<FlightRecord[]>;
  /** Deletes a flight and its samples. */
  deleteFlight(id: string): Promise<void>;
  /** Deletes every flight and its samples. */
  clearAllFlights(): Promise<void>;

  /**
   * Append one sample. Implementations are free to batch writes internally;
   * the sample becomes queryable after any pending batch flushes.
   */
  appendSample(
    flightId: string,
    key: string,
    t: number,
    v: unknown,
  ): Promise<void>;

  /**
   * Inclusive at both ends. Returns samples ordered by `t`. Empty arrays
   * when nothing matches: never rejects on empty range.
   */
  queryRange(
    flightId: string,
    key: string,
    tStart: number,
    tEnd: number,
  ): Promise<SeriesRange>;

  /**
   * Flush any pending batched writes so subsequent reads observe them. An
   * implementation that batches needs it; `MemoryStore` is a no-op.
   */
  flush(): Promise<void>;
}
