import type { LockedValue } from "./__generated__/contract";

/**
 * Returns whether a field arrived as a {@link LockedValue} instead of its
 * value: the save has not yet unlocked what the field needs, a tech node or a
 * building level. Useful for showing the operator what is missing instead of
 * an empty value, so a widget that shows the field checks this first. Used by
 * the chips that mark an upcoming orbital event.
 *
 * @category Readings
 * @categoryDescription Readings
 * Telling a locked field from an empty one: a field the save has not unlocked
 * arrives as a {@link LockedValue} naming what is missing, and these say which
 * of the two a widget holds. A Topic's {@link Reading} says separately whether
 * its value is current.
 */
export function isLocked(value: unknown): value is LockedValue {
  return (
    typeof value === "object" &&
    value !== null &&
    Array.isArray((value as { locked?: unknown }).locked)
  );
}

/**
 * Returns a field's value, or `null` while it is a {@link LockedValue}. Useful
 * in calculations, where a locked field and a missing one both mean there is
 * nothing to work with. To show the field, use {@link isLocked} instead, so
 * the operator sees why it is empty. Used by the maneuver planner, which
 * plans burns, and by the system view.
 *
 * @typeParam Value - The type of the field itself. It is a type parameter of
 * this function, not the SDK's `Value` quantity type.
 *
 * @category Readings
 */
export function unlessLocked<Value>(value: Value | LockedValue): Value | null {
  return isLocked(value) ? null : value;
}
