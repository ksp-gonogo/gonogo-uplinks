/**
 * The encoded-domain per-frame video delay backend, from the encoded-transform
 * cross-browser video-delay work of 2026-07-16, implementing the capture-UT
 * mapping that work validated per engine.
 *
 * Unlike `frame-delay.ts`'s decoded backend (`MediaStreamTrackProcessor` /
 * `MediaStreamTrackGenerator`: Chromium-only on the main thread), this
 * backend attaches to the standard, cross-browser
 * `RTCRtpScriptTransform`/`RTCTransformEvent.transformer` shape: a
 * `{readable, writable}` pair of encoded `RTCEncodedVideoFrame`s, delivered
 * pre-decode. Empirically confirmed to hold a real multi-second delay with
 * zero drops on Chromium, Firefox, and WebKit (spike report), gated on a
 * real `confirmedEdgeUt()` computation rather than arrival+fixedDelayMs
 * (Phase-1 report): this module is the production wiring of that proof.
 *
 * `attachEncodedFrameDelayTransform` is a thin adapter: it reuses
 * `runFrameDelayPipeline` verbatim ("a new backend
 * is a new source/sink pair, not a new engine") with three encoded-specific
 * defaults `frame-delay.ts`'s decoded backend doesn't need:
 *
 *  - `isKeyframe: (f) => f.type === "key"`: real classification, not the
 *    decoded backend's hardcoded `false` (irrelevant there: a decoded
 *    frame has no GOP dependency).
 *  - `frameBytes: (f) => f.data.byteLength`: real payload size, not the
 *    decoded backend's frame-count-as-1 cap.
 *  - `gopSafeEviction: true`, mandatory here (see
 *    `DelayedPlayoutBuffer.gopSafeEviction`'s doc): an encoded delta frame
 *    depends on a prior reference frame, so the decoded backend's
 *    drop-oldest-non-keyframe-one-at-a-time eviction would corrupt the
 *    decode chain.
 *
 * `close()` is never called on an encoded frame, `RTCEncodedVideoFrame`
 * holds no GPU/decoder resource (a plain data object), which is exactly why
 * `frame-delay.ts`'s `FrameLike.close` became optional.
 *
 * The camera SDK hands the receiver over through its encoded-transform
 * hook, so the delay worker's `self.onrtctransform` handler can take the
 * `RTCRtpScriptTransform` it is given; `attachEncodedWorkerFrameDelay` builds
 * that transform. The default byte cap holds tens of seconds of video, so a
 * feed held for minutes passes a larger `maxBufferedBytes`.
 */

import type { DelayClockLike } from "./delayed-playout-buffer";
import {
  DEFAULT_PACING_MAX_LEAD_SECONDS,
  type FrameDelayPipeline,
  type FrameLike,
  type FrameSink,
  type FrameSource,
  runFrameDelayPipeline,
} from "./frame-delay";

/**
 * The parts of an `RTCEncodedVideoFrame` the delay reads. A real encoded frame
 * satisfies it as it is. Useful for delaying video before it is decoded. Used
 * by {@link attachEncodedFrameDelayTransform}.
 *
 * @category Delayed video
 */
export interface EncodedVideoFrameLike extends FrameLike {
  /** `"key"` for a frame that can be decoded alone, `"delta"` for one that needs the frames before it. */
  readonly type: "key" | "delta";
  /** The encoded bytes. */
  readonly data: ArrayBuffer;
}

/**
 * The `transformer` of an `RTCTransformEvent`: a readable and a writable stream
 * of encoded frames. Useful for delaying video before it is decoded. Taken by
 * {@link attachEncodedFrameDelayTransform}, which the delay worker calls.
 *
 * @category Delayed video
 */
export interface EncodedTransformerLike {
  /** The frames coming in. */
  readable: ReadableStream<EncodedVideoFrameLike>;
  /** Where the delayed frames are written. */
  writable: WritableStream<EncodedVideoFrameLike>;
  /**
   * Asks the sender for a keyframe, as a real receiving transformer can. Called
   * after a flush discards frames the next ones depend on.
   */
  sendKeyFrameRequest?(): Promise<void>;
}

/**
 * Options for {@link attachEncodedFrameDelayTransform}: the delay clock, the
 * capture time to stamp each frame with, and the limits on what is held. Useful
 * for setting how a vessel's encoded video is held back before the operator
 * sees it, by the same delay as its telemetry.
 *
 * @category Delayed video
 */
export interface EncodedFrameDelayOptions {
  /** The delay clock: the same instance telemetry reads. */
  view: DelayClockLike;
  /**
   * Returns the UT to stamp a frame with, called once for each frame as it is
   * read, before it is decoded. {@link interpolateCaptureUt} computes one from
   * the capture clock.
   */
  captureUt(frame: EncodedVideoFrameLike): number;
  /**
   * The most encoded video, in bytes, to hold before dropping the oldest.
   * Defaults to {@link DEFAULT_MAX_BUFFERED_BYTES}.
   */
  maxBufferedBytes?: number;
  /**
   * How far behind, in seconds, the pacer may fall before it skips straight to
   * the newest frame. See {@link PresentationPacerOptions}.
   */
  maxPacingBacklogSeconds?: number;
  /** Non-fatal pipeline errors (a read/write rejection), reported here,
   *  never thrown across the internal pump loop. */
  onError?(error: unknown): void;
}

/**
 * The most encoded video, in bytes, the delay holds before it drops the oldest
 * frames, a whole keyframe group at a time so decoding never breaks: 8 MiB.
 * Useful as the cap on delayed video held in memory. Used by the radio session.
 *
 * @category Delayed video
 */
export const DEFAULT_MAX_BUFFERED_BYTES = 8 * 1024 * 1024;

/** Mirrors `frame-delay.ts`'s own default: see that constant's doc. */
const DEFAULT_PACING_MAX_BACKLOG_SECONDS = 0.5;

/**
 * Delays the encoded frames passing through `transformer`, the same way
 * {@link runFrameDelayPipeline} delays decoded ones. Useful for holding video
 * back by the signal delay before it is decoded. Used by the delay worker.
 *
 * Call `pipeline.tickPacing(nowWall)` about 60 times a second while it runs;
 * {@link startPacingTicker} does that.
 *
 * @category Delayed video
 */
export function attachEncodedFrameDelayTransform(
  transformer: EncodedTransformerLike,
  opts: EncodedFrameDelayOptions,
): FrameDelayPipeline {
  const source =
    transformer.readable.getReader() as FrameSource<EncodedVideoFrameLike>;
  const sink =
    transformer.writable.getWriter() as FrameSink<EncodedVideoFrameLike>;

  return runFrameDelayPipeline<EncodedVideoFrameLike>({
    view: opts.view,
    captureUt: opts.captureUt,
    source,
    sink,
    maxBufferedFrames: opts.maxBufferedBytes ?? DEFAULT_MAX_BUFFERED_BYTES,
    isKeyframe: (f) => f.type === "key",
    frameBytes: (f) => f.data.byteLength,
    gopSafeEviction: true,
    keepSinkOpenOnDispose: true,
    onNeedKeyframe: () => {
      try {
        transformer.sendKeyFrameRequest?.().catch(() => {});
      } catch {
        // A transformer that refuses the request leaves the wait for the sender's own keyframe interval.
      }
    },
    onError: opts.onError,
    pacing: {
      maxBacklogSeconds:
        opts.maxPacingBacklogSeconds ?? DEFAULT_PACING_MAX_BACKLOG_SECONDS,
      maxLeadSeconds: DEFAULT_PACING_MAX_LEAD_SECONDS,
    },
  });
}
