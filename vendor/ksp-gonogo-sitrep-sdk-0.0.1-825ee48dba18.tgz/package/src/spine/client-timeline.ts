import type { TimelinePoint } from "../timeline";

/**
 * `TimelinePoint` moved to `@ksp-gonogo/sitrep-sdk`: an Uplink writing a derived
 * channel has to name one, and it cannot import this package. Re-exported so
 * app-side imports read the same.
 */

export type { TimelinePoint } from "../timeline";

export interface ClientTimelineOptions {
  /**
   * An OPT-IN ceiling on how far behind the latest ingested `validAt` points
   * are retained. Unset (and nothing in production sets it) means no UT bound
   * at all: `maxPoints` is the always-on one.
   *
   * A UT window bounds memory only if you assume a sample rate, so it holds a
   * few dozen points of a slow channel and thousands of a fast one for the same
   * nominal cost. And its floor is measured from `latest.validAt`, which a
   * landed blackout dump moves: a dump spanning more than the window destroys
   * its own oldest half, and the pre-outage tail with it, the instant it
   * arrives. Set it only for a consumer that genuinely wants a fixed-UT view
   * and can afford to lose a wider dump.
   */
  retentionSeconds?: number;

  /**
   * The always-on bound: at most this many points per topic, dropping the
   * oldest to make room. Bounds memory directly rather than through an assumed
   * sample rate, and is indifferent to how much UT a burst spans, so a blackout
   * dump survives ingest whatever its width.
   *
   * Drop-oldest matches the server-side recorder's own overrun policy
   * (`ChannelEngine.RecorderBudgetBytes`) so the two do not fight: the
   * span nearest the live edge is the one both keep. What a drop cost is
   * readable off `droppedThroughUt` rather than left to be inferred from a
   * hole.
   *
   * 1500, which is about what 300 seconds of a channel emitting at 4 Hz comes
   * to, so the busiest topic's footprint is bounded and every slower one keeps
   * correspondingly more history.
   */
  maxPoints?: number;
}

const DEFAULT_MAX_POINTS = 1500;

/**
 * The buffer of delivered samples for one Topic, kept sorted by `validAt`
 * because samples can arrive out of order. Useful for showing the operator a
 * Topic's recent history and for carrying a value forward between samples. Used
 * by the timeline store and the delay authority.
 *
 * It is bounded by point count: at most `maxPoints` are kept, the oldest are
 * dropped, and `droppedThroughUt` reports the edge dropped through. A UT window
 * is available on top with `retentionSeconds`.
 *
 * A quickload rewind is detected from the epoch of each incoming sample:
 *
 * - a sample from a lower epoch than the timeline holds is a straggler queued
 *   behind the rewind, and is discarded on arrival
 * - a sample from a higher epoch is a rewind: every existing point is dropped
 *   at once and the timeline adopts the new epoch before the incoming point is
 *   appended, so data from before the rewind is never read afterwards
 */
export class ClientTimeline<Payload = unknown> {
  private points: TimelinePoint<Payload>[] = [];
  private currentEpoch = 0;
  private readonly retentionSeconds: number | undefined;
  private readonly baseMaxPoints: number;
  private maxPoints: number;
  private droppedThrough: number | undefined;
  /** How many of the oldest points `supersedeBefore` has already passed over. */
  private superseded = 0;

  /** Bumped on every append that changes the buffer (insert or epoch-reset). Memo key for later tasks. */
  revision = 0;

  constructor(options: ClientTimelineOptions = {}) {
    this.retentionSeconds = options.retentionSeconds;
    this.baseMaxPoints = options.maxPoints ?? DEFAULT_MAX_POINTS;
    this.maxPoints = this.baseMaxPoints;
  }

  /**
   * The `validAt` of the newest point this timeline has dropped to stay inside
   * its own bound, or `undefined` while nothing has been dropped. Data existed
   * at-or-below it and this client no longer has it.
   *
   * The client-side twin of the server's `Meta.gapSinceUt`, and separate from it
   * because the two say different things: that one reports what the subject
   * could not send, this one what the viewer could not keep. A consumer reading
   * a range that starts at-or-below this UT is looking at a truncated span, and
   * has to be told rather than shown a chart that simply starts later and looks
   * complete.
   *
   * Reset by a rewind (`adoptEpoch` / a higher-epoch append), because it
   * describes a record that no longer exists.
   */
  get droppedThroughUt(): number | undefined {
    return this.droppedThrough;
  }

  /** The epoch this timeline currently holds points for. */
  get epoch(): number {
    return this.currentEpoch;
  }

  /** Insert a delivered sample, sorted by `validAt` (tie-break: `meta.seq`). */
  append(point: TimelinePoint<Payload>): void {
    if (point.epoch < this.currentEpoch) {
      // Stale-epoch straggler (queued behind a rewind broadcast); never let pre-rewind data re-enter a post-rewind timeline.
      return;
    }
    if (point.epoch > this.currentEpoch) {
      // Rewind: the superseded timeline is dead. Drop it atomically before
      // adopting the new epoch, so there is no window where a read could
      // see a mix of old and new epoch's points.
      this.points = [];
      this.currentEpoch = point.epoch;
      this.droppedThrough = undefined;
      this.superseded = 0;
    }

    const index = this.insertionIndex(point);
    this.points.splice(index, 0, point);
    this.superseded = Math.min(this.superseded, index);
    this.revision++;

    this.autoEvict();
  }

  /** Latest point with `validAt <= ut` (current epoch only, the buffer never holds stale-epoch points). */
  at(ut: number): TimelinePoint<Payload> | undefined {
    // Points are sorted ascending by validAt, so the last one at or before `ut` is found by halving.
    let low = 0;
    let high = this.points.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      if (this.points[mid].validAt <= ut) low = mid + 1;
      else high = mid;
    }
    return low === 0 ? undefined : this.points[low - 1];
  }

  /**
   * The pair of points straddling `ut`, `[before, after]` where
   * `before.validAt <= ut < after.validAt`. Undefined when `ut` is before
   * the first point or at-or-after the last (nothing to interpolate
   * towards). A hold-last read (`at`) is what T2 consumers use; interpolation
   * lands in a later task: this is the seam it will use.
   */
  straddle(
    ut: number,
  ): [TimelinePoint<Payload>, TimelinePoint<Payload>] | undefined {
    for (let i = 0; i < this.points.length - 1; i++) {
      const before = this.points[i];
      const after = this.points[i + 1];
      if (before.validAt <= ut && ut < after.validAt) return [before, after];
    }
    return undefined;
  }

  /** All points with `validAt` in `[fromUt, toUt]`, inclusive. */
  range(fromUt: number, toUt: number): TimelinePoint<Payload>[] {
    if (!(fromUt <= toUt)) return [];
    // The points are sorted by `validAt`, so the window is one run of them, found by halving from each end rather than by reading every point a long flight has kept.
    return this.points.slice(
      this.firstIndexAfter(fromUt, false),
      this.firstIndexAfter(toUt, true),
    );
  }

  /** Where a window's edge at `ut` falls among the points: after every point at `ut` when `inclusive`, before them when not. */
  private firstIndexAfter(ut: number, inclusive: boolean): number {
    let low = 0;
    let high = this.points.length;
    while (low < high) {
      const mid = (low + high) >>> 1;
      const at = this.points[mid].validAt;
      if (inclusive ? at <= ut : at < ut) low = mid + 1;
      else high = mid;
    }
    return low;
  }

  /** The most recently ingested point: the confirmed edge for this topic. */
  latest(): TimelinePoint<Payload> | undefined {
    return this.points[this.points.length - 1];
  }

  /**
   * Proactively adopt a higher epoch with no incoming sample, a no-op if
   * `epoch` isn't actually higher than the one this timeline currently
   * holds. Used by `TimelineStore`'s cross-topic sweep (guards against
   * "the client ghost"): a rewind confirmed by one topic's
   * ingest doesn't, on its own, tell every other topic's `ClientTimeline` to
   * reset: each timeline only ever learns about a rewind from its own next
   * `append`. Without this, a slow/change-gated topic that hasn't re-sampled
   * since the rewind keeps serving its dead-epoch points indefinitely. The
   * store calls this on every registered timeline the instant any topic's
   * `append` bumps the shared epoch, so the drop happens immediately rather
   * than waiting for that topic's next sample.
   */
  adoptEpoch(epoch: number): void {
    if (epoch <= this.currentEpoch) return;
    this.points = [];
    this.currentEpoch = epoch;
    this.droppedThrough = undefined;
    this.superseded = 0;
    this.revision++;
  }

  /** Drop every point with `validAt < ut`. Used to enforce an externally-computed retention bound (e.g. the real delay window). */
  evictBelow(ut: number): void {
    const next = this.points.filter((p) => p.validAt >= ut);
    if (next.length === this.points.length) return;
    this.superseded = Math.max(
      0,
      this.superseded - (this.points.length - next.length),
    );
    this.points = next;
    this.revision++;
  }

  /**
   * Keep `scale` times the configured point bound, for a Topic arriving that many
   * times faster than one sample a second, so the buffer spans the same game
   * time. Dropping back evicts the oldest points at once.
   */
  scaleMaxPoints(scale: number): void {
    const maxPoints = Math.round(this.baseMaxPoints * scale);
    if (maxPoints === this.maxPoints) return;
    this.maxPoints = maxPoints;
    this.autoEvict();
  }

  /**
   * Replace the payload of every point older than the one on screen at `ut`,
   * the newest at or before it, with `shed(payload)`. The point on screen and
   * every point after it keep theirs, so a view that reaches `ut` or later
   * reads each sample whole. `ut` must not move back while the epoch holds,
   * which the delayed view edge never does.
   */
  supersedeBefore(
    ut: number,
    shed: (
      payload: TimelinePoint<Payload>["payload"],
    ) => TimelinePoint<Payload>["payload"],
  ): void {
    let onScreen = this.points.length;
    while (onScreen > 0 && this.points[onScreen - 1].validAt > ut) onScreen--;
    onScreen--;
    let changed = false;
    for (let i = this.superseded; i < onScreen; i++) {
      const point = this.points[i];
      const payload = shed(point.payload);
      if (payload === point.payload) continue;
      this.points[i] = { ...point, payload };
      changed = true;
    }
    this.superseded = Math.max(this.superseded, onScreen);
    if (changed) this.revision++;
  }

  private autoEvict(): void {
    const latest = this.latest();
    if (!latest) return;
    if (this.retentionSeconds !== undefined) {
      this.evictBelow(latest.validAt - this.retentionSeconds);
    }
    if (this.points.length <= this.maxPoints) return;
    const surplus = this.points.length - this.maxPoints;
    // Read the drop edge BEFORE splicing: it is the newest point going, which is the one at the boundary.
    this.droppedThrough = this.points[surplus - 1].validAt;
    this.points.splice(0, surplus);
    this.superseded = Math.max(0, this.superseded - surplus);
    this.revision++;
  }

  private insertionIndex(point: TimelinePoint<Payload>): number {
    // Linear scan from the end: append-mostly workload (new samples are
    // usually the newest), so this is O(1) amortized in the common case
    // despite being O(n) worst case for genuinely out-of-order delivery.
    let i = this.points.length;
    while (i > 0) {
      const prev = this.points[i - 1];
      if (
        prev.validAt < point.validAt ||
        (prev.validAt === point.validAt && prev.meta.seq <= point.meta.seq)
      ) {
        break;
      }
      i--;
    }
    return i;
  }
}
