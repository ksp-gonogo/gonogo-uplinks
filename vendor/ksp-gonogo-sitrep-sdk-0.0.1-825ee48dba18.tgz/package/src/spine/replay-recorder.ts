import { getAllKnownTopicIds } from "../topics";
import type { TelemetryClient } from "./client";
import type { ReplayFixture } from "./replay-transport";

export interface StreamRecorderOptions {
  /**
   * Full-archive opt-in. When `true`, `start()` additionally subscribes to
   * every topic `getAllKnownTopicIds()` reports (`@ksp-gonogo/sitrep-sdk`: the
   * SDK's own topics plus every bare-primitive Uplink topic a loaded client has
   * registered) so the
   * resulting fixture can replay any widget's history, not just whatever the
   * dashboard happened to have mounted while recording. This trades away the
   * subscription system's whole efficiency point (the mod
   * only produces what's watched) for completeness: costs more mod-side
   * produce load and a bigger recording. Default `false`: subscription-scoped,
   * the cheap default: the recording only ever holds the topics the
   * dashboard already subscribed, nothing extra.
   */
  recordAllTopics?: boolean;
}

/**
 * Captures a `TelemetryClient`'s raw wire frames into a `ReplayFixture`, the same
 * `{ subscribedTopics, frames }` shape `ReplayTransport` consumes, so an
 * operator's recording and a test fixture are structurally identical. Useful for
 * saving a flight so the operator can replay it later. Used by the flights
 * manager's automatic recording.
 *
 * It taps `client.onRawMessage`, which delivers verbatim `stream-data` and
 * `event` frames in arrival order. `client.subscribe` hands back only the
 * flattened last-value view and never delivers `event` frames, so a recording
 * made from it would not replay correctly.
 *
 * Recording is subscription-scoped by default: with `recordAllTopics` off,
 * `start()` registers no subscriptions of its own and records only the frames that
 * already flow because something else (a mounted widget, another recorder) is
 * subscribed. A recording therefore holds exactly the topics the dashboard had
 * open, and replaying a widget that was never mounted while recording shows
 * nothing. See `StreamRecorderOptions.recordAllTopics` for the opt-in alternative.
 *
 * Idle (never started, or after `stop()`) costs nothing: no listener is registered
 * on the client until `start()` runs.
 */
export class StreamRecorder {
  private readonly client: TelemetryClient;
  private readonly recordAllTopics: boolean;
  private frames: string[] = [];
  private bufferedCharacters = 0;
  private readonly observedTopics = new Set<string>();
  private detachRawTap: (() => void) | undefined;
  private readonly extraSubscriptions: Array<() => void> = [];
  private latestValidAt = 0;
  private recordingFlag = false;

  constructor(client: TelemetryClient, options: StreamRecorderOptions = {}) {
    this.client = client;
    this.recordAllTopics = options.recordAllTopics ?? false;
  }

  /** Whether `start()` has run without a matching `stop()` yet. */
  get recording(): boolean {
    return this.recordingFlag;
  }

  /** Frames captured so far in the current (or just-finished) session. */
  get frameCount(): number {
    return this.frames.length;
  }

  /**
   * How much the recorder holds, as the length of its frames' JSON text in
   * characters. The wire's text is ASCII apart from names, so this is close to
   * the bytes a store writes for it.
   */
  get bufferedSize(): number {
    return this.bufferedCharacters;
  }

  /** The highest `meta.validAt` observed so far: the recording's "now", in UT seconds. `0` before any frame lands. */
  get latestUt(): number {
    return this.latestValidAt;
  }

  /**
   * Begin capturing. No-op if already recording. Clears any frames left over
   * from a previous session: call `stop()` first to retrieve them.
   */
  start(): void {
    if (this.recordingFlag) return;
    this.recordingFlag = true;
    this.frames = [];
    this.bufferedCharacters = 0;
    this.observedTopics.clear();
    this.latestValidAt = 0;

    this.detachRawTap = this.client.onRawMessage((message) => {
      if (message.type !== "stream-data" && message.type !== "event") return;
      this.observedTopics.add(message.topic);
      const frame = JSON.stringify(message);
      this.frames.push(frame);
      this.bufferedCharacters += frame.length;
      if (
        message.type === "stream-data" &&
        message.meta.validAt > this.latestValidAt
      ) {
        this.latestValidAt = message.meta.validAt;
      }
    });

    if (this.recordAllTopics) {
      // The full live set: the SDK's own Topics PLUS every bare-primitive
      // Uplink Topic registered by a loaded client. Those are not static
      // members of `TOPIC_IDS`, so only iterating the runtime registry keeps
      // the full-archive recording complete.
      for (const topic of getAllKnownTopicIds()) {
        this.extraSubscriptions.push(this.client.subscribe(topic, () => {}));
      }
    }
  }

  /**
   * Hands back the frames captured so far as a `ReplayFixture` and carries on
   * recording into an empty buffer. No frame is lost or repeated between the
   * part handed back and the next: frames are delivered one at a time, and the
   * buffers are swapped between two of them. A part holds only its own frames,
   * so parts replay as one recording when their frames are joined in the order
   * they were taken. Useful for storing a long recording in pieces of a
   * bounded size.
   */
  takePart(): ReplayFixture {
    const part: ReplayFixture = {
      subscribedTopics: [...this.observedTopics],
      frames: this.frames,
    };
    this.frames = [];
    this.bufferedCharacters = 0;
    this.observedTopics.clear();
    return part;
  }

  /**
   * Stop capturing and return the `ReplayFixture` built from this session.
   * Idempotent-safe to call while not recording (returns whatever frames are
   * currently buffered, tearing down nothing extra). `subscribedTopics` is
   * the set of topics actually observed, never a static declaration, so it
   * stays accurate whether or not `recordAllTopics` forced extra subscriptions.
   */
  stop(): ReplayFixture {
    this.recordingFlag = false;
    this.detachRawTap?.();
    this.detachRawTap = undefined;
    for (const unsubscribe of this.extraSubscriptions) unsubscribe();
    this.extraSubscriptions.length = 0;

    return {
      subscribedTopics: [...this.observedTopics],
      frames: this.frames,
    };
  }
}
