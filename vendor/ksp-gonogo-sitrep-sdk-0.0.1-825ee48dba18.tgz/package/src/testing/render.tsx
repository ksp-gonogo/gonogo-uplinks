import {
  type RenderHookOptions,
  type RenderHookResult,
  type RenderOptions,
  type RenderResult,
  render as rtlRender,
  renderHook as rtlRenderHook,
} from "@testing-library/react";
import type { JSXElementConstructor, ReactElement, ReactNode } from "react";
import { createElement } from "react";
import { ThemeProvider } from "styled-components";
import { harnessTheme } from "./theme";

// A kit primitive reads `theme.colors` off styled-components' context and throws a TypeError without a provider; spacing and radii resolve without one.
type Wrapper = JSXElementConstructor<{ children: ReactNode }>;

/**
 * Composes rather than replaces: a caller's own `wrapper` nests inside the theme,
 * so adding a `TelemetryProvider` or a router never silently drops the theme
 * underneath it and turns every kit primitive into a TypeError.
 */
function withTheme(Extra?: Wrapper): Wrapper {
  return function HarnessWrapper({ children }: { children: ReactNode }) {
    return createElement(
      ThemeProvider,
      { theme: harnessTheme },
      Extra ? createElement(Extra, null, children) : children,
    );
  };
}

/**
 * The render function of `@testing-library/react` with the kit's theme always
 * mounted, so a `@ksp-gonogo/ui-kit` component renders without a provider of
 * your own. A `wrapper` you pass is mounted inside the theme. It needs
 * `@testing-library/react` and `styled-components` installed, and a DOM test
 * environment such as jsdom, in which a widget also needs
 * {@link installDomStubs} to have run. Any test runner works; the example uses
 * vitest, installed with `npm install -D vitest jsdom` and set to
 * `environment: "jsdom"` in its config.
 * Its options and result are Testing Library's own `RenderOptions` and
 * `RenderResult`, with Testing Library's default queries, which the signature
 * shows as `queries`. Useful for testing what an operator sees of a ui-kit
 * component or a widget.
 *
 * @example
 * ```tsx
 * import { render } from "@ksp-gonogo/sitrep-sdk/testing";
 * import { Badge } from "@ksp-gonogo/ui-kit";
 * import { expect, it } from "vitest";
 *
 * it("draws the badge with the kit's theme", () => {
 *   const { getByText } = render(<Badge tone="nogo">Abort</Badge>);
 *   expect(getByText("Abort")).toBeTruthy();
 * });
 * ```
 *
 * @category Rendering
 * @categoryDescription Rendering
 * Rendering a widget or a hook in a test with the theme and DOM stubs it needs,
 * and reading its text the way an operator sees it.
 */
export function render(
  ui: ReactElement,
  options?: RenderOptions,
): RenderResult {
  return rtlRender(ui, { ...options, wrapper: withTheme(options?.wrapper) });
}

/**
 * The hook-rendering function of `@testing-library/react` with the kit's theme
 * always mounted. A `wrapper` you pass is mounted inside the theme. Useful for
 * testing a hook that reads what the operator sees, such as a telemetry
 * reading.
 *
 * @example
 * ```tsx
 * import { useTelemetry } from "@ksp-gonogo/sitrep-sdk";
 * import {
 *   renderHook,
 *   setupStreamFixture,
 * } from "@ksp-gonogo/sitrep-sdk/testing";
 * import { expect, it } from "vitest";
 *
 * it("has no observed value before anything is emitted", () => {
 *   const fixture = setupStreamFixture();
 *   const { result } = renderHook(() => useTelemetry("vessel.flight"), {
 *     wrapper: fixture.Provider,
 *   });
 *   expect(result.current.state).not.toBe("observed");
 * });
 * ```
 *
 * @category Rendering
 */
export function renderHook<Result, Props>(
  render: (initialProps: Props) => Result,
  options?: RenderHookOptions<Props>,
): RenderHookResult<Result, Props> {
  return rtlRenderHook(render, {
    ...options,
    wrapper: withTheme(options?.wrapper),
  });
}

/**
 * The text a test probe should print for a value. A probe is a small test
 * component that prints what a hook returned so a test can assert on it. A
 * quantity (a `Value`, which pairs a magnitude with its unit) prints as its
 * magnitude, and anything else as it is. For a test of whether a value arrived,
 * not of how it is drawn; use `visibleText` from `@ksp-gonogo/ui-kit/testing`
 * for what a reader sees. Useful for testing that a value reached a widget,
 * such as a reading the operator is shown.
 *
 * @category Rendering
 */
export function probeText(v: unknown): string {
  return String(
    v !== null && typeof v === "object" && "magnitude" in v
      ? (v as { magnitude: unknown }).magnitude
      : v,
  );
}
