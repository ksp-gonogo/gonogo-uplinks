import type { TopicId, TopicPayload } from "../index";
import type { Reading } from "../reading";
import type { TimelinePoint } from "../timeline";
import type { TopicReading } from "./client-reading";

// ---------------------------------------------------------------------------
// The Processor primitive: a declared
// pure function of Topics (and other Processors), exposed two ways: called
// directly by a Contribution (pure), and consumed via useProcessor (Task 3.3)
// by an augment. One source, two forms, evaluated ONCE per Sitrep frame no
// matter how many consumers pull from it (Task 3.2's frame-batched evaluator).
//
// Lives in @ksp-gonogo/sitrep-client (the spine), not core: the evaluator and
// useProcessor need TimelineStore.subscribeFrame/currentFrame/sample, and core
// already depends on sitrep-client (not the reverse), so a registry in core
// called from the spine would cycle. See this plan's Phase 3 header.
// ---------------------------------------------------------------------------

/**
 * Opaque, branded handle returned by defineProcessor. Never constructed by
 * hand: carries the result type R through inference for downstream consumers.
 */
export interface ProcessorHandle<
  R,
  Id extends string = string,
  Carried extends boolean = boolean,
> {
  /**
   * The owner-stamped id this processor registered under.
   *
   * <p>Carried as a type parameter, not as a bare `string`, so a CONTRIBUTION
   * that deps on this handle can be handed its result under this exact key:
   * `topics[HANDLE.id]` is only typeable when `HANDLE.id` is more specific than
   * `string`. The client id is not known statically, so what survives is
   * `` `${string}:${Id}` ``, which is enough to key the record and still narrow
   * enough that a Topic id cannot be read through it.</p>
   */
  readonly id: Id;
  /** Type-only brand: never present at runtime, carries R through inference. */
  readonly __resultType?: R;
  /**
   * Type-only brand: whether this processor ANSWERS with currency.
   *
   * True when its own deps include a reading, which is what makes the answer
   * datable. Carried on the handle because every consumer, a hook and a nested
   * dep alike, has to know which of the two shapes it is receiving; a processor
   * that gained or lost a reading dep would otherwise change what it hands back
   * with nothing to notice.
   */
  readonly __carriesCurrency?: Carried;
}

/**
 * Whether a dep list makes its processor's answer datable.
 *
 * Wrapped in a tuple so a union of deps does not distribute: the question is
 * about the list as a whole, and a distributed `extends never` answers it once
 * per member.
 */
export type CarriesCurrency<Deps extends readonly Dep[]> = [
  Extract<Deps[number], ReadingDep>,
] extends [never]
  ? false
  : true;

/**
 * A dep asking for a Topic's `Reading` rather than its bare payload.
 *
 * The wrapper exists because a Topic id is a plain string, so there is nothing
 * to distinguish "give me the value" from "give me the value and its currency"
 * without one. `{ reading: "vessel.resources" }` reads at the call site as the
 * request it is.
 *
 * ## Why a processor needs this at all
 *
 * A processor resolved a Topic dep to `point.payload`: the VALUE channel alone,
 * with no staleness, no `validAt` and no model. So a derivation that reasons
 * ACROSS topics could not tell whether its inputs were current, and during a
 * blackout it computed on last-contact values and its consumers presented the
 * result as though it were now. `ShipSystems` does exactly that today: a
 * time-to-empty derived from levels observed twenty minutes ago, rendered with
 * nothing anywhere saying so. That is the failure this whole type exists to
 * prevent, in the widget where it matters most.
 *
 * ## Why it composes
 *
 * `evaluate` skips a processor whose `lastFrameGeneration` matches the frame,
 * so it is memoised WITHIN a frame and re-evaluated ACROSS frames.
 * `sampleReading` re-derives a reading carrying a model whenever the frame's
 * view time moves. Both are keyed on the same thing, the frame, so a processor sees a
 * reading built for the moment it is deriving for without any new invalidation
 * machinery.
 *
 * ## What a processor should NOT do with it
 *
 * Return it. A `Reading` is one Topic's currency; a cross-resource conclusion
 * ("four hours of oxygen, but not if the batteries go first") is not one
 * Topic's anything. A processor whose output is modelled carries its own
 * provenance instead, the way a projection channel's payload does with
 * `observed` / `projected` / `lower` / `upper` / `elapsed`.
 */
export interface ReadingDep<T extends TopicId = TopicId> {
  readonly reading: T;
}

/**
 * A dep whose topic is only known once the FIXED deps have resolved: "the orbit
 * of whichever vessel this route names", not a topic id anyone can write down.
 *
 * ## Why a fixed list cannot express it
 *
 * `comms.delay`'s model refuses a relayed route outright, and its own decline
 * says why: the route home starts at a relay, and where that relay is now sits
 * on `fleet.<guid>.orbit`, whose guid arrives IN the route. The model has the
 * guid in hand at reckon time; what it has no way to say is "subscribe that".
 * Every other dep variety names its topic at declaration time, which is exactly
 * the thing a subject cannot do.
 *
 * ## The payload type is stated, not looked up
 *
 * `P` is the payload the resolved topic carries, and the author gives it, the
 * same way `useStream<WireOf<VesselOrbitPayload>>(`fleet.${guid}.orbit`)`
 * already does at every other dynamic read in the tree. A dynamic topic has no
 * member in `TopicPayloadMap` to infer from: the ids are computed at runtime,
 * which is the same reason `dynamicWholeTopicPrefixes` exists rather than a
 * generated list.
 *
 * ## An undeclared subject declines, it does not guess
 *
 * `subject` returning `undefined` resolves the dep to `undefined`, which the
 * store already turns into the `input-absent` decline every other unmet dep
 * gets. A model that cannot name its subject has not got its input, and saying
 * so is the same answer as an absent channel rather than a new one.
 */
export interface SubjectDep<
  P = unknown,
  Fixed extends readonly unknown[] = readonly unknown[],
> {
  /** The topic to read, given the subject id: `` (id) => `fleet.${id}.orbit` ``. */
  forSubject(subjectId: string): string;
  /**
   * Which subject this reckon is about, read from the point and the fixed deps
   * resolved beside it. `undefined` means this reckon has no subject, which is
   * not the same as a missing input: the dep resolves to `undefined` and the
   * model decides.
   *
   * `Fixed` is the prefix of the model's own deps this selector reads, declared
   * so it destructures typed. Without it `resolved` is `readonly unknown[]` and
   * every selector opens with an assertion out of `unknown`, which is the thing
   * `unknown-cast` exists to stop. Declared as a METHOD rather than a property
   * so the bivariance lets a selector over a narrow tuple still satisfy the
   * `SubjectDep<unknown>` the `Dep` union carries.
   */
  subject(point: TimelinePoint<unknown>, resolved: Fixed): string | undefined;
  /** Phantom: the payload the resolved topic carries. Never read at runtime. */
  readonly __payloadType?: P;
}

/**
 * A processor dependency: a raw Topic id, a Topic's reading, another
 * processor's handle, or a per-subject topic resolved at reckon time.
 *
 * The last is a RECKONER's to declare. It is in this union rather than in a
 * second one because a reckoner's inputs are the same kind of thing a
 * processor's are, and the alternative is two vocabularies to keep in step (see
 * `ResolvedReckonerDep`, which says the same about resolution). A processor
 * handed one is refused out loud by the evaluator: a processor has no point to
 * take a subject from, and resolving it to `undefined` there would be
 * indistinguishable from an absent input.
 */
export type Dep =
  | TopicId
  | ReadingDep
  | ProcessorHandle<unknown>
  | SubjectDep<unknown>;

/** Whether this dep's topic is computed per subject rather than declared. */
export function isSubjectDep(dep: Dep): dep is SubjectDep<unknown> {
  return typeof dep === "object" && dep !== null && "forSubject" in dep;
}

/**
 * The resolved value for one dependency: a nested processor resolves to its
 * result type R; a reading dep resolves to the Topic's `Reading`; a Topic id
 * resolves to its payload (or undefined when that Topic has produced no frame
 * yet).
 */
type ResolvedDep<D extends Dep> =
  D extends ProcessorHandle<infer R, string, true>
    ? Reading<R>
    : D extends ProcessorHandle<infer R>
      ? R
      : D extends ReadingDep<infer T>
        ? TopicReading<TopicPayload<T>>
        : D extends TopicId
          ? TopicPayload<D> | undefined
          : never;

/** Positionally-mapped tuple of resolved dependency values, in deps order. */
export type ResolvedDeps<Deps extends readonly Dep[]> = {
  [K in keyof Deps]: Deps[K] extends Dep ? ResolvedDep<Deps[K]> : never;
};

/**
 * What a `compute` is told about the frame it is running for, beyond its deps.
 *
 * Only the frame's instants, and deliberately only those: a processor that needs to
 * know WHEN it is deriving for is common (anything turning an instant on the
 * wire into a remaining duration), and a processor that reaches for a wall
 * clock instead is the bug `readingAge` and the wall-clock ratchet exist to
 * stop. Handing it the frame's own frozen instants means there is nothing to
 * reach for.
 */
export interface ProcessorFrame {
  /** The frame's frozen view time. Every read in this frame shares it. */
  viewUt: number;
  /** The craft's present (SCET) for the same frame, the instant its readings are reckoned to. */
  scetUt: number;
  /** When a command sent this frame reaches the craft. */
  commandArrivalUt: number;
}

export interface ProcessorDefinition<
  Deps extends readonly Dep[] = readonly Dep[],
  R = unknown,
> {
  id: string;
  owner: string;
  deps: Deps;
  compute: (values: ResolvedDeps<Deps>, frame: ProcessorFrame) => R;
}

export type AnyProcessorDefinition = ProcessorDefinition<
  readonly Dep[],
  unknown
>;

const processors = new Map<string, AnyProcessorDefinition>();

/**
 * Declare a Processor. Registers under the owner-stamped id `${owner}:${id}`
 * (same owner-stamp convention as registerContribution) and returns an opaque
 * handle other processors and contributions depend on. Re-registering the
 * exact same definition (same compute reference) is a no-op so a module can be
 * imported twice; a DIFFERENT definition under an already-used id throws.
 */
export function defineProcessor<
  const Deps extends readonly Dep[],
  R,
  const Id extends string,
>(def: {
  id: Id;
  owner: string;
  deps: Deps;
  compute: (values: ResolvedDeps<Deps>, frame: ProcessorFrame) => R;
}): ProcessorHandle<R, `${string}:${Id}`, CarriesCurrency<Deps>> {
  /* Typed rather than inferred: a template expression widens to `string`, and
     the stamped id is what a contribution keys this processor's result by, so
     the shape has to survive as far as the handle. */
  const stampedId: `${string}:${Id}` = `${def.owner}:${def.id}`;
  const existing = processors.get(stampedId);
  const stamped: AnyProcessorDefinition = {
    id: stampedId,
    owner: def.owner,
    deps: def.deps,
    compute: def.compute as (
      values: ResolvedDeps<readonly Dep[]>,
      frame: ProcessorFrame,
    ) => unknown,
  };
  if (existing !== undefined) {
    if (existing.compute === stamped.compute) return { id: stampedId };
    throw new Error(
      `Processor id "${stampedId}" is already registered; a different ` +
        `definition cannot re-use it. Processor ids must be unique within ` +
        `their owner.`,
    );
  }
  processors.set(stampedId, stamped);
  return { id: stampedId };
}

/**
 * Declare the CONTRACT of a Processor without declaring the processor: its
 * owner-stamped id and its result type, published from here, for an
 * implementation that registers somewhere else.
 *
 * ## The problem it solves, and the one it does not
 *
 * An Uplink consumes a Processor by handle, because `useProcessor` reads `R`
 * off the handle's phantom brand. Handing it a bare `{ id }` gets `unknown`,
 * and `getProcessor(id)` is no better: an `AnyProcessorDefinition`'s result is
 * `unknown` by construction, so there is no route from an id back to a type.
 *
 * That is fine for a processor the SDK declares (`CELESTIAL_FACTS` and
 * `DELTA_V_BUDGET` both ship their handle and their result type from the root
 * barrel, and an Uplink test proves an Uplink can consume them). It is NOT fine
 * for one an Uplink declares, and no registry keyed by id can fix that: a
 * declaration merge is scoped to a TypeScript PROGRAM, and Uplink B's program
 * can never include Uplink A's declaration file, because A is unpublished and B
 * cannot depend on it. `TopicPayloadMap` has exactly the same limit for exactly
 * the same reason, and one Uplink cannot type another's Topic either.
 *
 * So the only place a declaration can sit that two Uplinks both compile against
 * is this package, and this is the shape that makes that a route rather than a
 * dead end: the CONTRACT here, the IMPLEMENTATION in whichever Uplink owns the
 * mod it derives from.
 *
 * ```ts
 * // in the SDK, next to the result type it names
 * export interface HabSummary { ... }
 * export const HAB_SUMMARY = defineProcessorContract<HabSummary>("<owner>:hab-summary");
 *
 * // in the owning Uplink, which imports the type it must satisfy
 * OWNER.registerProcessor({ id: "hab-summary", deps, compute });
 *
 * // in any OTHER Uplink, which imports neither that Uplink nor its types
 * const hab = useProcessor(HAB_SUMMARY);   // HabSummary | undefined
 * ```
 *
 * ## Absence is a value, not a crash
 *
 * A contract whose implementation never registers (the mod is not installed,
 * the Uplink did not load) evaluates to nothing and `useProcessor` answers
 * `undefined`, which every consumer already has to handle because that is also
 * what it answers with no provider mounted. That is deliberately the same
 * graceful-degradation shape a domain-gated widget already has, and it is why
 * this does not need a presence check bolted on.
 *
 * ## What it cannot check
 *
 * That the registered `compute` returns what the contract promises. The two
 * sides are in different packages and the brand is type-only, so the guarantee
 * comes from the implementing Uplink importing `R` from here and annotating its
 * `compute` with it. Declaring the type twice, once each side, is the failure
 * this exists to prevent, so do not.
 */
export function defineProcessorContract<R, const Id extends string = string>(
  id: Id,
): ProcessorHandle<R, Id> {
  // A contract names an id `registerProcessor` will STAMP, so it has to be
  // written owner-first. Checked here because the alternative is a handle that
  // silently answers `undefined` forever, which is indistinguishable from the
  // mod not being installed: the one case this is supposed to make legible.
  if (id.split(":").length !== 2 || id.startsWith(":") || id.endsWith(":")) {
    throw new Error(
      `Processor contract id "${id}" must be owner-stamped as "<owner>:<id>", ` +
        `matching what registerProcessor stamps for the Uplink that implements it.`,
    );
  }
  return { id };
}

export function getProcessor(id: string): AnyProcessorDefinition | undefined {
  return processors.get(id);
}

export function getAllProcessors(): AnyProcessorDefinition[] {
  return Array.from(processors.values());
}

/** Test-only: reset the processor registry to empty. */
export function clearProcessors(): void {
  processors.clear();
}
