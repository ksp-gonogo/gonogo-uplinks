// ---------------------------------------------------------------------------
// `@ksp-gonogo/sitrep-sdk/spine`: the REAL IMPLEMENTATIONS behind the host shims.
//
// Every name the root barrel publishes as an author-facing shim
// (`useTelemetry`, `useActionInput`, `registerSetting`, ...) resolves at runtime
// to `getHost().<member>`. This subpath is where those members are actually
// implemented, and the two are deliberately not the same module: the shim is what
// an Uplink calls, this is what the app and an Uplink's test WIRE INTO the host.
//
// The largest part of it is the read semantics of a topic. What
// `useTelemetry("system.state.bodyCount")` MEANS: the derived-channel path, the
// raw-field-subtopic fallback the legacy-key table rides on, epoch handling on a
// quickload rewind, and the frame-coherent memoisation that makes a re-read within
// one frame hand back the identical object. A widget depends on all of it while it
// renders.
//
// The rest arrived for the same reason by a different route: the dashboard-item
// and screen contexts, the action-input hook, the data-source hooks, and the
// setting and settings-tab registries were all in `@ksp-gonogo/core`, where an
// Uplink's test could not reach them to build a host. Each named only things
// already on this side of the line.
//
// It lives here rather than in `@ksp-gonogo/sitrep-client` because it never
// needed that package: the transitive import closure of these seven files was
// the sdk and itself, nothing more. Keeping them there meant an Uplink's tests
// could only reach the real read semantics through an unpublished package, and
// the alternative on the table was to reimplement the store inside the test
// harness. A test running against a reimplementation of the store is not
// evidence about the store, so the reimplementation is not on the table any
// more: this is a move, and an Uplink's tests run the code the app runs.
//
// Deliberately NOT re-exported from the root barrel. Authoring a derived channel
// needs `DerivedChannelDefinition` and `TimelinePoint`, which the root barrel
// already publishes; nothing about writing an Uplink needs `TimelineStore`
// itself. Publishing the class would freeze 1594 lines of evolving internals as
// third-party API, the same trap `TelemetryClient`-as-a-value was pulled back
// from. A test reaches it through this subpath; the app reaches it through
// `sitrep-client`'s re-export.
//
// Wildcards, not a curated name list: a curated one silently omitted six names
// `sitrep-client`'s own barrel re-exports, and the omission only surfaced as six
// TS2305s in a downstream package. The whole of each module belongs here.
// ---------------------------------------------------------------------------

/*
 * The rail's axis vocabulary lives a level up, since it is an author surface on
 * the root barrel. Re-exported here so the spine's own consumers reach it the
 * same way they reach `commandDelayed`.
 */
export * from "../rail-tags";
export * from "./atmospheric-reckoning";
export * from "./body-derivations";
export * from "./capability-lock";
export * from "./celestial-facts";
export * from "./channel-error-warning";
export * from "./client";
export * from "./client-reading";
export * from "./client-timeline";
export * from "./clock";
export * from "./command-gate";
export * from "./comms-delay-reckoning";
export * from "./comms-journey";
export * from "./comms-path-geometry";
export * from "./comms-route";
export * from "./connection-error-warning";
export * from "./connectivity-history";
export * from "./context";
export * from "./contributed-channels";
export * from "./contribution-scope";
export * from "./contributions";
export * from "./control-frame-to-read-frame";
export * from "./core-reckoners";
export * from "./dashboard-item";
export * from "./delay-authority";
export * from "./delta-v-budget";
export * from "./dv-stage-resources";
export * from "./heartbeat-tracker";
export * from "./held-command-actions";
export * from "./impact-point";
export * from "./kepler";
export * from "./kepler-reckoning";
export * from "./lagrange";
export * from "./lifecycle";
export * from "./lock-scope";
export * from "./map-command";
export * from "./map-topic";
export * from "./mod-settings";
export * from "./never-reckonable";
export * from "./orbit-patches";
export * from "./orbit-trajectory";
export * from "./orbital-solve";
export * from "./own-craft-vantage";
export * from "./past-track";
export * from "./processorEvaluator";
export * from "./processors";
export * from "./propagation";
export * from "./rail-registry";
export * from "./reckoners";
export * from "./reference-frame";
export * from "./replay-recorder";
export * from "./replay-session";
export * from "./replay-session-controller";
export * from "./replay-transport";
export * from "./screen";
export * from "./settings-registry";
export * from "./settings-tabs";
export { assertSizeDelta } from "./size-delta";
export * from "./space-center-state";
export * from "./stream-status";
export * from "./subscribe-read";
export * from "./subscriber-identity";
export * from "./system-state";
export * from "./timeline-store";
export * from "./topic-ownership";
export * from "./unowned-warning";
export * from "./uplink-clients";
export * from "./uplink-health";
export * from "./use-action-input";
export * from "./use-body-states";
export * from "./use-command";
export * from "./use-data-sources";
export * from "./use-late-telemetry-subscribe";
export * from "./use-orbit-trajectory";
export * from "./use-processor";
export * from "./use-route-commands";
export * from "./use-selected-vantage";
export * from "./use-stream";
export * from "./use-stream-event";
export * from "./use-telemetry";
export * from "./use-transmissions";
export * from "./view-clock";
export * from "./wire-payloads";
