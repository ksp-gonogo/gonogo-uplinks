import {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import type { CommandGateReport } from "../__generated__/contract";
import { CORE_ERROR_CODES, FaultCode } from "../__generated__/error-codes";
import {
  COMMAND_LOST,
  COMMAND_REFUSED,
  classifyCommandRejection,
} from "../api/command-rejection";
import type {
  BoundCommand,
  BoundCommandOptions,
  CommandFailure,
  CommandFound,
  CommandLoss,
  CommandRefusal,
  CommandStatus,
  CommandUndelivered,
  CommandWarning,
  UseCommandOptions,
  ValueCommand,
} from "../api/types";
import {
  type CommsDelayLike,
  currentMode,
  type DelayMode,
  type InFlightCommand,
  liveOneWaySeconds,
  type PathConnectedDuring,
  type PendingEntry,
} from "../command-delay";
import type {
  AnyCommandReply,
  CommandArgs,
  CommandId,
  CommandReply,
} from "../commands";
import { commandRail } from "../commands";
import type { RailTags } from "../rail-tags";
import { railTagsForCommand } from "../rail-tags";
import { type Reading, readingOf } from "../reading";
import type { Value } from "../unit-system";
import { value } from "../unit-system/value";
import {
  arrivalUtAfter,
  arrivalUtOf,
  arrivesTooLate,
  LATE_ARRIVAL_DETAIL,
  LATE_ARRIVAL_ERROR_CODE,
} from "./arrival-deadline";
import { bindCommand, bindValue } from "./bound-command";
import {
  carriesCommand,
  centreCommandOutcomes,
  centreCommandRows,
  centreRowId,
  createCentreCommandMemory,
  dismissCentreOutcome,
} from "./centre-commands";
import {
  type CommandGateStatus,
  hasItemVerdict,
  mergeGateReports,
  selectCommandGate,
  toGateStatus,
} from "./command-gate";
import { openCommandGroup } from "./command-group";
import {
  type CommandOutcomeSet,
  commandOutcomesOf,
  NO_OUTCOMES,
} from "./command-outcomes";
import { JOURNEY_TOPIC, readJourney } from "./comms-journey";
import { ROUTE_TOPIC, readRouteRows } from "./comms-route";
import {
  type CommsLinkLike,
  ConnectivityHistory,
} from "./connectivity-history";
import {
  useTelemetryClientOptional,
  useTelemetryStoreOptional,
} from "./context";
import { CENTRE_DELAY_TOPIC, IDENTITY_TOPIC } from "./delay-authority";
import { useDelayAuthorityOptional } from "./delay-authority-context";
import {
  GATE_CHECK_COMMAND,
  GATE_CHECK_DEBOUNCE_MS,
  gateCheckKey,
  readGateCheckReply,
} from "./gate-check";
import { queueAsKnown } from "./known-holds";
import { CommandError } from "./lifecycle";
import { useClaimCapability } from "./lock-scope";
import { commandDelayed } from "./map-command";
import { useRailRegistry } from "./rail-registry";
import {
  type PendingUplinkQueueLike,
  resolveTracked,
  type TrackedConfirmation,
} from "./resolve-tracked";
import {
  readNextLossUt,
  type SendStatus,
  sendStatusFromRoutes,
} from "./send-status";
import {
  type CommandTarget,
  commandTargetOf,
  UPLINK_DELAYS_TOPIC,
} from "./uplink-delays";
import { useLatestValue, useStream } from "./use-stream";
import { useStreamConnected } from "./use-stream-connected";
import { META_VANTAGE } from "./vantage";

export type { UseCommandOptions };

/** Shared constant so `getSnapshot` returns a referentially stable value when
 * no command has been dispatched yet, a fresh object literal here would
 * make `useSyncExternalStore` believe the snapshot changes on every render
 * and loop forever. */
const IDLE: CommandStatus = { phase: "idle" };

/** Shared constant for the same reason as `IDLE` above, an empty `inFlight`
 * array must be referentially stable across renders that have nothing
 * in-flight, or every consumer re-renders needlessly. */
const NO_IN_FLIGHT: InFlightCommand[] = [];

const NO_SUBSCRIBE = () => () => {};

/** A fresh `[]` per render would re-render every consumer of a hook that has no warning, which is nearly all of them. */
const NO_WARNINGS: CommandWarning[] = [];

const MOD_FAULTS: ReadonlySet<string> = new Set(
  CORE_ERROR_CODES.filter((d) => d.kind === "fault" && d.origin === "mod").map(
    (d) => d.id,
  ),
);

/** Whether `code` is a fault the mod itself answers with, rather than one this client mints about its own link. */
function isModFault(code: string): boolean {
  return MOD_FAULTS.has(code);
}

/**
 * The delay, in seconds, below which a likely refusal stops the press at the
 * control. A verdict held for less than this is as good as the game's own
 * answer; one held for this long or longer is advice and the press is sent. Zero
 * delay counts as below it. Used by {@link useCommand}.
 *
 * @internal
 */
export const GATE_STOPS_PRESS_BELOW_SECONDS = 5;

/**
 * The dispatch handle: send the command, read its status, and see the commands
 * still in flight. Useful for showing the operator whether a command has been
 * sent, confirmed or refused. Returned by {@link useCommand} and taken by the
 * panel's delay rail controls. `Args` and `Reply` come from the generated command
 * map when the hook was given a known `CommandId`.
 *
 * `Reply` falls back to {@link AnyCommandReply}, the result envelope, rather than
 * to `unknown`: it is what a handle addressed by a computed string, or reached
 * through a prop declared bare, still knows about its own answer. `Args` has no
 * such floor and stays `unknown`, because there is nothing every command's
 * arguments have in common.
 *
 * `dangerouslySendWithoutInput` is declared method-style rather than as a property holding a function.
 * That is what makes a typed handle assignable to the bare `UseCommandResult` that
 * every delay-rail control takes. As a property, `strictFunctionTypes` checks the
 * parameter contravariantly and a typed handle would no longer be assignable.
 */
export interface UseCommandResult<Args = unknown, Reply = AnyCommandReply> {
  /**
   * Sends this command with no kit input drawing it, so nothing on screen shows
   * the operator that it was sent except the panel's delay rail. Useful for a
   * send that no kit input starts, such as a price query, a background sync or
   * typed text in a script terminal. Used by a script terminal and by the
   * maneuver planner when it removes a completed node.
   *
   * A control the operator presses takes the command through its `command` prop
   * instead: pass {@link with} or {@link toArgs} to a {@link Button}, a
   * {@link Slider} or another kit input, which then draws sent, refused and the
   * rest. A key or serial binding presses a {@link useCommandControl}.
   *
   * Resolves with the reply once the command has run. Rejects when the game
   * refuses it, and when no reply arrives by the expected time. A refusal or loss
   * from a call whose promise nobody awaits is still recorded in `refusals` or
   * `losses`.
   *
   * `opts.label` is a description of this dispatch to show the operator.
   * `opts.topic` addresses the command to one part or route on the craft, such
   * as one script terminal.
   */
  dangerouslySendWithoutInput(
    args?: Args,
    opts?: { label?: string; topic?: string },
  ): Promise<Reply>;
  /**
   * This command with its arguments set, for a kit input to send when the
   * operator presses it. Useful for naming what one control sends and what
   * happens around the press. Taken by the `command` prop of a kit input such
   * as a button. `args` may be a function, called at the press, for arguments
   * that change while the control waits.
   */
  with(
    args?: Args | (() => Args),
    options?: BoundCommandOptions<Args, Reply>,
  ): BoundCommand<Args, Reply>;
  /**
   * This command with a way to turn an input's value into its arguments, for
   * an input that sets a value. Useful for a toggle, a stepper or a field.
   * Taken by the `command` prop of a kit input that sets a value. Return
   * `undefined` where there is nothing to send.
   */
  toArgs<Value>(
    toArgs: (value: Value) => Args | undefined,
    options?: BoundCommandOptions<Args, Reply>,
  ): ValueCommand<Value, Args, Reply>;
  /** The state of the latest dispatch. See {@link CommandStatus}. */
  status: CommandStatus;
  /**
   * Every dispatch of this command still travelling or awaiting its reply,
   * from this handle and from anyone else at the same command centre: another
   * screen, or another widget on this one. An entry that is overdue or lost
   * stays until dismissed; one that has arrived on a connected path is dropped.
   */
  inFlight: InFlightCommand[];
  /**
   * What the mod said of each dispatch of this command that it accepted with a
   * warning, such as a continuous input it will drop where it would have to
   * wait: from this handle while it is in flight, and from any other screen or
   * widget at the same command centre while it is on the centre's queue.
   */
  warnings: CommandWarning[];
  /**
   * How the command travels, as its Uplink declared it. {@link CommandDelay}
   * chooses how to draw the command from these.
   */
  tags: RailTags;
  /**
   * The one-way delay from the command centre the command is sent from to the
   * command's own target: `0` for a never-delayed sim-meta command (`time.*`)
   * and `0` at the meta-vantage, both instant by construction. For a command to
   * the active craft it is that centre's delay to the craft; for one to
   * anything else (the home command, a lens, another craft) it is the delay the
   * mod reports for that target on `system.uplink.delays`.
   * `<CommandDelay>` renders nothing at 0.
   *
   * `null` wherever the delay to the target is not known: no measurable path,
   * a change of craft whose new delay has not arrived, a target named by an
   * argument, or no reading at all. It is never 0 for those, and never the
   * delay to some other target. A 0 says the command arrives now, which for a
   * target nothing can reach is the one wrong answer that reads as everything
   * being fine.
   */
  effectiveDelaySeconds: number | null;
  /**
   * The one-way delay as the reading it arrived in, for drawing a delay figure
   * through `<Unit>`: a `comms.delay` that has gone quiet draws held. `null`
   * for an instant command and wherever {@link effectiveDelaySeconds} is
   * `null`.
   */
  delayReading: Reading<Value<"s">> | null;
  /**
   * What the connection from the command centre to the vessel is doing, from
   * `comms.delay`: `"live"` under the staged threshold, `"staged"` above it,
   * `"no-path"` when nothing measurable is reported.
   *
   * `null` until a `comms.delay` reading arrives, which is not the same as
   * `"no-path"`. It does not stop {@link UseCommandResult.dangerouslySendWithoutInput}: a command sent with no path is
   * reported in {@link losses}.
   */
  delayMode: DelayMode | null;
  /**
   * What an order sent now would do, from the sending centre's `comms.route`
   * prediction: it goes at once, is held for a predicted contact and arrives at
   * a stated time, or has no route. An advisory, never a gate: it does not
   * decide whether {@link UseCommandResult.dangerouslySendWithoutInput} dispatches. `undefined` for an instant command
   * and while no route is known for the sending centre.
   */
  sendStatus: SendStatus | undefined;
  /**
   * Removes the dispatch with this id from `inFlight`, `refusals`, `losses`,
   * `founds`, `undelivered` or `failures`. Dismissing it anywhere, such as from
   * the panel's delay rail, removes it here too.
   */
  dismiss: (id: string) => void;
  /**
   * Whether this handle is registered with the panel's command rail, which then
   * speaks and draws its outcomes. `false` for a handle made with `rail: false`
   * or with no rail above it. A control that would otherwise stay quiet beside
   * a rail reads it, so an outcome is never left with nobody to say it.
   */
  railed: boolean;
  /**
   * Whether a blocked gate stops the press. True for a command the mod declares
   * instant, and for a delayed command whose verdict is held for less than
   * {@link GATE_STOPS_PRESS_BELOW_SECONDS} seconds, since a verdict that fresh is
   * as good as the game's answer. At that limit or above, or when the delay is
   * not known, a blocked gate is advice: the command is sent and the game decides on
   * arrival.
   */
  gateStopsPress?: boolean;
  /** Dispatches the game refused, newest last, each with its reason. */
  refusals: CommandRefusal[];
  /**
   * Dispatches that got no reply, newest last. The command may still have run,
   * so sending it again may run it twice.
   */
  losses: CommandLoss[];
  /**
   * Dispatches that were reported lost and then answered after all, newest last.
   * An entry here has left `losses`. The command ran, so sending it again would
   * run it twice. See `CommandFoundOutcome` for what each outcome means.
   */
  founds: CommandFound[];
  /**
   * Dispatches that never left the operator's machine, newest last: the
   * connection stayed down until the transport gave up. An entry here has left
   * `losses`. The command did not run, so it is safe to send again once there
   * is a connection.
   */
  undelivered: CommandUndelivered[];
  /**
   * The stream to the mod is down, so a press sends nothing. A control reads it
   * to draw its stream-down state: dimmed, with a dotted edge.
   */
  streamDown: boolean;
  /**
   * Every dispatch from this hook the mod answered with a fault rather than a
   * reply, newest last, until the operator clears it with the same `dismiss`:
   * it expired or was cancelled on its way, a continuous input was dropped
   * where it would have waited, or a game load undid it. The mod said what
   * became of it, so it is neither a loss, which knows nothing, nor a refusal,
   * which is the game's verdict on the command. None of them ran.
   */
  failures: CommandFailure[];
  /**
   * What the mod says about this command before anyone presses anything: the
   * standing verdict of its declared gates, off `system.uplink.gates`.
   *
   * `undefined` when the command declares no gates, or the stream is not
   * carrying the channel, or nothing is connected. All three mean the same
   * thing to a control (nothing is known in advance), which is where every
   * control was before the channel existed, so a control that ignores this
   * field behaves exactly as it did.
   *
   * A `blocked` gate on a delayed command is advice that the game is likely to
   * refuse it: the control says why and the command is sent when pressed, for
   * the game to decide on arrival. On an instant command, which has no arrival,
   * `dangerouslySendWithoutInput` refuses locally with the gate's own reason
   * and dispatches nothing.
   */
  gate?: CommandGateStatus;
  /**
   * The standing verdict for a call with these arguments: the verdict the mod
   * published for the item they name, when the gate depends on which item that
   * is, else {@link gate}.
   *
   * A control that sends arguments draws itself from this rather than from
   * `gate`, so the one facility the career cannot afford goes dark while the
   * rest stay live. For an instant command `dangerouslySendWithoutInput`
   * refuses locally on the same answer. For a delayed command that would
   * reach the vessel at or after the UT it acts at, the answer is a blocked
   * verdict of advice only.
   */
  // A method rather than a function-valued property, so a typed handle stays assignable to the bare one.
  gateFor(args: Args): CommandGateStatus | undefined;
  /**
   * Asks the mod what this command's gate says about a call with these
   * arguments, from this hook's command centre, without sending it. Answers
   * what {@link gate} and {@link gateFor} cannot: a verdict that depends on a
   * choice the operator is making (a launch site, a time warp rate) or on the
   * centre they send from.
   *
   * Call it when the choice changes. It waits for a pause before asking, so a
   * form can call it on every keystroke and the mod is asked once about the
   * last value. The answer lands in {@link gateFor} for those same arguments
   * and for nothing else, so a verdict never outlives the choice it was about;
   * until it arrives, and whenever the mod cannot answer, `gateFor` says what it
   * said before. A `blocked` answer is drawn like any other gate, dark with the
   * mod's own reason. The dispatch remains the authority.
   *
   * Resolves with the verdict, or `undefined` when a later call replaced this
   * one or the mod could not answer.
   *
   * Every handle `useCommand` returns carries it. It is optional so that a
   * handle written by hand, such as a test double, need not supply one.
   */
  check?(args?: Args): Promise<CommandGateStatus | undefined>;
}

/**
 * The handle for a named command, with both its argument type and its reply type
 * resolved out of the generated command map. Useful for typing a prop, a field or
 * a helper that passes a dispatch handle around. `useCommand("...")` already
 * returns this. It takes a union of command ids as readily as one id, so a family
 * of writes that answer alike can be declared once:
 * `UseCommandResultFor<"vessel.control.setSas" | "vessel.control.setRcs">`.
 *
 * An Uplink reaches this the same way it reaches `useCommand`, off the published
 * SDK root, and its own augmented `CommandArgsMap` keys work here with nothing
 * extra registered.
 *
 * It is not named `CommandHandle`, which is already a different type on
 * `@ksp-gonogo/ui-kit`'s delay rail, imported in the same file by an Uplink.
 */
export type UseCommandResultFor<Command extends CommandId> = UseCommandResult<
  CommandArgs<Command>,
  CommandReply<Command>
>;

/**
 * Sends `command` to the mod through the nearest `TelemetryProvider` and reflects
 * its progress (`idle`, `in-flight`, then `confirmed` or `failed`). Useful for a
 * control that sends a command and shows the operator the delay before it takes
 * effect. Used by command widgets, and its handle is what {@link Button}
 * takes.
 *
 * The hook also holds the set of dispatches still in flight (`inFlight`), so a
 * command widget gets delay state from the same hook it already calls to dispatch,
 * with no separate opt-in. `dangerouslySendWithoutInput` can be called more than once; any status change
 * for the active request re-renders the caller. `inFlight` accumulates every
 * pending dispatch, not only the latest: see `UseCommandResult.inFlight`.
 *
 * A known `CommandId` resolves its args and its reply out of the generated command
 * map; anything else, such as a computed id or a dynamic per-subject command, keeps
 * the untyped handle. See the `useCommand` re-export in `../api` for the author's
 * account of that split.
 */
export function useCommand<Command extends CommandId>(
  command: Command,
  options?: UseCommandOptions<CommandArgs<Command>>,
): UseCommandResult<CommandArgs<Command>, CommandReply<Command>>;
export function useCommand<Args = unknown, Reply = AnyCommandReply>(
  command: string,
  options?: UseCommandOptions<Args>,
): UseCommandResult<Args, Reply>;
export function useCommand(
  command: string,
  options?: UseCommandOptions,
): UseCommandResult {
  /*
   * The mod's own declaration decides whether a command is about the program
   * rather than a craft, so a widget has no vantage to choose for one.
   */
  const vantage = commandRail(command)?.meta ? META_VANTAGE : options?.vantage;
  // Read through a ref: the caller passes a fresh check each render, over that render's telemetry.
  const confirmedByRef = useRef(options?.confirmedBy);
  confirmedByRef.current = options?.confirmedBy;
  useClaimCapability("command", command);
  // Degrade gracefully with no `TelemetryProvider` mounted (disconnected).
  // Status stays IDLE and `send` is a no-op: you can't dispatch a command with
  // no link, and the hook must not throw just because the dashboard rendered
  // before a connection exists.
  const client = useTelemetryClientOptional();
  const streamDown = !useStreamConnected();
  const [requestId, setRequestId] = useState<string | null>(null);

  const subscribe = useCallback(
    (onStoreChange: () => void) =>
      client ? client.subscribeStore(onStoreChange) : () => {},
    [client],
  );

  /*
   * The client drops the record of an answered command once a control stream
   * has sent enough newer ones, after which `getCommand` reads `idle` for an id
   * this hook did send. The last answer seen for the id stands in for it.
   */
  const lastSeenRef = useRef<{
    client: object;
    id: string;
    status: CommandStatus;
  } | null>(null);
  const getSnapshot = useCallback(() => {
    if (!client || !requestId) return IDLE;
    const current = client.getCommand(requestId);
    if (current.phase !== "idle") {
      lastSeenRef.current = { client, id: requestId, status: current };
      return current;
    }
    const last = lastSeenRef.current;
    return last?.client === client && last.id === requestId
      ? last.status
      : current;
  }, [client, requestId]);

  const status = useSyncExternalStore(subscribe, getSnapshot);
  // Re-reads the rows of commands a carried client dispatched, which `status` does not follow.
  useSyncExternalStore(subscribe, () => client?.carriedCommandsRevision() ?? 0);

  // --- inFlight bookkeeping: this hook's OWN dispatches, retained past a
  // queue age-out (Task 4 / Task 4a of the delayed-command-ux plan). ---
  const [dispatchedIds, setDispatchedIds] = useState<string[]>([]);
  // Ids the operator has cleared from `inFlight` (a dead command's manual out).
  // Pruned once the id leaves the underlying set anyway, so it can't grow
  // unbounded over a long session.
  const [dismissedIds, setDismissedIds] = useState<string[]>([]);
  /*
   * Refusals, losses, founds, undelivered and failures are held on the client,
   * keyed by command id, and accumulated on each dispatch promise's own
   * rejection rather than derived from `status`: status only tracks the LATEST
   * requestId, and these outcomes are terminal so nothing could re-derive
   * them. Held there, an outcome outlives the widget that sent the command.
   */
  const outcomeStore = useMemo(
    () => (client ? commandOutcomesOf(client) : null),
    [client],
  );
  const { refusals, losses, founds, undelivered, failures } =
    useSyncExternalStore(
      outcomeStore?.subscribe ?? NO_SUBSCRIBE,
      useCallback(
        () => outcomeStore?.get(command) ?? NO_OUTCOMES,
        [outcomeStore, command],
      ),
    );
  const editOutcomes = useCallback(
    <Key extends keyof CommandOutcomeSet>(
      key: Key,
      update: (prev: CommandOutcomeSet[Key]) => CommandOutcomeSet[Key],
    ) => outcomeStore?.edit(command, key, update),
    [outcomeStore, command],
  );
  const setRefusals = useCallback(
    (update: (prev: CommandRefusal[]) => CommandRefusal[]) =>
      editOutcomes("refusals", update),
    [editOutcomes],
  );
  const setLosses = useCallback(
    (update: (prev: CommandLoss[]) => CommandLoss[]) =>
      editOutcomes("losses", update),
    [editOutcomes],
  );
  const setUndelivered = useCallback(
    (update: (prev: CommandUndelivered[]) => CommandUndelivered[]) =>
      editOutcomes("undelivered", update),
    [editOutcomes],
  );
  const setFailures = useCallback(
    (update: (prev: CommandFailure[]) => CommandFailure[]) =>
      editOutcomes("failures", update),
    [editOutcomes],
  );
  const entryCacheRef = useRef<Map<string, PendingEntry>>(new Map());
  const firstSeenAtRef = useRef<Map<string, number>>(new Map());
  // Each tracked dispatch's args, for the caller's check of whether the telemetry shows them.
  const argsRef = useRef<Map<string, unknown>>(new Map());
  const labelsRef = useRef<Map<string, string>>(new Map());
  // Every request id this hook sent whose entry may still be queued, so its own entry never reads as someone else's.
  const ownIdsRef = useRef<Set<string>>(new Set());
  const centreMemoryRef = useRef(createCentreCommandMemory());
  // When this client first saw each ran dispatch's reply, as a UT.
  const answeredAtRef = useRef<Map<string, number>>(new Map());
  // Dispatches whose promise resolved, which still says they ran once the client has dropped the record.
  const ranRef = useRef<Set<string>>(new Set());
  const connectivityHistoryRef = useRef<ConnectivityHistory>(
    new ConnectivityHistory(),
  );

  const sentQueue = useLatestValue<PendingUplinkQueueLike>(
    "system.uplink.pending",
  );
  const journeyPayload = useLatestValue<unknown>(JOURNEY_TOPIC);
  // The queue as the centre knows it: a hold only once the relay's report of it has come home.
  const queue = useMemo(
    () => queueAsKnown(sentQueue, readJourney(journeyPayload)),
    [sentQueue, journeyPayload],
  );
  // Memoised on the report identity so a control does not re-render on every
  // unrelated render of its widget. The report is republished whole at the
  // engine's gate cadence, and every `useCommand` in the tree reads the same one.
  const liveGates = useLatestValue<CommandGateReport>("system.uplink.gates");
  const homeGates = useLatestValue<CommandGateReport>(
    "system.uplink.gates.home",
  );
  const craftGates = useLatestValue<CommandGateReport>(
    "system.uplink.gates.craft",
  );
  const gateReport = useMemo(
    () => mergeGateReports(liveGates, homeGates, craftGates),
    [liveGates, homeGates, craftGates],
  );
  const gate = useMemo(
    () => selectCommandGate(gateReport, command),
    [gateReport, command],
  );
  // Read by `send`, which is keyed on the command alone and so cannot close over the render's report.
  const gateReportRef = useRef(gateReport);
  gateReportRef.current = gateReport;
  const [checked, setChecked] = useState<
    | {
        key: string;
        status: CommandGateStatus;
        report: CommandGateReport | undefined;
      }
    | undefined
  >();
  const checkTimerRef = useRef<ReturnType<typeof setTimeout> | undefined>();
  const checkSeqRef = useRef(0);
  const checkSupersededRef = useRef<(() => void) | undefined>();
  const gateFor = useCallback(
    (args: unknown) => {
      const published = selectCommandGate(gateReport, command, args);
      const answered =
        checked && checked.key === gateCheckKey(args)
          ? checked.status
          : undefined;
      /*
       * A refusal about an item the engine also publishes holds only until the
       * engine publishes again: the state it was about (a pad, a vehicle)
       * changes with no change of arguments, and the report that follows is the
       * engine's current word on that item. A refusal about arguments the report
       * does not name has no other source, and stands.
       */
      const superseded =
        checked?.report !== gateReport &&
        hasItemVerdict(gateReport, command, args);
      const verdict =
        answered?.blocked && !superseded ? answered : (published ?? answered);
      if (verdict?.blocked) return verdict;
      // Advice only: the command still goes, and the game decides on arrival.
      const clock = storeRef.current?.clock;
      const arrivalUt = !clock
        ? undefined
        : isInstantRef.current || toActiveVesselRef.current
          ? arrivalUtOf(clock, !isInstantRef.current)
          : arrivalUtAfter(clock, effectiveDelayRef.current);
      return arrivesTooLate(command, args, arrivalUt)
        ? {
            command,
            blocked: true,
            undetermined: false,
            errorCode: LATE_ARRIVAL_ERROR_CODE,
            detail: LATE_ARRIVAL_DETAIL,
          }
        : verdict;
    },
    [gateReport, command, checked],
  );
  const check = useCallback(
    (args?: unknown): Promise<CommandGateStatus | undefined> => {
      checkSeqRef.current += 1;
      const seq = checkSeqRef.current;
      clearTimeout(checkTimerRef.current);
      checkSupersededRef.current?.();
      return new Promise((resolve) => {
        if (!client) {
          resolve(undefined);
          return;
        }
        checkSupersededRef.current = () => resolve(undefined);
        checkTimerRef.current = setTimeout(() => {
          checkSupersededRef.current = undefined;
          const { result } = client.dispatch(
            GATE_CHECK_COMMAND,
            { command, args: args ?? {} },
            undefined,
            undefined,
            vantage,
          );
          result
            .then(readGateCheckReply, () => undefined)
            .then((verdict) => {
              if (seq !== checkSeqRef.current) {
                resolve(undefined);
                return;
              }
              const status = verdict && toGateStatus(verdict, command);
              setChecked(
                status
                  ? {
                      key: gateCheckKey(args),
                      status,
                      report: gateReportRef.current,
                    }
                  : undefined,
              );
              resolve(status);
            });
        }, GATE_CHECK_DEBOUNCE_MS);
      });
    },
    [client, command, vantage],
  );
  // An answer is about one command from one centre, and a pending ask is about the same.
  // biome-ignore lint/correctness/useExhaustiveDependencies: the identity of the asker is the trigger
  useEffect(() => {
    setChecked(undefined);
    return () => {
      checkSeqRef.current += 1;
      clearTimeout(checkTimerRef.current);
      checkSupersededRef.current?.();
      checkSupersededRef.current = undefined;
    };
  }, [client, command, vantage]);
  /*
   * Whether a tracked dispatch has been settled by something other than
   * silence, which is what separates a command that arrived from one nobody
   * ever heard. Read off the client's own record for the request: `in-flight`
   * and `lost` are the absence of an answer, and every other phase is one,
   * a refusal, a late reply and a command that never left included. An `idle`
   * record for an id this hook sent is one the client dropped after it was
   * answered, since only answered records are dropped.
   */
  const acknowledged = useCallback(
    (id: string) => {
      const phase = client?.getCommand(id).phase;
      return phase !== undefined && phase !== "in-flight" && phase !== "lost";
    },
    [client],
  );
  /*
   * A primitive fingerprint of those phases, read through the same store
   * subscription, purely so an answer landing for an OLDER dispatch re-renders
   * this hook. `status`'s own snapshot tracks only the latest requestId, so
   * `useSyncExternalStore` bails out of the re-render when the one before it
   * settles, and the prune below would then run on a stale reading.
   */
  const judgedLost = useCallback(
    (id: string) => client?.getCommand(id).phase === "lost",
    [client],
  );
  const confirmation = useCallback(
    (id: string): TrackedConfirmation | undefined => {
      const check = confirmedByRef.current;
      if (!check || !argsRef.current.has(id)) return undefined;
      const status = client?.getCommand(id);
      const ran =
        status?.phase === "confirmed" ||
        (status?.phase === "found" && status.outcome === "ran") ||
        ranRef.current.has(id);
      if (!ran) return undefined;
      let answeredAtUt = answeredAtRef.current.get(id);
      if (answeredAtUt === undefined) {
        answeredAtUt = nowUtRef.current;
        answeredAtRef.current.set(id, answeredAtUt);
      }
      return { confirmed: check(argsRef.current.get(id)), answeredAtUt };
    },
    [client],
  );
  const ackPhases = useSyncExternalStore(
    subscribe,
    useCallback(
      () =>
        dispatchedIds
          .map((id) => {
            const status = client?.getCommand(id);
            if (status?.phase !== "in-flight") return status?.phase ?? "idle";
            return `${status.phase}${status.accepted ? "+" : ""}${status.warning ? "!" : ""}`;
          })
          .join(","),
      [client, dispatchedIds],
    ),
  );

  const connectivity = useLatestValue<CommsLinkLike>("comms.link");
  const commsDelay = useLatestValue<CommsDelayLike>("comms.delay");
  const commsDelayReading = useStream<CommsDelayLike>("comms.delay");
  const uplinkDelays = useLatestValue<unknown>(UPLINK_DELAYS_TOPIC);
  const uplinkDelaysReading = useStream<unknown>(UPLINK_DELAYS_TOPIC);
  const delayAuthority = useDelayAuthorityOptional();
  // Read only so a change of centre row or of craft re-renders the figure the authority holds.
  useLatestValue<unknown>(CENTRE_DELAY_TOPIC);
  useLatestValue<unknown>(IDENTITY_TOPIC);

  /*
   * The delay display + effective delay this command hands to `<CommandDelay>`.
   * `tags` is a pure function of the command id: the three axes as the
   * command's owning assembly declared them.
   *
   * `effectiveDelaySeconds` is 0 for a never-delayed sim-meta command
   * (`time.*`) and for a meta-vantage dispatch, both of which are instant
   * server-side and so are knowably zero. Otherwise it is the delay to the
   * command's own target, which only the mod can place: `system.uplink.delays`
   * says whether that is the active craft, timed by the centre's own delay to
   * it, or something else, with the figure the centre knows for it.
   *
   * A zero is NOT the fallback for an unknown delay, and nor is the active
   * craft's delay. `comms.delay.oneWaySeconds` splits "no path home" from "the
   * delay feature is off and the craft is connected" by that value alone
   * (`Sitrep.Contract/Comms.cs:CommsDelay`), and collapsing the first onto the
   * second clocked a craft nothing could reach as if it were on the LAN.
   */
  const tags = railTagsForCommand(command);
  const isInstant = !commandDelayed(command) || vantage === META_VANTAGE;
  const isInstantRef = useRef(isInstant);
  isInstantRef.current = isInstant;
  /*
   * Whether the verdict this handle holds is live. The mod publishes a delayed
   * command's verdict after its delay, whichever vantage the press is sent from,
   * so a command sent from the meta-vantage (no delay of its own) still reads an
   * old verdict and the press is advised rather than stopped.
   */
  const declaredInstant = !commandDelayed(command);
  const verdictTarget = declaredInstant
    ? null
    : commandTargetOf(uplinkDelays, command, undefined);
  const verdictDelaySeconds = delayToTarget(
    declaredInstant,
    verdictTarget,
    () =>
      delayAuthority
        ? delayAuthority.commandDelaySeconds(undefined)
        : liveOneWaySeconds(commsDelay),
  );
  const gateStopsPress =
    verdictDelaySeconds !== null &&
    verdictDelaySeconds < GATE_STOPS_PRESS_BELOW_SECONDS;
  const gateStopsPressRef = useRef(gateStopsPress);
  gateStopsPressRef.current = gateStopsPress;
  const sentFrom =
    vantage === undefined || vantage === "" ? undefined : vantage;
  const target = isInstant
    ? null
    : commandTargetOf(uplinkDelays, command, sentFrom);
  const toActiveVessel = target?.kind === "active-vessel";
  const toActiveVesselRef = useRef(toActiveVessel);
  toActiveVesselRef.current = toActiveVessel;
  const effectiveDelaySeconds = delayToTarget(isInstant, target, () =>
    delayAuthority
      ? delayAuthority.commandDelaySeconds(sentFrom)
      : liveOneWaySeconds(commsDelay),
  );
  const effectiveDelayRef = useRef(effectiveDelaySeconds);
  effectiveDelayRef.current = effectiveDelaySeconds;
  let delayReading: Reading<Value<"s">> | null = null;
  if (!isInstant && effectiveDelaySeconds !== null) {
    const figure = () => value("s", Math.max(0, effectiveDelaySeconds));
    if (
      toActiveVessel &&
      (commsDelayReading.state === "observed" ||
        commsDelayReading.state === "held")
    ) {
      delayReading = readingOf(commsDelayReading, figure);
    }
    if (
      !toActiveVessel &&
      (uplinkDelaysReading.state === "observed" ||
        uplinkDelaysReading.state === "held")
    ) {
      delayReading = readingOf(uplinkDelaysReading, figure);
    }
  }
  /*
   * The three-valued answer the package already computes, passed through rather
   * than re-derived, so a widget can SAY "no path" instead of inferring it from
   * a number that cannot express it. `null` is the fourth state and the one
   * `DelayMode` deliberately has no token for: nothing has been read, which is
   * not the same claim as "there is no path" and must not be dressed up as one.
   * A command to anything but the active craft has a mode only once its delay
   * is known.
   */
  const delayMode = toActiveVessel
    ? commsDelay
      ? currentMode(commsDelay)
      : null
    : target?.kind === "elsewhere" && target.seconds !== null
      ? currentMode({ oneWaySeconds: value("s", target.seconds) })
      : null;
  // A synchronous, NON-subscribing read of the same undelayed clock
  // `useUtNow` tracks (`ViewClock.utNowEstimate()`): deliberately NOT
  // `useUtNow()` itself, which subscribes to a real-wall-clock ~16ms tick
  // for the component's whole mounted lifetime. That per-frame subscription
  // is unnecessary here: `nowUt` only needs to be fresh AT the renders this
  // hook already causes (a queue/connectivity change, a status transition),
  // and the visual per-second countdown smoothing is `InFlightList`'s own
  // `useCountdown` value-hook's job, not this hook's. Avoiding the
  // independent real-timer subscription also avoids a real hazard it
  // otherwise creates: under load, that timer can fire outside any test's
  // `act()` boundary for every mounted `useCommand` caller, regardless of
  // whether the test ever touches `inFlight`.
  const store = useTelemetryStoreOptional();
  const nowUt = store?.clock.utNowEstimate() ?? 0;
  // Before any sample the estimate is a stand-in 0, which is no time to date an outcome against.
  const clockSampled =
    store !== undefined && Number.isFinite(store.clock.confirmedEdgeUt());
  const routePayload = useLatestValue<unknown>(ROUTE_TOPIC);
  const nextLossPayload = useLatestValue<unknown>("comms.nextLoss");
  const sendStatus = isInstant
    ? undefined
    : sendStatusFromRoutes(
        readRouteRows(routePayload),
        nowUt,
        vantage,
        readNextLossUt(nextLossPayload),
      );

  if (typeof connectivity?.connected === "boolean") {
    connectivityHistoryRef.current.record(nowUt, connectivity.connected);
  }

  const pathConnectedDuring: PathConnectedDuring = useCallback(
    (fromUt: number, toUt: number) =>
      connectivityHistoryRef.current.connectedDuring(fromUt, toUt),
    [],
  );

  // Latest `nowUt` by ref, read from `send` below. That `send` is a stable
  // `useCallback` keyed on `[client, command]` alone, so it cannot close over
  // the freshly-computed render-scope value.
  const nowUtRef = useRef(nowUt);
  nowUtRef.current = nowUt;
  const nowWall = store?.clock.wallNow() ?? performance.now() / 1000;
  const nowWallRef = useRef(nowWall);
  nowWallRef.current = nowWall;
  // The clock and the command's delay, for `send` to judge arrival at the moment it is called.
  const storeRef = useRef(store);
  storeRef.current = store;

  /*
   * Every handle is registered with the nearest command rail, which draws its
   * outcomes. A dispatch with no rail above it would be seen by nobody, so a
   * dev build throws on the first one; `rail: false` is for a hook that draws
   * the outcome itself.
   */
  const rail = useRailRegistry();
  const railed = options?.rail !== false;
  const railId = useId();
  const railVerifiedRef = useRef(false);
  const [dispatchTick, setDispatchTick] = useState(0);

  useEffect(() => {
    if (process.env.NODE_ENV === "production") return;
    if (dispatchTick === 0 || railVerifiedRef.current) return;
    if (railed && !rail) {
      throw new Error(
        `useCommand(${JSON.stringify(command)}).dangerouslySendWithoutInput() dispatched a command ` +
          "with no command rail mounted above it, so its outcome would reach " +
          "nobody. Mount the widget inside a DelayRailProvider: the dashboard, " +
          "renderWidget and the test render all do.",
      );
    }
    railVerifiedRef.current = true;
  }, [dispatchTick, command, rail, railed]);

  let inFlight = NO_IN_FLIGHT;
  if (dispatchedIds.length > 0) {
    const computed: InFlightCommand[] = [];
    for (const id of dispatchedIds) {
      const resolution = resolveTracked(
        id,
        queue,
        entryCacheRef.current,
        firstSeenAtRef.current,
        nowUt,
        nowWall,
        pathConnectedDuring,
        acknowledged,
        judgedLost,
        confirmation,
      );
      if (resolution.kind === "classified") {
        const sentWith = argsRef.current.get(id);
        computed.push(
          sentWith === undefined
            ? resolution.item
            : { ...resolution.item, args: sentWith },
        );
      }
    }
    // Hide dismissed commands. The underlying `computed` set still drives the
    // dismissed-id prune below, so a dismissed id is dropped from the set once
    // it leaves `computed` on its own.
    const visible =
      dismissedIds.length > 0
        ? computed.filter((c) => !dismissedIds.includes(c.id))
        : computed;
    if (visible.length > 0) inFlight = visible;
  }
  const centreRows = isInstant
    ? NO_IN_FLIGHT
    : centreCommandRows({
        command,
        queue,
        own: ownIdsRef.current,
        memory: centreMemoryRef.current,
        nowUt,
        pathConnectedDuring,
        statusOf: (id) => client?.getCarriedCommand(id),
      });
  if (centreRows.length > 0) {
    inFlight = [...inFlight, ...centreRows].sort(
      (a, b) => a.dispatchedAt - b.dispatchedAt,
    );
  }

  let warnings = NO_WARNINGS;
  for (const id of dispatchedIds) {
    const status = client?.getCommand(id);
    if (status?.phase !== "in-flight" || !status.warning) continue;
    if (warnings === NO_WARNINGS) warnings = [];
    warnings.push({
      id,
      command,
      label: labelsRef.current.get(id) ?? "",
      warning: status.warning,
    });
  }
  /*
   * The centre writes the same warning on the command's queue entry, so every
   * screen at the centre shows it, and the sender keeps one copy of its own.
   */
  for (const entry of queue?.pending ?? []) {
    if (!carriesCommand(entry, command) || !entry.warning) continue;
    const id = centreRowId(entry);
    if (warnings.some((w) => w.id === id)) continue;
    if (warnings === NO_WARNINGS) warnings = [];
    warnings.push({ id, command, label: entry.label, warning: entry.warning });
  }

  /*
   * What became of another screen's command, as the centre reports it, listed
   * with this hook's own refusals and failures so every screen says the same.
   */
  const centreOutcomes = isInstant
    ? null
    : centreCommandOutcomes({
        command,
        queue,
        own: ownIdsRef.current,
        memory: centreMemoryRef.current,
        nowUt: clockSampled ? nowUt : null,
        epoch: store?.clock.getEpoch() ?? 0,
      });
  const allRefusals =
    centreOutcomes && centreOutcomes.refusals.length > 0
      ? [...refusals, ...centreOutcomes.refusals]
      : refusals;
  const allFailures =
    centreOutcomes && centreOutcomes.failures.length > 0
      ? [...failures, ...centreOutcomes.failures]
      : failures;
  const allFounds =
    centreOutcomes && centreOutcomes.founds.length > 0
      ? [...founds, ...centreOutcomes.founds]
      : founds;

  // Prune tracked ids once resolved/expired, so `dispatchedIds` (and the
  // caches it drives) don't grow forever over a long session. Separate from
  // the render-time `inFlight` computation above so a resolved id
  // disappears from the rendered set immediately (this render) even before
  // the prune effect commits the smaller tracked-id array (next render).
  //
  // Deliberately NOT keyed on `nowUt`: reading `store.clock.utNowEstimate()`
  // synchronously (see above) means `nowUt` is a fresh value on literally
  // EVERY render, for ANY reason, keying this effect on it would refire
  // the prune on every single render of every mounted `useCommand` caller,
  // whether or not anything relevant changed. The render-time `inFlight`
  // computation above already hides a resolved entry immediately using the
  // current `nowUt`, regardless of whether this effect has caught up yet,
  // this effect only needs to run when something that could change a
  // resolution actually changed (`queue`, or the connectivity history via
  // `pathConnectedDuring`'s identity), reading the latest `nowUt` off the
  // ref at that point.
  // biome-ignore lint/correctness/useExhaustiveDependencies: ackPhases is a re-run trigger, not a body input
  useEffect(() => {
    /*
     * A dismissed dispatch is dropped outright. A command classified lost or
     * overdue never resolves on its own, so one that was only hidden would be
     * resolved again on every render for the rest of the session.
     */
    const dismissed = dismissedIds;
    setDispatchedIds((prev) => {
      const keep = prev.filter((id) => {
        if (dismissed.includes(id)) return false;
        const resolution = resolveTracked(
          id,
          queue,
          entryCacheRef.current,
          firstSeenAtRef.current,
          nowUtRef.current,
          nowWallRef.current,
          pathConnectedDuring,
          acknowledged,
          judgedLost,
          confirmation,
        );
        return (
          resolution.kind === "classified" || resolution.kind === "waiting"
        );
      });
      return keep.length === prev.length ? prev : keep;
    });
    setDismissedIds((prev) => {
      if (prev.length === 0) return prev;
      const keep = prev.filter((id) => !dismissed.includes(id));
      return keep.length === prev.length ? prev : keep;
    });
    /*
     * `ackPhases` is a re-run TRIGGER, not a value read in the body: a response
     * landing for a tracked dispatch changes what resolves, exactly as a queue
     * snapshot does.
     */
  }, [
    queue,
    pathConnectedDuring,
    acknowledged,
    judgedLost,
    confirmation,
    ackPhases,
    dismissedIds,
  ]);

  /*
   * Forget what was kept for a dispatch once it is no longer tracked. Only an
   * id that was tracked on the last commit is dropped: a dispatch writes its
   * first-seen time before its id reaches `dispatchedIds`, so an id that has
   * never been in the list is one that is about to be.
   */
  useEffect(() => {
    const own = ownIdsRef.current;
    if (own.size === 0) return;
    const queued = new Set<string>();
    for (const entry of queue?.pending ?? []) {
      queued.add(entry.clientRequestId);
      for (const member of entry.members ?? []) queued.add(member);
    }
    // A settled entry is still this hook's own while the centre lists it.
    for (const entry of queue?.settled ?? []) queued.add(entry.clientRequestId);
    for (const id of own) {
      if (!queued.has(id) && !dispatchedIds.includes(id)) own.delete(id);
    }
  }, [queue, dispatchedIds]);

  const trackedBeforeRef = useRef<readonly string[]>(dispatchedIds);
  useEffect(() => {
    for (const id of trackedBeforeRef.current) {
      if (dispatchedIds.includes(id)) continue;
      entryCacheRef.current.delete(id);
      firstSeenAtRef.current.delete(id);
      argsRef.current.delete(id);
      labelsRef.current.delete(id);
      answeredAtRef.current.delete(id);
      ranRef.current.delete(id);
    }
    trackedBeforeRef.current = dispatchedIds;
  }, [dispatchedIds]);

  const dismiss = useCallback(
    (id: string) => {
      centreMemoryRef.current.dismissed.add(id);
      dismissCentreOutcome(centreMemoryRef.current, id);
      setDismissedIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
      /*
       * An outcome is dropped outright rather than hidden behind `dismissedIds`.
       * That set is pruned once an id leaves the underlying in-flight set, which
       * a settled dispatch does as soon as its grace window closes, and a
       * dismissed outcome that came back would read as the command answering
       * twice.
       */
      outcomeStore?.dismiss(command, id);
    },
    [outcomeStore, command],
  );

  /*
   * Everything a dispatch needs once it has a request id: the tracking, and
   * the handling of its rejection. Run straight away for a send of its own,
   * by `sendTogether` when the group it joined has gone, and for a command an
   * earlier page of this screen sent and is still waiting on.
   */
  const trackDispatch = useCallback(
    (
      newRequestId: string,
      result: Promise<unknown>,
      args: unknown,
      label: string,
    ): Promise<AnyCommandReply> => {
      setRequestId(newRequestId);
      firstSeenAtRef.current.set(
        newRequestId,
        storeRef.current?.clock.wallNow() ?? performance.now() / 1000,
      );
      argsRef.current.set(newRequestId, args);
      labelsRef.current.set(newRequestId, label);
      ownIdsRef.current.add(newRequestId);
      result.then(
        () => {
          ranRef.current.add(newRequestId);
          outcomeStore?.supersedeFailures(command);
        },
        () => undefined,
      );
      setDispatchedIds((prev) => [...prev, newRequestId]);
      // Schedule the dev-only rail check on the first unverified dispatch (see the effect above).
      if (process.env.NODE_ENV !== "production" && !railVerifiedRef.current) {
        setDispatchTick((tick) => tick + 1);
      }
      // Mark the dispatch's own rejection as HANDLED without consuming it.
      //
      // Now that a dropped command rejects, a `void`ed dispatch would raise an unhandled rejection on every lost command.
      //
      // Attaching a no-op handler here marks `result` handled while leaving the
      // rejection fully observable to anyone who awaits it: `ManeuverPlanner`'s
      // `try/catch` around `dispatchPlanBurns` still sees the throw. Swallowing it
      // instead (returning a never-rejecting promise) would have been the wrong fix,
      // because that caller is the one that NEEDS the rejection.
      result.catch((err: unknown) => {
        // ONLY a refusal. `lost` decided nothing and the command may well have
        // executed; `failed` is the machinery, which the queue and the link
        // indicators already speak for. Calling either of them a refusal would
        // be a confident wrong answer about what the game said.
        const rejection = classifyCommandRejection(err);
        // No answer arrived. Kept because the queue CANNOT show this one: a
        // comms-loss drop is refused a `PendingUplink` before it is dispatched,
        // so `inFlight` is empty and there is nothing else that knows the
        // command existed. The loss carries the command and args from this
        // closure, since a `lost` rejection has no reply to name them from.
        if (rejection.kind === "lost") {
          setLosses((prev) => [
            ...prev,
            {
              id: newRequestId,
              command,
              args,
              label: label,
            },
          ]);
          return;
        }
        // It never left this machine: the transport gave up on the link while
        // this was still waiting on it. Collected here rather than in the sweep
        // because there is no loss to promote, the deadline having never come
        // round (or never been armed). Classified `failed`, so this reads the
        // code, since nothing was decided over there and so it is not a `kind` of its own.
        if (
          rejection.kind === "failed" &&
          rejection.code === FaultCode.Undelivered
        ) {
          setUndelivered((prev) => [
            ...prev,
            {
              id: newRequestId,
              command,
              args,
              label: label,
              reason: rejection.message,
            },
          ]);
          return;
        }
        // A fault the mod answered with names what became of the command, so it is kept to be said rather than dropped with the promise.
        if (rejection.kind === "failed" && isModFault(rejection.code)) {
          setFailures((prev) => [
            ...prev,
            {
              id: newRequestId,
              command,
              args,
              label: label,
              code: rejection.code,
              reason: rejection.message,
            },
          ]);
          return;
        }
        if (rejection.kind !== "refused") return;
        setRefusals((prev) => [
          ...prev,
          {
            id: newRequestId,
            errorCode: rejection.errorCode,
            reason: rejection.reason,
            command: rejection.command ?? command,
            args: rejection.args ?? args,
            label: rejection.label ?? label,
            breach: rejection.breach,
            detail: rejection.detail,
          },
        ]);
      });
      // The one place the wire's guarantee is asserted, and the layer entitled
      // to assert it. `TelemetryClient` is transport-level and deliberately
      // knows nothing about the command contract, so it resolves `unknown`;
      // this hook is keyed on the generated command map and does. Everything
      // above this line reads the reply through `AnyCommandReply` or through a
      // named command's own type, so the assertion is made once here instead of
      // being re-made, undocumented, at every call site that wanted to read
      // something.
      return result as Promise<AnyCommandReply>;
    },
    [
      command,
      outcomeStore,
      setLosses,
      setUndelivered,
      setFailures,
      setRefusals,
    ],
  );

  // Commands an earlier page of this screen sent under this id and is still waiting on, taken once so their answers show as a send's own do.
  useEffect(() => {
    if (!client) return;
    for (const held of client.restoredCommands(command)) {
      trackDispatch(held.requestId, held.result, held.args, held.label);
    }
  }, [client, command, trackDispatch]);

  const dangerouslySendWithoutInput = useCallback(
    (
      args?: unknown,
      opts?: { label?: string; topic?: string },
    ): Promise<AnyCommandReply> => {
      // No provider mounted: nothing left the ground, so nothing can come back.
      //
      // Resolving with `undefined` would read as a confirmed command:
      // a command `Button` awaits `send()`, calls `onConfirmed`, and returns to
      // rest, so a press with no link would render byte-identically to a press
      // that worked. A rejection is what the controls are built to read, and
      // it matches the client's own answer on `dispose()` and for a command
      // the engine dropped.
      if (!client) {
        const notMounted = new CommandError(
          COMMAND_LOST,
          `command ${JSON.stringify(command)} was not dispatched: no telemetry provider is mounted`,
        );
        openCommandGroup()?.poison(notMounted);
        const unsent = Promise.reject<AnyCommandReply>(notMounted);
        // Marked handled without being consumed, exactly as the dispatched
        // promise is below and for the same reason: a `void cmd.send(...)` call
        // site would otherwise raise an unhandled rejection every time it ran
        // with nothing mounted. The rejection stays fully observable to anyone
        // who awaits it.
        unsent.catch(() => undefined);
        return unsent;
      }
      /*
       * The command's own declaration already said no, so nothing is sent. The
       * refusal carries the gate's verdict and lands where a dispatched one
       * would, so every caller, not only a button, is refused the same way.
       */
      const refuseLocally = (
        verdict: Pick<
          CommandRefusal,
          "errorCode" | "reason" | "breach" | "detail"
        >,
        reason: string,
      ): Promise<AnyCommandReply> => {
        const refusal: CommandRefusal = {
          id: `local-refusal:${command}:${outcomeStore?.nextLocalSeq() ?? 0}`,
          errorCode: verdict.errorCode,
          reason: verdict.reason,
          command,
          args,
          label: opts?.label ?? "",
          breach: verdict.breach,
          detail: verdict.detail,
        };
        setRefusals((prev) => [...prev, refusal]);
        const error = new CommandError(
          COMMAND_REFUSED,
          `command ${JSON.stringify(command)} was not dispatched: ${reason}`,
          verdict.errorCode,
          refusal,
        );
        // A group goes whole or not at all, so one refused member refuses it.
        openCommandGroup()?.poison(error);
        const refused = Promise.reject<AnyCommandReply>(error);
        refused.catch(() => undefined);
        return refused;
      };
      /*
       * A gate stops the press only when its verdict is fresh enough to stand for
       * the game's answer: the command is declared instant, or its verdict is held
       * a few seconds at most. Past that the command goes and the mod reads the
       * gates again when it arrives.
       */
      const standing = selectCommandGate(gateReportRef.current, command, args);
      if (standing?.blocked && gateStopsPressRef.current) {
        return refuseLocally(standing, "its gate refuses it");
      }
      // A command that acts at a UT and would land at or after it is stopped before it leaves, on the same terms.
      if (gateStopsPressRef.current) {
        const clock = storeRef.current?.clock;
        const arrivalUt = !clock
          ? undefined
          : isInstantRef.current || toActiveVesselRef.current
            ? arrivalUtOf(clock, !isInstantRef.current)
            : arrivalUtAfter(clock, effectiveDelayRef.current);
        if (arrivesTooLate(command, args, arrivalUt)) {
          return refuseLocally(
            { errorCode: LATE_ARRIVAL_ERROR_CODE, detail: LATE_ARRIVAL_DETAIL },
            LATE_ARRIVAL_DETAIL,
          );
        }
      }
      const track = (
        newRequestId: string,
        result: Promise<unknown>,
      ): Promise<AnyCommandReply> =>
        trackDispatch(newRequestId, result, args, opts?.label ?? "");
      const group = openCommandGroup();
      if (group) {
        return group.capture({
          client,
          command,
          args,
          label: opts?.label,
          topic: opts?.topic,
          vantage,
          instant: isInstantRef.current,
          track,
        });
      }
      const { requestId: newRequestId, result } = client.dispatch(
        command,
        args,
        opts?.label,
        opts?.topic,
        vantage,
      );
      return track(newRequestId, result);
    },
    [client, command, vantage, trackDispatch, outcomeStore, setRefusals],
  );

  const outcome = {
    status,
    inFlight,
    warnings,
    refusals: allRefusals,
    losses,
    founds: allFounds,
    undelivered,
    streamDown,
    failures: allFailures,
    tags,
    effectiveDelaySeconds,
    delayReading,
    delayMode,
    sendStatus,
    dismiss,
    gate,
  };

  // Keyed on identity only, so a moving outcome updates in place rather than re-registering.
  // biome-ignore lint/correctness/useExhaustiveDependencies: outcome changes are applied by the update effect below
  useEffect(() => {
    if (!rail || !railed) return;
    return rail.register({ id: railId, ...outcome });
  }, [rail, railed, railId]);

  // The rail's shallow-equal guard means an outcome that did not move notifies nobody.
  useEffect(() => {
    if (!rail || !railed) return;
    rail.update(railId, outcome);
  });

  const handle: UseCommandResult = {
    dangerouslySendWithoutInput,
    gateFor,
    check,
    railed: railed && rail !== null,
    gateStopsPress,
    ...outcome,
    with: (args, options) => bindCommand(handle, args, options),
    toArgs: (toArgs, options) => bindValue(handle, toArgs, options),
  };
  return handle;
}

/** 0 for an instant command, the target's own figure elsewhere, `activeVessel()` for the active craft, and `null` for a target nobody has placed. */
function delayToTarget(
  isInstant: boolean,
  target: CommandTarget | null,
  activeVessel: () => number | null,
): number | null {
  if (isInstant) return 0;
  if (target?.kind === "elsewhere") return target.seconds;
  if (target?.kind === "active-vessel") return activeVessel();
  return null;
}
