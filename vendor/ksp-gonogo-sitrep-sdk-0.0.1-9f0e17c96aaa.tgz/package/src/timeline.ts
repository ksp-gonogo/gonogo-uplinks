import type { Meta } from "./__generated__/contract";

/**
 * The derived-channel authoring contract.
 *
 * An Uplink contributes derived channels: it declares a topic, the inputs it reads,
 * and a pure `derive` that answers for one view time. Writing one means naming a
 * `TimelinePoint` and a `DerivedGet`, so both belong on the surface a
 * third-party author actually has.
 *
 * They lived in `@ksp-gonogo/sitrep-client` until the Uplink isolation rule made the
 * consequence visible: a bundled Uplink contributes a resource-projection channel
 * and could only do it by importing app-internal types, which is precisely the thing
 * an outside author cannot do. Nothing here needs the store; it is the
 * vocabulary for talking to it, and the store itself stays app-side.
 */

/**
 * One point on a topic's `ClientTimeline`.
 *
 * `payload: null` is a tombstone (absence-as-data), a
 * confirmed "there is no value", distinct from `undefined` (never received).
 * `meta` is kept whole (not just the payload) because quality-picking,
 * subject-provenance guarding (`sameSubject`, later task), and staleness all
 * need fields beyond the value itself.
 *
 * `epoch` is the client-side timeline-reset generation this point was
 * ingested under (mirrors `meta.timelineEpoch`, copied in verbatim by
 * whoever constructs the point: `ClientTimeline.append` trusts it, it does
 * not re-derive it from `meta`).
 */
export interface TimelinePoint<Payload = unknown> {
  validAt: number;
  payload: Payload | null;
  meta: Meta;
  epoch: number;
}

/**
 * What a `derive()` function reads inputs through, enforces the
 * "single-view-time invariant". Deliberately NOT `(topic) => value`, it
 * returns the whole `TimelinePoint` (so `derive` can read `meta.quality`/
 * `meta.source` for quality-picking and subject-provenance), and it is
 * always bound to one frame's frozen `viewUt` by `TimelineStore.sample`/`sampleDerived`: there
 * is no overload that takes a UT, and no way to ask for "latest" from inside
 * a derivation. That is what makes the invariant structural rather than a
 * convention derive authors have to remember: `get` physically cannot read
 * any UT but the one this derive call was invoked for. `get` also resolves
 * derived-on-derived inputs transparently (it's just another `sample()`
 * call), so a derived channel can list another derived channel as an input.
 */
export type DerivedGet = <Payload = unknown>(
  topic: string,
) => TimelinePoint<Payload> | undefined;

export interface DerivedChannelDefinition<Payload> {
  /** The topic this channel registers as, e.g. `"system.state"`. */
  topic: string;
  /**
   * Declarative list of input topics this channel reads. Not currently used
   * to drive subscription ref-counting (that requires wiring `TimelineStore`
   * to `TelemetryClient`'s subscribe machinery, not yet done); recorded
   * here as the channel's own documentation of its dependencies, and
   * reserved for that wiring.
   */
  inputs: string[];
  /**
   * Pure function: same `(get, viewUt)` inputs must produce the same output,
   * always (the replay/scrub contract). Two distinct
   * "nothing" results: never conflate them:
   * - Return `undefined` when an input has no point at-or-before `viewUt`
   *   yet in the current epoch: "not whole yet" (cold start, or
   *   resynchronizing after an epoch reset until the first post-reset
   *   keyframe lands per input). `sample()`/`sampleDerived` propagate
   *   this as "no point at all", never a fabricated tombstone.
   * - Return `null` for a confirmed absence (a tombstoned input, or the
   *   channel's own subject genuinely gone): never a fabricated
   *   zero-valued record.
   */
  derive: (get: DerivedGet, viewUt: number) => Payload | null | undefined;
  /**
   * Expose `"<topic>.<field>"` subtopics that read a single field off the
   * one memoized record: e.g. `system.state.bodyCount`.
   * Field names are resolved dynamically off whatever `derive` returns, so
   * no static field list is needed here.
   */
  fields?: boolean;
}
