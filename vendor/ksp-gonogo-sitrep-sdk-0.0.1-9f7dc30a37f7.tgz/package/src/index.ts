/**
 * The TypeScript package an Uplink's client is written against. Gonogo is a
 * KSP mod that streams the game's state to the Gonogo app over a WebSocket, as
 * Topics (a named stream of one kind of value, such as `vessel.orbit`) and
 * commands; an Uplink is an add-on that extends that mod with Topics and
 * commands of its own and ships widgets for the app. This package holds the
 * typed contract for every Topic and command, generated from the mod's C#, and
 * the calls a client makes with it: `defineUplinkClient`, `registerComponent`,
 * `useTelemetry`, `useCommand` and the quantity types that carry a value with
 * its unit (`Value`).
 *
 * @packageDocumentation
 */
export * from "./__generated__/contract";
export type { GeneratedControlChannelId } from "./__generated__/control-channels";
export type {
  GeneratedHeldAtHomeTopic,
  GeneratedTrueNowTopic,
} from "./__generated__/delay-roles";
export * from "./__generated__/error-codes";
export * from "./api";
// The HOST's logger, not `@ksp-gonogo/logger`'s singleton (a bundled second copy of
// that is a dead logger: console-only, never reaching Axiom or the shared
// `exportLogs()` buffer). Published from the root barrel and NOT from `./api`,
// deliberately: `api/index.ts` says why it is absent there, and re-exporting it
// through that barrel is what made `perf/PerfBudget -> api/index ->
// api/settings/SettingsService -> perf/PerfBudget` a cycle.
//
// Published at all because `@ksp-gonogo/ui-kit` is published and does real work:
// the contribution aggregation isolates a throwing contribution and has to say
// which one threw. Its only alternative was a bare `console.warn`, which is
// invisible to Axiom, so the one place an Uplink author's broken `compute` gets
// reported would have been the place nobody can read after the fact.
export { logger } from "./api/logger";
// The BINARY LANE's read side. Published on the root barrel rather than behind
// a subpath: it pulls nothing (no WebCodecs, no worker, no React), and an
// Uplink that publishes an opaque channel needs to read one back on any screen.
export type {
  BinaryFrameFailure,
  BinaryFrameResult,
  StreamBinaryMessage,
} from "./binary-frame";
export {
  BINARY_LANE_MAGIC,
  BINARY_LANE_PREFIX_BYTES,
  BINARY_LANE_STREAM_BINARY,
  decodeBinaryFrame,
  frameBytes,
  isBinaryFrame,
} from "./binary-frame";
export { parseServerMessage } from "./client";
// The read contract: `useTelemetry` answers with a `Reading`, so the union and its accessors ship on the author surface rather than app-side.
export * from "./combine-readings";
// Pure delayed-command derivations. Published because delay is ambient: an
// Uplink rendering its own command surface needs the same mode/phase vocabulary
// the app's rail uses, and there is nothing app-specific in deriving it.
export type {
  CommsDelayLike,
  DelayMode,
  InFlightCommand,
  PathConnectedDuring,
  PendingEntry,
  PredictedPhase,
  RailCrossing,
} from "./command-delay";
export {
  classifyRetained,
  currentMode,
  deriveInFlight,
  deriveRailEntry,
  latchForward,
  pendingCrossing,
} from "./command-delay";
/*
 * The typed command vocabulary: the write-side twin of the Topic registry below.
 * `useCommand` is keyed on `CommandId`, and an Uplink declaring its own commands
 * augments `CommandArgsMap`/`CommandReplyMap` and registers the id here.
 */
export {
  type AnyCommandReply,
  COMMAND_IDS,
  type CommandArgs,
  type CommandArgsMap,
  type CommandId,
  type CommandReply,
  type CommandReplyMap,
  commandRail,
  getAllKnownCommandIds,
  isCommandId,
  registerUplinkCommand,
} from "./commands";
// The link grading behind comms.degrade: one 0..1 number an Uplink choosing a
// quality (a video feed's bitrate, a voice channel's noise) can key on without
// knowing which comms mod is installed. Published because the alternative every
// consumer reaches for, `1 - comms.signal.strength`, is a different quality curve
// per install with nothing on the wire saying so, and because the absent case is
// a branch a caller must be made to write. See comms-degrade.ts.
export type { DegradeRating } from "./comms-degrade";
export { degradeRating, degradeRatingOf } from "./comms-degrade";
// The compat numbers a `gonogo-uplink.json` is gated on. Published here because
// an Uplink's build has to write them and could not read any of them.
export {
  CONTRACT_MAJOR,
  CONTRACT_MINOR,
  EXTENSION_API_VERSION,
} from "./compat-versions";
// The contract's own enums as value-to-name tables and closed name unions,
// the sibling of `ksp-enum-names` below. A widget resolving an ordinal it read
// off the wire needs them, and a table it typed itself is how a name no build
// emits comes to compile.
export * from "./contract-enum-names";
/**
 * The value tags a contract declares, in the table an Uplink's codegen writes
 * and passes to `defineUplinkClient`.
 */
export type {
  ContractReckonableRow,
  ContractTagTable,
  SampleKind,
  ValueTags,
} from "./contract-tags";
export {
  type ControlChannelHandle,
  type ControlChannelId,
  controlChannelIds,
  getControlChannel,
} from "./control-channels";
// The contract's own crew standing, and the reason it is not a KSP mirror: see
// crew-standing.ts. Published because a crew surface in an Uplink reads the same
// roster and must not report a retiree as a fatality either.
export {
  CREW_STANDING_NAMES,
  CREW_STANDING_ORDER,
  type CrewStandingName,
  canBeSacked,
  crewStandingFromRosterStatus,
  crewStandingLabel,
  crewUnavailableSentence,
  isFatality,
} from "./crew-standing";
// Whether a Topic's value is entitled to be read as of TRUE NOW, or only as of
// now minus the light-time to the craft. Published for the same reason
// reckonability is: an Uplink declaring a ground-side channel of its own needs
// the same answer core reads, and a widget that draws a career balance beside a
// vessel reading has to be able to say which of the two is current.
export {
  type DeclaredDelayRoles,
  type DelayLane,
  delayLaneOf,
  type HeldAtHomeTopic,
  isHeldAtHomeTopic,
  isTrueNowTopic,
  readDeclaredDelayRoles,
  type TrueNowTopic,
} from "./delay-roles";
// The atmospheric-descent maths a velocity-height plot is drawn from. Published
// because it is the only input a contributor to that plot cannot rebuild from
// the wire, and two independently written integrators on one plot disagree for
// reasons no operator can see. See descent.ts.
export type { DescentProjection, ProjectDescentOptions } from "./descent";
export {
  DESCENT_SETTLE_TOLERANCE,
  DESCENT_TRACE_STEPS,
  projectDescent,
  relativeDensityCurve,
  terminalVelocityCurve,
} from "./descent";
// Ordinal->name tables and closed name unions for the contract's enums. On the
// root barrel rather than in the spine because an Uplink needs them as much as
// the app does: KSP's ResourceFlowMode reaches the Kerbalism Uplink and its
// PartCategories reach ShipMap, and an Uplink that had to transcribe the member
// set beside its own switch is back to the defect these tables exist to end.
// Derived from the generated contract and nothing else, so they carry no spine
// weight into the SDK.
export { namesByValue, namesOf } from "./enum-names";
export * from "./envelope";
// The discrete-occurrence timeline. It lives here rather than in the spine
// because an Uplink that PRODUCES an event topic needs the same primitive the
// spine consumes it with, and the spine is unpublished. Imports nothing, so it
// carries no spine weight into the SDK.
export type {
  ConnectivityAt,
  EventOccurrence,
  EventRevealOptions,
  EventTimelineOptions,
} from "./event-timeline";
export { EventTimeline } from "./event-timeline";
// The provider extension bag: the opaque core half of how a provider extends a
// Kernel-elected payload without a core change. The TYPED half is always in the
// provider's own package (see ./extensions.ts).
export {
  PROVIDER_EXTENSIONS_FIELD,
  type ProviderExtension,
  type ProviderExtensions,
} from "./extensions";
// Which coordinate frame a Vec3 field is expressed in, off the [SitrepFrame] tags, so a widget or a test can check two vectors share axes before combining them
export { type FieldFrame, frameOf } from "./field-frames";
// The buffered-recording subsystem: wraps a live `DataSource`, persists every
// sample into a `FlightStore` keyed by inferred flight, and answers columnar range
// queries. An Uplink's tests build one to assert what its widgets read, and
// `data` is `private: true`, so the harness they needed was unbuildable outside
// this repo. Its transitive imports were this package and itself all along.
export type { KeyEnricher } from "./flight/BufferedDataSource";
export { BufferedDataSource } from "./flight/BufferedDataSource";
export { DataSourceWrapper } from "./flight/DataSourceWrapper";
export { debugFlight } from "./flight/debugFlight";
export type { DerivedKeyDef } from "./flight/derive";
export {
  clearDerivedKeys,
  getDerivedKeys,
  registerDerivedKey,
} from "./flight/derive";
export type {
  ExportFlightOptions,
  FlightChapter,
  FlightFixture,
} from "./flight/fixtureIO";
export {
  exportFlightToFixture,
  FLIGHT_FIXTURE_FORMAT,
  fixtureDurationMs,
  importFixtureToStore,
  isFlightFixture,
} from "./flight/fixtureIO";
export {
  DEFAULT_KEEP_COUNT,
  getKeepCount,
  setKeepCount,
  subscribeAutoDelete,
} from "./flight/flightAutoDelete";
export type {
  DetectorDecision,
  DetectorInput,
} from "./flight/flightDetector";
export { FlightDetector } from "./flight/flightDetector";
export { KeyedListenerSet, ListenerSet } from "./flight/ListenerSet";
export type { LocalStorageStoreOptions } from "./flight/storage/LocalStorageStore";
export { LocalStorageStore } from "./flight/storage/LocalStorageStore";
export { MemoryStore } from "./flight/storage/MemoryStore";
export type { FlightStore } from "./flight/storage/Store";
export { FLIGHTS_DESC } from "./flight/storage/Store";
export type {
  DataKeyMeta,
  FlightChapterRecord,
  FlightCrashOutcome,
  FlightOutcome,
  FlightRecord,
  FlightRecoveryOutcome,
  MissionMeta,
  ReadingSeriesRange,
  Sample,
  SeriesBridge,
  SeriesInterpolation,
  SeriesRange,
  SeriesReckonedSpan,
  SeriesStatusSpan,
  SeriesTimeBasis,
  TopicFieldHandle,
  UnitHint,
} from "./flight/types";
export { seriesKeyOf } from "./flight/types";
export * from "./ksp-enum-names";
export { isLocked, unlessLocked } from "./locked";
// The magnitude unwrap, beside `Value` because that is what it unwraps. ui-kit re-exports these three, so no call site moved.
export {
  asQuantityish,
  magnitudeOf,
  magnitudeOr,
  type Quantityish,
} from "./magnitude";
// What a burn's three delta-v slots are called in the basis the burn declares.
// Published for the reason `enum-names` above is: the slots are positional and
// the field names are the stock basis's, so an Uplink planner working in the
// Frenet trihedron needs these words and had been transcribing them.
export {
  type ManeuverBasisLabels,
  maneuverBasisLabels,
} from "./maneuver-basis";
// The rate-budget class itself, not just its options type. Every new data source
// is required to register a budget and all eight Uplink test setups call
// `installTestGate`, so it has to be reachable from a published package or that
// requirement only ever applied to code inside this repo.
export { PerfBudget } from "./perf/PerfBudget";
/*
 * The delay rail's three axes, and the derivations that fill them in from what
 * the mod declares. An author reaches for these when they put something on the
 * rail that is not a discrete acked command: the vocabulary is here, and the kit
 * that draws it decides which combinations it can render.
 */
export {
  type CommandRail,
  type RailDelivery,
  type RailDirection,
  type RailTags,
  railTagsForCommand,
  railTagsForControlAxis,
  railTagsForTelemetry,
  railTagsFromCommandRail,
  UNDECLARED_COMMAND_RAIL_TAGS,
} from "./rail-tags";
// How a dotted key becomes (wire topic, field path). Published because the
// catalogue every picker offers from has to decide whether a key it is about to
// offer would resolve back to the Topic it came from, and deciding that from the
// key's SHAPE is what put an unfillable key in the picker before.
export {
  type RawFieldSubtopic,
  splitRawFieldSubtopic,
} from "./raw-field-split";
export * from "./reading";
// Which VALUES the contract says a model can carry forward, and from which
// published inputs. On the author surface because the promise is made to an API
// consumer holding nothing but the stream: an Uplink writing its own reckoner
// reads the same declaration core does, rather than re-deriving from a doc.
export {
  type GeneratedReckonableInput,
  type GeneratedReckonableValue,
  isReckonableTopic,
  type OwnedReckonableValue,
  type ReckonableFieldMap,
  type ReckonableFields,
  type ReckonableTopic,
  reckonableInputSpelling,
  reckonableInputsOf,
  reckonableValuesOf,
} from "./reckonability";
// Which Topics a client package has registered at runtime, and a subscription
// to that answer changing. Read by the app's field catalogue; an Uplink author
// registers the way they already do and never calls these.
export {
  getRuntimeRegisteredTopicIds,
  registerDynamicTopicPrefix,
  subscribeRuntimeTopicRegistry,
} from "./runtime-topic-registry";
// THE AIR: the other half of an altitude, for the regime the conic hands over
// to. Published from the ROOT barrel for the same reason the conic is: an
// author who cannot reach `withinAtmosphere` cannot write a model that hands
// over at the same instant core's does, and two models drawing their own
// boundary is the disagreement no widget could report.
export {
  type AtmosphericDescentFit,
  type AtmosphericFlightInput,
  atmosphericAdmissibility,
  atmosphericAltitudeAt,
  atmosphericAltitudeBandAt,
  DESCENT_WINDOW,
  horizonSecondsFor,
  localGravity,
  type SlopeFit,
  verticalAccelerationOver,
  withinAtmosphere,
} from "./spine/atmospheric-reckoning";
export {
  type BodyPose,
  type BodyPoseCurrency,
  poseAtIndex,
  SYSTEM_POSES,
  type SystemPoses,
  systemPosesAt,
} from "./spine/body-pose";
// What a locked `LockScope` hands its fallback, which ui-kit publishes.
export type { CapabilityLock } from "./spine/capability-lock";
// ---------------------------------------------------------------------------
// SHARED PROCESSORS: the handles, their result types, and the pure derivations behind them.
//
// Published from the ROOT barrel rather than only from `./spine`, because the
// root barrel is the whole of what an Uplink may import, and a Processor nobody
// outside this repo can name is not shared, whatever
// `registerProcessor`'s owner stamp says. The machinery stays where it was:
// `defineProcessor`, the evaluator and `TimelineStore` are still spine-only, and
// `useProcessor` reaches the evaluator through the host shim above.
//
// A handle here is a DECLARATION, not a subscription. Importing the SDK registers
// the definition; nothing evaluates until a `useProcessor` or a contribution dep
// activates it.
// ---------------------------------------------------------------------------
export {
  ANALYTIC_BODY_HORIZON,
  type BodyAtmosphere,
  type BodyFigures,
  type BodyHorizon,
  bodyAtIndex,
  bodyNamed,
  CELESTIAL_FACTS,
  type CelestialBody,
  type CelestialFacts,
  deriveCelestialFacts,
} from "./spine/celestial-facts";
export {
  type BudgetProvenance,
  DELTA_V_BUDGET,
  type DeltaVBudget,
  type DeltaVStage,
  deriveDeltaVBudget,
  normaliseStage,
} from "./spine/delta-v-budget";
export type { UplinkActionOutcome } from "./spine/held-command-actions";
export {
  type Anomalies,
  type ConicShape,
  type ConicSolution,
  canPropagate,
  eccentricFromTrueAnomaly,
  type OrbitElements,
  type PropagationHorizonLike,
  rotatePerifocalToInertial,
  type StateVector,
  solve,
  solveAnomalies,
  solveConic,
  solveHyperbolicAnomaly,
  trueAnomalyFromEccentric,
  trueAnomalyFromHyperbolic,
} from "./spine/kepler";
// ---------------------------------------------------------------------------
// THE CONIC: the one two-body propagator in this repo, and the guard that says where it stops holding.
//
// Published from the ROOT barrel because a registered reckoner is only a real
// extension point if an author can reach what core reaches. Every one of these
// lived behind `/spine`, which the isolation gate blocks, so an Uplink wanting
// to forward-model an orbit had to vendor a solver of its own or build a derived
// channel instead: the mechanism that can only LABEL arithmetic, never do it.
//
// `keplerAdmissibility` is the interesting one. It is where the withdrawal
// conditions live (a loaded craft with no coast to show, the SOI transition,
// the producer's stated horizon, the atmosphere interface), and a second copy
// of them is exactly how two models of one Topic come to disagree about where
// the conic ends.
// ---------------------------------------------------------------------------
export {
  advanceByVelocity,
  atmosphereDepthOf,
  buildElements,
  type ConicBodiesInput,
  type ConicOrbitInput,
  type ConicPendingInput,
  type ConicThrustInput,
  entryInterfaceRadius,
  isHyperbolic,
  isUnderThrust,
  keplerAdmissibility,
  type LoadedCoastEvidence,
  loadedCoastEvidence,
  propagateVesselOrbit,
  trySolve,
  trySolveAnomalies,
  type WireOrbitElements,
} from "./spine/kepler-reckoning";
export type { Capability } from "./spine/lock-scope";
export { DYNAMIC_WHOLE_TOPIC_PREFIXES } from "./spine/map-topic";
export { phaseAngleBetween } from "./spine/phase-angle";
/*
 * The powered-flight model and the pieces of it an Uplink would need to write
 * one of its own: the burn, its evidence, and the state-to-elements conversion
 * that is the conic's inverse.
 */
export {
  elementsFromState,
  type PoweredFlight,
  type PoweredFlightEvidence,
  type PoweredFlightFields,
  type PoweredOrbitProjection,
  type PoweredThrustInput,
  poweredFlight,
  poweredFlightEvidence,
} from "./spine/powered-reckoning";
// The CONTRACT half of the Processor primitive, and the only route by which a
// Processor one Uplink implements can be consumed, typed, by another. Published
// alongside the handle type it returns; `defineProcessor` itself stays
// spine-only, because declaring a processor needs the evaluator and declaring
// its contract does not. See `defineProcessorContract`'s own doc for why a
// declaration-merged registry keyed by id cannot do this job.
export {
  type CarriesCurrency,
  type Dep,
  defineProcessorContract,
  type ProcessorFrame,
  type ProcessorHandle,
  type ReadingDep,
  type ResolvedDeps,
  type SubjectDep,
} from "./spine/processors";
// Which screen the widget is mounted on, and which seat that puts the operator
// in. The `Screen` and `Seat` TYPES are already on this barrel (via `./api`),
// so until now an author had the vocabulary and not the hook that answers in
// it: `useScreen` was reachable only through `/spine`, which is not an author
// surface. A widget that draws differently aboard the craft than at mission
// control, or that gates on light-time, is asking about the SEAT, so the three
// seat helpers publish alongside it. `ScreenProvider` deliberately does not:
// the app decides which screen a widget is mounted on, never the widget.
export {
  seatOf,
  useIsPilot,
  useScreen,
  useSeat,
} from "./spine/screen";
export type { StoredStreamBackedSettingOf } from "./spine/settings-registry";
// The shape of `system.uplinkHealth`, so an Uplink can read the roster it is
// itself reported on. Published because health is where an Uplink says what it
// depends on and whether that dependency is usable, which is the sort of thing a
// widget wants to badge beside the numbers it draws. Types only: the roster is
// read with `useStream("system.uplinkHealth")` like any other channel, and
// deriving it is the spine's job rather than an author's.
export type {
  ContractVersionReading,
  SystemUplinkHealth,
  UplinkHealthEntry,
  UplinkHealthFact,
  UplinkHealthStateName,
} from "./spine/uplink-health";
export { HEALTH_STATE_NAMES } from "./spine/uplink-health";
export { useSystemInstant } from "./system-instant";
export * from "./timeline";
export {
  type EnumEncoding,
  enumerateTopicFields,
  type TopicField,
  type TopicFieldKind,
} from "./topic-fields";
export {
  type ChannelFamily,
  DERIVED_CHANNEL_IDS,
  type DerivedChannelId,
  familyPrefix,
  getAllKnownTopicIds,
  isCollectionTopic,
  isDerivedChannelId,
  isTopicId,
  isWidgetChannelId,
  registerBarePrimitiveTopic,
  registerCollectionTopic,
  TOPIC_IDS,
  type TopicId,
  type TopicPayload,
  type TopicPayloadMap,
  topicMatchesFamily,
  type WidgetChannelId,
  type WidgetFieldPath,
} from "./topics";
// The unit model: Value, dimensions, arithmetic, the unit table.
//
// The members sit flat: a call site writes
// `import { value } from "@ksp-gonogo/sitrep-sdk"` like it does for everything
// else the SDK offers.
//
// `Vec3Of` is the exception and still comes from `./value` below: it is the
// name the generated contract puts on a unit-carrying vector, and there is no
// second spelling of it worth exporting.
export {
  affineVectorUnitFor,
  asDeterministic,
  asStatic,
  assertGuardsRegistered,
  calendarRatio,
  carryDeterminism,
  type DeclaredUnit,
  Dimension,
  declaredUnitFor,
  displaySymbol,
  hydrate,
  isCalendarUnit,
  isDeterministicValue,
  isExactValue,
  isStaticValue,
  isUnit,
  isValue,
  type KnownUnit,
  type KspCalendar,
  kspCalendar,
  kspYearDays,
  lookupUnit,
  namespaceOf,
  onUnitRegistered,
  type PointUnit,
  type RegisteredUnit,
  type ResourceNamespaces,
  registerUnit,
  resetUnitRegistry,
  type SameDimensionAs,
  STANDARD_GRAVITY,
  STOCK_KERBIN_CALENDAR,
  setKspCalendar,
  staticValue,
  UNIT_DEFINITIONS,
  type UnitDeclaration,
  type UnitDeclarations,
  type UnitDefinition,
  type UnitPresentation,
  type UnitRegistration,
  type UnitRung,
  type UnknownUnit,
  unitGuard,
  type Value,
  type Vector3,
  value,
  vectorMagnitude,
} from "./unit-system";
export {
  type KnownSitrepUnit,
  registerEnumMembers,
  registerProviderExtensionShape,
  registerTopicUnits,
  registerTypeUnits,
  type ShapesByField,
  type SitrepUnit,
  shapesForTopic,
  shapesForType,
  staticsForTopic,
  staticsForType,
  type UnitsByField,
  unitOf,
  unitOfTypeField,
  unitsForTopic,
  unitsForType,
} from "./units";
export type { Vec3Of } from "./value";
// The pure view-clock formula. Shared by the spine's `ViewClock` and by the
// delayed-media worker, which evaluates it off-thread against a serialisable
// snapshot: one implementation, never a fork.
export type {
  ClockFormulaInputs,
  ClockFormulaSnapshot,
} from "./view-clock-formula";
export {
  computeConfirmedEdgeUt,
  computeUtNowEstimate,
} from "./view-clock-formula";
// The input type of the two wrap functions above, so a caller holding a
// pre-wrap frame can say so. Reachable from the root barrel because a caller
// reading an unwrapped dynamic topic needs it outside a test too.
export type { WireOf } from "./wrap-units";
export {
  dehydrateArgs,
  hydratePayload,
  wrapTopicPayload,
  wrapTypePayload,
} from "./wrap-units";
