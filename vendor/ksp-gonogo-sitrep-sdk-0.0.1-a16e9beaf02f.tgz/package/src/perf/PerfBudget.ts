// The host-routed logger shim, not `@ksp-gonogo/logger`'s singleton: a bundled
// second copy of that is console-only and never reaches the shared ring buffer or
// Axiom. Only touched on an actual breach, so a budget constructed at module
// scope never needs a host to exist yet.
import { hasHost } from "../api/host";
import { logger } from "../api/logger";

/**
 * The single global slot the budget registry lives in. A string key rather than a
 * symbol so two different builds of this package still find the same Set.
 */
const PERF_BUDGET_REGISTRY_KEY = "__GONOGO_PERF_BUDGETS__" as const;

declare global {
  var __GONOGO_PERF_BUDGETS__: Set<PerfBudget> | undefined;
}

/**
 * What {@link createPerfBudget} and `new PerfBudget` take.
 *
 * @category Logging and performance
 */
export interface PerfBudgetOptions {
  /** Human-readable label used in the warning message. */
  name: string;
  /** Rolling window in ms. Default 1000 (i.e. budget = "per second"). */
  windowMs?: number;
  /**
   * Threshold per window. The total summed amount across all `record()`
   * calls in the current window must stay <= this value. When it
   * exceeds, a warn fires (rate-limited to one per window).
   */
  threshold: number;
  /** Suffix for the warning message: "events", "bytes", "writes" etc. */
  unit?: string;
}

interface Event {
  t: number;
  n: number;
}

/**
 * A soft performance budget: counts events (or bytes, or writes) over a
 * rolling window and logs a warning when the total goes over `threshold`. At
 * most one warning per window, and in the running app nothing else changes: it
 * never throws or slows anything down. In a test run that has called
 * `PerfBudget.installTestGate()`, a test that pushes a budget over its
 * threshold fails. `windowTotal()` returns the current total, for a test that asserts
 * on steady-state cost.
 *
 * An Uplink calls {@link createPerfBudget}, which makes one of these in the
 * app's own copy of the SDK and returns a handle to it. `new PerfBudget(...)`
 * works too: both land in the same registry, shared by every copy of the SDK
 * on the page.
 *
 * Make one at module scope beside the code it measures and call `record()` on
 * each event. Recording costs one `Date.now()` and an array push. The three
 * static members are called on the class: `PerfBudget.getAll()`,
 * `PerfBudget.clearRegistry()` and `PerfBudget.installTestGate()`.
 *
 * @category Logging and performance
 */
export class PerfBudget {
  private readonly opts: Required<PerfBudgetOptions>;
  private events: Event[] = [];
  private headIdx = 0;
  private currentSum = 0;
  private lastWarnAt = 0;
  private exceedanceCount = 0;

  constructor(opts: PerfBudgetOptions) {
    this.opts = {
      windowMs: opts.windowMs ?? 1000,
      unit: opts.unit ?? "events",
      ...opts,
    };
    PerfBudget.registry.add(this);
  }

  /**
   * Record one event of `amount` units (default 1). Triggers a warn
   * when the windowed sum exceeds the budget; the warn is throttled so
   * a sustained overrun logs once per window, not on every record call.
   */
  record(amount = 1, now: number = Date.now()): void {
    this.events.push({ t: now, n: amount });
    this.currentSum += amount;
    this.trim(now);
    if (this.currentSum > this.opts.threshold) {
      this.exceedanceCount++;
      if (now - this.lastWarnAt >= this.opts.windowMs) {
        this.lastWarnAt = now;
        const context = {
          observed: this.currentSum,
          threshold: this.opts.threshold,
          windowMs: this.opts.windowMs,
          unit: this.opts.unit,
          // Total times we've crossed the threshold since the budget was created: useful for spotting flapping vs sustained issues.
          exceedanceCount: this.exceedanceCount,
        };
        // Host-gated, and it has to be. The shim throws a named error when no
        // host is installed, which is right for `registerComponent` and very
        // wrong here: this is the DIAGNOSTIC path of a budget being breached, and
        // a warning that takes down the thing it is observing is worse than no
        // warning. A budget is constructed at module scope and recorded against
        // from hot paths, both of which can run long before any host exists.
        if (hasHost()) {
          logger.warn(`[perf-budget] ${this.opts.name} exceeded`, context);
        } else {
          console.warn(`[perf-budget] ${this.opts.name} exceeded`, context);
        }
      }
    }
  }

  /** Current windowed total (events × amount). Useful in tests. */
  windowTotal(now: number = Date.now()): number {
    this.trim(now);
    return this.currentSum;
  }

  /** How many times the threshold has been exceeded since construction. */
  getExceedanceCount(): number {
    return this.exceedanceCount;
  }

  /** Empties the rolling window and sets the exceedance count back to zero, as if the budget were new. For tests. */
  reset(): void {
    this.events = [];
    this.headIdx = 0;
    this.currentSum = 0;
    this.lastWarnAt = 0;
    this.exceedanceCount = 0;
  }

  /**
   * Empties the rolling window, so `windowTotal()` is 0 again, and leaves the
   * exceedance count as it was. The test gate calls it before each test, so
   * one test's burst is not counted against the next.
   */
  resetWindow(): void {
    this.events = [];
    this.headIdx = 0;
    this.currentSum = 0;
    this.lastWarnAt = 0;
  }

  /** The budget's name, as warnings and a failed test print it. */
  get name(): string {
    return this.opts.name;
  }
  /** The total within one window above which the budget is exceeded. */
  get threshold(): number {
    return this.opts.threshold;
  }
  /** The length of the rolling window, in milliseconds. */
  get windowMs(): number {
    return this.opts.windowMs;
  }
  /** What is being counted, as a word for the warning, such as `"samples"`. */
  get unit(): string {
    return this.opts.unit;
  }

  private trim(now: number): void {
    const cutoff = now - this.opts.windowMs;
    while (this.headIdx < this.events.length) {
      const e = this.events[this.headIdx];
      if (e.t >= cutoff) break;
      this.currentSum -= e.n;
      this.headIdx++;
    }
    // Periodically compact the underlying array so it doesn't grow
    // unbounded (we only ever push and never splice the front in the
    // hot path).
    if (this.headIdx > 256 && this.headIdx > this.events.length / 2) {
      this.events = this.events.slice(this.headIdx);
      this.headIdx = 0;
    }
  }

  // ── Static registry ───────────────────────────────────────────────────────

  /**
   * Every PerfBudget self-registers here on construction, which is what lets the
   * test gate below iterate all of them.
   *
   * Held on `globalThis`, not as a module-static `Set`.
   *
   * It was a module static, and that was safe only while this class lived in
   * `@ksp-gonogo/core`, which an Uplink cannot bundle. Published from the sdk it
   * would be the textbook second-copy-of-a-registry failure: a bundled Uplink
   * registers its budgets into its own `Set`, the widget lists the app's, and the
   * Uplink's budgets are simply invisible with nothing raising a word. Same
   * mechanism, same reason, as `GONOGO_HOST_KEY`.
   *
   * This is why `GonogoHost.createPerfBudget` exists, and it stays: it is the
   * documented author-facing route and costs nothing. Reaching the class
   * directly is safe too, which matters because a budget is constructed at
   * MODULE SCOPE (`const B = new PerfBudget(...)`) and so cannot go through a
   * host that may not be installed yet.
   */
  private static get registry(): Set<PerfBudget> {
    globalThis[PERF_BUDGET_REGISTRY_KEY] ??= new Set<PerfBudget>();
    return globalThis[PERF_BUDGET_REGISTRY_KEY];
  }

  /** Every budget registered in this browser page (one window, shared by every copy of the SDK loaded into it), in the order they were made. */
  static getAll(): readonly PerfBudget[] {
    return [...PerfBudget.registry];
  }

  /** Test-only: clears the registry. Doesn't dispose existing instances. */
  static clearRegistry(): void {
    PerfBudget.registry.clear();
  }

  /**
   * Makes every test fail that pushes a budget over its threshold. Each test
   * notes every budget's exceedance count before it runs, and fails afterwards
   * if any count rose. Call it once from a test setup file (`setupFiles` in a
   * Vitest config) so it applies to every test.
   *
   * It checks the budgets registered in the page the tests run in, which is
   * every budget made with `new PerfBudget` or `createPerfBudget` there, an
   * Uplink's own included.
   *
   * A test that goes over a threshold on purpose either clears the registry
   * in its own `afterEach`, or calls `reset()` on the budget before it ends.
   *
   * It needs a test runner that provides global `beforeEach` and `afterEach`,
   * and does nothing without them.
   */
  static installTestGate(): void {
    /* The runner's, read reflectively: declaring them would collide with the
       types vitest itself contributes wherever both are in one program. */
    const before: unknown = Reflect.get(globalThis, "beforeEach");
    const after: unknown = Reflect.get(globalThis, "afterEach");
    if (typeof before !== "function" || typeof after !== "function") return;

    let snapshot = new Map<string, number>();
    before(() => {
      // Reset the rolling-window content of every budget so a previous
      // test's burst doesn't bleed into this one. Keeps exceedance
      // counts for the diff at end of test.
      for (const b of PerfBudget.getAll()) b.resetWindow();
      snapshot = new Map(
        PerfBudget.getAll().map((b) => [b.name, b.getExceedanceCount()]),
      );
    });
    after(() => {
      const offenders: string[] = [];
      for (const b of PerfBudget.getAll()) {
        const prev = snapshot.get(b.name) ?? 0;
        const now = b.getExceedanceCount();
        if (now > prev) {
          offenders.push(
            `${b.name}: +${now - prev} exceedance${now - prev === 1 ? "" : "s"} (now ${now}, was ${prev}); total=${b.windowTotal()} threshold=${b.threshold}`,
          );
        }
      }
      if (offenders.length > 0) {
        throw new Error(
          `[perf-budget gate] one or more budgets exceeded their soft cap during this test. ` +
            `If the regression is real, fix it; if intentional, reset the budget at the end of the test.\n  - ` +
            offenders.join("\n  - "),
        );
      }
    });
  }
}
