// ---------------------------------------------------------------------------
// `@ksp-gonogo/sitrep-sdk/testing`: the test-only host injector.
//
// Under the injected-host model the app installs the real implementation at
// boot, but a unit test runs with no app. This subpath lets an author (and the
// sdk's own tests) install a fake host so the shims resolve instead of throwing
// the "no host installed" error. Self-contained: no core import, no cycle.
//
// It also ships the RENDER harness: `render`/`renderHook` with the
// kit's theme always mounted, plus Testing Library re-exported unchanged.
// Testing Library and styled-components are OPTIONAL peers and this is a separate
// entry from the root barrel, so a runtime consumer never resolves any of it.
//
// The rule for what belongs here, with no names to mis-grep: a helper lives in
// this subpath once it needs nothing above this package, and in
// `@ksp-gonogo/sitrep-testing` until then. That boundary MOVES as registries come
// down into the leaf, and the spine and two registries below crossed it rather
// than being reimplemented, so the direction of travel is that this subpath
// eventually holds all of it and `sitrep-testing` retires.
//
// Do not name a helper this subpath does not yet export, not even as a
// proposal: a grep of the sdk for that symbol hits this prose and reads as
// though the export already exists.
// ---------------------------------------------------------------------------

// Everything else Testing Library offers (`screen`, `waitFor`, `within`, `act`,
// `fireEvent`, `cleanup`, ...) passes straight through, so this subpath is a
// drop-in for the import source. The named exports above take precedence, so
// `render`/`renderHook` resolve to the themed versions.
export * from "@testing-library/react";
// The `clear` half of the three registries this package OWNS outright rather than
// shimming: action handlers here, then `clearMapPoiProviders` and
// `clearUplinkHandles` below (import ordering splits them around the augment line).
// Forwarded here as well as from the root barrel, because a test is the only caller
// of a `clear` and wants it from the same import as `render`.
export { clearActionHandlers } from "../api/action-dispatch";
// The registry-observation half. `getAugmentsForSlot` is on the root barrel next to
// `registerAugment`, since reading a slot's augments is something a widget does too;
// `clearAugments` is test-only and so lives here rather than on the author surface.
// Both resolve through the host, which is the point: a test observes the same
// registry the shim wrote to, instead of reaching for ui-kit's copy and relying on
// the two happening to be the same object.
export {
  clearAugments,
  clearPlanDrafts,
  getAugmentsForSlot,
} from "../api/index";
export { clearMapPoiProviders } from "../api/map-poi";
export { clearUplinkHandles } from "../api/uplink-handles";
// The transport double. It named nothing above this leaf (wire messages, `Meta`,
// `wrapTopicPayload`), so its old home in the unpublished `@ksp-gonogo/sitrep-client`
// was the only reason an Uplink's `sentCommands`/`isSubscribed` assertions needed a
// package an outside author cannot install.
// ── The spine, for a test that drives it directly ───────────────────────────
//
// `setupStreamFixture` covers the common case and should be reached for first.
// These are for a test that builds its own pipeline: a second store, a clock it
// scrubs by hand, a processor it activates without a provider.
//
// Forwarded from `../spine` rather than re-exported from the root barrel, because
// the root barrel is the AUTHOR surface and none of this belongs on it: nothing
// about writing an Uplink needs `TimelineStore`, and publishing it there would
// freeze the store's internals as third-party API. A test is a different audience
// from a widget, and this subpath is where that difference is expressed.
export {
  type DerivedGet,
  mapTopic,
  processorRuntimeFor,
  setActiveTelemetryClientForTests,
  TelemetryProvider,
  TimelineStore,
  ViewClock,
} from "../spine";
export { consoleLogger } from "./console-logger";
export { createTestTelemetryClient } from "./create-test-telemetry-client";
export { createFakeWallClock, type FakeWallClock } from "./fake-wall-clock";
// The act-warning gate's post-body wait, inert unless the gate sets its variable.
export {
  ACT_GATE_STRETCH_ENV,
  installActGateStretch,
} from "./install-act-gate-stretch";
// The jsdom shims a widget test needs before it can mount anything.
export { installDomStubs } from "./install-dom-stubs";
// The WHOLE host, built from the real implementations rather than a subset. See its
// own doc for why a partial host fails repeatedly, and for the four ui-kit members
// the caller supplies because this package cannot import that one back.
export {
  installRealTestHost,
  type UiKitHostPieces,
} from "./install-real-test-host";
export { installTestHost, resetTestHost } from "./install-test-host";
// The in-memory `Storage` shim.
export { memoryStorage } from "./memory-storage";
// The in-memory `DataSource` double.
export {
  MockDataSource,
  type MockDataSourceOptions,
} from "./mock-data-source";
// What `useAlarmRequest` was asked for under the real test host. The app owns
// the alarm list, so a test below the app asserts on the REQUEST rather than on
// an alarm that has nowhere to exist.
export {
  clearRequestedAlarms,
  getRequestedAlarms,
  type RecordedAlarmRequest,
} from "./recorded-alarm-requests";
export { probeText, render, renderHook } from "./render";
// The stream fixture: a real `TelemetryProvider` over a real
// `TelemetryClient`/`TimelineStore`/`ViewClock`, fed by hand-authored emissions.
// It sits here rather than a package above because the spine it drives is in this
// package now, so there is no reimplementation involved in publishing it.
export {
  type StreamFixture,
  type StreamFixtureOptions,
  setupStreamFixture,
  stopArriving,
} from "./stream-fixture";
export {
  makeMeta,
  observedPayload,
  type SentCommand,
  StubTransport,
  type WireOf,
  wrapWire,
} from "./stub-transport";

import type { CommandArgs, CommandId } from "../commands";

export { harnessTheme } from "./theme";

/**
 * A dispatch's args at the type the contract declares for that command.
 *
 * A transport's command handler is typed `(command: string, args: unknown)`,
 * because it carries every Uplink's commands and cannot know whose it holds.
 * This is the one step from there to the declared shape, so a test asserting on
 * an arg field stops compiling when the contract renames it.
 */
export function commandArgs<C extends CommandId>(
  args: unknown,
): CommandArgs<C> {
  return args as CommandArgs<C>;
}
