/**
 * How a widget-facing key resolves to the stream Topic it reads from.
 *
 * `isKnownFieldPath` / `resolveValueTopic` say whether a dotted path names a
 * field the contract declares, and which Topic a caller should sample for it.
 * Both read the contract's own generated metadata through
 * `unitsForTopic`/`shapesForTopic`, so a Topic an Uplink or a derived channel
 * registered at module load resolves alongside a first-party one.
 *
 * `mapTopic` vouches for a key in a DYNAMIC namespace, which no generated
 * metadata can enumerate. Every other key is deliberately NOT routed: mapping
 * one would point a read at a Topic nothing publishes.
 */

import { dynamicPrefixOf } from "../runtime-topic-registry";
import {
  isPluralShape,
  shapesForTopic,
  shapesForType,
  shapeTypeName,
  unitsForTopic,
  unitsForType,
} from "../units";

export { DYNAMIC_WHOLE_TOPIC_PREFIXES } from "../runtime-topic-registry";

/** `vessel.partActions.<flightId>`: the per-part PAW namespace `VesselUplink` publishes, keyed by a numeric flight id. */
const PART_ACTIONS_PREFIX = "vessel.partActions.";
const PART_ACTIONS_DYNAMIC = /^vessel\.partActions\.\d+$/;

/**
 * The Topic a dynamic key is read from, or `undefined` when the key is under
 * no registered prefix. A dynamic key, such as one per body or per part, is its
 * own Topic; what this checks is that some code registered its prefix with
 * `registerDynamicTopicPrefix`.
 *
 * @category Stream fixture
 */
export function mapTopic(key: string): string | undefined {
  const prefix = dynamicPrefixOf(key);
  if (prefix === undefined) return undefined;
  if (prefix === PART_ACTIONS_PREFIX && !PART_ACTIONS_DYNAMIC.test(key)) {
    return undefined;
  }
  return key;
}

/**
 * Walks the contract's own generated metadata from a topic root down a dotted
 * path, returning whether every segment names a real field.
 *
 * A field is real when the topic (or the type reached so far) declares it with
 * a UNIT, or declares it as a nested contract TYPE, which is the two halves the
 * unit-map codegen emits from one pass.
 *
 * A PLURAL shape (`*Type` for a dynamic-key map, `Type[]` for a list) ends the
 * walk rather than being descended into: what follows a map is a key the
 * contract never names (a facility id, a vessel id), and what follows a list is
 * a field of one element, so neither is something a sample of the parent Topic
 * can reach. The path AS FAR AS the collection is still a real field and still
 * resolves.
 */
function walksContractMetadata(topic: string, segments: string[]): boolean {
  if (segments.length === 0) return false;

  if (!isKnownTopic(topic)) return false;
  let units: Readonly<Record<string, string>> = unitsForTopic(topic as never);
  let shapes: Readonly<Record<string, string>> = shapesForTopic(topic as never);

  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    const last = i === segments.length - 1;

    if (units[segment] !== undefined) {
      // A unit is a leaf, so anything after it is not a field.
      return last;
    }

    /*
     * A vector's unit sits on a DOTTED leaf key (`"relativePosition.x"`) rather
     * than on a nested shape, because the shared vector type carries no unit of
     * its own and the components are what a reader indexes. Consuming one
     * segment at a time can never match one, so the whole remainder is tried as
     * a single key. The read resolves such a path by walking into the payload,
     * which is why refusing it here would reject a field that works.
     */
    if (!last && units[segments.slice(i).join(".")] !== undefined) return true;

    const shape: string | undefined = shapes[segment];
    if (shape === undefined) return false;
    if (last) return true;
    if (isPluralShape(shape)) return false;

    const nested = shapeTypeName(shape);
    units = unitsForType(nested);
    shapes = shapesForType(nested);
    if (isEmpty(units) && isEmpty(shapes)) return false;
  }

  return false;
}

function isEmpty(record: Readonly<Record<string, unknown>>): boolean {
  for (const _ in record) return false;
  return true;
}

/**
 * Whether the contract declares `topic` as a Topic at all.
 *
 * Read off the generated metadata through `unitsForTopic`/`shapesForTopic` for
 * the same reason {@link isKnownFieldPath} does: that indirection is what sees
 * a Topic registered at module load, which an Uplink's own payload type and
 * every client-derived channel only ever are.
 *
 * Distinct from {@link isKnownFieldPath}, and the distinction is a real one for
 * a caller: the reads keyed by a whole Topic (a status, a plotted window) and
 * the reads keyed by a field path within one are different vocabularies, and a
 * key valid in one is not valid in the other.
 */
export function isKnownTopic(topic: string): boolean {
  return !(
    isEmpty(unitsForTopic(topic as never)) &&
    isEmpty(shapesForTopic(topic as never))
  );
}

/**
 * Whether `path` names a field the contract declares under one of its Topics.
 *
 * Read entirely off the contract's own generated metadata, through
 * `unitsForTopic`/`shapesForTopic` rather than the generated maps directly. That
 * indirection is what lets it see a Topic registered at module load: an Uplink's
 * own payload type, and every client-derived channel, which is computed here
 * and appears in no contract type at all. Reading the maps directly is blind to
 * both.
 */
export function isKnownFieldPath(path: string): boolean {
  // Topic ids contain dots, so the split point is found rather than assumed: the longest prefix the contract knows as a topic wins.
  const segments = path.split(".");
  for (let cut = segments.length - 1; cut >= 1; cut--) {
    const topic = segments.slice(0, cut).join(".");
    if (!isKnownTopic(topic)) continue;
    if (walksContractMetadata(topic, segments.slice(cut))) return true;
  }
  return false;
}

/**
 * The Topic a picked key reads from. A key in a dynamic namespace is vouched
 * for by {@link mapTopic}; a field path IS the path it reads, so it needs no
 * translation and only needs vouching for: the picker offers paths the contract
 * declares, and a path it does not declare resolves to nothing rather than to a
 * subscription no channel serves.
 *
 * One function so that the readers of a picked key (the threshold evaluators
 * and the note-tag resolver) agree on what a key means.
 */
export function resolveValueTopic(key: string): string | undefined {
  const mapped = mapTopic(key);
  if (mapped !== undefined) return mapped;
  return isKnownFieldPath(key) ? key : undefined;
}
