import type { MapPoiProviderDefinition } from "./types";

/**
 * The map-POI registry, which lives here rather than in `@ksp-gonogo/core`
 * because an Uplink is the main thing that contributes to it: registering a
 * provider was already reachable from the published surface as a host shim, but
 * reading one back (`getMapPoiProviders`) was not, so an Uplink could write to
 * this registry and then had no published way to assert it had.
 *
 * A provider contributes data (an array of points for the currently-mapped
 * body), not a renderable component. MapView owns the one shared
 * hover/action/marker-styling surface, so N providers do not each invent their
 * own hover UX. Consumed by MapView's `MapPoiLayer`.
 */

/**
 * The single global slot the registry lives in, keyed by a string rather than a
 * symbol so two different builds of this package still find the same state.
 *
 * A module-static `Map` was safe while `core` was the only home and nothing
 * bundled it. Now that this file can be bundled into an Uplink, a module-static
 * one would be the silent second-copy-of-a-registry failure: the Uplink
 * registers a provider into its own copy and MapView reads the app's, with no
 * error anywhere. Same reasoning, and the same fix, as `PerfBudget`'s registry.
 */
const MAP_POI_REGISTRY_KEY = "__GONOGO_MAP_POI_PROVIDERS__" as const;

interface MapPoiRegistry {
  providers: Map<string, { def: MapPoiProviderDefinition; order: number }>;
  /** Registration order, so `getMapPoiProviders` is stable rather than Map-insertion-lucky. */
  counter: number;
  listeners: Set<() => void>;
}

function registry(): MapPoiRegistry {
  const slot = globalThis as typeof globalThis & {
    [MAP_POI_REGISTRY_KEY]?: MapPoiRegistry;
  };
  slot[MAP_POI_REGISTRY_KEY] ??= {
    providers: new Map(),
    counter: 0,
    listeners: new Set(),
  };
  return slot[MAP_POI_REGISTRY_KEY];
}

function notifyChange(): void {
  for (const cb of registry().listeners) cb();
}

/**
 * Calls `cb` whenever a map point-of-interest provider is registered or removed,
 * and returns the unsubscribe function. Useful for a map layer that redraws its
 * markers when the set of providers changes. Used by the map widget's
 * point-of-interest layer.
 *
 * @category Maps and coverage
 */
export function onMapPoiProvidersChange(cb: () => void): () => void {
  const { listeners } = registry();
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

/**
 * Adds a provider of points of interest for the map, replacing any registered
 * under the same id. Useful for putting an Uplink's own markers on the body
 * map the operator is viewing. Used by the map widget's provider of stock
 * points of interest.
 *
 * @category Maps and coverage
 */
export function registerMapPoiProvider(def: MapPoiProviderDefinition): void {
  const state = registry();
  state.providers.set(def.id, { def, order: state.counter++ });
  notifyChange();
}

/**
 * Every registered provider, in registration order. Useful for drawing the
 * points of every provider on the map. Used by the map widget's
 * point-of-interest layer.
 *
 * @category Maps and coverage
 */
export function getMapPoiProviders(): MapPoiProviderDefinition[] {
  return Array.from(registry().providers.values())
    .sort((a, b) => a.order - b.order)
    .map((entry) => entry.def);
}

/**
 * Removes every provider. For tests; a running app never calls it.
 *
 * @category Maps and coverage
 */
export function clearMapPoiProviders(): void {
  const state = registry();
  state.providers.clear();
  state.counter = 0;
  notifyChange();
}
