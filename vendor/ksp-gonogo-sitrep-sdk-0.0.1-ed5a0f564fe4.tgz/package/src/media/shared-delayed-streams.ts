/**
 * One delayed pipeline per camera, shared by every consumer of that camera.
 *
 * Delay is a property of the camera, not of the viewer. Before this module,
 * each consumer delayed its own copy: the delayed-playout hook built a fresh
 * pipeline per hook call, so a `CameraFeed` and the docking-HUD backdrop
 * pointed at the same camera would each try to build one. Two problems, one
 * fatal:
 *
 *   - **Fatal**: both Breakout-Box backends construct a
 *     `MediaStreamTrackProcessor` over the track, and a `MediaStreamTrack`
 *     admits only one processor: the second consumer's build throws. Same
 *     shape for the encoded backend: `RTCRtpScriptTransform` is one-per
 *     `RTCRtpReceiver`. So a second viewer on one camera was never
 *     supportable, only unreachable-by-luck.
 *   - **Wasteful**: even where it worked it would decode the same frames
 *     twice.
 *
 * And it was incoherent on its face: two consumers of one camera showing
 * different delays is never what anyone wants, they are looking at the same
 * lens through the same one delay authority.
 *
 * The fix is to delay once at the source and hand the delayed output to every
 * consumer: one processor per track, N consumers of its output. This module
 * is that seam, a refcounted, keyed cache of in-flight pipelines. It lives
 * in `sitrep-client` (beside the delay authority `ViewClock`, not in any
 * camera package) because it is about media + time. It knows nothing about
 * WebRTC or any camera SDK: the caller supplies the key (the shared
 * `MediaStream`/track identity) and the build function.
 *
 * Lifecycle:
 *   - first `acquire(key)` starts a build; later `acquire(key)` calls while
 *     that build is in flight (or after it settled) attach to the same entry
 *     and see the same result: so a consumer attaching mid-stream gets the
 *     existing delayed output rather than spawning a second processor;
 *   - the last `release()` disposes the pipeline and drops the entry. A build
 *     that settles after the last release is disposed immediately and never
 *     published (the teardown race a `raw`-stream swap creates).
 *
 * The "contribution" seam: each lease contributes a value (in practice the
 * capture-clock sample provider) and the build reads `contribution()`, the
 * first still-live lease's. This matters because the pipeline outlives the
 * consumer that happened to build it: if that consumer unmounts while another
 * still watches, a closure captured over the builder's refs would silently go
 * stale (a frozen capture UT -> frames stamped against a dead clock). Reading
 * the active contribution per call re-points automatically. Every consumer of
 * one camera reads the same app-wide clock, so any live one is equivalent.
 */

/** What a build produces: the value to publish, plus the physical pipeline's
 *  teardown/flush handles. `dispose` runs when the last lease releases.
 *
 * @category Delayed video
 */
export interface BuiltDelayedStream<Result> {
  /** What the builder made. */
  result: Result;
  /** Tears the stream down. */
  dispose?(): void;
  /** Drops the frames it holds. */
  flush?(): void;
}

/**
 * What the build function of a {@link SharedDelayedStreams} entry receives.
 *
 * @category Delayed video
 */
export interface DelayedStreamBuildContext<Contribution> {
  /** The first still-live lease's contribution, or `undefined` if every
   *  contributing lease has released. Call this per use (never hoist it),
   *  re-pointing away from an unmounted builder is the whole point. */
  contribution(): Contribution | undefined;
}

/**
 * Builds the delayed stream a {@link SharedDelayedStreams} entry shares.
 *
 * @category Delayed video
 */
export type DelayedStreamBuild<Result, Contribution> = (
  ctx: DelayedStreamBuildContext<Contribution>,
) => Promise<BuiltDelayedStream<Result>> | BuiltDelayedStream<Result>;

/**
 * One consumer's hold on a shared delayed stream. Release it when done; the
 * stream is torn down once its last holder releases.
 *
 * @category Delayed video
 */
export interface DelayedStreamLease<Result, Contribution> {
  /** The currently published result, or `undefined` while the build is in
   *  flight. */
  get(): Result | undefined;
  /** Notified whenever the published result changes. */
  subscribe(cb: () => void): () => void;
  /** Update this lease's contribution (call on every render, cheap). */
  setContribution(c: Contribution): void;
  /** Flush the shared pipeline (timeline reset). Affects every consumer,
   *  correct, since they share one buffer. */
  flush(): void;
  /** Detach. The last release tears the pipeline down. */
  release(): void;
}

interface Entry<Result, Contribution> {
  built?: BuiltDelayedStream<Result>;
  result?: Result;
  settled: boolean;
  /** Live leases, in acquisition order: the Map's iteration order is what
   *  makes `contribution()` deterministic ("first still-live lease"). */
  contributions: Map<object, Contribution | undefined>;
  listeners: Set<() => void>;
}

/**
 * Shares one delayed stream between every consumer of the same source, keyed
 * by the source object itself, such as the `MediaStream` every view of one
 * camera holds. Each consumer takes a lease, and the stream is built for the
 * first and torn down after the last.
 *
 * Create your own instance in a test, so its entries stay separate.
 *
 * @category Delayed video
 */
export class SharedDelayedStreams<Result, Contribution, Key = object> {
  private entries = new Map<Key, Entry<Result, Contribution>>();

  /**
   * Attach to the shared pipeline for `key`, building it if this is the
   * first consumer. `build` runs at most once per entry, a second acquire
   * on a live key never builds.
   */
  acquire(
    key: Key,
    build: DelayedStreamBuild<Result, Contribution>,
  ): DelayedStreamLease<Result, Contribution> {
    const token = {};
    let entry = this.entries.get(key);
    const isFirst = entry === undefined;
    if (!entry) {
      entry = {
        settled: false,
        contributions: new Map(),
        listeners: new Set(),
      };
      this.entries.set(key, entry);
    }
    const e = entry;
    e.contributions.set(token, undefined);

    if (isFirst) {
      const ctx: DelayedStreamBuildContext<Contribution> = {
        contribution: () => {
          for (const c of e.contributions.values()) {
            if (c !== undefined) return c;
          }
          return undefined;
        },
      };
      const settle = (built: BuiltDelayedStream<Result>) => {
        // The last lease may have released while the build was in flight, dispose rather than publish a pipeline nobody is watching.
        if (this.entries.get(key) !== e) {
          built.dispose?.();
          return;
        }
        e.built = built;
        e.result = built.result;
        e.settled = true;
        for (const cb of e.listeners) cb();
      };
      const abort = () => {
        // A throwing build leaves nothing to publish; drop the entry so a later
        // acquire on the same key can retry rather than wedging on a
        // permanently-"building" record.
        if (this.entries.get(key) === e) this.entries.delete(key);
      };
      // Settle SYNCHRONOUSLY when `build` is synchronous (the encoded and
      // main-thread backends), so a consumer sees the result in the same tick
      // it acquired: no spurious extra "connecting" frame. Only a genuinely
      // async build (the worker backend) settles on a later microtask.
      let produced:
        | Promise<BuiltDelayedStream<Result>>
        | BuiltDelayedStream<Result>;
      try {
        produced = build(ctx);
      } catch {
        abort();
        produced = undefined as never;
      }
      const dispatchProduced = (p: typeof produced): void => {
        if (p instanceof Promise) {
          void p.then(settle, abort);
          return;
        }
        if (p !== undefined) {
          settle(p);
        }
      };
      dispatchProduced(produced);
    }

    return {
      get: () => e.result,
      subscribe: (cb) => {
        e.listeners.add(cb);
        return () => {
          e.listeners.delete(cb);
        };
      },
      setContribution: (c) => {
        if (e.contributions.has(token)) e.contributions.set(token, c);
      },
      flush: () => e.built?.flush?.(),
      release: () => {
        if (!e.contributions.delete(token)) return; // idempotent
        if (e.contributions.size > 0) return;
        if (this.entries.get(key) === e) this.entries.delete(key);
        e.built?.dispose?.();
        e.built = undefined;
        e.listeners.clear();
      },
    };
  }

  /** Live entry count: for tests/diagnostics. */
  get size(): number {
    return this.entries.size;
  }

  /** Whether `key` currently has a live shared entry. */
  has(key: Key): boolean {
    return this.entries.has(key);
  }
}
