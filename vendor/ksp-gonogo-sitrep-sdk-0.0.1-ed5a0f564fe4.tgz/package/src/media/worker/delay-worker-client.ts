/**
 * Main-thread client for the shared delay worker (cross-browser
 * video-delay design, 2026-07-16). This is the Safari-today /
 * Firefox-once-it-lands backend: see `frame-delay.ts`'s module doc for the
 * full backend picture. It rests on per-engine verification done by hand,
 * because no test harness has these APIs.
 *
 * One worker, lazily spun up on first use, shared across every camera feed
 * on the page, and a camera switch posts a new
 * `createPipeline`/`dispose` pair, never a fresh `new Worker()`.
 *
 * `createWorkerFrameDelayStream` mirrors `createFrameDelayStream`'s
 * contract as closely as an inherently-async operation allows: it resolves
 * `null` (never throws, never rejects) whenever the pipeline can't be
 * built here: no `Worker` support, no video track, the worker rejected
 * construction, or (the common case on Chrome/Firefox as of the
 * verification above) `postMessage(..., [track])` throws synchronously
 * because this engine doesn't support transferring a `MediaStreamTrack`
 * at all. The caller treats a `null` resolution
 * exactly like the main-thread backend's `null` return, "can't delay ⇒
 * no video" (decision 5), never a live fallback.
 *
 * Not unit-tested (see `delay-worker.ts`'s doc for why), thin
 * message-passing glue over already-tested pieces, validated by the manual
 * cross-browser check.
 */

import type { ClockFormulaSnapshot } from "../../view-clock-formula";
import type { CaptureClockSample } from "../capture-clock";
import type { DelayClockLike } from "../delayed-playout-buffer";
import type { FrameDelayStream } from "../frame-delay";
import { startPacingTicker } from "../frame-delay";
import type {
  CreatePipelineMessage,
  MainToWorkerMessage,
  WorkerToMainMessage,
} from "./delay-worker";

/**
 * A {@link DelayClockLike} that can also hand over its state to copy into a
 * worker about 60 times a second. The app's view clock is one.
 *
 * @category Delayed video
 */
export interface SnapshottableDelayClock extends DelayClockLike {
  /** A copy of the clock's formula, to hand to a worker. */
  snapshot(): ClockFormulaSnapshot;
}

/**
 * Options for `createWorkerFrameDelayStream`.
 *
 * @category Delayed video
 */
export interface CreateWorkerFrameDelayStreamOptions {
  /** The clock the delay follows. */
  view: SnapshottableDelayClock;
  /** Read fresh on every ~60Hz tick; forwarded to the worker only when it
   *  actually changed (reference inequality): the low-rate capture clock
   *  updates ~1Hz, no need to resend an unchanged sample 60x/sec. */
  getCaptureSample(): CaptureClockSample;
  /** The most frames the worker holds before dropping the oldest. */
  maxBufferedFrames?: number;
  /** The backlog past which pacing drops frames; see `DEFAULT_PACING_MAX_BACKLOG_SECONDS`. */
  maxPacingBacklogSeconds?: number;
  /** Called with a non-fatal pipeline error. */
  onError?(error: unknown): void;
}

const DEFAULT_MAX_PACING_BACKLOG_SECONDS = 0.5; // see frame-delay.ts's own default + rationale

let sharedWorker: Worker | null | undefined; // undefined = not attempted yet, null = attempt failed
let pipelineCounter = 0;

interface PendingReady {
  resolve(track: MediaStreamTrack): void;
  reject(reason: string): void;
}
const pendingReady = new Map<string, PendingReady>();
const nonFatalErrorHandlers = new Map<string, (reason: string) => void>();

function getSharedWorker(): Worker | null {
  if (sharedWorker !== undefined) return sharedWorker;
  if (typeof Worker === "undefined") {
    sharedWorker = null;
    return null;
  }
  try {
    const worker = new Worker(new URL("./delay-worker.js", import.meta.url), {
      type: "module",
    });
    worker.postMessage({
      type: "init",
      mainTimeOriginMs: performance.timeOrigin,
    } satisfies MainToWorkerMessage);
    worker.onmessage = (ev: MessageEvent<WorkerToMainMessage>) => {
      const msg = ev.data;
      switch (msg.type) {
        case "pipelineReady":
          pendingReady.get(msg.pipelineId)?.resolve(msg.track);
          pendingReady.delete(msg.pipelineId);
          return;
        case "pipelineError":
          pendingReady.get(msg.pipelineId)?.reject(msg.reason);
          pendingReady.delete(msg.pipelineId);
          return;
        case "pipelineNonFatalError":
          nonFatalErrorHandlers.get(msg.pipelineId)?.(msg.reason);
          return;
      }
    };
    sharedWorker = worker;
    return worker;
  } catch {
    sharedWorker = null;
    return null;
  }
}

function post(
  worker: Worker,
  msg: MainToWorkerMessage,
  transfer?: Transferable[],
): void {
  worker.postMessage(msg, transfer ?? []);
}

/** Starts the ~60Hz loop posting `clockSnapshot` (worker-global, so every
 *  pipeline on the shared worker reads the same clock, matches the app's
 *  one real `ViewClock`) and `captureSample` (per-pipeline, only when the
 *  sample reference actually changed) for one pipeline. Returns a stop
 *  function. Shared by both backends this file exposes, narrowed to just
 *  the two members either needs, so `AttachEncodedFrameDelayOptions`
 *  satisfies it structurally without a nominal relationship to
 *  `CreateWorkerFrameDelayStreamOptions`. */
function startPipelineTicker(
  worker: Worker,
  pipelineId: string,
  opts: Pick<CreateWorkerFrameDelayStreamOptions, "view" | "getCaptureSample">,
): () => void {
  let lastSample: CaptureClockSample | null = null;
  return startPacingTicker(() => {
    post(worker, { type: "clockSnapshot", snapshot: opts.view.snapshot() });
    const sample = opts.getCaptureSample();
    if (sample !== lastSample) {
      lastSample = sample;
      post(worker, { type: "captureSample", pipelineId, sample });
    }
  });
}

/**
 * A delayed copy of the first video track of `raw`, with the delay running in
 * a worker. Resolves `null`, and never throws, when it cannot be built,
 * including when the browser refuses to move the track to a worker.
 *
 * @category Delayed video
 */
export async function createWorkerFrameDelayStream(
  raw: MediaStream,
  opts: CreateWorkerFrameDelayStreamOptions,
): Promise<FrameDelayStream | null> {
  // Check worker support BEFORE touching `raw`: cheap, synchronous, and
  // means a caller in a Worker-less environment never needs `raw` to be a
  // real MediaStream-shaped object at all (matters for tests exercising
  // this path with opaque stream tokens, same convention
  // `createFrameDelayStream`'s `isFrameDelaySupported()` guard follows).
  const worker = getSharedWorker();
  if (!worker) return null;

  const track = raw.getVideoTracks()[0];
  if (!track) return null;

  pipelineCounter += 1;
  const pipelineId = `delay-${pipelineCounter}`;

  const readyPromise = new Promise<MediaStreamTrack>((resolve, reject) => {
    pendingReady.set(pipelineId, { resolve, reject });
  });

  const createMsg: CreatePipelineMessage = {
    type: "createPipeline",
    pipelineId,
    track,
    maxBufferedFrames: opts.maxBufferedFrames,
    maxPacingBacklogSeconds:
      opts.maxPacingBacklogSeconds ?? DEFAULT_MAX_PACING_BACKLOG_SECONDS,
  };

  try {
    // The transfer list is what actually moves the track, a browser that
    // doesn't support transferring a MediaStreamTrack (Chrome/Firefox) throws
    // HERE, synchronously, before the worker ever sees the message.
    worker.postMessage(createMsg, [track]);
  } catch (err) {
    pendingReady.delete(pipelineId);
    opts.onError?.(err);
    return null;
  }

  let outputTrack: MediaStreamTrack;
  try {
    outputTrack = await readyPromise;
  } catch (reason) {
    opts.onError?.(new Error(String(reason)));
    return null;
  }

  nonFatalErrorHandlers.set(pipelineId, (reason) => {
    opts.onError?.(new Error(reason));
  });
  const stopTicker = startPipelineTicker(worker, pipelineId, opts);

  return {
    stream: new MediaStream([outputTrack]),
    dispose: () => {
      stopTicker();
      nonFatalErrorHandlers.delete(pipelineId);
      post(worker, { type: "dispose", pipelineId });
    },
    flush: () => {
      post(worker, { type: "flush", pipelineId });
    },
  };
}

// ---------------------------------------------------------------------------
// Encoded-transform backend.
// Empirically validated on Chromium, Firefox and WebKit, gated on a real
// confirmedEdgeUt() computation. Reachable
// from the main-screen and station/broker camera path via
// the camera data source's `getReceiverForStream`: see that method's doc for the
// reconciliation of why this is wireable gonogo-side, no SDK change needed.
// ---------------------------------------------------------------------------

/**
 * Options for `attachEncodedWorkerFrameDelay`.
 *
 * @category Delayed video
 */
export interface AttachEncodedFrameDelayOptions {
  /** The clock the delay follows. */
  view: SnapshottableDelayClock;
  /** Read fresh on every ~60Hz tick, same contract as
   *  `CreateWorkerFrameDelayStreamOptions.getCaptureSample`. */
  getCaptureSample(): CaptureClockSample;
  /** Real byte cap: see `encoded-frame-delay.ts`'s `DEFAULT_MAX_BUFFERED_BYTES`. */
  maxBufferedBytes?: number;
  /** The backlog past which pacing drops frames; see `DEFAULT_PACING_MAX_BACKLOG_SECONDS`. */
  maxPacingBacklogSeconds?: number;
  /** Called with a non-fatal pipeline error. */
  onError?(error: unknown): void;
}

/**
 * What `attachEncodedWorkerFrameDelay` returns.
 *
 * @category Delayed video
 */
export interface EncodedFrameDelayHandle {
  /** Detach the transform (`receiver.transform = null`) and tear down this
   *  pipeline's worker-side state. Idempotent from the caller's
   *  perspective: safe to call once, matching every other backend's
   *  `dispose()` contract in this package. */
  dispose(): void;
  /** Drops the frames the pipeline holds. */
  flush(): void;
}

/**
 * Delays the encoded video arriving at `receiver`, in a worker, before it is
 * decoded. Unlike {@link createWorkerFrameDelayStream} it makes no new stream:
 * keep showing the stream you already have, which is delayed from then on.
 *
 * It takes effect at once or not at all. Returns `null`, and reports through
 * `onError`, when it cannot attach: there is no `Worker`, or the browser's
 * `RTCRtpScriptTransform` threw, as it does when the receiver already has a
 * transform. Check `typeof RTCRtpScriptTransform !== "undefined"` first to
 * skip the attempt on a browser without it. Treat `null` as the delay being
 * unavailable, never as permission to show the live stream.
 *
 * @category Delayed video
 */
export function attachEncodedWorkerFrameDelay(
  receiver: RTCRtpReceiver,
  opts: AttachEncodedFrameDelayOptions,
): EncodedFrameDelayHandle | null {
  const worker = getSharedWorker();
  if (!worker) return null;

  pipelineCounter += 1;
  const pipelineId = `encoded-${pipelineCounter}`;

  try {
    receiver.transform = new RTCRtpScriptTransform(worker, {
      pipelineId,
      maxBufferedBytes: opts.maxBufferedBytes,
      maxPacingBacklogSeconds: opts.maxPacingBacklogSeconds,
    });
  } catch (err) {
    opts.onError?.(err);
    return null;
  }

  nonFatalErrorHandlers.set(pipelineId, (reason) => {
    opts.onError?.(new Error(reason));
  });
  const stopTicker = startPipelineTicker(worker, pipelineId, opts);

  return {
    dispose: () => {
      stopTicker();
      nonFatalErrorHandlers.delete(pipelineId);
      post(worker, { type: "dispose", pipelineId });
      receiver.transform = null;
    },
    flush: () => {
      post(worker, { type: "flush", pipelineId });
    },
  };
}
