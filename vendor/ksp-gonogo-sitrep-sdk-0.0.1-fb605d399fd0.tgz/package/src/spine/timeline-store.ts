import { type Meta, Quality, Staleness } from "../__generated__/contract";
import type { Transport } from "../api/transport";
import {
  type DeclaredDelayRoles,
  type DelayLane,
  delayLaneOf,
  readDeclaredDelayRoles,
} from "../delay-roles";
import { magnitudeOr, type Quantityish } from "../magnitude";
import { PerfBudget } from "../perf/PerfBudget";
import { splitRawFieldSubtopic } from "../raw-field-split";
import type {
  AnyReckonerDefinition,
  BandKind,
  DepWindow,
  ReckonerWindow,
  ReckoningBasis,
  ReckoningDecline,
  StaleGrade,
  TopicModel,
  UncertaintyBand,
} from "../reading";
import { bandIsWellFormed } from "../reading";
import { reckonableInputSpelling, reckonableValuesOf } from "../reckonability";
import type { DerivedChannelDefinition, DerivedGet } from "../timeline";
import { isValue, type Value, value } from "../unit-system/value";
import {
  type ReckonerFor,
  readingFrom,
  type TopicReading,
} from "./client-reading";
import {
  ClientTimeline,
  type ClientTimelineOptions,
  type TimelinePoint,
} from "./client-timeline";
/**
 * The derived-channel authoring types moved to `@ksp-gonogo/sitrep-sdk` so an Uplink
 * can write a channel without importing this package. Re-exported here unchanged.
 */
import {
  HeartbeatTracker,
  type HeartbeatTrackerOptions,
} from "./heartbeat-tracker";
import { getProcessorValue } from "./processorEvaluator";
import { type Dep, isSubjectDep, type SubjectDep } from "./processors";
import {
  CORE_RECKONER_OWNER,
  getReckoner,
  getReckonerConflicts,
} from "./reckoners";
import { shareEqual } from "./share-equal";
import type { StreamStatusValue } from "./stream-status";
import { worstStatus } from "./stream-status";
import type { Certainty, ViewClock } from "./view-clock";

export type { DerivedChannelDefinition, DerivedGet } from "../timeline";

/**
 * The frozen view-time token for one frame / read cycle, enforces the
 * "single-view-time invariant". There is deliberately no method
 * anywhere in this file that reads "the current time" and hands back a
 * fresh UT per call: every read goes through a `FrameToken`, and a token's
 * `viewUt` never changes after it's minted. That's what makes the
 * invariant structural rather than a convention callers have to remember.
 */
export interface FrameToken {
  readonly viewUt: number;
  /**
   * The same instant for a channel the mod declares `DelayRole.TrueNow`: the
   * live estimate, with no light-time subtracted. Frozen at mint alongside
   * `viewUt` and for the same reason, so a frame that reads both kinds of topic
   * reads each of them at one instant rather than at whatever the clock had
   * reached by that particular read.
   *
   * A whole light-time ahead of `viewUt` at a real delay and EQUAL to it at
   * zero, which is why nothing in the tree could see the difference until the
   * mod started classifying: with `delaySeconds()` at 0 the two edges are the
   * same number.
   */
  readonly trueNowViewUt: number;
  /**
   * Internal validity marker, bumped by every `beginFrame()` call. Not
   * meant to be read by callers, it's what lets `sample()` detect a token
   * a caller cached across a frame boundary and fall back to the current
   * frame instead of honoring a frozen-in-the-past `viewUt` forever.
   */
  readonly generation: number;
  /**
   * Whether `viewUt` sits at-or-before the `ViewClock`'s certainty horizon
   * as of the moment this token was minted. Computed once
   * here: NOT recomputed against the live clock on each read, for the
   * same frame-coherence reason values are memoized per token: a mid-frame
   * `ingest` that nudges the horizon forward must not flip a read's
   * certainty mid-frame any more than it can flip its value. See
   * `TimelineStore.sampleCertainty`.
   */
  readonly certainty: Certainty;
  /** {@link certainty} for {@link trueNowViewUt}, against the true-now horizon. Classifying a true-now read against the DELAYED horizon would report `"predicted"` for every one of them, the reading being a light-time past it by construction. */
  readonly trueNowCertainty: Certainty;
}

/**
 * Freeze both view times and both certainties off one clock, in one place.
 *
 * One place because the two mint sites (the constructor and `beginFrame`) have
 * to agree: a token minted with only one lane filled in would read every
 * true-now topic at `undefined` view time, and a constructor that quietly
 * disagreed with `beginFrame` would do it only on the first frame.
 */
function mintToken(clock: ViewClock, generation: number): FrameToken {
  const viewUt = clock.viewUt("delayed");
  const trueNowViewUt = clock.viewUt("true-now");
  return {
    viewUt,
    trueNowViewUt,
    generation,
    certainty: clock.certaintyFor(viewUt, "delayed"),
    trueNowCertainty: clock.certaintyFor(trueNowViewUt, "true-now"),
  };
}

export interface TimelineStoreOptions {
  timelineOptions?: ClientTimelineOptions;
  /** Options for the store's `HeartbeatTracker` (the keyframe-cadence heartbeat), per-topic keyframe intervals, staleness-margin tuning. */
  heartbeatOptions?: HeartbeatTrackerOptions;
  /**
   * Dynamic-namespace prefixes (each ending in `.`) whose topics are WHOLE raw
   * wire topics despite having 3+ dot-segments. A generated topic list cannot
   * stand in for this: these ids are computed at runtime (per body, per part,
   * per CPU) and so have no member in any list to match against, which is why
   * the prefix mechanism survives `splitRawFieldSubtopic`'s longest-known-topic
   * lookup rather than being folded into it. A topic that
   * `startsWith` any of these resolves to its own identity in
   * `resolveRawFieldSubtopic` (and thus `resolveSubscriptionTopics`), instead of
   * being mis-split into a `<domain.channel>.<fieldPath>` parent that no channel
   * publishes. Injected (never hard-coded) so this mod-agnostic store names no
   * mod token: the app passes `DYNAMIC_CARRIED_TOPIC_PREFIXES`
   * (`default-carried-topics.ts`) for the Uplink per-(body,type) namespaces.
   */
  dynamicWholeTopicPrefixes?: readonly string[];
  /**
   * How the store holds up a topic a {@link SubjectDep} resolved, for as long
   * as that subject stands. Returns its own release.
   *
   * The store owns this lifetime and nothing else can: the subject is not known
   * at subscribe time, so the read's own set (`subscribeTopicRead`, resolved
   * once when the read mounts) cannot contain it, and a model declaring a
   * per-subject input without this would decline `input-absent` for ever while
   * nothing anywhere held the topic up. That is not a hypothetical failure
   * mode, it is #193/#195 exactly, where a declared-but-unsubscribed dep made
   * one widget decline while the widget beside it reckoned fine.
   *
   * Injected rather than a client, for the same reason the processor evaluator
   * takes an injected subscribe: this store is mod-agnostic and holds no
   * transport. Absent, a subject dep still RESOLVES against whatever is already
   * flowing and simply never holds anything up itself, which is the honest
   * degradation for a test double that wires no subscriber.
   */
  subscribeDynamicTopic?: (topic: string) => () => void;
}

/**
 * Whether a model claiming `covered` has answered for a read of `fieldPath`.
 *
 * Segment-wise, never a string prefix: `relativePosition` must not answer for
 * `relativePositionError`, which is a different field that happens to start
 * with the same characters. `""` covers everything, being the payload root.
 */
function coversPath(covered: string, fieldPath: readonly string[]): boolean {
  if (covered === "") return true;
  const segments = covered.split(".");
  if (segments.length > fieldPath.length) return false;
  return segments.every((segment, i) => segment === fieldPath[i]);
}

/** Walk a dotted path into a modelled payload, the read half of `coversPath`. */
function walkFieldPath(value: unknown, fieldPath: readonly string[]): unknown {
  let cursor = value;
  for (const segment of fieldPath) {
    if (cursor === null || typeof cursor !== "object") return undefined;
    cursor = (cursor as Record<string, unknown>)[segment];
  }
  return cursor;
}

/**
 * Which lane a derived channel is read in: the most conservative of its
 * declared inputs.
 *
 * A channel with NO declared inputs derives from constants and is as current as
 * the frame either way, so it takes the delayed lane with everything else
 * rather than being special-cased into the one that can run ahead.
 *
 * Reads `def.inputs` and not what `derive` actually consulted, because the lane
 * has to be decided before `derive` runs. A channel that consults a subset of
 * its declared inputs is therefore read no more current than the input it
 * declared and skipped, which is the safe direction of that inaccuracy.
 */
function derivedLane(
  def: DerivedChannelDefinition<unknown>,
  declaredLane: (topic: string) => DelayLane,
): DelayLane {
  const inputs = def.inputs ?? [];
  return inputs.length > 0 &&
    inputs.every((topic) => declaredLane(topic) === "true-now")
    ? "true-now"
    : "delayed";
}

/** Synthetic envelope `Meta` stamped on a derived-channel read. Real staleness/quality propagation from inputs (derived channels ultimately should propagate the worst input staleness) is not yet implemented, this is intentionally minimal, just enough to satisfy the `Meta` shape every `TimelinePoint` carries. */
function derivedMeta(viewUt: number, epoch: number): Meta {
  return {
    source: "derived",
    validAt: viewUt,
    seq: 0,
    deliveredAt: viewUt,
    vantage: "derived",
    quality: Quality.OnRails,
    active: true,
    staleness: Staleness.Fresh,
    timelineEpoch: epoch,
  };
}

/**
 * One instant a model answered for, and what answered. NEVER an observation:
 * see `TimelineStore.sampleReckonedTail`, which is the only thing that mints
 * one and hands it straight to the boundary that draws it.
 *
 * Not a `TimelinePoint`, on purpose. A `TimelinePoint` is what the craft sent,
 * it carries a `Meta` full of the wire's own claims about provenance and
 * staleness, and there is no honest thing to put in those fields for an instant
 * nothing arrived at. Substituting plausible ones is exactly how a projection
 * becomes indistinguishable from a reading.
 */
export interface ReckonedSample<T> {
  /** The UT the model answered FOR. */
  atUt: number;
  /**
   * The model's answer: a finite `number`, or a finite `Value` with its unit
   * still on it. A payload that arrived wrapped stays wrapped all the way to
   * the boundary that plots it, which is the only place a magnitude is taken.
   */
  value: T;
  basis: ReckoningBasis;
  /**
   * How well the model knew this instant, present only where the model offered
   * a band for the root path.
   *
   * In the value's own unit BY CONSTRUCTION: {@link ReckonedBound} resolves to
   * the same quantity type `value` carries, so an end in another unit is a
   * compile error at the consumer and is dropped at the producer. It used to be
   * a pair of bare magnitudes resting on a sentence in {@link UncertaintyBand}'s
   * doc comment, which was the only thing saying which unit they were in; that
   * became a real exposure when the point estimate started carrying a unit,
   * because until then there was nothing for the two ends to disagree with.
   *
   * The magnitudes are taken where the value's is, at the boundary that plots
   * it (`@ksp-gonogo/data`'s `useDataSeries`), so the three travel to the chart
   * together rather than one of them arriving there already unwrapped.
   *
   * The three move together. Either all of `bandLo`, `bandHi` and `bandKind`
   * are here or none is; a half-band is a producer bug and reads downstream as
   * no band at all.
   */
  bandLo?: ReckonedBound<T>;
  bandHi?: ReckonedBound<T>;
  bandKind?: BandKind;
}

/**
 * The quantity one end of a {@link ReckonedSample}'s band is in: whatever the
 * sample's own value is in.
 *
 * A sample whose value is a bare magnitude still gets a wrapped end, because a
 * band is only ever minted from an {@link UncertaintyBand} and that type's ends
 * are `Value`s whatever the payload holds. `Value` with its unit left open is
 * the honest answer there: nothing in the payload says what the number measures,
 * so nothing here can promise the end agrees with it.
 */
export type ReckonedBound<T> = T extends Value<infer U> ? Value<U> : Value;

/**
 * What a topic's own model says happened across the part of a gap between two
 * samples that nothing observed. See {@link TimelineStore.gapModel}.
 *
 * `carried: false` is a model that claimed the plotted path at the earlier
 * sample and withdrew before the span ended, so nothing can say what the value
 * did there. `carried: false, unclaimed: true` is the same answer reached with
 * no model at all: nothing claims the plotted path, and the span is wider than
 * the mod samples at when warp is not thinning it, so the part beyond that is
 * one the sampling skipped and a chord across it is a path nothing observed.
 * `carried: true` holds the model's answers at instants strictly inside the
 * span, for a chart to hold its own chord against: this type says what the
 * model claims, and only the chart knows whether a difference is one it can
 * draw.
 */
export type GapModel =
  | { readonly carried: false }
  | { readonly carried: false; readonly unclaimed: true }
  | {
      readonly carried: true;
      readonly basis: ReckoningBasis;
      readonly t: readonly number[];
      /** The model's answers at `t`, wrapped exactly as a reckoned tail's are. */
      readonly v: readonly unknown[];
    };

/** The answer for a span wider than warp-free sampling that no model claims. */
const UNCLAIMED: GapModel = { carried: false, unclaimed: true };

/**
 * How many instants inside one unobserved span the model is asked about. Enough
 * to draw one full swing of an orbit smoothly, which is the most a single span
 * can hide before the samples themselves start to alias it.
 */
const GAP_MODEL_SAMPLES = 24;

/**
 * The most instants one reckoned tail may be sampled at.
 *
 * A RESOLUTION cap, never a horizon: exceeding it widens the stride so the tail
 * still reaches the view time, because shortening it instead would silently
 * draw a shorter horizon than the model actually claimed, which is the one
 * thing this cap must not be able to do.
 *
 * 48 draws a conic smoothly at any chart width this app renders, and bounds the
 * per-frame cost of asking a model for a value at a few thousand a second across
 * a dashboard's worth of plotted series.
 */
const MAX_RECKONED_TAIL_SAMPLES = 48;

/** The engine-built roster whose `delayRoles` block decides every declared topic's lane. */
const UPLINK_ROSTER_TOPIC = "system.uplinks";

/**
 * How far apart to sample a reckoned tail: the cadence the observations
 * themselves were arriving at, widened if that would overrun the resolution
 * cap.
 *
 * Matching the observed cadence rather than picking a number is what keeps the
 * modelled run drawn at the same fidelity as the measured run beside it, so the
 * eye reads the change in STROKE rather than a change in how blocky the line
 * is. With fewer than two observations in the window there is no cadence to
 * match and the whole tail is one stride.
 */
function reckonedTailStep(
  inWindowUts: readonly number[],
  lastObservedUt: number,
  toUt: number,
): number {
  const span = toUt - lastObservedUt;
  const gaps: number[] = [];
  for (let i = 1; i < inWindowUts.length; i++) {
    gaps.push(inWindowUts[i] - inWindowUts[i - 1]);
  }
  gaps.sort((a, b) => a - b);
  // Median, not mean: one long pause inside the window is exactly the thing a
  // mean would let dominate the cadence of everything after it.
  const cadence = gaps.length > 0 ? gaps[gaps.length >> 1] : span;
  const floor = span / MAX_RECKONED_TAIL_SAMPLES;
  return Math.max(cadence > 0 ? cadence : span, floor);
}

/**
 * A model's answer as something a LINE can be drawn through, or nothing.
 *
 * The finiteness test for a `Value` is the algebra's own `isFinite()` rather
 * than `Number.isFinite` over an unwrapped magnitude, so asking whether a
 * quantity is drawable costs no unwrap: the whole point of carrying the wrapper
 * this far is that the magnitude is taken once, where the chart is built.
 *
 * See {@link TimelineStore.sampleReckonedTail}'s "Only a continuous quantity
 * gets a tail" for what the exclusions buy and which shape still slips through.
 */
function plottableQuantity(raw: unknown): number | Value | undefined {
  if (typeof raw === "number") return Number.isFinite(raw) ? raw : undefined;
  if (isValue(raw)) return raw.isFinite() ? raw : undefined;
  return undefined;
}

/**
 * Whether a band is about the quantity the model just answered with, rather
 * than merely about some quantity.
 *
 * `bandIsWellFormed` asks whether the three ends agree with EACH OTHER, which a
 * band in the wrong unit passes. This is the other half: the band's own `value`
 * is contractually the number `reckon` produced at that path, so where the
 * reckoned value is a quantity the two units have to be the same string.
 *
 * A bare-magnitude value is accepted with any band, because there is nothing to
 * compare it against and refusing every band on those topics would take the
 * shading off the one shape that has carried it longest.
 */
function bandDescribes(
  drawable: number | Value,
  band: UncertaintyBand,
): boolean {
  return !isValue(drawable) || drawable.unit === band.value.unit;
}

/**
 * The newest run of `points` with no break in the record inside it.
 *
 * A window that spans a blackout must not be handed over whole: a model given
 * samples from either side of one draws a trend through an outage it has no
 * readings for, which is the same falsehood as a chart joining a line across
 * it. So the run is cut at the newest break and whatever survives goes to the
 * model, where the reckoner's own `minSamples` decides whether it is still
 * enough. That is why there is no separate "the window hit a gap" rejection:
 * truncating feeds the floor that already exists.
 *
 * Two things count as a break, and BOTH are positive claims. `meta.gapSinceUt`
 * is the producer saying data existed before this sample and is gone, set only
 * on the first sample after the break, so that sample is kept and everything
 * older is dropped. A tombstone (`payload === null`) is the value confirmed
 * ABSENT and later back, which is a change of regime and not a reading, so it
 * goes too.
 *
 * Nothing here looks at the interval between samples, and nothing here may. The
 * stream is change-gated: a topic carries a point only when its value actually
 * changed, so a quiet minute and a minute of blackout are the same shape in the
 * buffer and opposite facts about the world. Only a claim can tell them apart.
 */
function contiguousTail<T>(
  points: readonly TimelinePoint<T>[],
): TimelinePoint<T>[] {
  for (let i = points.length - 1; i >= 0; i--) {
    const point = points[i];
    if (point.payload === null) return points.slice(i + 1);
    if (point.meta.gapSinceUt != null) return points.slice(i);
  }
  return [...points];
}

/**
 * A window as the store resolved it, plus whether a break is what shortened it.
 *
 * The flag exists for the decline sentence and nothing else. "The window holds
 * two samples" and "the window holds two samples because the other four are on
 * the far side of a blackout" send an operator to different places, and only
 * the store is in a position to tell them apart.
 */
interface ResolvedWindow<T> {
  readonly points: TimelinePoint<T>[];
  readonly truncatedAtBreak: boolean;
}

/**
 * `points` reduced to at most `max`, keeping both ends and spreading the rest
 * evenly by INDEX.
 *
 * `maxSamples` is a cost cap, not a rejection, so a fuller window thins and the
 * model runs. Spreading by index rather than by UT is deliberate: an even
 * spread in time would need an expected interval, and the change-gated stream
 * does not have one.
 */
function thinTo<T>(
  points: TimelinePoint<T>[],
  max: number,
): TimelinePoint<T>[] {
  if (max <= 0) return [];
  if (points.length <= max) return points;
  if (max === 1) return [points[points.length - 1]];
  const last = points.length - 1;
  const out: TimelinePoint<T>[] = [];
  for (let i = 0; i < max; i++) {
    out.push(points[Math.round((i * last) / (max - 1))]);
  }
  return out;
}

/**
 * What a tail walk needs from a topic's model: when the observations stop, the
 * cadence they were arriving at, and one question the walk can ask per instant.
 */
interface ReckonedWalk {
  /** The newest instant an observation behind this topic exists for. */
  lastObservedUt: number;
  /** Every observed instant, unfiltered: the caller windows and sorts them. */
  inWindowUts: number[];
  /**
   * The model's answer for one instant, or nothing where it declines.
   *
   * `band` is the root-path band where the model offered one, and it is asked
   * per instant rather than once for the walk because widening with elapsed
   * time is the whole content of a band: one interval reused down the tail
   * would draw a parallel-sided ribbon and assert that carrying a value
   * further costs nothing.
   */
  answerAt(at: number):
    | {
        value: unknown;
        basis: ReckoningBasis;
        band?: UncertaintyBand;
      }
    | undefined;
}

/**
 * Model answers asked for a reckoned tail.
 *
 * Every one is provider-supplied compute on the frame path, and there are up to
 * `MAX_RECKONED_TAIL_SAMPLES` of them per plotted series per frame. The cap
 * bounds one tail; this catches the case the cap cannot see, which is a
 * dashboard that has quietly acquired enough modelled traces to spend the frame
 * budget on arithmetic nobody measured. The tail is memoised per frame, so a
 * healthy dashboard of four modelled series sits near 6k/sec at 60fps.
 */
const RECKONED_TAIL_BUDGET = new PerfBudget({
  name: "Reckoned tail derives/sec",
  threshold: 20_000,
  windowMs: 1000,
  unit: "derives",
});

/**
 * Field names that carry a DEGREE-valued angle where wrapping is physically
 * meaningful: e.g. `longitude` 179 -> -179 is a
 * 2-degree hop across the antimeridian, not a ~358-degree hop the other way
 * around the planet. Interpolated the SHORT way around the wrap in
 * `lerpFieldValue` below, instead of the naive straight-line lerp every
 * other numeric field gets. A small, explicit allowlist rather than a
 * heuristic (no name-sniffing for "looks like an angle"), extend this set
 * deliberately as more angular fields (heading, bearing) actually appear in
 * a payload.
 */
const ANGULAR_DEGREE_FIELD_NAMES: ReadonlySet<string> = new Set([
  "longitude",
  "heading",
  "bearing",
]);

/**
 * Field names that are numeric but not genuinely continuous, an index,
 * enum ordinal, or other discrete quantity where a fractional value is
 * physically meaningless: e.g.
 * `referenceBodyIndex` 1 -> 2 must never become `1.5`. Held at `before`
 * rather than fractionalized, mirroring how a non-numeric field that's
 * identical on both sides already passes through unchanged. Same
 * explicit-allowlist reasoning as `ANGULAR_DEGREE_FIELD_NAMES`: extend
 * deliberately, don't infer from naming conventions.
 */
const DISCRETE_NUMERIC_FIELD_NAMES: ReadonlySet<string> = new Set([
  "referenceBodyIndex",
]);

/** Normalize a degree value into `(-180, 180]`. */
function normalizeDegrees(deg: number): number {
  const wrapped = ((((deg + 180) % 360) + 360) % 360) - 180;
  // The above maps 180 -> -180; prefer the +180 representative for the
  // boundary case so a stationary angle round-trips exactly.
  return wrapped === -180 ? 180 : wrapped;
}

/** Interpolate a degree-valued angle the SHORT way around the wrap, at `t` in `[0, 1]`. */
function lerpAngleDegrees(before: number, after: number, t: number): number {
  const diff = normalizeDegrees(after - before);
  return normalizeDegrees(before + diff * t);
}

/**
 * Interpolate one field value at `t`, honoring the angular-wrap and
 * discrete-field policies above. Falls back to
 * the caller's identical-value-passthrough / refuse-on-mismatch handling for
 * anything that isn't a plain number pair.
 */
function lerpFieldValue(
  key: string,
  before: unknown,
  after: unknown,
  t: number,
): { value: unknown } | undefined {
  // A declared quantity arrives WRAPPED, so the numeric branch below would
  // never fire for it and every measured field would hold-last instead of
  // interpolating. Lerp the magnitudes and re-declare the unit: both samples
  // are the same field on the same topic, so their units agree by
  // construction.
  if (isValue(before) && isValue(after)) {
    const lerped = lerpFieldValue(key, before.magnitude, after.magnitude, t);
    if (lerped === undefined || typeof lerped.value !== "number") {
      return undefined;
    }
    return { value: value(before.unit, lerped.value) };
  }
  if (typeof before === "number" && typeof after === "number") {
    if (DISCRETE_NUMERIC_FIELD_NAMES.has(key)) {
      return { value: before }; // hold-last; never fractionalize an index/ordinal
    }
    if (ANGULAR_DEGREE_FIELD_NAMES.has(key)) {
      return { value: lerpAngleDegrees(before, after, t) };
    }
    return { value: before + (after - before) * t };
  }
  if (Object.is(before, after)) return { value: before };
  return undefined;
}

/**
 * Linearly interpolate between two payloads of matching shape at `t` in
 * `[0, 1]`: the confirmed-range interpolation primitive.
 * Numeric payloads lerp directly. A plain (non-array, non-null) object
 * lerps field-by-field via `lerpFieldValue`: a genuinely continuous numeric
 * field lerps straight-line, an ANGULAR field (`ANGULAR_DEGREE_FIELD_NAMES`)
 * wraps the short way instead of blending through the far side of the
 * wrap, a DISCRETE numeric field (`DISCRETE_NUMERIC_FIELD_NAMES`) holds at
 * `before` rather than fractionalizing, a non-numeric field that is
 * IDENTICAL on both sides passes through unchanged (e.g. an unchanged
 * string/enum field), and a non-numeric field that actually DIFFERS makes
 * the whole interpolation refuse (`undefined`): there is no honest halfway
 * point between two different strings, and a caller asking for a lerp
 * should never get a silently-wrong blended object back. Anything else
 * (arrays, non-number/non-object primitives, mismatched key sets) also
 * returns `undefined`, signalling "fall back to hold-last" to the caller.
 */
export function lerpPayload<T>(before: T, after: T, t: number): T | undefined {
  if (typeof before === "number" && typeof after === "number") {
    return (before + (after - before) * t) as T;
  }

  if (
    before !== null &&
    after !== null &&
    typeof before === "object" &&
    typeof after === "object" &&
    !Array.isArray(before) &&
    !Array.isArray(after)
  ) {
    const beforeObj = before as Record<string, unknown>;
    const afterObj = after as Record<string, unknown>;
    const keys = Object.keys(beforeObj);
    if (keys.length === 0) return undefined;
    if (keys.some((key) => !(key in afterObj))) return undefined;

    const result: Record<string, unknown> = {};
    for (const key of keys) {
      const lerped = lerpFieldValue(key, beforeObj[key], afterObj[key], t);
      if (!lerped) return undefined;
      result[key] = lerped.value;
    }
    return result as T;
  }

  return undefined;
}

/**
 * `TimelineStore.sampleInterpolated`'s core: straddle `viewUt` in `timeline`
 * and lerp, falling back to hold-last (`ClientTimeline.at`) whenever
 * there's nothing to straddle, either bracketing point is a tombstone
 * (never interpolate across an absence transition: the confirmed truth
 * mid-transition is still "whatever was last known", not a fabricated
 * blend toward/away from `null`), or `lerpPayload` can't
 * honestly produce a value.
 */
function interpolatedRead<T>(
  timeline: ClientTimeline<T>,
  viewUt: number,
): TimelinePoint<T> | undefined {
  const straddle = timeline.straddle(viewUt);
  if (!straddle) return timeline.at(viewUt);

  const [before, after] = straddle;
  if (before.payload === null || after.payload === null) return before;

  const span = after.validAt - before.validAt;
  const t = span === 0 ? 0 : (viewUt - before.validAt) / span;
  const payload = lerpPayload(before.payload, after.payload, t);
  if (payload === undefined) return before;

  return {
    validAt: viewUt,
    payload,
    meta: before.meta,
    epoch: before.epoch,
  };
}

/**
 * Ties per-topic `ClientTimeline`s to the one shared `ViewClock` and mints
 * the frozen `FrameToken` every read goes through.
 *
 * Two consumption tiers:
 * - **Reactive**: `subscribeFrame` + `sample` back a `useSyncExternalStore`
 *   hook that reads at whatever `FrameToken`
 *   `currentFrame()` currently holds, it does NOT mint its own token per
 *   render, so two components rendering in the same frame see the same
 *   `viewUt` even if wall time ticks between their renders.
 * - **Imperative**: `sample(topic, token)` for a caller's own rAF loop
 *   (canvas widgets): pass the token from `currentFrame()` (or one you
 *   minted yourself with `beginFrame()`) explicitly.
 *
 * This is the foundation derived channels build on, along with staleness
 * consumption and confirmed-vs-predicted reads.
 * Derived-channel registration (`registerDerivedChannel`) is implemented
 * here: see `sample`/`sampleDerived` for how a derived topic is resolved
 * and memoized through the exact same per-frame cache raw topics use.
 */
export class TimelineStore {
  private readonly timelines = new Map<string, ClientTimeline<unknown>>();
  private readonly derivedChannels = new Map<
    string,
    DerivedChannelDefinition<unknown>
  >();
  private readonly frameListeners = new Set<() => void>();
  private currentToken: FrameToken;
  private generation = 0;

  /**
   * The topic each reckoner's {@link SubjectDep} currently holds up, keyed by
   * the reckoner's own topic.
   *
   * One entry per reckoner topic, not per subject: a model has one subject at a
   * time, and a route that moves to a different relay should stop holding up
   * the old relay's orbit rather than accumulate both. The entry is replaced
   * (old released first) when the subject changes, and swept when the reckon
   * stops happening at all, which is what "the last reader goes" looks like
   * from in here: nothing reads, nothing reckons, nothing touches the entry.
   */
  private readonly subjectSubscriptions = new Map<
    string,
    { topic: string; release: () => void; generation: number }
  >();

  /**
   * The subscribe seam {@link holdSubjectTopic} uses, late-bound.
   *
   * A store is built BEFORE its client and outlives a client swap
   * (`attachStore`/`subscribeStore` re-wire the same store to a new one), so a
   * subscribe captured at construction would be a dead client's after the first
   * swap. Set from the provider's effect and cleared on unmount, exactly as
   * `setProcessorTopicSubscriber` does for the evaluator's own seam.
   *
   * The constructor option remains for a caller that has one up front, which is
   * every test double.
   */
  private dynamicSubscriber?: (topic: string) => () => void;

  /**
   * Wire (or clear) the subscribe a per-subject dep's topic is held up with.
   *
   * Clearing releases what is currently held: those subscriptions belong to the
   * client going away, and keeping their releases would call a dead client's.
   */
  setDynamicSubscriber(
    subscribe: ((topic: string) => () => void) | undefined,
  ): void {
    this.dynamicSubscriber = subscribe;
    if (subscribe !== undefined) return;
    for (const entry of this.subjectSubscriptions.values()) entry.release();
    this.subjectSubscriptions.clear();
  }

  /**
   * Per-`FrameToken` memoization cache, gives frame coherence: the same
   * `(token, topic)` read always returns the same result for that token's
   * lifetime. Keyed by token object identity via a `WeakMap` so it never
   * needs manual cleanup, once a token is no longer referenced anywhere
   * (including as `currentToken`), its cache entry is collected too. The
   * first `sample(topic, token)` read for a given `(token, topic)` pair is
   * authoritative for that token's whole lifetime; a mid-frame `ingest`
   * cannot flip it. Also the seam derived channels reuse instead of
   * building their own per-frame cache.
   */
  private readonly frameCache = new WeakMap<FrameToken, Map<string, unknown>>();

  /**
   * What each derived channel answered last, and the point served for each of
   * its field subtopics. A frame whose `derive` comes out structurally equal
   * hands back these same objects, so a reader comparing by reference sees a
   * change only when the record really moved. Keyed by definition, so a
   * channel re-registered under the same topic starts clean.
   */
  private readonly derivedCarry = new WeakMap<
    DerivedChannelDefinition<unknown>,
    { value: unknown; points: Map<string, TimelinePoint<unknown>> }
  >();

  /**
   * Last `Reading` per topic, with the inputs it was built from, so a reading's
   * identity tracks its DATA rather than the frame it was read in. Deliberately
   * NOT the frame cache, which is keyed on a token that changes every ingest
   * tick: see `sampleReading` for why that distinction is load-bearing.
   */
  /**
   * One judgement per plotted topic per later sample of a gap, with everything
   * it was judged from. Weak, so a sample that leaves the buffer takes its
   * judgements with it.
   */
  private readonly gapModels = new WeakMap<
    TimelinePoint<unknown>,
    Map<string, { readonly key: string; readonly answer: GapModel | undefined }>
  >();
  private readonly readings = new Map<
    string,
    {
      point: TimelinePoint<unknown> | undefined;
      status: StreamStatusValue;
      epoch: number;
      /** The frame view time the reading was built for. Only a reckoning depends on it. */
      viewUt: number;
      /** Whether the topic was known unowned. Flips the arm with no other input changing. */
      unowned: boolean;
      /**
       * The decline that was on the reading, flattened to a comparable string.
       * Its own input, because it is a function of OTHER topics' data.
       */
      declineKey: string | undefined;
      reading: TopicReading<unknown>;
    }
  >();

  /**
   * Topics the mod answered a subscribe for with nothing, so nothing will ever
   * publish them. Fed by `TelemetryClient`, which owns the ack tracker that
   * decides it; the store only remembers the verdict and folds it into the arm.
   *
   * A `Set` of the exceptional case rather than a status per topic, because the
   * overwhelming majority of topics are owned and saying so costs nothing.
   */
  private readonly unownedTopics = new Set<string>();

  /**
   * The topics whose input rules are being settled right now, so a cycle among
   * models cannot recurse forever.
   *
   * Enforcing the rules means asking each declared input's OWN model how far it
   * reaches and how well it knows its answer, which is another registered model
   * with its own declared inputs. Nothing forbids two owners registering models
   * that name each other's topics, and a cycle would otherwise be a stack
   * overflow on a frame rather than a decline. A topic already on this set is
   * skipped: a model cannot bound itself, and the model that started the walk is
   * the one whose answer is being judged.
   */
  private readonly enforcingInputRules = new Set<string>();

  /** Missed-keyframe-heartbeat tracker backing `sampleStatus`'s client-inferred `"held-stale"`. */
  readonly heartbeats: HeartbeatTracker;

  /**
   * Whole-transport connectivity, fed by `setTransportConnected`/
   * `attachTransport` (the "transport-down short-circuit": see
   * `sampleRawStatus`). Defaults to `true` (connected) so a caller that never
   * wires this up sees today's pure per-topic heartbeat inference unchanged,
   * this is opt-in, so `TimelineStore` needs no direct `Transport`
   * reference by default.
   */
  private transportConnected = true;

  /**
   * The delay roles the mod stated on the newest `system.uplinks` delivered.
   * `undefined` before one arrives and when the newest carried none (a mod older
   * than contract 16.13), which leaves every lane on the generated core table.
   *
   * Captured at ingest rather than read off that topic's timeline, because a
   * role is a fact about the running mod rather than about a moment: a rewind
   * that empties the roster's timeline must not drop every Uplink channel back
   * into the delayed lane until the next keyframe.
   */
  private declaredRoles: DeclaredDelayRoles | undefined;

  constructor(
    readonly clock: ViewClock,
    private readonly options: TimelineStoreOptions = {},
  ) {
    this.currentToken = mintToken(clock, this.generation);
    this.heartbeats = new HeartbeatTracker(options.heartbeatOptions);
  }

  /**
   * Set whole-transport connectivity.
   * While `false`, `sampleStatus` short-circuits every topic that has
   * confirmed data to `"disconnected"` immediately, instead of letting each
   * one independently drift into `"held-stale"` on its own heartbeat margin;
   * see `sampleRawStatus` for the full precedence against server-stamped
   * staleness and a confirmed `"absent"` tombstone, both of which still win
   * outright over this.
   */
  setTransportConnected(connected: boolean): void {
    this.transportConnected = connected;
  }

  /**
   * Convenience wiring of `setTransportConnected` directly off a `Transport`
   * (or anything with the same `status`/`onStatusChange` shape, e.g. the one
   * `TelemetryClient` holds), seeds the current status immediately and
   * keeps it live via `onStatusChange`. Only `"connected"` counts as
   * connected; `"reconnecting"`/`"error"`/`"disconnected"` all collapse to
   * the same disconnected input: this layer only distinguishes "the
   * link is currently reliable" from "it isn't"; the finer `TransportStatus`
   * taxonomy is presentation detail this layer doesn't need. Returns an
   * unsubscribe function.
   */
  attachTransport(
    transport: Pick<Transport, "status" | "onStatusChange">,
  ): () => void {
    this.setTransportConnected(transport.status === "connected");
    return transport.onStatusChange((status) => {
      this.setTransportConnected(status === "connected");
    });
  }

  /**
   * Append a delivered sample for `topic` and feed its timing into the
   * shared `ViewClock`. Does NOT advance the frame, ingest and frame
   * advance are independent (many samples can arrive within one frame; the
   * frame only advances on `beginFrame()`).
   *
   * Store-level epoch guard (avoids "the client ghost", a stale point
   * surviving a reconnect/epoch bump):
   * the store, not any individual `ClientTimeline`, is the epoch
   * authority. A point tagged with an epoch lower than the shared clock's
   * current epoch is refused outright, even for a topic whose
   * `ClientTimeline` has never been touched (a freshly-created timeline
   * defaults to epoch 0, which would otherwise wrongly admit a pre-rewind
   * straggler as if it were live). If this ingest is the one that bumps the
   * clock's epoch, every other registered timeline is swept forward to the
   * new epoch immediately, so a topic that hasn't re-sampled since the
   * rewind goes cold right away instead of continuing to serve dead-epoch
   * points until it happens to receive its own next sample.
   */
  ingest<T>(topic: string, point: TimelinePoint<T>): void {
    const priorEpoch = this.clock.getEpoch();
    if (point.epoch < priorEpoch) {
      // Stale-epoch straggler by the store's authoritative epoch, refused,
      // not merely masked at read time.
      return;
    }

    if (point.epoch > priorEpoch) {
      // Rewind confirmed by THIS point: clear heartbeat history BEFORE
      // recording its own arrival below, so a pre-reset expectation can
      // never wrongly flag (or wrongly clear) a HeldStale during the
      // resynchronizing period that follows. This point's own arrival still
      // counts as a fresh heartbeat for its topic once the clear has run.
      this.heartbeats.reset();
    }

    this.timelineFor<T>(topic).append(point);
    if (topic === UPLINK_ROSTER_TOPIC) {
      this.declaredRoles = readDeclaredDelayRoles(point.payload);
    }
    this.clock.observeSample(
      point.validAt,
      point.meta.deliveredAt,
      point.epoch,
    );
    // Every ingested sample: keyframe or change-emission alike, confirms
    // the link is alive as of this arrival. Deliberately keyed on
    // `meta.deliveredAt`, never `point.validAt` (see
    // `HeartbeatTracker`'s doc comment for why).
    this.heartbeats.noteArrival(topic, point.meta.deliveredAt);

    const newEpoch = this.clock.getEpoch();
    if (newEpoch > priorEpoch) {
      for (const lagging of this.timelines.values()) {
        lagging.adoptEpoch(newEpoch);
      }
    }
  }

  /** The per-topic `ClientTimeline`, created on first access. */
  getTimeline<T>(topic: string): ClientTimeline<T> {
    return this.timelineFor<T>(topic);
  }

  /**
   * Register a derived channel. From this point on,
   * `sample(def.topic, token)`, and every reactive read built on it,
   * transparently returns the memoized derived
   * value instead of reading a raw `ClientTimeline`, callers never need to
   * know whether a topic is raw or derived ("raw-vs-derived
   * invisible" to consumers). If `def.fields` is set, `"<topic>.<field>"` subtopics are
   * resolved too (`resolveDerivedTopic`).
   *
   * Registering the same `topic` twice replaces the previous definition,
   * useful for hot-reload/test setup, not a guarded no-op.
   */
  registerDerivedChannel<T>(def: DerivedChannelDefinition<T>): void {
    this.derivedChannels.set(
      def.topic,
      def as DerivedChannelDefinition<unknown>,
    );
  }

  /**
   * Whether a channel is already registered for `topic`. Lets a caller adding
   * channels after construction leave an existing one alone, so a topic keeps
   * the model it was built with rather than the model whichever import landed
   * last.
   */
  hasDerivedChannel(topic: string): boolean {
    return this.derivedChannels.has(topic);
  }

  /**
   * Mint a new frozen `FrameToken` from the clock's current `viewUt()` and
   * make it `currentFrame()`'s value. Call once per animation frame / read
   * cycle (e.g. from `clock.onFrame` or a widget's own rAF loop); never
   * once per read.
   */
  beginFrame(): FrameToken {
    this.generation++;
    this.releaseUntouchedSubjects();
    this.currentToken = mintToken(this.clock, this.generation);
    for (const listener of this.frameListeners) listener();
    return this.currentToken;
  }

  /**
   * Drop the dynamic subscription of any reckoner that did not reckon on the
   * previous frame.
   *
   * A mounted read samples every frame, so a live subject is touched every
   * frame and survives. One frame of grace rather than zero, because the sweep
   * runs BEFORE this frame's reads: judging on the frame just begun would
   * release every entry before anything had a chance to touch it.
   */
  private releaseUntouchedSubjects(): void {
    for (const [topic, entry] of this.subjectSubscriptions) {
      if (entry.generation >= this.generation - 1) continue;
      entry.release();
      this.subjectSubscriptions.delete(topic);
    }
  }

  /**
   * Hold up `subjectTopic` for `reckonerTopic`, replacing whatever that
   * reckoner was holding up before.
   *
   * Marked with the current generation on every call, including when the topic
   * is unchanged: the mark is what {@link releaseUntouchedSubjects} reads, so a
   * standing subject has to re-assert itself each frame to stay held.
   */
  private holdSubjectTopic(reckonerTopic: string, subjectTopic: string): void {
    const held = this.subjectSubscriptions.get(reckonerTopic);
    if (held?.topic === subjectTopic) {
      held.generation = this.generation;
      return;
    }
    held?.release();
    const subscribe =
      this.dynamicSubscriber ?? this.options.subscribeDynamicTopic;
    if (!subscribe) {
      this.subjectSubscriptions.delete(reckonerTopic);
      return;
    }
    this.subjectSubscriptions.set(reckonerTopic, {
      topic: subjectTopic,
      release: subscribe(subjectTopic),
      generation: this.generation,
    });
  }

  /** The token minted by the most recent `beginFrame()` call. What every reactive read uses; never recomputed per read. */
  currentFrame(): FrameToken {
    return this.currentToken;
  }

  /**
   * `topic`'s certainty in this frame: `"confirmed"` when the view time its
   * delay lane is read at sat at-or-before that lane's certainty horizon when
   * the token was minted, `"predicted"` past it.
   *
   * Per topic because a frame has two view times, a light-time apart, and each
   * is judged against its own horizon: a true-now channel can have reported up
   * to the instant it is read at while a delayed one has not. Rides alongside a
   * value/status read for the same topic and frame, never inside either
   * (`sample()` for the value, `sampleStatus()` for staleness and absence, this
   * for certainty), and the three compose freely: a topic can be `"predicted"`
   * and `"resyncing"` at once, or `"confirmed"` and `"held-stale"`. Mirrors
   * `sample()`/`sampleStatus()`'s stale-token fallback.
   */
  sampleCertainty(
    topic: string,
    token: FrameToken = this.currentToken,
  ): Certainty {
    const effectiveToken =
      token.generation === this.generation ? token : this.currentToken;
    return this.laneForTopic(topic) === "true-now"
      ? effectiveToken.trueNowCertainty
      : effectiveToken.certainty;
  }

  /** Passthrough to the shared clock's certainty horizon, the first-class SDK value (`sdk.view.certaintyHorizonUt()`). */
  certaintyHorizonUt(): number {
    return this.clock.certaintyHorizonUt();
  }

  /**
   * The raw wire topics that must actually be subscribed (via
   * `TelemetryClient.subscribe`) to keep `topic` resolvable, the
   * derived-input ref-counting mechanism. A derived channel's own
   * topic (or one of its `"<topic>.<field>"` subtopics) is NEVER itself a
   * subscribable wire topic; no server channel produces it, so a caller
   * that naively subscribed to the derived topic NAME would never receive
   * any data and the channel would silently stay "not whole yet" forever.
   * This resolves `topic` down to the declared `inputs` it actually needs,
   * recursively (a derived channel's own `inputs` can themselves be derived,
   * per `DerivedGet`'s doc: `derive` can read another derived channel as an
   * input), de-duplicated, and defended against a malformed cyclical
   * declaration (an authoring bug, never expected in practice) via a
   * visited-set guard rather than an infinite loop.
   *
   * Identity (`[topic]`) for a topic that isn't derived at all, a genuinely
   * raw topic subscribes to itself, same as before this method existed.
   */
  resolveSubscriptionTopics(topic: string): string[] {
    const out = new Set<string>();
    this.collectSubscriptionTopics(topic, out, new Set());
    return [...out];
  }

  /**
   * The raw wire topics `topic`'s ELECTED reckoner needs subscribed before it
   * will answer, on top of the ones {@link resolveSubscriptionTopics} already
   * names.
   *
   * A model declares its inputs and `registeredReckoning` refuses to run it
   * with one of them missing, which is the whole point of declaring them. But
   * nothing was holding those inputs UP. A read subscribed the topic it was
   * reading and a derived channel's `inputs`, and a raw topic's reckoner deps
   * are neither, so a lone plot of `vessel.flight.altitudeAsl` declined with
   * `input-absent` for ever and drew no tail, while the same plot beside a
   * widget reading `vessel.orbit` drew one. Whether a model runs is not
   * supposed to be a fact about the rest of the dashboard.
   *
   * The ladder is {@link rawReckonedWalk}'s, deliberately: the topic's own
   * registration, else the record's where `topic` is a field of one. Read
   * through `getReckoner` rather than off any list here, so an Uplink-owned
   * model is served exactly as core's is.
   *
   * ## Depth is ONE, and that is not an oversight
   *
   * A dep is resolved by `registeredReckoning` with a bare `sample()`, which
   * consults no model, so a dep's own reckoner never runs for it and that
   * reckoner's deps are never read. Walking further would subscribe topics
   * nothing was going to ask for, and a dep that is itself reckonable is
   * exactly where such a walk could go round in a circle. Each dep still passes
   * through `resolveSubscriptionTopics`, so a DERIVED dep expands to its raw
   * inputs under that method's own cycle guard.
   *
   * A `ProcessorHandle` dep names no wire topic and is skipped: a processor is
   * ref-count ACTIVATED rather than subscribed (`activateProcessor`), and
   * subscribing its inputs without activating it leaves `getProcessorValue`
   * answering `undefined` anyway. Nothing in the tree declares one on a
   * reckoner today, and the point layer has the same hole.
   */
  reckonerDepTopics(topic: string): string[] {
    const parsed = this.resolveRawFieldSubtopic(topic);
    const elected =
      getReckoner(topic) ?? (parsed ? getReckoner(parsed.rawTopic) : undefined);
    if (!elected) return [];
    const out = new Set<string>();
    for (const dep of elected.definition.deps as readonly Dep[]) {
      const depTopic =
        typeof dep === "string"
          ? dep
          : "reading" in dep
            ? dep.reading
            : undefined;
      if (depTopic === undefined) continue;
      for (const wireTopic of this.resolveSubscriptionTopics(depTopic)) {
        out.add(wireTopic);
      }
    }
    return [...out];
  }

  private collectSubscriptionTopics(
    topic: string,
    out: Set<string>,
    visiting: Set<string>,
  ): void {
    const resolved = this.resolveDerivedTopic(topic);
    if (!resolved) {
      // Raw record field-subtopic: the raw wire topic that must
      // actually be subscribed is the record itself (`"time.warp"`), never
      // the literal dotted field string (`"time.warp.warpRate"`): nothing
      // publishes to the latter. See `resolveRawFieldSubtopic`/`sample()`'s
      // matching branch.
      const rawField = this.resolveRawFieldSubtopic(topic);
      out.add(rawField ? rawField.rawTopic : topic);
      return;
    }
    const parentTopic = resolved.def.topic;
    if (visiting.has(parentTopic)) return; // cyclical declaration, break, don't loop forever
    visiting.add(parentTopic);
    for (const input of resolved.def.inputs) {
      this.collectSubscriptionTopics(input, out, visiting);
    }
  }

  /**
   * True when `topic` names a `"<parent>.<field>"` subtopic whose PARENT
   * resolved to a whole, non-tombstoned derived record (the derivation
   * genuinely ran) but `field` is not a key on the record it produced, a
   * structurally dead mapping (e.g. a stale migration-table entry pointing
   * at a field a `derive()` function never emits), as opposed to ordinary
   * "not whole yet" loading (parent has no point at all yet) or a confirmed
   * absence (parent tombstoned): both of which return `false` here, same as
   * a healthy field that just hasn't arrived.
   *
   * `sample()` alone can't make this distinction: `sampleDerived`'s field
   * lookup collapses "unknown field name" and "not whole yet" onto the same
   * `undefined` return, deliberately (see its own doc comment). This is a
   * SEPARATE diagnostic read for a caller (the `@ksp-gonogo/core` `useDataValue`
   * compatibility shim: belt-and-suspenders
   * fallback safety) that needs to tell "still loading, keep waiting" apart
   * from "this can never resolve, fall back to another source"; never
   * folded into `sample()`'s own return value.
   *
   * This guard covers both DERIVED
   * channel parents and RAW record field-subtopics (`resolveRawFieldSubtopic`,
   * e.g. `"vessel.resources.resources.<name>.current"`). A raw fieldpath
   * that's wrong or has drifted would otherwise serve a permanent
   * `undefined` with no fallback (the FuelStatus-class
   * bug: `useTelemetry(vesselKey) ?? 0` turning a silent resolution
   * failure into an empty gauge). The second branch below applies the exact
   * same "whole-but-missing-field = unresolvable" check to a raw parent,
   * walking the FULL fieldpath (which may be 1+ segments, unlike the
   * single-segment derived-channel case above) via the same walk
   * `sampleRawFieldSubtopic`/`sampleRange` use.
   */
  isUnresolvableField(
    topic: string,
    token: FrameToken = this.currentToken,
  ): boolean {
    const dot = topic.lastIndexOf(".");
    if (dot === -1) return false;
    const parentTopic = topic.slice(0, dot);
    const field = topic.slice(dot + 1);

    if (this.derivedChannels.has(parentTopic)) {
      const parentPoint = this.sample<Record<string, unknown>>(
        parentTopic,
        token,
      );
      if (!parentPoint || parentPoint.payload === null) return false;
      return !(field in parentPoint.payload);
    }

    const rawField = this.resolveRawFieldSubtopic(topic);
    if (!rawField) return false;

    const parentPoint = this.sample<Record<string, unknown>>(
      rawField.rawTopic,
      token,
    );
    if (!parentPoint || parentPoint.payload === null) return false;

    let cursor: unknown = parentPoint.payload;
    for (const segment of rawField.fieldPath) {
      if (
        cursor === null ||
        typeof cursor !== "object" ||
        !(segment in (cursor as object))
      ) {
        return true; // whole parent, but this field path doesn't resolve
      }
      cursor = (cursor as Record<string, unknown>)[segment];
    }
    return false;
  }

  /**
   * `true` when `topic` names a registered DERIVED channel, its own topic
   * or one of its `"<topic>.<field>"` subtopics (`resolveDerivedTopic`).
   * `false` for a raw topic, including a raw record field-subtopic
   * (`resolveRawFieldSubtopic`, e.g. `"vessel.orbit.sma"`), that string
   * LOOKS derived-shaped (it has dots) but resolves to a real wire record's
   * timeline, not a registered `derive()` function. What `sampleRange`
   * consults to decide "there's a stored history to range over" (a raw
   * topic always has one, a derived topic never does, it's a per-frame
   * computed value, see `sampleRange`'s own doc) versus `isUnresolvableField`
   * above, which asks a narrower question (a specific FIELD NAME on an
   * otherwise-whole derived record) for a different caller.
   */
  isDerivedTopic(topic: string): boolean {
    return this.resolveDerivedTopic(topic) !== undefined;
  }

  /**
   * Windowed range read for a raw topic (or raw record field-subtopic): the
   * backfill side of a historical series read, where `sample()` is the live
   * side. Mirrors `sample()`'s raw-topic / raw-field-subtopic resolution
   * (`resolveRawFieldSubtopic`, see `timeline-store-raw-fields.test.ts`) but
   * returns every buffered point in `[fromUt, toUt]` instead of one
   * hold-last read.
   *
   * Returns `undefined`, not an empty array, when `topic` resolves to a
   * registered DERIVED channel (`isDerivedTopic`): a derived value is
   * computed fresh per frame from whatever its inputs currently hold
   * (`sampleDerived`), never stored as its own buffered history, so there is
   * structurally nothing to range over. This is the caller's "give up,
   * permanently, on this topic" signal: distinct from an empty array,
   * which means "genuinely nothing landed in the window yet" and may fill
   * in on a later read as more samples arrive.
   *
   * For a literal raw topic, returns its `ClientTimeline.range` verbatim.
   * For a raw record field-subtopic, reads the PARENT raw topic's range and
   * extracts `fieldPath` from each point's payload: skipping (never
   * fabricating a value for) a tombstoned parent point or one whose payload
   * doesn't have the field, the same two "nothing to serve" cases
   * `sampleRawFieldSubtopic` treats identically for a single read.
   *
   * Bounded to the CURRENT epoch, exactly like `sample()`'s raw path, a
   * timeline still sitting on a lower epoch (hasn't re-sampled since a
   * rewind) reads as empty rather than serving dead-epoch history into a
   * live series.
   */
  sampleRange<T>(
    topic: string,
    fromUt: number,
    toUt: number,
  ): TimelinePoint<T>[] | undefined {
    if (this.resolveDerivedTopic(topic)) return undefined;

    const epoch = this.clock.getEpoch();
    const rawField = this.resolveRawFieldSubtopic(topic);
    if (!rawField) {
      const timeline = this.timelineFor<T>(topic);
      if (timeline.epoch < epoch) return [];
      return timeline.range(fromUt, toUt);
    }

    const parentTimeline = this.timelineFor<Record<string, unknown>>(
      rawField.rawTopic,
    );
    if (parentTimeline.epoch < epoch) return [];

    const out: TimelinePoint<T>[] = [];
    for (const point of parentTimeline.range(fromUt, toUt)) {
      if (point.payload === null) continue; // tombstone, nothing to extract
      let cursor: unknown = point.payload;
      let resolved = true;
      for (const segment of rawField.fieldPath) {
        if (
          cursor === null ||
          typeof cursor !== "object" ||
          !(segment in (cursor as object))
        ) {
          resolved = false;
          break;
        }
        cursor = (cursor as Record<string, unknown>)[segment];
      }
      if (!resolved) continue; // unknown field on this point, nothing to serve
      out.push({
        validAt: point.validAt,
        payload: cursor as T,
        meta: point.meta,
        epoch: point.epoch,
      });
    }
    return out;
  }

  /**
   * Windowed series for a DERIVED topic: the counterpart to `sampleRange`
   * (which structurally can't serve one: a derived value is computed fresh
   * per frame, nothing is ever stored). Backs `@ksp-gonogo/data`'s
   * `useDataSeries` shim so a Graph-style widget plotting a registered
   * derived-channel key gets a REAL series off the
   * stream instead of permanently falling back to the legacy
   * `BufferedDataSource`: see that hook's own doc comment for the "why".
   *
   * Replays `def.derive` at every UT any of its raw `inputs` actually
   * changed at within `[fromUt, toUt]` (a change-gated raw timeline only
   * ever carries a point when something changed, so this is exactly the set
   * of instants the derived value could have changed too), a synthetic
   * `get` built by hold-last lookup over each raw input's own buffered range
   * (queried from `-Infinity` through `toUt`, so an input that last changed
   * BEFORE `fromUt` still resolves correctly at the first in-window
   * instant; `ClientTimeline`'s own retention window bounds this, not an
   * unbounded scan).
   *
   * Declared `inputs` are assumed RAW (not another derived topic), true of
   * every channel in `PRODUCTION_DERIVED_CHANNELS` today, even though `get`
   * itself resolves derived-on-derived inputs transparently at the live-frame
   * layer (`sample()`'s own doc comment). A derived-on-derived input here
   * degrades to "no point at that instant" (`sampleRange` already returns
   * `undefined` for a derived topic, folded into an empty array below)
   * rather than recursing: safe, just sparser, and nothing registered
   * exercises it today.
   *
   * Returns `undefined` when `topic` doesn't resolve to a registered derived
   * channel at all (mirrors `sampleRange`'s contract): callers are expected
   * to gate on `isDerivedTopic` first, same as `sampleRange`'s own callers
   * gate the other way.
   */
  sampleDerivedRange<T>(
    topic: string,
    fromUt: number,
    toUt: number,
  ): TimelinePoint<T>[] | undefined {
    const resolved = this.resolveDerivedTopic(topic);
    if (!resolved) return undefined;
    const { def, field } = resolved;

    const epoch = this.clock.getEpoch();

    const inputRanges = new Map<string, TimelinePoint<unknown>[]>();
    const changeUts = new Set<number>();
    for (const inputTopic of def.inputs) {
      const points =
        this.sampleRange<unknown>(inputTopic, -Infinity, toUt) ?? [];
      inputRanges.set(inputTopic, points);
      for (const point of points) {
        if (point.validAt >= fromUt && point.validAt <= toUt) {
          changeUts.add(point.validAt);
        }
      }
    }

    const sortedUts = [...changeUts].sort((a, b) => a - b);
    const out: TimelinePoint<T>[] = [];

    for (const ut of sortedUts) {
      const get: DerivedGet = <I>(
        inputTopic: string,
      ): TimelinePoint<I> | undefined => {
        const points = inputRanges.get(inputTopic);
        if (!points || points.length === 0) return undefined;
        let last: TimelinePoint<unknown> | undefined;
        for (const point of points) {
          if (point.validAt <= ut) last = point;
          else break;
        }
        return last as TimelinePoint<I> | undefined;
      };

      const value = def.derive(get, ut);
      if (value === undefined) continue; // not whole yet at this instant

      let payload: unknown;
      if (value === null) {
        payload = null; // confirmed absence
      } else if (field) {
        if (!(field in (value as object))) continue; // unknown field name
        payload = (value as Record<string, unknown>)[field];
      } else {
        payload = value;
      }

      out.push({
        validAt: ut,
        payload: payload as T,
        meta: derivedMeta(ut, epoch),
        epoch,
      });
    }

    return out;
  }

  /**
   * The part of a series NOBODY MEASURED: what the topic's own forward model
   * says the quantity did between the last observation and `toUt`.
   *
   * `sampleDerivedRange` above emits a point only where a declared INPUT
   * changed, which is exactly right for history and is why a chart of a
   * modelled quantity simply stopped at the last thing that arrived. During a
   * blackout no input changes, so the trace ended and said nothing about
   * whether the value was knowable. This is the other half: it asks the topic's
   * model for instants that had no observation behind them, and stamps each one
   * with the basis the model claimed for it.
   *
   * The model is the one `sampleReading` consults: the one registered for the
   * topic, else a field read borrowing its record's. Core's models and an
   * author's are both read through `getReckoner`, so a chart cannot draw one and
   * silently drop the other.
   *
   * ## Deliberately not a `TimelinePoint`, and deliberately not merged in
   *
   * A reckoned instant is a presentation-time projection, so it must never be
   * reachable as an observation. Keeping it in its own return type and its own
   * method is what makes that structural rather than a convention: nothing
   * stores one, the mission-history replay reaches for `sampleDerivedRange` and
   * never this, and a recording exported later cannot contain one. The one
   * caller that wants both halves joins them at the boundary that draws them,
   * and says which indices came from here.
   *
   * ## The horizon is the MODEL's, and it is asked at every instant
   *
   * There is no cutoff here and no window constant, for the same reason
   * `Reading` carries no horizon field: a model withdraws by declining, and the
   * absence of an answer IS the statement of trust. The difference a series
   * makes is that the question gets asked once per instant instead of once per
   * frame, so a horizon inside the window is expressible at all. The walk stops
   * at the first instant the model declines: a model gets worse with
   * age and never better, so a decline is the end of the tail rather than a
   * hole in it.
   *
   * ## Only a continuous quantity gets a tail, and it keeps its unit
   *
   * A model that moves a flag, a mode name or a vector may be perfectly honest
   * at a point and still have nothing a LINE can say: joining two states of an
   * enum draws a slope through values that do not exist. So a tail is emitted
   * only for a finite `number` or a finite `Value`, which excludes booleans,
   * strings, vectors and whole records by construction. A numeric enum would
   * pass this test and is the one shape to keep out of a plotted key by hand.
   *
   * A `Value` comes back WRAPPED, because every `vessel.flight` field is one and
   * a bare-number test would draw nothing for a carried altitude on every frame
   * of a descent. The magnitude is taken once, at the boundary
   * that plots it (`@ksp-gonogo/data`'s `useDataSeries`), not here, so nothing
   * between the model and the chart holds a number that has forgotten what it
   * measures.
   *
   * Returns an empty array for a topic with no model, or nothing yet observed,
   * which are the same answer to the caller: there is no tail to draw.
   */
  sampleReckonedTail<T>(
    topic: string,
    fromUt: number,
    toUt: number,
  ): ReckonedSample<T>[] {
    const epoch = this.clock.getEpoch();
    return this.memoize(
      this.currentToken,
      `\0reckontail\0${topic}\0${fromUt}\0epoch\0${epoch}`,
      () => this.computeReckonedTail<T>(topic, fromUt, toUt),
    );
  }

  private computeReckonedTail<T>(
    topic: string,
    fromUt: number,
    toUt: number,
  ): ReckonedSample<T>[] {
    const walk = this.rawReckonedWalk(topic, fromUt, toUt);
    // Nothing observed, or the newest observation IS the view time: either way
    // there is no interval for a model to have carried anything across.
    if (!walk || walk.lastObservedUt >= toUt) return [];

    const inWindow = [...new Set(walk.inWindowUts)]
      .filter((ut) => ut >= fromUt && ut <= toUt)
      .sort((a, b) => a - b);
    const step = reckonedTailStep(inWindow, walk.lastObservedUt, toUt);
    const out: ReckonedSample<T>[] = [];
    for (let ut = walk.lastObservedUt + step; ; ut += step) {
      /*
       * The last stride lands on `toUt` exactly rather than short of it: the
       * right-hand end of the tail is the frame's own view time, and stopping a
       * fraction of a step early would leave a gap between the model and the
       * moment the whole frame is drawn for.
       */
      const at = ut >= toUt - step * 0.5 ? toUt : ut;
      RECKONED_TAIL_BUDGET.record();
      const answer = walk.answerAt(at);
      if (!answer) break; // the model's own horizon
      const drawable = plottableQuantity(answer.value);
      if (drawable === undefined) break;
      const sample: ReckonedSample<T> = {
        atUt: at,
        value: drawable as T,
        basis: answer.basis,
      };
      /*
       * A malformed band is dropped and the instant still drawn. The value is
       * the model's answer either way, and refusing the point over a bad
       * interval would turn a shading bug into a hole in the trace. A band in
       * some OTHER unit than the value goes the same way: it is internally
       * coherent, so `bandIsWellFormed` has nothing to say about it, and what
       * makes it wrong is only visible against the quantity it claims to
       * describe. That comparison is possible at all because the ends stay
       * wrapped; while they were written out as bare magnitudes, a band in
       * seconds reached two numeric slots a chart reads as metres.
       *
       * The cast is the one `value` above already takes, and for the same
       * reason: this method is generic over a payload it reaches by runtime
       * path, so `T` is not resolved here, and the two checks on the condition
       * above are what establish the agreement `ReckonedBound<T>` states.
       */
      if (
        answer.band &&
        bandIsWellFormed(answer.band) &&
        bandDescribes(drawable, answer.band)
      ) {
        sample.bandLo = answer.band.lo as ReckonedBound<T>;
        sample.bandHi = answer.band.hi as ReckonedBound<T>;
        sample.bandKind = answer.band.kind;
      }
      out.push(sample);
      if (at >= toUt) break;
    }
    return out;
  }

  /**
   * What `topic`'s own model says happened across the part of the gap between
   * two consecutive samples that no observation covers, or `undefined` where
   * nothing covers it and nothing claims to.
   *
   * ## Only the span the sampling missed is asked about
   *
   * `time.warp.observationQuantumUt` is how far apart the mod's samples of the
   * game were, read off the `time.warp` sample in force at the later point. A
   * gap wider than that is a quiet channel: the mod looked once a quantum and
   * found nothing worth sending. So the unobserved span is the LAST quantum of
   * the gap, or the whole gap where it is shorter, which at 1x is one second
   * and under high warp is one physics tick of thousands.
   *
   * ## The model is asked from the start of that span, as a held reading
   *
   * The earlier sample's record, re-stamped at the instant the span opens,
   * because the mod confirmed it unchanged at every look until then: a quiet
   * channel that moves at the end of forty seconds was last known one second
   * before the move, not forty. At that instant first: a model that makes no
   * claim on the plotted path there (no reckoner, a field it copies rather
   * than moves, a decline on the record's own terms) says nothing about the
   * span either, and the answer is `undefined`. Then at instants across the
   * span and at its end: a model
   * that withdraws at any of them did not carry it (`carried: false`), and one
   * that answers at all of them hands back its path. A conic on rails carries
   * any gap it does not leave the patch or enter air during; a first-order dead
   * reckoning does not carry two thousand seconds.
   *
   * Declared inputs resolve at the current frame, as they do for the reckoned
   * tail. They are part of the cache key, so an input that arrives later is
   * asked again rather than latched.
   *
   * ## Where nothing claims the span
   *
   * `time.warp.sampleIntervalUt` is the spacing the mod samples at while warp is
   * not thinning it, the resolution every chart has always drawn its chords at.
   * A span no wider than that is left to the chart as it always was, and the
   * answer is `undefined`. A wider one that no model claims is `unclaimed`: the
   * sampling skipped the part beyond it, and nothing stands behind a chord
   * across it. Where the host states no such interval, nothing can tell the two
   * apart, and the answer stays `undefined`.
   */
  gapModel(
    topic: string,
    before: TimelinePoint<unknown>,
    after: TimelinePoint<unknown>,
  ): GapModel | undefined {
    const gap = after.validAt - before.validAt;
    if (!(gap > 0)) return undefined;
    const warp = this.sampleRange<{
      observationQuantumUt?: Quantityish | null;
      sampleIntervalUt?: Quantityish | null;
    }>("time.warp", Number.NEGATIVE_INFINITY, after.validAt)?.at(-1)?.payload;
    const quantum = magnitudeOr(warp?.observationQuantumUt, Number.NaN);
    if (!(quantum > 0)) return undefined;
    const span = Math.min(gap, quantum);
    const unclaimed =
      span > magnitudeOr(warp?.sampleIntervalUt, Number.POSITIVE_INFINITY)
        ? UNCLAIMED
        : undefined;

    const parsed = this.resolveRawFieldSubtopic(topic);
    const rawTopic = parsed?.rawTopic ?? topic;
    const token = this.currentToken;
    if (!getReckoner(rawTopic)) return unclaimed;
    const inputs = this.reckonerDepTopics(rawTopic)
      .map(
        (dep) => `${dep}@${this.sample<unknown>(dep, token)?.validAt ?? "-"}`,
      )
      .join(",");
    const key = `${before.validAt}\0${span}\0${unclaimed !== undefined}\0${inputs}\0${this.clock.getEpoch()}`;
    /*
     * Keyed on the RECORD's point, not the one handed in: a field read's range
     * is minted fresh on every call, so a judgement keyed on it would never be
     * found again.
     */
    const record = parsed
      ? this.sampleRange<unknown>(rawTopic, after.validAt, after.validAt)?.find(
          (point) => point.validAt === after.validAt,
        )
      : after;
    if (!record) return undefined;
    let byTopic = this.gapModels.get(record);
    if (!byTopic) {
      byTopic = new Map();
      this.gapModels.set(record, byTopic);
    }
    const cached = byTopic.get(topic);
    if (cached?.key === key) return cached.answer;
    const answer =
      this.computeGapModel(topic, before, after, span) ?? unclaimed;
    byTopic.set(topic, { key, answer });
    return answer;
  }

  private computeGapModel(
    topic: string,
    before: TimelinePoint<unknown>,
    after: TimelinePoint<unknown>,
    span: number,
  ): GapModel | undefined {
    const parsed = this.resolveRawFieldSubtopic(topic);
    const rawTopic = parsed?.rawTopic ?? topic;
    const fieldPath = parsed?.fieldPath ?? [];
    const reckoner = this.registeredReckonerFn<unknown>(
      rawTopic,
      this.currentToken,
    );
    if (!reckoner) return undefined;
    const held = parsed
      ? this.sampleRange<unknown>(
          rawTopic,
          before.validAt,
          before.validAt,
        )?.find((point) => point.validAt === before.validAt)
      : before;
    if (!held || held.payload === null) return undefined;
    const from = after.validAt - span;
    const anchor: TimelinePoint<unknown> = { ...held, validAt: from };
    /*
     * A path the model MOVES. The root entry every model carries only says the
     * record is under its claim, and a field copied verbatim beside a moved one
     * is the last observation, which says nothing about the span.
     */
    const answerAt = (at: number) => {
      const model = reckoner(anchor, "held-stale", at);
      const moved = model?.modelled.find((entry) =>
        fieldPath.length === 0
          ? entry.path === ""
          : entry.path !== "" && coversPath(entry.path, fieldPath),
      );
      if (!model || !moved) return undefined;
      return {
        basis: moved.basis,
        value: walkFieldPath(model.reckon(at), fieldPath),
      };
    };
    const opening = answerAt(from);
    if (!opening) return undefined;
    const t: number[] = [];
    const v: unknown[] = [];
    for (let k = 1; k <= GAP_MODEL_SAMPLES; k++) {
      const at = from + (span * k) / (GAP_MODEL_SAMPLES + 1);
      const answer = answerAt(at);
      if (!answer) return { carried: false };
      t.push(at);
      v.push(answer.value);
    }
    if (!answerAt(after.validAt)) return { carried: false };
    return { carried: true, basis: opening.basis, t, v };
  }

  /**
   * A raw topic's tail, off the model an Uplink registered for it.
   *
   * The same ladder `sampleReading` walks: a whole-topic reckoner, or a field
   * read borrowing its record's model. Wired because a registration seam that reaches the point
   * layer and stops there is a half-built extension point, and an author whose
   * model draws a propagated marker on the map but leaves a plot of the same
   * quantity ending mid-window has nothing to tell them that is by design.
   *
   * The model is re-asked at every instant rather than resolved once and pulled
   * repeatedly, which is the only way its horizon is expressible at all:
   * `TopicModel` has no failure return by design, so a model withdraws by not
   * being OFFERED, and offering is what the reckoner call is.
   *
   * Root coverage is required for the same reason `readingFrom` requires it: a
   * model that moves one field of forty-seven has not answered for the value
   * this read asked about. For a field subtopic `fieldScopedReckoner` has
   * already narrowed, and the root it claims is the narrowed value's.
   */
  private rawReckonedWalk(
    topic: string,
    fromUt: number,
    toUt: number,
  ): ReckonedWalk | undefined {
    const token = this.currentToken;
    const reckoner =
      this.registeredReckonerFn<unknown>(topic, token) ??
      this.fieldScopedReckoner<unknown>(topic, token);
    if (!reckoner) return undefined;
    const point = this.sample<unknown>(topic, token);
    if (!point || point.payload === null) return undefined;
    const status = this.sampleStatus(topic, token);
    /*
     * The three statuses that are not a missed update. A tail FILLS a silence,
     * and there is no silence in any of them, so there is nothing to draw.
     *
     * This deliberately no longer matches `readingFrom`, which does consult a
     * reckoner on a live reading: a POINT reading asks "is this quantity
     * forward-modelled", which a conic answers yes to whether or not the last
     * packet was late, while a tail asks "what happened during the gap", which
     * has no answer when there was no gap. The two questions diverged when
     * reckonability came off the staleness discriminant, and the divergence is
     * the correct outcome rather than an oversight.
     */
    if (status === "live" || status === "resyncing" || status === "absent") {
      return undefined;
    }
    const observed = this.sampleRange<unknown>(topic, fromUt, toUt) ?? [];
    return {
      lastObservedUt: point.validAt,
      inWindowUts: observed.map((p) => p.validAt),
      answerAt: (at) => {
        const model = reckoner(point, status, at);
        const root = model?.modelled.find((entry) => entry.path === "");
        if (!model || !root) return undefined;
        return {
          value: model.reckon(at),
          basis: root.basis,
          band: model.bandAt?.(at)?.[""],
        };
      },
    };
  }

  /**
   * Imperative tier: read `topic` at a frame token's frozen `viewUt`
   * (defaults to `currentFrame()`: there is no per-read "now").
   *
   * Three behaviours combine here:
   * - **Stale-token fallback**: a `token` from a superseded frame (its
   *   `generation` doesn't match the store's current one, e.g. a caller
   *   cached a token across a `beginFrame()` boundary) is not honored;
   *   the read is routed to `currentFrame()` instead.
   * - **Store-level epoch guard**: if `topic`'s timeline is
   *   still sitting on an epoch lower than the shared clock's, it's treated
   *   as cold (`undefined`) rather than serving its dead-epoch data, this
   *   is what actually closes the cross-topic ghost even in the split
   *   second before `ingest`'s proactive sweep has touched it, and for a
   *   timeline that gets lazily created (via `timelineFor`) after a rewind.
   * - **Frame-coherent memoization**: the first read of a given
   *   `(topic, token)` pair is authoritative for that token's whole
   *   lifetime, so a mid-frame `ingest` can't flip the answer mid-read-cycle
   *   (tearing): the change only surfaces once a new `beginFrame()` mints a
   *   new token. **Except across an epoch bump**:
   *   the memo key folds in `clock.getEpoch()`, same as the derived-topic
   *   path below, so a mid-token quickload rewind is a cache miss rather
   *   than a replayed pre-bump ghost: including to a derived channel's
   *   `get()` reading this same topic through this same token.
   */
  sample<T>(
    topic: string,
    token: FrameToken = this.currentToken,
  ): TimelinePoint<T> | undefined {
    return this.sampleInLane<T>(topic, token, undefined);
  }

  /**
   * {@link sample}, with the delay lane pinned rather than taken from the
   * topic's own declaration.
   *
   * Only a DERIVED channel pins one, and only to its own lane: a channel whose
   * inputs are a mix reads all of them delayed, so its output is never stamped
   * more current than its most delayed input and never blends two instants a
   * light-time apart into one value. See {@link sampleDerived}.
   */
  private sampleInLane<T>(
    topic: string,
    token: FrameToken,
    laneOverride: DelayLane | undefined,
  ): TimelinePoint<T> | undefined {
    const effectiveToken =
      token.generation === this.generation ? token : this.currentToken;
    const lane = laneOverride ?? this.laneForTopic(topic);
    const viewUt = this.viewUtFor(effectiveToken, lane);

    const resolved = this.resolveDerivedTopic(topic);
    if (resolved) {
      // Outer memoize keyed by the EXACT requested topic (parent or a field
      // subtopic): this is what gives a re-read within the same frame back
      // the identical `TimelinePoint` object (referential stability for
      // React bail-out, mirroring the raw-topic path below), on top of the
      // inner memoize inside `sampleDerived` that keeps `derive` itself
      // running only once per frame regardless of how many field subtopics
      // of the same parent are read.
      //
      // The key folds in the CURRENT epoch, memos must die
      // by epoch: unlike the frame-coherent raw-topic path below (which
      // deliberately freezes for the token's whole lifetime), a derived
      // value must NOT survive a mid-frame epoch bump
      // (quickload rewind) for the rest of the frame. Folding epoch into the
      // key makes a post-bump read a fresh cache miss, so it falls through to
      // `sampleDerived` and recomputes against the new epoch instead of
      // serving pre-reset output.
      const epoch = this.clock.getEpoch();
      return this.memoize(
        effectiveToken,
        `${topic}\0epoch\0${epoch}\0lane\0${lane}`,
        () => this.sampleDerived<T>(resolved, effectiveToken, epoch),
      );
    }

    // Folds in the CURRENT epoch: exactly like the derived-topic key above,
    // guarding against the same class of stale-epoch ghost. Without this, the
    // first read of a given (token, topic) pair is authoritative for the
    // token's whole lifetime (frame-coherence, intentional for an
    // ordinary mid-frame ingest): but a mid-frame EPOCH BUMP is not an
    // ordinary ingest: it's a quickload rewind that the store's cross-topic
    // sweep (`ingest`) already propagates to every `ClientTimeline`
    // immediately. An unkeyed cache would keep replaying the pre-bump
    // `TimelinePoint` object for the rest of the token's life, including to
    // any derived channel's `get()` that reads this same topic through this
    // same token: defeating the epoch guard below and the sweep that just
    // ran. Folding epoch into the key makes a post-bump read a fresh cache
    // miss, so it falls through to the guard/`timeline.at` again instead.
    const epoch = this.clock.getEpoch();
    const literal = this.memoize(
      effectiveToken,
      `${topic}\0epoch\0${epoch}\0lane\0${lane}`,
      () => {
        const timeline = this.timelineFor<T>(topic);
        if (timeline.epoch < epoch) return undefined;
        return timeline.at(viewUt);
      },
    );
    if (literal !== undefined) return literal;

    // Raw record field-subtopic fallback, which is what the retired flat key
    // vocabulary used to depend on and what a dotted read still uses:
    // `topic` is a `"<domain>.<channel>.<field...>"` string with no
    // registered-derived-channel match: e.g. `"time.warp.warpRate"`. No
    // wire message is EVER published to that literal string; the real wire
    // topic is `"time.warp"`, a whole record `{ warpRate, warpRateIndex,
    // warpMode, paused }`. See `resolveRawFieldSubtopic`'s own doc for the
    // longest-known-topic rule that decides where the split falls.
    //
    // Deliberately tried SECOND, only once the literal read above came back
    // `undefined`: never first. A topic string that genuinely IS a raw
    // topic in its own right, even a 3+-segment one (`use-timeline-stream
    // .test.tsx` ingests straight into `"vessel.flight.altitudeAsl"` as a
    // literal topic against a bare store), must keep reading its own literal
    // timeline; shadowing it unconditionally with the field-split
    // interpretation would silently stop that from ever resolving.
    const rawField = this.resolveRawFieldSubtopic(topic);
    if (!rawField) return literal;
    return this.memoize(
      effectiveToken,
      `\0rawfield\0${topic}\0epoch\0${epoch}\0lane\0${lane}`,
      () =>
        this.sampleRawFieldSubtopic<T>(rawField, effectiveToken, laneOverride),
    );
  }

  /** The frozen view time `token` exposes for `lane`. Both are minted together, so which one a read takes is the only thing a lane decides. */
  private viewUtFor(token: FrameToken, lane: DelayLane): number {
    return lane === "true-now" ? token.trueNowViewUt : token.viewUt;
  }

  /**
   * Which lane `topic` is read in, for every shape of topic this store serves
   * rather than only the declared ones.
   *
   * A DERIVED channel takes the most conservative of its inputs
   * ({@link derivedLane}). A raw FIELD SUBTOPIC takes its parent record's lane,
   * because `time.warp.warpRate` is the same wire frame as `time.warp` and
   * reading the two at different instants would be the same record disagreeing
   * with itself. Anything else is its own declaration, and an undeclared
   * topic is delayed.
   */
  private laneForTopic(topic: string): DelayLane {
    const derived = this.resolveDerivedTopic(topic);
    if (derived) return derivedLane(derived.def, this.declaredLane);
    /* The whole topic is asked first because a topic under a TrueNow dynamic
       namespace is its own wire topic, and the generic field split would
       otherwise cut it into a parent no prefix matches. A field subtopic of a
       static channel is never itself declared, so asking it first costs that
       read nothing. */
    if (this.declaredLane(topic) === "true-now") return "true-now";
    const rawField = this.resolveRawFieldSubtopic(topic);
    return rawField ? this.declaredLane(rawField.rawTopic) : "delayed";
  }

  /** A whole declared topic's lane, by the roles the mod stated when it has stated any. */
  private readonly declaredLane = (topic: string): DelayLane =>
    delayLaneOf(topic, this.declaredRoles);

  /**
   * Interpolating raw-topic read, the confirmed view is an
   * interpolation of buffered samples up to the confirmed edge, fills
   * the seam `ClientTimeline.straddle` left open (its own doc comment: "a
   * hold-last read (`at`) is what T2 consumers use; interpolation lands in
   * a later task").
   *
   * Deliberately NOT what `sample()`/`get` use for raw reads: some raw
   * topics (orbit ELEMENTS foremost) are a *cause* valid until superseded,
   * not a measured quantity: interpolating between two elements samples
   * straddling a maneuver would blend through physically nonsensical
   * intermediate orbits. `sample()` stays hold-last for exactly that
   * reason; this method is for MEASURED/discrete raw values where a
   * straight line between two buffered samples is an honest estimate in
   * between (`vessel.flight`'s measured kinematics, for one).
   *
   * Falls back to hold-last (`ClientTimeline.at`) whenever there's nothing
   * to straddle (fewer than two points, or `viewUt` is at-or-after the
   * latest point: the normal confirmed-live case, since the confirmed
   * edge is usually sample-clamped right at the newest sample) or the
   * bracketing payloads can't be honestly lerped (`lerpPayload` returns
   * `undefined`: mismatched shape, a non-numeric field that actually
   * differs, or either side is a tombstone); never fabricates a value it
   * can't justify.
   *
   * A derived topic already computed its own record at the frozen
   * `viewUt`: propagation (or the channel's own basis-appropriate
   * handling) IS its past-horizon/interpolation story, so this falls
   * through to the ordinary derived read (`sample`) rather than
   * interpolating the OUTPUT record after the fact.
   */
  sampleInterpolated<T>(
    topic: string,
    token: FrameToken = this.currentToken,
    laneOverride?: DelayLane,
  ): TimelinePoint<T> | undefined {
    const effectiveToken =
      token.generation === this.generation ? token : this.currentToken;
    const lane = laneOverride ?? this.laneForTopic(topic);

    if (this.resolveDerivedTopic(topic)) {
      return this.sampleInLane<T>(topic, effectiveToken, laneOverride);
    }

    // Same epoch-fold as `sample()`'s raw path above. A mid-token epoch bump
    // must invalidate this cache entry too, rather than replaying a pre-bump
    // interpolation for the rest of the token's life.
    const epoch = this.clock.getEpoch();
    return this.memoize(
      effectiveToken,
      `\0interp\0${topic}\0epoch\0${epoch}\0lane\0${lane}`,
      () => {
        const timeline = this.timelineFor<T>(topic);
        if (timeline.epoch < epoch) return undefined;
        return interpolatedRead(timeline, this.viewUtFor(effectiveToken, lane));
      },
    );
  }

  /**
   * The parent record's model, scoped to one field subtopic.
   *
   * A model is per TOPIC because physics needs siblings (Kepler wants eight
   * elements at once, dead reckoning a position AND a velocity), and its
   * expression is per FIELD because a payload is not one reckoning class:
   * `vessel.target` carries relative geometry that propagates beside identity
   * fields only a command changes beside metadata. Registration is therefore
   * keyed on the record, and a field read borrows the record's model and asks
   * whether it covers that path, which is the same parent-delegation
   * `sample()` and `sampleStatus()` already do for value and status.
   *
   * The model is handed the PARENT's point, not the narrowed field point: a
   * dead-reckoner given `{x, y, z}` alone cannot see the velocity it needs.
   * Only the result is narrowed.
   */
  private fieldScopedReckoner<T>(
    topic: string,
    token: FrameToken,
  ): ReckonerFor<T> | undefined {
    const parsed = this.resolveRawFieldSubtopic(topic);
    if (!parsed) return undefined;
    const parentReckoner = this.registeredReckonerFn<unknown>(
      parsed.rawTopic,
      token,
    );
    if (!parentReckoner) return undefined;
    return (_point, grade, viewUt) => {
      const parentPoint = this.sample<unknown>(parsed.rawTopic, token);
      if (!parentPoint || parentPoint.payload === null) return undefined;
      const model = parentReckoner(
        parentPoint as TimelinePoint<unknown>,
        grade,
        viewUt,
      );
      const covering = model?.modelled.find((entry) =>
        coversPath(entry.path, parsed.fieldPath),
      );
      if (!model || !covering) return undefined;
      return {
        // From this read's point of view the whole (narrowed) value is
        // modelled, so the root is what it claims.
        modelled: [{ path: "", basis: covering.basis }],
        reckon: (at) => walkFieldPath(model.reckon(at), parsed.fieldPath) as T,
        /*
         * The band is looked up at the EXACT field path, never inherited from
         * a shorter one the way `covering` inherits a basis. A basis is a
         * property of the model and is true of every path it moves; a band is
         * two numbers in one quantity's unit, so a band on the payload root is
         * not this field's band and borrowing it would put a metre interval
         * around a speed.
         */
        bandAt: (at) => {
          const field = model.bandAt?.(at)?.[parsed.fieldPath.join(".")];
          return field ? { "": field } : undefined;
        },
      };
    };
  }

  /**
   * One step of a declared input's dotted path, or `undefined` when the payload
   * does not carry it. `null` counts as carried-and-absent, `false` and `0` do
   * not: `frameRotating` is a declared input whose whole job is to be `false`
   * most of the time.
   */
  private static walkPath(payload: unknown, path: string): unknown {
    let current = payload;
    for (const segment of path.split(".")) {
      if (current === null || typeof current !== "object") return undefined;
      current = (current as Record<string, unknown>)[segment];
    }
    return current;
  }

  /**
   * The decline for a declared input that did not arrive, named the way the
   * CONTRACT names it.
   *
   * A reckoner declares its inputs in `Dep` notation and the contract declares
   * them as `relativeVelocity` / `@vessel.orbit` / `@vessel.orbit#mu`. Where the
   * two name the same Topic the contract's spelling wins, so the string a widget
   * renders and the string the mark carries are the same string; a dep the
   * contract does not name falls back to the same `@topic` shape rather than to
   * a second convention.
   */
  private static absentInput(topic: string, dep: Dep): ReckoningDecline {
    return {
      reason: "input-absent",
      input: TimelineStore.inputSpelling(topic, dep),
    };
  }

  /**
   * How one declared dep is NAMED to an operator: the contract's own spelling
   * where the contract names the same Topic, and the `@topic` shape otherwise.
   *
   * Shared by both declines that name an input, because a reader who is told
   * `@vessel.orbit` ran out and `@vessel.orbit` did not arrive should be reading
   * the same string for the same thing.
   */
  private static inputSpelling(topic: string, dep: Dep): string {
    if (typeof dep !== "string") {
      /*
       * A subject dep names no topic until a subject is in hand, and the two
       * callers that reach here (the absent-input and the horizon declines)
       * both run where one is not. The resolve loop names the RESOLVED topic
       * itself when it has one, so this is only the un-subjected spelling.
       */
      if (isSubjectDep(dep)) return "@<per-subject>";
      return "reading" in dep ? `@${dep.reading}` : dep.id;
    }
    const declared = reckonableValuesOf(topic)
      .flatMap((row) => row.inputs)
      .find((input) => input.topic === dep);
    return declared ? reckonableInputSpelling(declared) : `@${dep}`;
  }

  /**
   * The Topic a dep names, or `undefined` for a processor handle, which names
   * none, and for a subject dep, whose topic is not known until a reckon
   * resolves its subject.
   */
  private static depTopic(dep: Dep): string | undefined {
    if (typeof dep === "string") return dep;
    if (isSubjectDep(dep)) return undefined;
    return "reading" in dep ? dep.reading : undefined;
  }

  /**
   * One declared input, resolved for the frame the model is running for.
   *
   * The notation is a Processor's `Dep`, unchanged, because a reckoner's inputs
   * are the same kind of thing and a second spelling would be two vocabularies
   * to keep in step. The RESOLUTION differs in one place and deliberately: a
   * Topic id gives the `TimelinePoint`, not the bare payload a processor gets,
   * because a forward model withdraws on facts that live on the envelope
   * (`meta.quality` is what tells the conic the craft is under physics) and a
   * payload-only resolution would hide them behind an `undefined` the model
   * could not tell from an absent channel.
   */
  private resolveReckonerDep(dep: Dep, token: FrameToken): unknown {
    if (typeof dep === "string") return this.sample<unknown>(dep, token);
    if ("reading" in dep)
      return this.sampleReading<unknown>(dep.reading, token);
    /*
     * A subject dep is resolved by the second pass in `registeredReckoning`,
     * which is the only place the subject exists, so it never arrives here.
     * Narrowed rather than left to the fallthrough below: the compiler caught
     * that this function would otherwise have read `.id` off it and asked the
     * processor registry for `undefined`, which answers `undefined`, which is
     * spelled the same as an absent input.
     */
    if (isSubjectDep(dep)) return undefined;
    return getProcessorValue(dep.id);
  }

  /**
   * A registered model for `topic` with its inputs already resolved, the reason
   * nothing ran, or `undefined` when nobody has registered one.
   *
   * The three answers are distinct and the caller needs all three: a model to
   * offer, a refusal to render, or nothing at all, which is what lets the
   * remaining ladder rungs (a derived channel's label, a field read borrowing
   * its record's model) still be tried.
   *
   * ## A declared input that did not arrive declines BEFORE the model runs
   *
   * That is the whole point of declaring them. A model that reached for whatever
   * it liked could not be told from one whose inputs never came: both answer
   * nothing, and a caller sees a silent absence on a value the contract promised
   * was carriable. So a `deps` entry resolving to nothing is a decline the store
   * builds, naming the input the way the CONTRACT spells it where the contract
   * names it at all, and the model is never asked a question it cannot answer.
   *
   * A `ReadingDep` never resolves to nothing (`sampleReading` always answers,
   * `pending` included), so declaring one is a way to say "hand me this Topic's
   * currency and let me judge it" rather than "refuse without it".
   *
   * ## The window is resolved BEFORE the deps, and it is the other refusal
   *
   * A `minSamples` the record cannot meet means the model has nothing to take a
   * trend from, so it is settled first and the deps are never read: there is no
   * point resolving four inputs for a model that is not going to run. It is the
   * only rejection the window has. `maxSamples` thins and the model runs, and a
   * window truncated at a gap simply arrives shorter, where the same floor
   * judges it.
   *
   * A dep that opted into a window resolving to NO points is the same answer as
   * an un-windowed dep resolving to `undefined`, and gets the same decline: the
   * input the contract named did not arrive.
   */
  private registeredReckoning<T>(
    topic: string,
    token: FrameToken,
    point: TimelinePoint<T> | undefined,
    grade: StaleGrade | undefined,
    viewUt: number,
  ):
    | { readonly owner: string; readonly model: TopicModel<T, unknown> }
    | { readonly declined: ReckoningDecline }
    | undefined {
    const elected = getReckoner(topic);
    if (!elected) return undefined;
    if (!point || point.payload === null) return undefined;
    const definition = elected.definition;

    const own = this.windowedHistory(topic, token, point, definition.window);
    const floor = definition.window?.minSamples ?? 1;
    if (own.points.length < floor) {
      return { declined: TimelineStore.tooLittleHistory(own, floor) };
    }

    /*
     * Two passes, because a subject dep's topic is a function of the others. The
     * fixed deps resolve first, positionally, and the subject selector is then
     * handed that array: `comms.delay` reads its relay's guid out of the
     * `comms.path` point sitting at index 0. Pre-sized rather than pushed so a
     * subject dep's own slot is filled in place and every fixed dep keeps the
     * index the model destructures it at.
     */
    const resolved: unknown[] = new Array(definition.deps.length);
    for (const [index, dep] of definition.deps.entries()) {
      if (isSubjectDep(dep)) continue;
      if (typeof dep === "string") {
        const depWindow = definition.depWindows?.[dep];
        if (depWindow) {
          const anchor = this.sample<unknown>(dep, token);
          const { points } = this.windowedHistory(
            dep,
            token,
            anchor,
            depWindow,
          );
          if (points.length === 0) {
            return { declined: TimelineStore.absentInput(topic, dep) };
          }
          resolved[index] = points;
          continue;
        }
      }
      const value = this.resolveReckonerDep(dep, token);
      if (value === undefined) {
        return { declined: TimelineStore.absentInput(topic, dep) };
      }
      resolved[index] = value;
    }
    for (const [index, dep] of definition.deps.entries()) {
      if (!isSubjectDep(dep)) continue;
      const subjectId = dep.subject(point, resolved);
      /*
       * NO SUBJECT IS NOT A MISSING INPUT, and conflating the two would break
       * the commonest case. A `comms.delay` route straight home has no relay,
       * so there is no vessel whose orbit is wanted and the model runs exactly
       * as it does today; declining here would refuse every direct route to fix
       * the relayed one. The dep resolves to `undefined`, which is what its
       * declared type already says it can be, and the model branches.
       */
      if (subjectId === undefined) {
        resolved[index] = undefined;
        continue;
      }
      const subjectTopic = dep.forSubject(subjectId);
      /*
       * Held BEFORE it is sampled, and deliberately not after: the first reckon
       * is the one that discovers the subject, so sampling first would decline
       * on a topic nobody had asked the wire for yet and only hold it up as a
       * consequence of that decline. Holding first means the decline below is
       * the honest "it has not arrived YET", and the next frame has it.
       */
      this.holdSubjectTopic(topic, subjectTopic);
      const value = this.sample<unknown>(subjectTopic, token);
      if (value === undefined) {
        return {
          declined: { reason: "input-absent", input: `@${subjectTopic}` },
        };
      }
      resolved[index] = value;
    }
    const answer = definition.reckon(point, resolved, {
      grade,
      viewUt,
      history: own.points,
    });
    if ("declined" in answer) return { declined: answer.declined };

    /*
     * The input rules are applied AFTER the model is chosen, because a
     * registration is not always one model: `vessel.flight` returns a conic
     * above the atmosphere interface and an integrator of the observed descent
     * rate below it, and only the model itself knows which sample is which.
     * Asking the rule first meant asking it of both at once, so an opt-out
     * true of one was necessarily taken for the other.
     *
     * `reckon` is documented as cheap ("it is asked whether a model exists and
     * what it covers"), and the deps are already resolved above, so running it
     * before the rules costs a selection rather than a solve.
     */
    const exempt = TimelineStore.exemptionsFor(definition, answer);
    const bounding = definition.deps.filter((dep) => {
      const depTopic = TimelineStore.depTopic(dep);
      return depTopic === undefined || exempt.horizon[depTopic] === undefined;
    });
    const outOfReach = this.inputPastItsHorizon(topic, bounding, token);
    if (outOfReach) return { declined: outOfReach };
    return {
      owner: elected.owner,
      model: this.bandFlooredByInputs(
        topic,
        answer,
        definition.deps.filter((dep) => {
          const depTopic = TimelineStore.depTopic(dep);
          return depTopic === undefined || exempt.band[depTopic] === undefined;
        }),
        token,
      ),
    };
  }

  /**
   * The opt-outs in force for the model this registration just returned:
   * whatever it declared registration-wide, plus whatever it declared for the
   * BASIS this particular model was produced on.
   *
   * A registration-wide opt-out still means every model it returns, which is
   * right where a registration really is one model. `perBasis` is what lets a
   * registration that returns two say which of them the reason is true of.
   */
  private static exemptionsFor(
    definition: AnyReckonerDefinition,
    model: TopicModel<unknown, unknown>,
  ): {
    horizon: Record<string, string | undefined>;
    band: Record<string, string | undefined>;
  } {
    const exempt = definition.exempt;
    if (!exempt) return { horizon: {}, band: {} };
    const basis = model.modelled[0]?.basis;
    const byBasis = basis === undefined ? undefined : exempt.perBasis?.[basis];
    /*
     * A registration-wide opt-out still means every input of every model this
     * registration returns, which is what it has always meant. The per-basis
     * form narrows it twice: to the models produced on one basis, and to the
     * inputs the reason is actually about.
     */
    const everyInput = (reason: string | undefined) =>
      reason === undefined
        ? {}
        : Object.fromEntries(
            definition.deps
              .map((dep) => TimelineStore.depTopic(dep))
              .filter((depTopic): depTopic is string => depTopic !== undefined)
              .map((depTopic) => [depTopic, reason]),
          );
    return {
      horizon: { ...everyInput(exempt.horizon), ...(byBasis?.horizon ?? {}) },
      band: { ...everyInput(exempt.band), ...(byBasis?.band ?? {}) },
    };
  }

  /**
   * The decline for a model whose declared input cannot itself be carried to
   * this frame, or `undefined` when every input still reaches.
   *
   * This is the horizon rule, and it is spelled as a withdrawal because a
   * horizon has no other spelling here: there is no horizon FIELD on a
   * `TopicModel` to clamp, and `Reading`'s own doc is explicit that a model
   * withdraws by not being offered on the next frame. So the composition rule
   * "no further than the shortest of my inputs" becomes "not offered on a frame
   * where an input has run out", which is the same statement made in the
   * vocabulary the type already has.
   *
   * Only an input that HAS a model can have run out. An input nobody models is
   * held-last and makes no claim about how far it reaches, so declining on one
   * would refuse every model in the tree: `system.bodies` changes once a session
   * and is permanently stale, and a hold-last is exactly the right reading of
   * it.
   *
   * Asked AFTER the deps resolve, so an input that never arrived is reported as
   * absent rather than as out of reach. The two are different facts and the
   * absent one is the more basic.
   */
  private inputPastItsHorizon(
    topic: string,
    deps: readonly Dep[],
    token: FrameToken,
  ): ReckoningDecline | undefined {
    return this.whileEnforcing(topic, () => {
      for (const dep of deps) {
        const depTopic = TimelineStore.depTopic(dep);
        if (depTopic === undefined) continue;
        const answer = this.inputReckoning(depTopic, token);
        if (
          answer &&
          "declined" in answer &&
          answer.declined.reason === "beyond-horizon"
        ) {
          return {
            reason: "beyond-horizon",
            input: TimelineStore.inputSpelling(topic, dep),
            note: `${depTopic} cannot itself be carried this far, and nothing modelled from it reaches further than it does`,
          };
        }
      }
      return undefined;
    });
  }

  /**
   * Run `walk` with `topic` marked as under enforcement, and unmark it only if
   * this call is what marked it.
   *
   * The bookkeeping is here rather than inlined at both call sites because
   * getting it wrong is invisible: an inner call that unmarked a topic its
   * CALLER had marked would reopen the cycle the mark exists to close, and every
   * test would still pass right up to the frame two models named each other.
   */
  private whileEnforcing<T>(topic: string, walk: () => T): T {
    const marked = !this.enforcingInputRules.has(topic);
    if (marked) this.enforcingInputRules.add(topic);
    try {
      return walk();
    } finally {
      if (marked) this.enforcingInputRules.delete(topic);
    }
  }

  /**
   * One declared input's OWN registered model for this frame, resolved exactly
   * as a read of that topic would resolve it.
   *
   * Resolved by TOPIC rather than off the dep the model was handed, which is
   * the whole reason the rules apply without an author writing anything. Only a
   * `ReadingDep` resolves to a `Reading` carrying currency and bands, every
   * shipped reckoner declares bare Topic ids, and reading enforcement off the
   * handed dep would have made both rules opt-in through a spelling choice.
   *
   * At the input's OWN delay lane's view time, not the dependent's. The input's
   * uncertainty is the uncertainty of the value that actually fed the model, and
   * that value is the one its own frame carries.
   */
  private inputReckoning(
    depTopic: string,
    token: FrameToken,
  ):
    | { readonly owner: string; readonly model: TopicModel<unknown, unknown> }
    | { readonly declined: ReckoningDecline }
    | undefined {
    if (this.enforcingInputRules.has(depTopic)) return undefined;
    if (!getReckoner(depTopic)) return undefined;
    const status = this.sampleStatus(depTopic, token);
    if (status === "resyncing" || status === "absent") return undefined;
    return this.whileEnforcing(depTopic, () =>
      this.registeredReckoning<unknown>(
        depTopic,
        token,
        this.sample<unknown>(depTopic, token),
        status === "live" ? undefined : (status as StaleGrade),
        this.viewUtFor(token, this.laneForTopic(depTopic)),
      ),
    );
  }

  /**
   * The model, with its bands held to what its inputs' own bands support.
   *
   * The band rule, and it wraps `bandAt` rather than running it, because a
   * reckoning is a PULL: the store decides which arm to build without running
   * the model, and forcing every input's band on a frame nobody asked for one
   * would undo that. A model offering no band at all is handed back untouched,
   * which is the honest majority and costs nothing.
   *
   * Two claims are policed and neither needs to know the model's mathematics: a
   * `bound` over a `sigma1` input (a capped error derived from an uncapped one)
   * and a zero-width band over an input with width (exactness derived from
   * uncertainty). The first is DOWNGRADED, keeping the model's own numbers and
   * softening only what they claim; the second is DROPPED, because widening it
   * would mean inventing a width, and `ReckonedBands` already says a fabricated
   * band is worse than none. See {@link ReckonerInputRule} for why widths are
   * deliberately not compared.
   */
  private bandFlooredByInputs<T, R>(
    topic: string,
    model: TopicModel<T, R>,
    deps: readonly Dep[],
    token: FrameToken,
  ): TopicModel<T, R> {
    const inner = model.bandAt;
    if (!inner) return model;
    return {
      modelled: model.modelled,
      reckon: (viewUt) => model.reckon(viewUt),
      bandAt: (viewUt) => {
        const own = inner.call(model, viewUt);
        if (!own) return own;
        const floor = this.inputBandFloor(topic, deps, token);
        if (!floor.softest && !floor.inexact) return own;
        const held: { [path: string]: UncertaintyBand | undefined } = {};
        for (const [path, band] of Object.entries(own)) {
          held[path] = band && TimelineStore.holdBand(band, floor);
        }
        return held;
      },
    };
  }

  /** One band held to the floor its model's inputs set, or dropped where it cannot be. */
  private static holdBand(
    band: UncertaintyBand,
    floor: { softest: boolean; inexact: boolean },
  ): UncertaintyBand | undefined {
    if (floor.inexact && band.lo.equals(band.hi)) return undefined;
    if (floor.softest && band.kind === "bound") {
      return { ...band, kind: "sigma1" };
    }
    return band;
  }

  /**
   * What the declared inputs' own bands warrant, across every input that offers
   * one: whether any is a `sigma1` and whether any has width.
   *
   * Memoised per frame because a plotted tail asks for a band at every instant
   * it draws, and the inputs' claims do not move between two instants of one
   * frame: the floor is a statement about the input readings, which are frozen
   * for the frame, not about the view time being asked for.
   *
   * Marked as under enforcement for the walk, like the horizon half, because
   * asking an input for its band runs that input's own floored model, which asks
   * ITS inputs. Two models naming each other's topics would otherwise bounce
   * between the two `bandAt` wrappers forever.
   */
  private inputBandFloor(
    topic: string,
    deps: readonly Dep[],
    token: FrameToken,
  ): { softest: boolean; inexact: boolean } {
    const topics = deps
      .map((dep) => TimelineStore.depTopic(dep))
      .filter((dep): dep is string => dep !== undefined);
    return this.memoize(
      token,
      `reckon-band-floor:${topic}\0${topics.join("\0")}`,
      () =>
        this.whileEnforcing(topic, () => {
          let softest = false;
          let inexact = false;
          for (const depTopic of topics) {
            const answer = this.inputReckoning(depTopic, token);
            if (!answer || !("model" in answer)) continue;
            const at = this.viewUtFor(token, this.laneForTopic(depTopic));
            for (const band of Object.values(answer.model.bandAt?.(at) ?? {})) {
              if (!band) continue;
              if (band.kind === "sigma1") softest = true;
              if (!band.lo.equals(band.hi)) inexact = true;
            }
          }
          return { softest, inexact };
        }),
    );
  }

  /**
   * The decline the store raises on a reckoner's behalf when its own topic
   * carried fewer samples than the model said it needed.
   *
   * No `input`: the topic being read is not one of the model's declared inputs,
   * and naming it there would put a topic id where every other decline puts the
   * CONTRACT's spelling of a declared input. The note carries the numbers
   * instead, which is what an operator can act on.
   */
  private static tooLittleHistory(
    window: ResolvedWindow<unknown>,
    needed: number,
  ): ReckoningDecline {
    const because = window.truncatedAtBreak
      ? ", the rest of the window being on the far side of a break in the record"
      : "";
    return {
      reason: "insufficient-history",
      note: `the model needs ${needed} samples of its own topic and the window holds ${window.points.length}${because}`,
    };
  }

  /**
   * One topic's own record across a declared window, gap-truncated and thinned,
   * memoised for the frame.
   *
   * Anchored on `anchor`, the newest point at-or-before the frame's view time,
   * and NOT on the view time itself. A reckoner physically cannot see past its
   * confirmed edge, which is what makes reckoning honest, and a window measured
   * back from the view time would empty out during exactly the blackout a model
   * exists to carry a value across: the last minute of contact is the minute a
   * rate estimate wants.
   *
   * With no window declared the answer is `[anchor]`. The single point a
   * reckoner used to get is a one-sample window, so it is served by the same
   * path rather than by a branch that skips all of this.
   *
   * Memoised per `(topic, span, cap, token)` because the reckoned tail re-asks
   * the model at every instant it draws, and a range read per instant would put
   * the whole buffer through a filter dozens of times for one unchanging answer.
   */
  private windowedHistory<T>(
    topic: string,
    token: FrameToken,
    anchor: TimelinePoint<T> | undefined,
    window: ReckonerWindow | DepWindow | undefined,
  ): ResolvedWindow<T> {
    if (!anchor || anchor.payload === null) {
      return { points: [], truncatedAtBreak: false };
    }
    if (!window) return { points: [anchor], truncatedAtBreak: false };
    const key = `reckon-window:${topic}:${anchor.validAt}:${window.spanUt}:${window.maxSamples}`;
    return this.memoize(token, key, () => {
      const raw = this.sampleRange<T>(
        topic,
        anchor.validAt - window.spanUt,
        anchor.validAt,
      );
      // A derived topic has no stored history to range over (`sampleRange`
      // answers `undefined` for one), so its window is the point it computed.
      if (!raw || raw.length === 0) {
        return { points: [anchor], truncatedAtBreak: false };
      }
      const contiguous = contiguousTail(raw);
      return {
        points: thinTo(contiguous, window.maxSamples),
        truncatedAtBreak: contiguous.length < raw.length,
      };
    });
  }

  /**
   * The elected registration as a plain `ReckonerFor`, for the two paths that
   * want a model and have no use for the reason it was withheld: a field read
   * borrowing its record's model, and a plotted tail re-asking at every instant.
   * `sampleReading` calls {@link registeredReckoning} directly, because the
   * reason and the owner are exactly what a reading carries.
   */
  private registeredReckonerFn<T>(
    topic: string,
    token: FrameToken,
  ): ReckonerFor<T> | undefined {
    if (!getReckoner(topic)) return undefined;
    return (point, grade, viewUt) => {
      const answer = this.registeredReckoning<T>(
        topic,
        token,
        point,
        grade,
        viewUt,
      );
      return answer && "model" in answer
        ? (answer.model as TopicModel<T>)
        : undefined;
    };
  }

  /**
   * The first declared input `topic` is missing this frame, spelled the way the
   * contract spells it, or `undefined` when every one of them is here (and when
   * the contract declares nothing about the topic at all).
   *
   * Walks every marked value's inputs rather than only the one a caller asked
   * about, because a reading is whole-topic: the projection carries every marked
   * field, so a model that cannot produce one of them cannot fill the arm.
   */
  private missingDeclaredInput(
    topic: string,
    token: FrameToken,
  ): ReckoningDecline | undefined {
    const declared = reckonableValuesOf(topic);
    if (declared.length === 0) return undefined;
    const own = this.sample<unknown>(topic, token);
    for (const declaredValue of declared) {
      for (const input of declaredValue.inputs) {
        const payload =
          input.topic === ""
            ? own?.payload
            : this.sample<unknown>(input.topic, token)?.payload;
        const reached =
          payload === undefined || payload === null
            ? undefined
            : input.path === ""
              ? payload
              : TimelineStore.walkPath(payload, input.path);
        if (reached === undefined || reached === null) {
          return {
            reason: "input-absent",
            input: reckonableInputSpelling(input),
          };
        }
      }
    }
    return undefined;
  }

  /**
   * Why the declared model did not answer for `topic` this frame, or `undefined`
   * when the contract declares nothing about it.
   *
   * Only asked when no model was on offer, which for a DECLARED topic is a
   * specific refusal rather than the honest default it is elsewhere: the mark is
   * a promise that the wire carries the model's inputs, so if nothing answered,
   * either an input did not arrive, two owners are contesting the topic, or no
   * model is registered to run at all. Naming which beats a silent absence, and
   * the name is the contract's own spelling of the input so the string a widget
   * renders is the string the contract carries.
   */
  private declineFor(
    topic: string,
    token: FrameToken,
  ): ReckoningDecline | undefined {
    if (reckonableValuesOf(topic).length === 0) return undefined;

    if (getReckonerConflicts().some((conflict) => conflict.topic === topic)) {
      return {
        reason: "contested",
        note: "two owners registered a model for this topic, so neither is served",
      };
    }

    const missing = this.missingDeclaredInput(topic, token);
    if (missing) return missing;

    // Every declared input is here and nothing ran. Core registers a vanilla for
    // every marked Topic, so reaching this means core's reckoner module was
    // never imported: a build that dropped it, or a test that cleared the
    // registry. Saying so beats presenting as a missing input, which would send
    // a reader looking at the wire.
    return {
      reason: "model-inapplicable",
      note: "no model is registered for this topic",
    };
  }

  /**
   * The topic's value AND its currency as one `TopicReading<T>`, at a frame token's
   * frozen `viewUt`: `sample()` and `sampleStatus()` folded into the union a
   * widget cannot read incuriously. See `Reading`'s own doc for the mechanism.
   *
   * **Identity tracks the DATA, not the frame**, and that is load-bearing
   * rather than an optimisation. `useTelemetry` hands the result straight to
   * `useSyncExternalStore`, which compares snapshots with `Object.is`. The
   * per-frame `memoize` cache alone is not enough here: `beginFrame()` mints a
   * new `FrameToken` on every ingest tick, so a token-keyed entry is a fresh
   * object per frame by construction, and every widget reading telemetry would
   * re-render at frame cadence forever whether or not anything arrived. It
   * would also hand a fresh `reckon` thunk identity to every consumer's
   * dependency arrays on every frame.
   *
   * `sample()` and `sampleStatus()` do not need this because a payload's
   * identity is its own and a status is a string; a union is a WRAPPER, so it
   * has to be told. The last reading per topic is therefore kept and returned
   * again while the sampled point's identity, the status and the epoch are all
   * unchanged. Frame memoization still sits on top, so repeat reads within one
   * frame never re-derive.
   *
   * `reading-identity.test.ts` is the guard.
   */
  sampleReading<T>(
    topic: string,
    token: FrameToken = this.currentToken,
  ): TopicReading<T> {
    const effectiveToken =
      token.generation === this.generation ? token : this.currentToken;
    // Epoch-folded like every sibling read: a reading memoized before a
    // mid-frame epoch bump (quickload rewind) must not survive it.
    const epoch = this.clock.getEpoch();
    return this.memoize(
      effectiveToken,
      `\0reading\0${topic}\0epoch\0${epoch}`,
      () => {
        const point = this.sample<T>(topic, effectiveToken);
        const status = this.sampleStatus(topic, effectiveToken);
        const viewUt = this.viewUtFor(effectiveToken, this.laneForTopic(topic));
        /*
         * The registered model is asked FIRST and its answer is final, decline
         * included. Falling through to the record's model after a registered
         * model declined would serve a second model for one topic and hand two
         * answers to one widget.
         */
        const registered =
          // The arms `readingFrom` builds without ever consulting a model:
          // nothing to carry (resyncing), and a confirmed absence, which outranks
          // every staleness grade. Asking anyway would run a solve per frame
          // through a resync and throw the answer away.
          status === "resyncing" || status === "absent"
            ? undefined
            : this.registeredReckoning<T>(
                topic,
                effectiveToken,
                point,
                status === "live" ? undefined : (status as StaleGrade),
                viewUt,
              );
        const reckonedModel =
          registered && "model" in registered ? registered.model : undefined;
        const reckoner: ReckonerFor<T> | undefined = reckonedModel
          ? () => reckonedModel as TopicModel<T>
          : registered
            ? undefined
            : this.fieldScopedReckoner<T>(topic, effectiveToken);
        const owner =
          registered && "owner" in registered
            ? registered.owner
            : CORE_RECKONER_OWNER;
        const unowned = this.unownedTopics.has(topic);
        // Built only where the CONTRACT declared a value reckonable. An
        // undeclared topic has nothing to explain, and its reading is typed
        // `Reading`, which has no `declined` member on any arm, so a reason
        // attached there is one no caller can reach.
        //
        // The check is on the whole expression rather than on the `declineFor`
        // branch alone. A registered reckoner declines too, and a reckoner is
        // registered by topic STRING with no mark involved, so an Uplink may
        // have one on any topic at all.
        const declined =
          reckonableValuesOf(topic).length === 0
            ? undefined
            : registered && "declined" in registered
              ? registered.declined
              : reckoner
                ? undefined
                : this.declineFor(topic, effectiveToken);
        const declineKey = declined
          ? `${declined.reason}\0${declined.input ?? ""}`
          : undefined;
        const previous = this.readings.get(topic);
        if (
          previous !== undefined &&
          previous.point === point &&
          previous.status === status &&
          previous.epoch === epoch &&
          previous.unowned === unowned &&
          // A decline names a published input that did not arrive, so it moves
          // when a DIFFERENT topic's data does. Folding it into the identity
          // check is what stops a reading freezing on "no orbit yet" through the
          // frame the orbit lands on.
          previous.declineKey === declineKey &&
          // A reading depends on the frame's view time ONLY through a
          // reckoning, so a topic nobody models keeps its identity across a
          // frame exactly as before. Where a model is on offer now, an
          // advancing view time is a real input change: the modelled value is
          // for a different moment. Where one was on offer for the FROZEN
          // reading and is not now, the withdrawal is itself the change, and
          // reusing that reading is what made `Reading`'s "it withdraws by not
          // being offered on the next frame" untrue.
          ((reckoner === undefined &&
            previous.reading.reckoning.status !== "available") ||
            previous.viewUt === viewUt)
        ) {
          return previous.reading as TopicReading<T>;
        }
        const reading = declined
          ? readingFrom(
              point,
              status,
              viewUt,
              reckoner,
              unowned,
              declined,
              owner,
            )
          : readingFrom(
              point,
              status,
              viewUt,
              reckoner,
              unowned,
              undefined,
              owner,
            );
        this.readings.set(topic, {
          point,
          status,
          epoch,
          viewUt,
          unowned,
          declineKey,
          reading: reading as TopicReading<unknown>,
        });
        return reading as TopicReading<T>;
      },
    );
  }

  /**
   * The topic's `StreamStatusValue` at a frame token's frozen `viewUt`,
   * the staleness/absence surface, read alongside
   * `sample()` never inside it. Mirrors `sample()`'s stale-token fallback
   * and frame-coherent memoization exactly (same generation check, the same
   * per-`(token, key)` cache) so a status read and a value read for the
   * same topic in the same frame always agree about which frame they
   * describe. Field subtopics (`"<topic>.<field>"`) share their parent
   * derived channel's status outright: a field is just one slice of the
   * one memoized record, staleness applies to the whole record.
   */
  sampleStatus(
    topic: string,
    token: FrameToken = this.currentToken,
  ): StreamStatusValue {
    const effectiveToken =
      token.generation === this.generation ? token : this.currentToken;

    const resolved = this.resolveDerivedTopic(topic);
    if (resolved) {
      const parentTopic = resolved.def.topic;
      // Fold epoch into the key exactly like the derived-VALUE path in
      // sample(). A derived status must NOT survive a mid-frame epoch bump
      // (quickload rewind) for the rest of the frame, or a status read and a
      // value read for the same topic in the same frame could disagree about
      // which epoch they describe.
      const epoch = this.clock.getEpoch();
      return this.memoize(
        effectiveToken,
        `\0status\0${parentTopic}\0epoch\0${epoch}`,
        () => this.sampleDerivedStatus(resolved.def, effectiveToken),
      );
    }

    /*
     * A raw field subtopic with no literal point of its own takes its parent's
     * status outright, by recursing on the parent, which lands in the ordinary
     * raw branch and memoizes there. A topic that genuinely IS its own literal
     * raw topic, even a 3+-segment one fed directly, keeps its own status.
     *
     * Asked BEFORE the literal read, because that read goes through
     * `sample()`, which already walks the field out of the parent: it finds a
     * point, and the heartbeat tracker is then asked about a topic string no
     * frame ever carried and answers "not overdue", so the field would read
     * `live` off a parent that has gone stale.
     */
    const rawFieldParent = this.resolveRawFieldSubtopic(topic);
    if (rawFieldParent && !this.hasLiteralPoint(topic, effectiveToken)) {
      return this.sampleStatus(rawFieldParent.rawTopic, effectiveToken);
    }

    // Fold epoch into the raw-status key too. A status memoized before a
    // mid-frame epoch bump must not survive it, or it would disagree with the
    // (epoch-folded) value read for the same topic and could report the dead
    // timeline's status for the rest of the frame.
    const epoch = this.clock.getEpoch();
    return this.memoize(
      effectiveToken,
      `\0status\0${topic}\0epoch\0${epoch}`,
      () => this.sampleRawStatus(topic, effectiveToken),
    );
  }

  /** Whether `topic` has a point recorded under its own literal string, in this epoch, by the frame's view time. */
  private hasLiteralPoint(topic: string, token: FrameToken): boolean {
    const timeline = this.timelines.get(topic);
    if (!timeline || timeline.epoch < this.clock.getEpoch()) return false;
    return (
      timeline.at(this.viewUtFor(token, this.laneForTopic(topic))) !== undefined
    );
  }

  /**
   * Precedence, most to least authoritative (folding in
   * the transport-down short-circuit):
   *
   * 1. No point at all in the current epoch -> `"resyncing"`. Unaffected by
   *    transport status: a topic we've never heard from is "cold", not
   *    "disconnected"; there's no confirmed subject to report link-down
   *    against yet (mirrors `HeartbeatTracker.isOverdue`'s own "no arrival
   *    is not overdue" precedent).
   * 2. A tombstone (`payload: null`) -> `"absent"`, unconditionally, a
   *    confirmed subject-absence is a fact about the SUBJECT, never masked
   *    by transport-down (a fact about the LINK). The two axes are
   *    orthogonal: the client already confirmedly knows there
   *    is no value, and that doesn't stop being true just because the
   *    transport dropped a moment later.
   * 3. Server-stamped `meta.staleness` wins outright when present (a
   *    catch-up/late-joiner mark is authoritative, no client inference
   *    needed for it, and it out-ranks a live transport-down reading too:
   *    it's a stronger, already-settled claim about this specific point).
   * 4. Transport-down short-circuit: when
   *    `setTransportConnected(false)` is in effect, every topic with
   *    confirmed, non-tombstoned, non-server-stamped data reads
   *    `"disconnected"` immediately: not each independently waiting out its
   *    own heartbeat margin to notice the same one dead pipe.
   * 5. Otherwise the `HeartbeatTracker` (missed-keyframe inference, never
   *    `validAt` age) decides live vs. held-stale.
   *
   * `isOverdue` is keyed off `clock.certaintyHorizonUt()`, NOT
   * `token.viewUt`. The overdue
   * check is about a genuine gap in CONFIRMED arrivals, not about how far
   * the predicted-mode viewUt has raced ahead of the horizon on wall time
   * alone: in predicted mode `viewUt` is `utNowEstimate()`, which can run
   * arbitrarily far ahead of anything actually confirmed, and would falsely
   * flag a perfectly healthy topic as overdue purely because the display is
   * looking further into the future. The horizon only advances when
   * something real confirms elapsed UT (a delivered sample, on any topic),
   * which is exactly what "overdue" should track.
   */
  private sampleRawStatus(topic: string, token: FrameToken): StreamStatusValue {
    const point = this.sample(topic, token);
    if (!point) return "resyncing";
    if (point.payload === null) return "absent";
    if (point.meta.staleness === Staleness.LastBeforeBlackout) {
      return "last-before-blackout";
    }
    if (point.meta.staleness === Staleness.Recorded) return "recorded";
    if (point.meta.staleness === Staleness.HeldStale) return "held-stale";
    if (!this.transportConnected) return "disconnected";
    return this.heartbeats.isOverdue(
      topic,
      this.clock.certaintyHorizonUt(),
      this.clock.confidence(),
      this.keyframeFloorGapUt(token),
    )
      ? "held-stale"
      : "live";
  }

  /**
   * The least UT the mod leaves between two keyframes right now: its
   * real-time keyframe floor times the warp rate, both off the latest
   * `time.warp` sample so the two are from the same instant. Zero without
   * one, which widens nothing and is right at 1x.
   */
  private keyframeFloorGapUt(token: FrameToken): number {
    const warp = this.sample<{
      warpRate?: Quantityish;
      keyframeFloorSec?: Quantityish;
    }>("time.warp", token)?.payload;
    if (!warp) return 0;
    const gap =
      magnitudeOr(warp.warpRate, 0) * magnitudeOr(warp.keyframeFloorSec, 0);
    return Number.isFinite(gap) && gap > 0 ? gap : 0;
  }

  /** A derived channel's own status: the worst of every declared input's. */
  private sampleDerivedStatus(
    def: DerivedChannelDefinition<unknown>,
    token: FrameToken,
  ): StreamStatusValue {
    const getStatus = (inputTopic: string) =>
      this.sampleStatus(inputTopic, token);
    return worstStatus(def.inputs.map(getStatus));
  }

  /**
   * `topic` is either a registered derived channel's own topic, or (when
   * that channel opted into `fields: true`) a `"<topic>.<field>"` subtopic
   * of one. Anything else (including a raw topic that happens to contain a
   * dot, e.g. `"vessel.orbit"` itself) resolves to `undefined` here and
   * falls through to the raw-timeline path in `sample()`.
   */
  private resolveDerivedTopic(
    topic: string,
  ): { def: DerivedChannelDefinition<unknown>; field?: string } | undefined {
    const exact = this.derivedChannels.get(topic);
    if (exact) return { def: exact };

    const dot = topic.lastIndexOf(".");
    if (dot === -1) return undefined;
    const parentTopic = topic.slice(0, dot);
    const field = topic.slice(dot + 1);
    const parent = this.derivedChannels.get(parentTopic);
    if (!parent?.fields) return undefined;
    return { def: parent, field };
  }

  /**
   * Splits a dotted topic into the REAL raw wire topic and the remaining
   * segments as a nested field path into that record's payload (see this
   * file's own doc comment on the `sample()` branch that calls this, and
   * `timeline-store-raw-fields.test.ts`). A 3-segment key
   * (`"vessel.orbit.sma"`) yields a 1-element field path;
   * `"vessel.thermal.hottestPart.skinTemp"` yields a 2-element path, walked in
   * one nested lookup rather than a second round of topic resolution.
   *
   * The split lands at the LONGEST KNOWN topic id the key starts with
   * (`splitRawFieldSubtopic`), so a genuinely-3-segment topic is its own wire
   * topic and can carry a field path of its own:
   * `"alarm.scet.fired.firedAtUt"` is `alarm.scet.fired` plus `firedAtUt`,
   * where splitting after the second segment made it a `fired.firedAtUt` path
   * into `alarm.scet`, which is an ARRAY and has no such field. `undefined`
   * when the key IS a whole topic: fewer than 3 segments (`"vessel.orbit"`
   * itself is the raw topic), or a known topic id at full length; both are
   * left to the ordinary raw-literal path in `sample()`.
   *
   * The dynamic-namespace prefixes are checked FIRST and are not subsumed by
   * that lookup: a per-(body,type) or per-CPU topic is computed at runtime and
   * so has no member in any generated list to match against.
   *
   * Never consulted for a topic `resolveDerivedTopic` already matched
   * (checked first at every call site): a registered derived channel's own
   * `fields: true` subtopics keep using that mechanism unchanged.
   */
  private resolveRawFieldSubtopic(
    topic: string,
  ): { rawTopic: string; fieldPath: string[] } | undefined {
    /* A topic under an injected `dynamicWholeTopicPrefixes` entry IS its own
       raw wire topic, not a `<topic>.<fieldPath>` split: resolving it as a
       field subtopic would subscribe/sample a parent no channel publishes. */
    if (
      this.options.dynamicWholeTopicPrefixes?.some((p) => topic.startsWith(p))
    ) {
      return undefined;
    }
    return splitRawFieldSubtopic(topic);
  }

  /**
   * Reads `parsed.rawTopic` (a real raw topic, recurses through the ordinary
   * `sample()` path, including its own derived-channel/epoch/frame-coherence
   * handling) and walks `parsed.fieldPath` into its payload.
   *
   * Mirrors `sampleDerived`'s two "nothing" cases (never conflated):
   * no point on the parent at all yet -> `undefined` ("not whole
   * yet": the raw topic's own not-arrived-yet case, propagated as-is,
   * intentionally NOT re-classified). A tombstoned parent (`payload: null`)
   * -> a real point with `payload: null` (a confirmed absence, the whole
   * record is gone, so every field of it is too). A field name not present
   * on an otherwise-whole, non-null record -> `undefined` (the phantom-
   * mapping case `TimelineStore.isUnresolvableField`'s doc describes for the
   * derived-channel analog; not extended to this raw path, every raw-field
   * key that vocabulary shipped was checked against the real wire fixture
   * before it was retired, so there is no known-dead mapping this needs to
   * catch yet).
   *
   * Reuses the parent point's own `meta`/`validAt`/`epoch` verbatim, unlike
   * a DERIVED channel (which fabricates its own `derivedMeta`), a raw field
   * subtopic isn't a new computation, it's the same measured/received record
   * narrowed to one field, so its staleness/quality/provenance genuinely ARE
   * the whole record's.
   */
  private sampleRawFieldSubtopic<T>(
    parsed: { rawTopic: string; fieldPath: string[] },
    token: FrameToken,
    laneOverride: DelayLane | undefined,
  ): TimelinePoint<T> | undefined {
    const parentPoint = this.sampleInLane<Record<string, unknown>>(
      parsed.rawTopic,
      token,
      laneOverride,
    );
    if (!parentPoint) return undefined; // not whole yet
    if (parentPoint.payload === null) {
      return {
        validAt: parentPoint.validAt,
        payload: null as T,
        meta: parentPoint.meta,
        epoch: parentPoint.epoch,
      };
    }

    let cursor: unknown = parentPoint.payload;
    for (const segment of parsed.fieldPath) {
      if (
        cursor === null ||
        typeof cursor !== "object" ||
        !(segment in (cursor as object))
      ) {
        return undefined; // unknown field: nothing to serve
      }
      cursor = (cursor as Record<string, unknown>)[segment];
    }

    return {
      validAt: parentPoint.validAt,
      payload: cursor as T,
      meta: parentPoint.meta,
      epoch: parentPoint.epoch,
    };
  }

  /**
   * Compute (or reuse the frame-memoized) value for a derived channel, the
   * SAME `memoize` seam raw `sample()` reads use, keyed by the channel's own
   * topic so N field-subtopic reads (`system.state.bodyCount`, ...) in one
   * frame still call `derive` exactly
   * once (memoized to once per `(topic, frame)`). `get`
   * (passed to `derive`) is `sample` bound to this SAME `token`, the
   * structural single-view-time invariant: there is no other way for
   * a `derive` implementation to read a UT. `epoch` is threaded in from the
   * caller (rather than re-read via `this.clock.getEpoch()`) so the value
   * used to build the memo key and the value stamped on the resulting point
   * are guaranteed to agree, even though `derive` itself may cause further
   * ingests via side effects it has no business having.
   */
  private sampleDerived<T>(
    resolved: { def: DerivedChannelDefinition<unknown>; field?: string },
    token: FrameToken,
    epoch: number,
  ): TimelinePoint<T> | undefined {
    const { def, field } = resolved;

    // Keyed distinctly from `def.topic` itself (a `\0`-prefixed key can
    // never collide with a real topic string), the OUTER `memoize` call in
    // `sample()` also uses `def.topic` as its key when the parent topic
    // (not a field subtopic) is what's requested, so sharing the same key
    // here would let that outer wrapped `TimelinePoint` clobber this raw
    // derive() value in the shared per-token cache. Also folds in `epoch`
    // (see `sample()`'s matching comment): this is the memo that actually
    // calls `derive`, so it's the one that must recompute on a mid-frame
    // epoch bump; the outer memoize in `sample()` only needs a matching key
    // so it doesn't short-circuit before ever reaching this one.
    // The channel's own lane: TRUE-NOW only when every declared input is, and
    // DELAYED the moment one is not. Both halves matter. A derived record must
    // not be stamped more current than the most delayed thing it read, and its
    // inputs are pinned to the same lane so one value is never assembled from
    // two instants a light-time apart. A channel reading a delayed vessel
    // channel and the true-now `system.bodies` stays delayed, and reads the body
    // catalogue at the delayed instant.
    const lane = derivedLane(def, this.declaredLane);

    const { value, observedAt } = this.memoize(
      token,
      `\0derived\0${def.topic}\0epoch\0${epoch}`,
      () => {
        // The oldest input this record actually CONSUMED, which is how current
        // it really is. Stamping `token.viewUt` instead would make every derived
        // read report an age of zero, so a record twenty minutes into a blackout
        // would look exactly as fresh as one reporting now. Tracked here rather
        // than declared per channel because `get` is the only way in and the
        // store owns it: a channel cannot forget to say what it read, and a
        // channel that consults a subset of its declared `inputs` comes out
        // right without special-casing.
        let oldest = Number.POSITIVE_INFINITY;
        const note = <V>(
          point: TimelinePoint<V> | undefined,
        ): TimelinePoint<V> | undefined => {
          if (point) oldest = Math.min(oldest, point.validAt);
          return point;
        };
        const viewUt = this.viewUtFor(token, lane);
        const get: DerivedGet = (inputTopic) =>
          note(this.sampleInLane(inputTopic, token, lane));
        const derived = def.derive(get, viewUt);
        const carry = this.carryFor(def);
        carry.value = shareEqual(carry.value, derived);
        return {
          value: carry.value,
          // Nothing read (a channel deriving from constants) is as current as
          // the frame; nothing can be older than the moment being asked about.
          observedAt: Number.isFinite(oldest)
            ? Math.min(oldest, viewUt)
            : viewUt,
        };
      },
    );

    if (value === undefined) {
      // Not whole yet: an input has no point at-or-before `viewUt` in the
      // current epoch (cold start, or resynchronizing after an epoch reset).
      // There is no point to serve at all here, NOT a
      // tombstone: propagates through field subtopics too, since there's
      // nothing to extract a field from yet.
      return undefined;
    }

    if (value === null) {
      // Confirmed absence, a required input tombstoned or the channel itself returning null: a real point carrying `payload: null`, per the tombstone model.
      return this.carryPoint(def, field, null as T, observedAt, epoch);
    }

    if (field && !(field in (value as object))) return undefined; // unknown field name, nothing to serve

    const payload = field
      ? (Reflect.get(value as object, field) as T)
      : (value as T);

    return this.carryPoint(def, field, payload, observedAt, epoch);
  }

  private carryFor(def: DerivedChannelDefinition<unknown>): {
    value: unknown;
    points: Map<string, TimelinePoint<unknown>>;
  } {
    let carry = this.derivedCarry.get(def);
    if (!carry) {
      carry = { value: undefined, points: new Map() };
      this.derivedCarry.set(def, carry);
    }
    return carry;
  }

  /** The point last served for this field when it describes the same thing, else a new one. */
  private carryPoint<T>(
    def: DerivedChannelDefinition<unknown>,
    field: string | undefined,
    payload: T,
    observedAt: number,
    epoch: number,
  ): TimelinePoint<T> {
    const points = this.carryFor(def).points;
    const key = field ?? "";
    const previous = points.get(key) as TimelinePoint<T> | undefined;
    if (
      previous !== undefined &&
      previous.payload === payload &&
      previous.validAt === observedAt &&
      previous.epoch === epoch
    ) {
      return previous;
    }
    const point: TimelinePoint<T> = {
      validAt: observedAt,
      payload,
      meta: derivedMeta(observedAt, epoch),
      epoch,
    };
    points.set(key, point as TimelinePoint<unknown>);
    return point;
  }

  /**
   * Frame-coherent memoized read: the first `compute()` for a given
   * `(token, key)` pair wins for that token's lifetime; subsequent calls
   * return the cached result even if the underlying data changes in
   * between. Private for now, exposed indirectly via `sample()`, but
   * deliberately generic so derived channels can reuse the same
   * per-frame cache instead of building their own.
   */
  private memoize<T>(token: FrameToken, key: string, compute: () => T): T {
    let cache = this.frameCache.get(token);
    if (!cache) {
      cache = new Map();
      this.frameCache.set(token, cache);
    }
    if (cache.has(key)) {
      return cache.get(key) as T;
    }
    const value = compute();
    cache.set(key, value);
    return value;
  }

  /**
   * Record that nothing will ever publish `topic`, so its reading is `unowned`
   * rather than a `pending` that will never resolve.
   *
   * Notifies frame listeners directly rather than waiting for the next
   * `beginFrame()`: the verdict arrives on a timer, not on a sample, and a
   * dashboard with no live data has no reason to be minting frames. Without
   * this the widget that most needs telling would be the last to hear.
   */
  markTopicUnowned(topic: string): void {
    if (this.unownedTopics.has(topic)) return;
    this.unownedTopics.add(topic);
    // The reading's other inputs are unchanged, so the identity cache would
    // hand back the `pending` arm it built before the verdict.
    this.readings.delete(topic);
    for (const listener of this.frameListeners) listener();
  }

  /**
   * Forget every ownership verdict. The link dropped, so nothing is decided any
   * more: the next connection is a new mod session and has to answer again.
   */
  clearTopicOwnership(): void {
    if (this.unownedTopics.size === 0) return;
    for (const topic of this.unownedTopics) this.readings.delete(topic);
    this.unownedTopics.clear();
    for (const listener of this.frameListeners) listener();
  }

  /** Whether the mod answered a subscribe for `topic` with nothing. */
  isTopicUnowned(topic: string): boolean {
    return this.unownedTopics.has(topic);
  }

  /** Notified once per `beginFrame()` call: backs the reactive tier's `useSyncExternalStore` subscription. */
  subscribeFrame(cb: () => void): () => void {
    this.frameListeners.add(cb);
    return () => this.frameListeners.delete(cb);
  }

  private timelineFor<T>(topic: string): ClientTimeline<T> {
    let timeline = this.timelines.get(topic);
    if (!timeline) {
      timeline = new ClientTimeline<T>(this.options.timelineOptions);
      this.timelines.set(topic, timeline as ClientTimeline<unknown>);
    }
    return timeline as ClientTimeline<T>;
  }
}
