# @ksp-gonogo/uplink-tools

The Uplink docs toolchain: it renders an Uplink's scenes in a real browser,
generates its page, and supplies the app's own widgets as the host widgets an
augment is drawn inside.

It is a **devDependency**. Nothing here ships in an Uplink's bundle.

## What is in it

| entry | what it is |
|---|---|
| `@ksp-gonogo/uplink-tools` | the harness API and the `gonogo-uplink render` / `docs` implementation. Node: esbuild, Playwright, the filesystem |
| `@ksp-gonogo/uplink-tools/render-probe` | the browser half, which mounts a widget in the page the harness builds |
| `@ksp-gonogo/uplink-tools/page-check` | the assertion an Uplink's own suite runs to keep its committed page honest. Deliberately free of Playwright, so an author with no browser can still run it |
| `@ksp-gonogo/uplink-tools/widgets` | the app's own widgets, registered, so a scene can name one as its `_scene.hostWidget` |

You will not usually import the first of these: `gonogo-uplink render` and
`gonogo-uplink docs` forward to it, resolved from your own install.

`gonogo-uplink docs` writes `README.md`, `gonogo-uplink.json` and
`docs/widgets.json`, the record of each widget you register. The README's widget
sections are rendered from those records, and `docs --check` and
`expectUplinkPageCurrent` fail when any of the three no longer matches your
registrations. Commit all three.

## What a fixture puts on the stream

A fixture's `_stream` block is the wire its scene is fed from:

```json
{
  "_scene": { "widget": "reactor" },
  "_stream": {
    "pinnedUt": 1000,
    "delaySeconds": 60,
    "emits": [
      { "topic": "example.reactor", "payload": {}, "validAt": 940 },
      { "topic": "example.reactor", "payload": {} }
    ]
  }
}
```

| field | what it does |
|---|---|
| `emits` | replayed once the scene has subscribed, in the order written, or in the order sent under `delaySeconds`. An entry's `validAt` is the instant it was sent; with none it was sent at `pinnedUt` |
| `pinnedUt` | the operator's view time, which the scene is drawn at when it has no `delaySeconds`. Defaults to `1000000` |
| `stopsArriving` | drop the link once every emit has landed, so the picture is of figures that are held |
| `delaySeconds` | a one-way light time between the craft and the screen, in seconds |

**`delaySeconds`** stages what an operator sees across a light time. Each
reading sent at `validAt` is delivered `delaySeconds` later, the view time is
the newest `validAt` delivered (an emit naming none counts as `pinnedUt`), and
the craft's present runs one light time ahead of it.
Every reading is reckoned to that present exactly as it is in the app, so a
scene can show a modelled figure beside the observed one, drawn with the kit's
modelled mark. Without it, or at `0`, the view time and the craft's present are
one instant and nothing is carried across. A reckoner that fits a trend needs
more than one reading, so give those emits a history of `validAt`s. If your
widget reads the light time off `comms.delay`, emit that too: the delay stages
the clock, not the topic.

Under a delay an `advanceUt` step moves the craft's present and leaves the view
time where it is until something newer is delivered, so a negative `advanceUt`
is refused.

## Using the host widgets

An Uplink's docs page shows its widgets, and some of them are an AUGMENT or a
CONTRIBUTION into a widget that ships with the app. To draw one honestly you
need the widget around it:

```json
{
  "devDependencies": {
    "@ksp-gonogo/uplink-tools": "^0.1.0"
  },
  "gonogo": {
    "renderWith": ["@ksp-gonogo/uplink-tools/widgets"]
  }
}
```

A fixture can then name the widget it extends:

```json
{ "_scene": { "hostWidget": "strategies" } }
```

There is nothing to `import` from `/widgets`. It exports no symbols: importing it
runs the app widgets' own registrations, which is all the harness needs to
resolve a scene's `hostWidget`.

**`/widgets` is for the docs page only.** Name it in `devDependencies` and in
`gonogo.renderWith`, and nowhere else: never put `@ksp-gonogo/uplink-tools` in
`dependencies`, and never import `/widgets` from your client. If you want one
of its components for real use, ask for that component in `@ksp-gonogo/ui-kit`.

## Why a stand-in is not enough

The harness already synthesises a stand-in for a scene that names none, and it
covers more than you would expect: an augment mounts in that stand-in's `Panel`,
and `Panel` draws every widget's `<id>.badges` itself, so a badge contribution
lands there exactly as it lands in the real widget.

Every **other** contribution slot is drawn by the host widget's own body, and a
stand-in's body draws nothing. `strategies.screens`,
`space-center-status.facilities` and `astronaut-complex.readouts` are each read
by a `useContributions(...)` inside the widget. Standing in for those produces a
blank frame that reports success. A real widget's own body is the only thing that draws
them.

## Its relation to `@ksp-gonogo/ui-kit`

`@ksp-gonogo/ui-kit` is a peer dependency: install the two at matching
versions. The harness draws with the kit and its `/grid` and `/testing`
entries, and the app widgets behind `/widgets` are built on it.
